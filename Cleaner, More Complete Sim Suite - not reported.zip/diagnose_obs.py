# -*- coding: utf-8 -*-
"""
CRITICAL: Observation Energy Going Wrong Direction
==================================================

Your observation energy is INCREASING, not DECREASING!
This means beliefs are moving AWAY from observations.

Step 90: obs=4014.009
Step 91: obs=4014.047  ⬆ WRONG!
Step 92: obs=4014.085  ⬆ WRONG!
Step 93: obs=4014.123  ⬆ WRONG!

Should be:
Step 90: obs=4014.009
Step 91: obs=3950.xxx  ⬇ RIGHT!
Step 92: obs=3890.xxx  ⬇ RIGHT!

Possible causes:
1. Observation gradients have WRONG SIGN
2. Learning rate is NEGATIVE (unlikely)
3. Observations are regenerating each step (Lambda_obs bug!)
4. Gradient computation has a sign error

Author: Chris & Claude
"""

import numpy as np


def diagnose_gradient_direction(system):
    """
    Check if observation gradients point in the right direction.
    
    The gradient should point TOWARD observations, not away.
    """
    from gradients.gradient_engine import compute_observation_gradients
    from free_energy_clean import compute_observation_energy
    
    print("\n" + "="*70)
    print("GRADIENT DIRECTION TEST")
    print("="*70)
    
    for i, agent in enumerate(system.agents[:2]):  # Test first 2 agents
        if not hasattr(agent, 'observations') or not agent.observations:
            continue
        
        print(f"\nAgent {i}:")
        
        # Current energy
        E_before = compute_observation_energy(system, agent, lambda_obs=1.0)
        print(f"  E_obs (before): {E_before:.6f}")
        
        # Compute gradient
        grads = compute_observation_gradients(system, agent)
        grad_mu = grads.grad_mu_q
        
        # Test: move in gradient direction (should INCREASE energy - wrong!)
        # Test: move OPPOSITE gradient (should DECREASE energy - right!)
        
        mu_orig = agent.mu_q.copy()
        lr = 0.01
        
        # Move in gradient direction
        agent.mu_q = mu_orig + lr * grad_mu
        E_with_grad = compute_observation_energy(system, agent, lambda_obs=1.0)
        
        # Move opposite gradient
        agent.mu_q = mu_orig - lr * grad_mu  
        E_against_grad = compute_observation_energy(system, agent, lambda_obs=1.0)
        
        # Restore
        agent.mu_q = mu_orig
        
        print(f"  E_obs (with +grad):    {E_with_grad:.6f}  (ΔE = {E_with_grad - E_before:+.6f})")
        print(f"  E_obs (with -grad):    {E_against_grad:.6f}  (ΔE = {E_against_grad - E_before:+.6f})")
        
        # Diagnosis
        if E_with_grad < E_before:
            print("  ✓ Moving with gradient DECREASES energy (correct)")
        else:
            print("  ❌ Moving with gradient INCREASES energy (WRONG!)")
            print("     → Gradient has WRONG SIGN!")
        
        if E_against_grad > E_before:
            print("  ✓ Moving against gradient INCREASES energy (correct)")
        else:
            print("  ❌ Moving against gradient DECREASES energy (suspicious)")


def check_observation_sign_convention():
    """
    Verify the sign convention in observation energy.
    
    Free energy: F = E[log q(x)] - E[log p(x,o)]
                   = KL(q||p) - E[log p(o|x)]
    
    We want to MINIMIZE F, which means MAXIMIZE E[log p(o|x)].
    
    So observation energy should be: -λ * E[log p(o|x)]
    (Negative sign converts maximization to minimization)
    
    When E[log p(o|x)] is high (good fit), energy is low (negative).
    When E[log p(o|x)] is low (bad fit), energy is high (positive).
    """
    print("\n" + "="*70)
    print("OBSERVATION ENERGY SIGN CONVENTION CHECK")
    print("="*70)
    
    print("\nCorrect convention:")
    print("  E_obs = -λ * ∫ E_q[log p(o|x)] dx")
    print("  ")
    print("  When beliefs FIT observations well:")
    print("    log p(o|x) ≈ 0 (high likelihood)")
    print("    E_obs ≈ 0 (low energy)")
    print("  ")
    print("  When beliefs DON'T FIT observations:")
    print("    log p(o|x) << 0 (low likelihood)")
    print("    E_obs >> 0 (high energy)")
    print("  ")
    print("  Gradient: ∇_μ E_obs should point TOWARD observations")
    
    print("\nCheck your compute_observation_energy():")
    print("  Should have: energy = -lambda_obs * spatial_integrate(log_lik, chi)")
    print("  Should NOT: energy = +lambda_obs * spatial_integrate(log_lik, chi)")


def check_if_observations_changing():
    """
    Check if observations are being regenerated each step.
    
    If Lambda_obs bug isn't fixed, ensure_observation_model() might
    be re-initializing observations every time!
    """
    print("\n" + "="*70)
    print("CHECK: Are observations changing between steps?")
    print("="*70)
    
    print("\nSave observations before training:")
    print("  obs_snapshot = {i: list(a.observations.values())[0].copy() ")
    print("                  for i, a in enumerate(system.agents)}")
    print("\nAfter 10 steps, check:")
    print("  for i, agent in enumerate(system.agents):")
    print("      obs_now = list(agent.observations.values())[0]")
    print("      obs_before = obs_snapshot[i]")
    print("      diff = np.linalg.norm(obs_now - obs_before)")
    print("      print(f'Agent {i}: obs changed by {diff:.6f}')")
    print("\nIf diff > 1e-10: Observations are being regenerated! (BAD!)")


def diagnose_why_energy_increasing():
    """
    Comprehensive diagnostic for increasing observation energy.
    """
    print("\n" + "="*70)
    print("WHY IS OBSERVATION ENERGY INCREASING?")
    print("="*70)
    
    print("\nPossible causes (in order of likelihood):")
    print("\n1. Observations regenerating each step (Lambda_obs bug)")
    print("   → Fix: ensure_observation_model() check")
    print("   → Check: hasattr(system, 'Lambda_obs') should be False")
    print("   → Check: observations not changing between steps")
    
    print("\n2. Observation gradients have WRONG SIGN")
    print("   → Check: compute_observation_gradients()")
    print("   → Test: Move with gradient, energy should decrease")
    
    print("\n3. Observations are identical (no diversity)")
    print("   → Check: pairwise ||obs_i - obs_j|| should be > 0.1")
    print("   → Fix: Increase obs_bias_scale")
    
    print("\n4. Beliefs moving away due to coupling dominance")
    print("   → Check: λ_obs >> λ_belief_align + λ_prior_align")
    print("   → Current: λ_obs=1, coupling=2 (WRONG!)")
    print("   → Fix: λ_obs=20, coupling=0.1")
    
    print("\n5. Learning rate wrong sign (very unlikely)")
    print("   → Check: lr_mu_q > 0")


def emergency_fixes():
    """Quick fixes to try immediately."""
    print("\n" + "="*70)
    print("EMERGENCY FIXES")
    print("="*70)
    
    print("\n1. FIX Lambda_obs BUG (HIGHEST PRIORITY):")
    print("   In system.py:")
    print("   - __init__: self.Lambda_obs = None → self.R_obs = None")
    print("   - ensure_observation_model: check R_obs not Lambda_obs")
    
    print("\n2. VERIFY observations aren't changing:")
    print("   # Before training")
    print("   obs_before = [list(a.observations.values())[0].copy() for a in system.agents]")
    print("   # After 1 step")
    print("   trainer.step()")
    print("   obs_after = [list(a.observations.values())[0] for a in system.agents]")
    print("   # Check")
    print("   for i in range(len(obs_before)):")
    print("       print(f'Agent {i}: {np.allclose(obs_before[i], obs_after[i])}')")
    print("   # Should all be True!")
    
    print("\n3. TEST gradient direction:")
    print("   diagnose_gradient_direction(system)")
    
    print("\n4. If nothing works, PRINT actual observation values:")
    print("   for i, a in enumerate(system.agents):")
    print("       obs = list(a.observations.values())[0]")
    print("       print(f'Agent {i} obs: {obs}')")


# =============================================================================
# Main diagnostic
# =============================================================================

def run_full_diagnostic(system):
    """Run all diagnostics."""
    check_observation_sign_convention()
    check_if_observations_changing()
    diagnose_gradient_direction(system)
    diagnose_why_energy_increasing()
    emergency_fixes()


if __name__ == "__main__":
    print(__doc__)