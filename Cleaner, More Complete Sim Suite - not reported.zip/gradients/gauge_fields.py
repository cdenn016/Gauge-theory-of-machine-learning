"""
Gauge Fields on SO(3) Principal Bundle
======================================

Representation and geometry of gauge fields φ(c) for active inference agents.

Mathematical Framework:
----------------------
Each agent carries a gauge field φ: C → so(3) over its support region.

**Axis-Angle Representation:**
    φ(c) ∈ ℝ³ where ||φ|| encodes rotation angle, φ/||φ|| encodes axis
    
**Lie Group Element:**
    g(c) = exp(φ(c)) ∈ SO(3)
    
**Transport Operator:**
    Ω_ij(c) = g_i(c) · g_j(c)^{-1} = exp(φ_i(c)) · exp(-φ_j(c))

**Principal Ball:**
    Valid φ must satisfy ||φ(c)|| < π - margin to avoid branch cuts

**Natural Gradient:**
    Updates on φ must respect SO(3) geometry via right-Jacobian J(φ)

Author: Clean Rebuild
Date: November 2025
"""

import numpy as np
from typing import Optional, Tuple, Literal
from math_utils.numerical_utils import safe_inv, sanitize_sigma
from config import SystemConfig
from math_utils.transport import _rodrigues_formula, _skew_symmetric
# =============================================================================
# Gauge Field Container
# =============================================================================

class GaugeField:
    """
    Container for agent's gauge field φ(c) over spatial support.
    
    Attributes:
        phi: Axis-angle field, shape (*S, 3)
        support_shape: Spatial dimensions tuple
        K: Latent dimension
    
    Examples:
        >>> # 1D chain
        >>> field_1d = GaugeField.zeros(shape=(100,), K=3)
        >>> field_1d.phi.shape
        (100, 3)
        
        >>> # 2D grid
        >>> field_2d = GaugeField.zeros(shape=(32, 32), K=5)
        >>> field_2d.phi.shape
        (32, 32, 3)
    """
    
    def __init__(
        self,
        phi: np.ndarray,
        K: int,
        *,
        validate: bool = True,
        margin: float = 1e-2,
    ):
        """
        Initialize gauge field from axis-angle array.
        
        Args:
            phi: Axis-angle field, shape (*S, 3)
            K: Latent dimension
            validate: If True, check principal ball constraint
            margin: Safety margin from branch cut (π - margin)
        """
        self.phi = np.asarray(phi, dtype=np.float32, order='C')
        self.K = int(K)
        
        if self.phi.shape[-1] != 3:
            raise ValueError(f"Last dimension must be 3 (so(3)), got {self.phi.shape[-1]}")
        
        self.support_shape = self.phi.shape[:-1]
        
        if validate:
            self._check_principal_ball(margin)
    
    def _check_principal_ball(self, margin: float) -> None:
        """Verify ||φ|| < π - margin everywhere."""
        norms = np.linalg.norm(self.phi, axis=-1)
        max_norm = float(np.max(norms))
        threshold = np.pi - margin
        
        if max_norm >= threshold:
            raise ValueError(
                f"Gauge field violates principal ball constraint:\n"
                f"  max ||φ|| = {max_norm:.4f}\n"
                f"  threshold = {threshold:.4f}"
            )
    
    def exponentiate(self, eps: float = 1e-8) -> np.ndarray:
        """
        Compute g(c) = exp(φ(c)) ∈ SO(3).
        
        Returns:
            g: Rotation matrices, shape (*S, 3, 3) for K=3
        """
        if self.K == 3:
            return _rodrigues_formula(self.phi, eps=eps)
        else:
            raise NotImplementedError(f"K={self.K} not yet supported")
    
    @classmethod
    def zeros(cls, shape: Tuple[int, ...], K: int) -> 'GaugeField':
        """Create identity gauge field (φ = 0 everywhere)."""
        phi = np.zeros(shape + (3,), dtype=np.float32)
        return cls(phi, K, validate=False)
    
    @classmethod
    def random(
        cls,
        shape: Tuple[int, ...],
        K: int,
        *,
        scale: float = 0.5,
        seed: Optional[int] = None,
    ) -> 'GaugeField':
        """
        Create random gauge field with controlled magnitude.
        
        Args:
            shape: Spatial shape
            K: Latent dimension
            scale: Maximum rotation angle
            seed: Random seed
        """
        if seed is not None:
            np.random.seed(seed)
        
        phi = np.random.randn(*shape, 3).astype(np.float32)
        norms = np.linalg.norm(phi, axis=-1, keepdims=True)
        phi = phi / np.maximum(norms, 1e-8) * (scale * np.random.rand(*shape, 1))
        
        return cls(phi, K, validate=True, margin=0.1)
    
    def copy(self) -> 'GaugeField':
        """Create a copy of this gauge field."""
        return GaugeField(self.phi.copy(), self.K, validate=False)
    
    def __repr__(self) -> str:
        return (
            f"GaugeField(shape={self.support_shape}, K={self.K}, "
            f"||φ||_max={np.max(np.linalg.norm(self.phi, axis=-1)):.4f})"
        )




# =============================================================================
# Principal Ball Retraction
# =============================================================================

def retract_to_principal_ball(
    phi: np.ndarray,
    *,
    margin: float = 1e-2,
    mode: Literal['mod2pi', 'project'] = 'mod2pi',
) -> np.ndarray:
    """
    Retract gauge field to principal ball ||φ|| < π - margin.
    
    Two modes:
        - 'mod2pi': Wrap to [0, 2π) with antipodal flip
        - 'project': Radial projection (simpler but discontinuous)
    
    Args:
        phi: Axis-angle field, shape (*S, 3)
        margin: Safety margin from branch cut
        mode: Retraction method
    
    Returns:
        phi_retracted: Shape (*S, 3), satisfies ||φ|| < π - margin
    
    Examples:
        >>> phi = np.array([[3.5, 0.0, 0.0]])  # θ ≈ 3.5 > π
        >>> phi_ret = retract_to_principal_ball(phi)
        >>> np.linalg.norm(phi_ret) < np.pi
        True
    """
    phi = np.asarray(phi, dtype=np.float64)
    
    if phi.shape[-1] != 3:
        raise ValueError(f"Expected shape (*S, 3), got {phi.shape}")
    
    # Compute norms
    theta = np.linalg.norm(phi, axis=-1, keepdims=True)  # (*S, 1)
    
    # ✅ FIX: Add epsilon BEFORE division to avoid 0/0
    theta_safe = np.maximum(theta, 1e-12)  # Never actually zero
    
    # Compute normalized axis (safe now)
    axis = phi / theta_safe  # No warning!
    
    # Handle true zero-norm case: set to arbitrary unit vector
    # (These points won't matter since theta=0 means identity anyway)
    is_zero = (theta < 1e-12)[..., 0]
    if np.any(is_zero):
        axis[is_zero] = np.array([1.0, 0.0, 0.0])
    
    # Threshold
    r_max = float(np.pi - margin)
    
    if mode == 'mod2pi':
        # ========== Modulo 2π with antipodal flip ==========
        two_pi = 2.0 * np.pi
        
        # Wrap to [0, 2π)
        theta_wrapped = np.remainder(theta[..., 0], two_pi)
        
        # Flip axis if θ > π (antipodal symmetry)
        flip = theta_wrapped > np.pi
        theta_final = np.where(flip, two_pi - theta_wrapped, theta_wrapped)
        axis_final = np.where(flip[..., None], -axis, axis)
        
        # Clamp to safety margin
        theta_final = np.minimum(theta_final, r_max)
        
        phi_new = axis_final * theta_final[..., None]
    
    elif mode == 'project':
        # ========== Radial projection ==========
        # Only scale down if exceeds limit
        exceeds = theta[..., 0] > r_max
        scale = np.ones_like(theta[..., 0])
        scale[exceeds] = r_max / theta_safe[exceeds, 0]
        
        phi_new = phi * scale[..., None]
    
    else:
        raise ValueError(f"Unknown mode: {mode}")
    
    return phi_new.astype(np.float32, copy=False)

# =============================================================================
# Natural Gradient
# =============================================================================

def natural_gradient_phi(
    phi: np.ndarray,
    grad_phi_euclidean: np.ndarray,
    *,
    eps: float = 1e-8,
    mode: Literal['right', 'left'] = 'right',
) -> np.ndarray:
    """
    Project Euclidean gradient to natural (geometric) gradient on SO(3).
    
    Formula (right-invariant):
        δφ = J(φ)^{-1} · ∇_φ L
        
    where J(φ) is the right Jacobian:
        J(φ) = I - (θ/2)[u]_× + ((1 - h(θ))/θ²)[u]_×²
        h(θ) = (θ/2)cot(θ/2)
    
    Args:
        phi: Current gauge field, shape (*S, 3)
        grad_phi_euclidean: Euclidean gradient ∇_φ L, shape (*S, 3)
        eps: Numerical stability threshold
        mode: 'right' (default) or 'left' invariant metric
    
    Returns:
        delta_phi: Natural gradient, shape (*S, 3)
    
    Examples:
        >>> # Small φ: natural ≈ Euclidean
        >>> phi_small = np.array([[0.1, 0.0, 0.0]])
        >>> grad = np.array([[1.0, 0.0, 0.0]])
        >>> delta = natural_gradient_phi(phi_small, grad)
        >>> np.allclose(delta, grad, rtol=0.1)
        True
        
        >>> # Large φ: natural differs significantly
        >>> phi_large = np.array([[2.5, 0.0, 0.0]])
        >>> delta_large = natural_gradient_phi(phi_large, grad)
        >>> np.linalg.norm(delta_large) < np.linalg.norm(grad)
        True
    """
    phi = np.asarray(phi, dtype=np.float64)
    grad = np.asarray(grad_phi_euclidean, dtype=np.float64)
    
    if phi.shape != grad.shape:
        raise ValueError(f"Shape mismatch: phi {phi.shape}, grad {grad.shape}")
    
    if phi.shape[-1] != 3:
        raise ValueError(f"Expected (*S, 3), got {phi.shape}")
    
    # Compute right Jacobian inverse J^{-1}(φ)
    J_inv = _compute_jacobian_inverse(phi, eps=eps, mode=mode)
    
    # Apply J^{-1} to gradient
    # delta_phi[..., a] = Σ_b J_inv[..., a, b] · grad[..., b]
    delta_phi = np.einsum('...ab,...b->...a', J_inv, grad, optimize=True)
    
    return delta_phi.astype(np.float32, copy=False)


def _compute_jacobian_inverse(
    phi: np.ndarray,
    *,
    eps: float = 1e-8,
    mode: Literal['right', 'left'] = 'right',
) -> np.ndarray:
    """
    Compute J^{-1}(φ) for right or left-invariant metric.
    
    Right Jacobian Inverse:
        J^{-1}(φ) = I + (θ/2)[u]_× + (1 - h(θ))[u]_×²
        
    where h(θ) = (θ/2)cot(θ/2) with Taylor expansion near θ=0.
    
    Args:
        phi: Shape (*S, 3)
        eps: Small angle threshold
        mode: 'right' or 'left'
    
    Returns:
        J_inv: Shape (*S, 3, 3)
    """
    spatial_shape = phi.shape[:-1]
    
    # Compute θ = ||φ||
    theta = np.linalg.norm(phi, axis=-1, keepdims=True)  # (*S, 1)
    
    # Unit axis
    u = np.where(
        theta > eps,
        phi / theta,
        np.array([1.0, 0.0, 0.0])
    )
    
    # Skew-symmetric matrices
    u_cross = _skew_symmetric(u)
    u_cross_sq = u_cross @ u_cross
    
    # Coefficients
    theta_val = theta[..., 0]
    
    # For small θ, use Taylor series
    small = theta_val < eps
    
    c1 = np.zeros_like(theta_val)
    c2 = np.zeros_like(theta_val)
    
    if np.any(small):
        t = theta_val[small]
        t2 = t * t
        c1[small] = 0.5
        c2[small] = 1.0/12.0 + t2/720.0
    
    if np.any(~small):
        t = theta_val[~small]
        t2 = t * t
        
        # h(θ) = (θ/2)cot(θ/2)
        half_t = 0.5 * t
        h = half_t / np.tan(half_t)
        
        c1[~small] = 0.5
        c2[~small] = (1.0 - h) / t2
    
    # J^{-1} = I + c1·[u]_× + c2·[u]_×²
    I = np.eye(3, dtype=phi.dtype)
    
    J_inv = (
        I +
        c1[..., None, None] * u_cross +
        c2[..., None, None] * u_cross_sq
    )
    
    if mode == 'left':
        # Left Jacobian inverse: J_L^{-1}(φ) = J_R^{-1}(-φ)
        J_inv = _compute_jacobian_inverse(-phi, eps=eps, mode='right')
    
    return J_inv


# =============================================================================
# Update with Retraction
# =============================================================================

def update_gauge_field(
    gauge_field: GaugeField,
    delta_phi: np.ndarray,
    learning_rate: float,
    *,
    retraction_mode: Literal['mod2pi', 'project'] = 'mod2pi',
    margin: float = 1e-2,
) -> GaugeField:
    """
    Update gauge field with retraction to principal ball.
    
    Algorithm:
        1. φ_new = φ + τ · δφ (Euclidean step)
        2. φ_new = retract(φ_new) (project to principal ball)
    
    Args:
        gauge_field: Current gauge field
        delta_phi: Natural gradient, shape (*S, 3)
        learning_rate: Step size τ
        retraction_mode: How to enforce principal ball constraint
        margin: Safety margin from branch cut
    
    Returns:
        updated_field: New GaugeField with updated φ
    """
    # Euclidean update
    phi_new = gauge_field.phi + learning_rate * delta_phi
    
    # Retract to principal ball
    phi_retracted = retract_to_principal_ball(
        phi_new,
        margin=margin,
        mode=retraction_mode,
    )
    
    return GaugeField(phi_retracted, gauge_field.K, validate=False)

# -*- coding: utf-8 -*-
"""
ANALYTICAL Gauge Field Gradients via Transport Differential
============================================================

Implements the missing analytical gradients ∂S/∂φ(c) using the chain rule
with transport operator differentials.

Mathematical Framework:
----------------------
For alignment energy term:
    E_ij = ∫ β_ij(c) KL(q_i(c) || Ω_ij[q_j](c)) dc

The gradient w.r.t. φ_i or φ_j requires:
    ∂E_ij/∂φ^a = ∫ β_ij(c) · ∂KL/∂Ω_ij : ∂Ω_ij/∂φ^a dc

where:
    - ∂Ω_ij/∂φ_i^a = (dexp)_a(φ_i) · exp(-φ_j)  [from transport.py]
    - ∂Ω_ij/∂φ_j^b = -exp(φ_i) · (dexp)_b(φ_j) · exp(-φ_j)
    - ∂KL/∂Ω_ij computed via transported distribution gradients

This replaces finite difference approximations with exact analytical formulas.

Author: Clean Implementation
Date: November 2025
"""




# =============================================================================
# KL Gradient w.r.t. Transport Operator
# =============================================================================

def grad_kl_wrt_transport(
    mu_i: np.ndarray,
    Sigma_i: np.ndarray,
    mu_j: np.ndarray,
    Sigma_j: np.ndarray,
    Omega_ij: np.ndarray,
    *,
    eps: float = 1e-8,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute ∂KL(q_i || Ω[q_j])/∂Ω as a pair of gradient tensors.
    
    For KL(N(μ_i, Σ_i) || N(Ω μ_j, Ω Σ_j Ωᵀ)), we need:
        ∂KL/∂Ω = ∂KL/∂(Ω μ_j) ⊗ μ_j + ∂KL/∂(Ω Σ_j Ωᵀ) [complex tensor]
    
    Returns gradients suitable for contraction with ∂Ω/∂φ.
    
    Args:
        mu_i, Sigma_i: Source distribution parameters, shape (..., K), (..., K, K)
        mu_j, Sigma_j: Target distribution parameters (before transport)
        Omega_ij: Transport operator, shape (..., K, K)
        eps: Numerical stability
    
    Returns:
        grad_mu: Gradient tensor for mean transport, shape (..., K)
        grad_Sigma_factor: Gradient factor for covariance, shape (..., K, K)
            Note: Full ∂KL/∂Ω covariance term is complex; we return a useful factor
    
    Implementation:
        Transport: μ'_j = Ω μ_j, Σ'_j = Ω Σ_j Ωᵀ
        
        ∂KL/∂μ'_j = Σ_i⁻¹(μ_i - μ'_j)  [from standard KL gradient]
        
        Chain rule: ∂KL/∂Ω involves ∂μ'_j/∂Ω = μ_j ⊗ I and ∂Σ'_j/∂Ω
        
        We compute the contraction: tr(∂KL/∂Ω · dΩ) for each component
    """
    mu_i = np.asarray(mu_i, dtype=np.float64)
    Sigma_i = np.asarray(Sigma_i, dtype=np.float64)
    mu_j = np.asarray(mu_j, dtype=np.float64)
    Sigma_j = np.asarray(Sigma_j, dtype=np.float64)
    Omega_ij = np.asarray(Omega_ij, dtype=np.float64)
    
    # Ensure numerical stability
    Sigma_i = sanitize_sigma(Sigma_i, eps)
    Sigma_j = sanitize_sigma(Sigma_j, eps)
    
    # Transport distributions
    mu_j_transported = np.einsum('...ij,...j->...i', Omega_ij, mu_j, optimize=True)
    Sigma_j_transported = np.einsum(
        '...ij,...jk,...lk->...il',
        Omega_ij, Sigma_j, Omega_ij,
        optimize=True
    )
    Sigma_j_transported = sanitize_sigma(Sigma_j_transported, eps)
    
    # Compute inverses
    Sigma_i_inv = safe_inv(Sigma_i, eps)
    Sigma_j_t_inv = safe_inv(Sigma_j_transported, eps)
    
    # ========== Mean gradient: ∂KL/∂μ'_j ==========
    delta_mu = mu_i - mu_j_transported  # (..., K)
    grad_wrt_mu_transported = np.einsum(
        '...ij,...j->...i',
        Sigma_j_t_inv, delta_mu,
        optimize=True
    )  # (..., K)
    
    # For chain rule with Ω: ∂μ'_j/∂Ω_{ab} = μ_j[b] δ_{a*}
    # Contraction: ∂KL/∂Ω_{ab} = grad_wrt_mu_transported[a] · μ_j[b]
    # Store: grad_mu_factor for later contraction with dΩ
    grad_mu_factor = np.einsum(
        '...i,...j->...ij',
        grad_wrt_mu_transported, mu_j,
        optimize=True
    )  # (..., K, K)
    
    # ========== Covariance gradient: ∂KL/∂Σ'_j ==========
    # ∂KL/∂Σ'_j = ½(Σ'_j⁻¹ - Σ_i⁻¹) for base KL
    # But we need ∂Σ'_j/∂Ω where Σ'_j = Ω Σ_j Ωᵀ
    
    # Simplified: for small perturbations, dominant term is:
    # ∂KL/∂Ω ≈ grad_wrt_mu_transported ⊗ μ_j (handled above)
    # Plus Σ term (complex 4th-order tensor - approximate with Frobenius-like)
    
    # Compute useful factor for Σ contribution
    grad_Sigma_base = 0.5 * (Sigma_j_t_inv - Sigma_i_inv)  # (..., K, K)
    
    # Chain rule factor (simplified for practical use)
    # Full formula: complex, but for optimization we use effective gradient
    grad_Sigma_factor = np.einsum(
        '...ij,...jk->...ik',
        grad_Sigma_base, Sigma_j,
        optimize=True
    )  # (..., K, K)
    
    return (
        grad_mu_factor.astype(np.float32, copy=False),
        grad_Sigma_factor.astype(np.float32, copy=False)
    )


def contract_gauge_gradient(
    grad_mu_factor: np.ndarray,
    grad_Sigma_factor: np.ndarray,
    dOmega_dPhi: Tuple[np.ndarray, ...],
    *,
    weight: float = 1.0,
) -> np.ndarray:
    """
    Contract KL gradients with transport differential to get ∂L/∂φ.
    
    Computes: ∑_a weight · tr(∂KL/∂Ω : ∂Ω/∂φ^a)
    
    Args:
        grad_mu_factor: From grad_kl_wrt_transport, shape (..., K, K)
        grad_Sigma_factor: From grad_kl_wrt_transport, shape (..., K, K)
        dOmega_dPhi: Tuple of 3 arrays (dΩ/dφ^x, dΩ/dφ^y, dΩ/dφ^z), each (..., K, K)
        weight: Scalar weight (e.g., β_ij or γ_ij at a point, or spatially integrated)
    
    Returns:
        grad_phi: Gradient w.r.t. φ, shape (..., 3)
    """
    grad_mu_factor = np.asarray(grad_mu_factor, dtype=np.float64)
    grad_Sigma_factor = np.asarray(grad_Sigma_factor, dtype=np.float64)
    
    grad_phi_components = []
    
    for a in range(3):
        dOmega_a = np.asarray(dOmega_dPhi[a], dtype=np.float64)  # (..., K, K)
        
        # Contraction: tr(grad_factor · dΩ/dφ^a)
        # Mean contribution
        contrib_mu = np.einsum('...ij,...ij->...', grad_mu_factor, dOmega_a, optimize=True)
        
        # Sigma contribution
        contrib_Sigma = np.einsum('...ij,...ij->...', grad_Sigma_factor, dOmega_a, optimize=True)
        
        # Total for this component
        grad_phi_a = weight * (contrib_mu + contrib_Sigma)
        grad_phi_components.append(grad_phi_a)
    
    # Stack into (..., 3)
    grad_phi = np.stack(grad_phi_components, axis=-1)
    
    return grad_phi.astype(np.float32, copy=False)


# =============================================================================
# Full Gauge Gradient Computation
# =============================================================================

def compute_gauge_gradient_alignment(
    agent_i_mu: np.ndarray,
    agent_i_Sigma: np.ndarray,
    agent_j_mu: np.ndarray,
    agent_j_Sigma: np.ndarray,
    phi_i: np.ndarray,
    phi_j: np.ndarray,
    generators: np.ndarray,
    beta_ij: np.ndarray,  # Spatial field of weights
    *,
    direction: str = 'i',
    eps: float = 1e-8,
) -> np.ndarray:
    """
    Compute analytical gauge gradient ∂/∂φ for alignment energy.
    
    For agent i:
        ∂/∂φ_i [β_ij(c) KL(q_i(c) || Ω_ij[q_j](c))]
    
    For agent j:
        ∂/∂φ_j [β_ij(c) KL(q_i(c) || Ω_ij[q_j](c))]
    
    This replaces finite differences with analytical chain rule.
    
    Args:
        agent_i_mu, agent_i_Sigma: Source agent parameters, shape (*S, K), (*S, K, K)
        agent_j_mu, agent_j_Sigma: Target agent parameters
        phi_i, phi_j: Gauge fields, shape (*S, 3)
        generators: SO(3) generators, shape (3, K, K)
        beta_ij: Spatial weight field, shape (*S,) - can be position-dependent
        direction: 'i' for ∂/∂φ_i or 'j' for ∂/∂φ_j
        eps: Numerical stability
    
    Returns:
        grad_phi: Gradient field, shape (*S, 3)
    """
    from math_utils.transport import compute_transport, compute_transport_differential
    
    # Compute transport operator
    Omega_ij = compute_transport(phi_i, phi_j, generators, validate=False)
    
    # Compute differential ∂Ω/∂φ
    dOmega_dPhi = compute_transport_differential(
        phi_i, phi_j, generators,
        direction=direction,
        exp_phi_i=None,
        exp_phi_j=None,
    )
    
    # Compute KL gradient w.r.t. Ω
    grad_mu_factor, grad_Sigma_factor = grad_kl_wrt_transport(
        agent_i_mu, agent_i_Sigma,
        agent_j_mu, agent_j_Sigma,
        Omega_ij,
        eps=eps,
    )
    
    # Initialize gradient
    spatial_shape = phi_i.shape[:-1]
    grad_phi = np.zeros((*spatial_shape, 3), dtype=np.float32)
    
    # Contract at each spatial point with weight β_ij(c)
    # Note: beta_ij can vary spatially!
    for idx in np.ndindex(spatial_shape):
        weight = float(beta_ij[idx])
        
        if abs(weight) < 1e-12:
            continue  # Skip if weight negligible
        
        # Extract local values
        gmu = grad_mu_factor[idx]  # (K, K)
        gSig = grad_Sigma_factor[idx]  # (K, K)
        dOm = tuple(dOmega_dPhi[a][idx] for a in range(3))  # 3x (K, K)
        
        # Contract
        grad_phi[idx] = contract_gauge_gradient(
            gmu, gSig, dOm, weight=weight
        )
    
    return grad_phi


# =============================================================================
# Integration into Gradient Engine
# =============================================================================

def compute_gauge_gradients_all_pairs(
    system,
    agent_idx: int,
    mode: str = 'belief',
    *,
    use_softmax_weights: bool = True,
) -> np.ndarray:
    """
    Compute gauge field gradients for one agent from all alignment terms.
    
    FIXED: Removed redundant chi_ij masking - beta_ij already handles it!
    
    Args:
        system: MultiAgentSystem instance
        agent_idx: Index of agent to compute gradients for
        mode: 'belief' for β_ij weights, 'prior' for γ_ij weights
        use_softmax_weights: If True, use β_ij(c) or γ_ij(c); if False, uniform
    
    Returns:
        grad_phi: Accumulated gradient, shape (*S, 3)
    """
    agent_i = system.agents[agent_idx]
    
    # Initialize gradient
    grad_phi = np.zeros_like(agent_i.gauge.phi, dtype=np.float32)
    
    # Get neighbors (agents with spatial overlap)
    neighbors = system.get_neighbors(agent_idx)
    
    if len(neighbors) == 0:
        return grad_phi
    
    if use_softmax_weights:
        if mode == 'belief':
            weights = system.compute_softmax_weights(agent_idx, mode='belief')
            lambda_weight = system.config.lambda_belief_align
        else:
            weights = system.compute_softmax_weights(agent_idx, mode='prior')
            lambda_weight = system.config.lambda_prior_align
    
    # Accumulate gradients from all pairs
    for j in neighbors:
        agent_j = system.agents[j]
        
        # Get spatial weight field: β_ij(c) or γ_ij(c)
        # CRITICAL: This is ALREADY zero outside C_i ∩ C_j!
        # (from compute_softmax_weights with thresholding)
        if j not in weights:
            continue
        
        beta_ij = weights[j]  # Shape: spatial_shape
        
        # ✅ REMOVED REDUNDANT MASKING:
        # OLD (WRONG):
        #   chi_ij = system.get_overlap_mask(agent_idx, j)
        #   beta_ij = beta_ij * chi_ij.astype(np.float32)
        #
        # WHY REMOVED:
        # - beta_ij from compute_softmax_weights uses log-sum-exp with chi_ij
        # - Thresholding ensures beta_ij = 0 outside overlap
        # - Multiplying by chi_ij again is redundant
        # - Same principle as softmax coupling gradients
        
        # Early exit if beta_ij is negligible everywhere
        if np.max(np.abs(beta_ij)) < 1e-12:
            continue
        
        # Get distributions
        if mode == 'belief':
            mu_i, Sigma_i = agent_i.mu_q, agent_i.Sigma_q
            mu_j, Sigma_j = agent_j.mu_q, agent_j.Sigma_q
        else:
            mu_i, Sigma_i = agent_i.mu_p, agent_i.Sigma_p
            mu_j, Sigma_j = agent_j.mu_p, agent_j.Sigma_p
        
        # Compute analytical gradient for this pair
        grad_phi_ij = compute_gauge_gradient_alignment(
            mu_i, Sigma_i,
            mu_j, Sigma_j,
            agent_i.gauge.phi,
            agent_j.gauge.phi,
            agent_i.generators,
            beta_ij,  # Already properly masked!
            direction='i',
        )
        
        # Accumulate with global weight
        grad_phi += lambda_weight * grad_phi_ij
    
    return grad_phi



# =============================================================================
# Utilities
# =============================================================================

def phi_distance(phi1: np.ndarray, phi2: np.ndarray) -> np.ndarray:
    """
    Geodesic distance between gauge fields on SO(3).
    
    For small φ in principal ball: d ≈ ||φ₁ - φ₂|| (Euclidean approximation)
    
    Args:
        phi1, phi2: Axis-angle fields, shape (*S, 3)
    
    Returns:
        distance: Shape (*S,)
    """
    delta = phi1 - phi2
    return np.linalg.norm(delta, axis=-1).astype(np.float32)