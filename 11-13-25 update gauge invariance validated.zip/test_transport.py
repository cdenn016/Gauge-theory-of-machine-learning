#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SO(3) Transport Validation Suite
================================

Click-to-run test module (no CLI) for your gauge transport stack.

Covers:

1. SO(3) generator closure and normalization.
2. Basic properties of exp(Σ φ^a G_a) via _matrix_exponential_so3:
   - orthogonality
   - det ≈ +1
   - correct small-angle derivative: exp(ε φ·G) ≈ I + ε φ·G
3. Transport operator properties:
   - Identity: Ω_ii = I
   - Inverse:  Ω_ij Ω_ji = I
   - Composition: Ω_ij Ω_jk = Ω_ik
   - Orthogonality + det(Ω) ≈ +1
4. Action on Gaussian fibers via push_gaussian:
   - μ' = Ω μ
   - Σ' = Ω Σ Ωᵀ
5. Batch shape sanity for compute_transport and _matrix_exponential_so3.
"""

import numpy as np

from math_utils.generators import generate_so3_generators
from math_utils.transport import (
    compute_transport,
    _matrix_exponential_so3,
)
from math_utils.push_pull import GaussianDistribution, push_gaussian


# ---------------------------------------------------------------------
# 1. Generator sanity: SO(3) commutators
# ---------------------------------------------------------------------

def test_so3_generators_closure():
    """
    Generators must satisfy SO(3) commutation relations for any odd K:

        [G_x, G_y] =  G_z
        [G_y, G_z] =  G_x
        [G_z, G_x] =  G_y

    up to numerical tolerance.
    """
    eps = 1e-5

    for K in (3, 5, 7):
        G = generate_so3_generators(K)  # shape (3, K, K)
        Jx, Jy, Jz = G

        Cxy = Jx @ Jy - Jy @ Jx
        Cyz = Jy @ Jz - Jz @ Jy
        Czx = Jz @ Jx - Jx @ Jz

        if not np.allclose(Cxy, Jz, atol=eps):
            raise AssertionError(f"SO(3) commutator [Jx,Jy]!=Jz for K={K}")
        if not np.allclose(Cyz, Jx, atol=eps):
            raise AssertionError(f"SO(3) commutator [Jy,Jz]!=Jx for K={K}")
        if not np.allclose(Czx, Jy, atol=eps):
            raise AssertionError(f"SO(3) commutator [Jz,Jx]!=Jy for K={K}")


# ---------------------------------------------------------------------
# 2. Basic properties of _matrix_exponential_so3
# ---------------------------------------------------------------------

def test_matrix_exponential_basic_properties():
    """
    Validate that _matrix_exponential_so3:

      - Returns orthogonal matrices (RᵀR ≈ I)
      - Has det(R) ≈ +1
      - For small ε, exp(ε φ·G) ≈ I + ε φ·G (correct tangent).
    """
    rng = np.random.default_rng(0)
    K = 3  # fundamental rep; also valid for other K

    G = generate_so3_generators(K)  # (3,K,K)
    I = np.eye(K)

    # ---- Orthogonality + det=+1 for generic φ ----
    phi = rng.standard_normal((16, 3))
    R = _matrix_exponential_so3(phi, G)  # (16,K,K)

    if R.shape != (16, K, K):
        raise AssertionError(f"_matrix_exponential_so3 shape mismatch: {R.shape}")

    for n in range(16):
        RtR = R[n].T @ R[n]
        if not np.allclose(RtR, I, atol=1e-5):
            raise AssertionError(f"R[{n}] not orthogonal (RᵀR != I)")

        det = np.linalg.det(R[n].astype(np.float64))
        if not np.isclose(det, 1.0, atol=1e-4):
            raise AssertionError(f"det(R[{n}]) != 1 (got {det})")

    # ---- Small-angle derivative test ----
    # For small ε, exp(ε φ·G) ≈ I + ε X, where X = Σ φ^a G_a
    phi_small = rng.standard_normal((8, 3))
    eps = 1e-5
    phi_eps = eps * phi_small

    # Build X = Σ_a φ^a G_a
    X = np.einsum("na,aij->nij", phi_small, G)  # (8,K,K)

    R_small = _matrix_exponential_so3(phi_eps, G)  # (8,K,K)

    # Compare (R_small - I)/eps to X
    dR_numeric = (R_small - I) / eps  # broadcast I over batch

    # We only need them to match to first order, so allow some slack
    if not np.allclose(dR_numeric, X, atol=1e-3, rtol=1e-2):
        max_err = np.max(np.abs(dR_numeric - X))
        raise AssertionError(
            f"Small-angle derivative mismatch in exp(φ·G); max |Δ| = {max_err}"
        )


# ---------------------------------------------------------------------
# 3. Transport operator group properties
# ---------------------------------------------------------------------

def test_compute_transport_group_properties():
    """
    Validate Ω_ij from compute_transport:

      - Identity:    Ω_ii ≈ I
      - Inverse:     Ω_ij Ω_ji ≈ I
      - Composition: Ω_ij Ω_jk ≈ Ω_ik
      - Orthogonal:  ΩᵀΩ ≈ I, det(Ω) ≈ +1
    """
    rng = np.random.default_rng(1)
    K = 5
    G = generate_so3_generators(K)

    phi_i = rng.standard_normal(3)
    phi_j = rng.standard_normal(3)
    phi_k = rng.standard_normal(3)

    # Identity: φ_i == φ_i ⇒ Ω_ii ≈ I
    Omega_ii = compute_transport(phi_i, phi_i, G)
    I = np.eye(K)
    if not np.allclose(Omega_ii, I, atol=1e-6):
        raise AssertionError("Ω_ii not identity")

    # Inverse: Ω_ij Ω_ji ≈ I
    Omega_ij = compute_transport(phi_i, phi_j, G)
    Omega_ji = compute_transport(phi_j, phi_i, G)
    if not np.allclose(Omega_ij @ Omega_ji, I, atol=1e-5):
        raise AssertionError("Ω_ij Ω_ji != I")

    # Composition: Ω_ij Ω_jk ≈ Ω_ik
    Omega_jk = compute_transport(phi_j, phi_k, G)
    Omega_ik = compute_transport(phi_i, phi_k, G)

    if not np.allclose(Omega_ij @ Omega_jk, Omega_ik, atol=1e-5):
        raise AssertionError("Ω_ij Ω_jk != Ω_ik")

    # Orthogonality + det=+1 for a generic Ω_ij
    RtR = Omega_ij.T @ Omega_ij
    if not np.allclose(RtR, I, atol=1e-5):
        raise AssertionError("Ω_ij is not orthogonal: RᵀR != I")

    det = np.linalg.det(Omega_ij.astype(np.float64))
    if not np.isclose(det, 1.0, atol=1e-4):
        raise AssertionError(f"det(Ω_ij) != 1 (got {det})")


# ---------------------------------------------------------------------
# 4. Gaussian fiber transport via push_gaussian
# ---------------------------------------------------------------------

def test_transport_action_on_gaussian():
    """
    Check that push_gaussian implements:

        μ' = Ω μ
        Σ' = Ω Σ Ωᵀ

    for random Gaussian and Ω from compute_transport.
    """
    rng = np.random.default_rng(2)
    K = 5
    G = generate_so3_generators(K)

    phi_i = rng.standard_normal(3)
    phi_j = rng.standard_normal(3)
    Omega_ij = compute_transport(phi_i, phi_j, G)  # (K,K)

    # Make a random SPD covariance
    mu = rng.standard_normal(K)
    A = rng.standard_normal((K, K))
    Sigma = A @ A.T + 0.5 * np.eye(K)

    gaussian = GaussianDistribution(mu=mu, Sigma=Sigma)
    pushed = push_gaussian(gaussian, Omega_ij, compute_precision=False)

    mu_manual = Omega_ij @ mu
    Sigma_manual = Omega_ij @ Sigma @ Omega_ij.T

    if not np.allclose(pushed.mu, mu_manual, atol=1e-5):
        raise AssertionError("push_gaussian: μ' != Ω μ")

    if not np.allclose(pushed.Sigma, Sigma_manual, atol=1e-5):
        raise AssertionError("push_gaussian: Σ' != Ω Σ Ωᵀ")


# ---------------------------------------------------------------------
# 5. Batch shape sanity for compute_transport + exponential
# ---------------------------------------------------------------------

def test_transport_batch_shapes():
    """
    Ensure compute_transport and _matrix_exponential_so3 handle
    batched φ with consistent shapes.
    """
    rng = np.random.default_rng(3)
    K = 5
    G = generate_so3_generators(K)

    # Batch of N axis-angle vectors
    N = 10
    phi_i = rng.standard_normal((N, 3))
    phi_j = rng.standard_normal((N, 3))

    Omega = compute_transport(phi_i, phi_j, G)          # (N,K,K)
    if Omega.shape != (N, K, K):
        raise AssertionError(f"compute_transport batch shape wrong: {Omega.shape}")

    # Check orthogonality for each batch slice
    I = np.eye(K)
    for n in range(N):
        RtR = Omega[n].T @ Omega[n]
        if not np.allclose(RtR, I, atol=1e-5):
            raise AssertionError(f"Ω[{n}] not orthogonal in batch test")

    # Exponential batch shape as well
    phi = rng.standard_normal((N, 3))
    R = _matrix_exponential_so3(phi, G)
    if R.shape != (N, K, K):
        raise AssertionError(f"_matrix_exponential_so3 batch shape wrong: {R.shape}")


# ---------------------------------------------------------------------
# Click-to-run harness
# ---------------------------------------------------------------------

TESTS = [
    test_so3_generators_closure,
    test_matrix_exponential_basic_properties,
    test_compute_transport_group_properties,
    test_transport_action_on_gaussian,
    test_transport_batch_shapes,
]


def main():
    print("========================================")
    print(" SO(3) Transport Validation Suite")
    print("========================================\n")

    for fn in TESTS:
        name = fn.__name__
        print(f"--- Running {name} ---")
        fn()
        print(f"{name}: OK\n")

    print("✅ All transport tests PASSED.")


if __name__ == "__main__":
    main()
