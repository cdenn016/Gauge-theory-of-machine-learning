# -*- coding: utf-8 -*-
"""
Created on Thu Nov 13 12:35:44 2025

@author: chris and christine
"""

"""
0D Gauge Transformer Configuration
===================================

Desktop-optimized configuration for Ryzen 9900X + 64GB RAM.

Target: ~2-3M parameters, trainable in reasonable time.

Author: Implementation from plan.py
Date: November 2025
"""

# =============================================================================
# Desktop-Friendly Configuration (2-3M parameters)
# =============================================================================

DESKTOP_CONFIG = {
    # Vocabulary & Embedding
    'vocab_size': 5000,          # Reduced vocabulary
    'embed_dim': 96,              # K=96 fiber dimension
    'max_seq_len': 128,           # Shorter sequences for faster training

    # Architecture
    'n_layers': 3,                # 3 transformer blocks
    'n_heads': 4,                 # Fewer attention heads
    'hidden_dim': 384,            # FFN dimension (4 × embed_dim)

    # Base Manifold (0D - single point!)
    'base_manifold_dim': 0,       # All agents at single point c*
    'num_agents_per_point': 128,  # = max_seq_len (all agents at c*)

    # SO(3) Gauge Structure
    'gauge_group': 'SO(3)',
    'irrep_spec': [
        # (irrep_label, multiplicity, dimension)
        ('ℓ0', 12, 1),            # 12 scalar channels
        ('ℓ1', 7, 3),             # 7 vector channels (dim=3)
        ('ℓ2', 5, 5),             # 5 rank-2 tensor channels
        ('ℓ3', 2, 7),             # 2 rank-3 tensor channels
    ],  # Total: 12×1 + 7×3 + 5×5 + 2×7 = 72 → pad to 96

    # Variational Free Energy Parameters
    'kappa_beta': 1.0,            # Temperature for belief coupling β_ij
    'kappa_gamma': 0.5,           # Temperature for prior coupling γ_ij
    'epsilon': 1e-8,              # Softmax numerical stability
    'alpha': 1.0,                 # Self-consistency weight
    'lambda_phi': 0.01,           # Gauge field smoothness penalty

    # Training
    'batch_size': 8,              # Small batches for desktop
    'learning_rate': 5e-4,        # Slightly higher for faster convergence
    'warmup_steps': 500,          # Shorter warmup
    'max_steps': 20000,           # Reduced for desktop training
    'gradient_clip': 1.0,
    'weight_decay': 0.1,

    # Natural Gradient
    'use_natural_gradient': True,
    'fisher_update_freq': 10,     # Update Fisher estimate every N steps
    'fisher_ema_decay': 0.99,     # EMA for online Fisher estimation

    # Misc
    'dtype': 'float32',           # Use float32 to save memory
    'device': 'cpu',              # Can switch to 'cuda' if GPU available
    'num_workers': 4,             # For dataloaders
    'log_every': 100,             # Log every N steps
    'checkpoint_every': 2000,     # Checkpoint frequency
}


# =============================================================================
# Standard Configuration (5-7M parameters) - if you want more capacity
# =============================================================================

STANDARD_CONFIG = {
    'vocab_size': 10000,
    'embed_dim': 192,
    'n_layers': 4,
    'n_heads': 6,
    'hidden_dim': 768,
    'max_seq_len': 256,

    'base_manifold_dim': 0,
    'num_agents_per_point': 256,

    'gauge_group': 'SO(3)',
    'irrep_spec': [
        ('ℓ0', 18, 1),
        ('ℓ1', 10, 3),
        ('ℓ2', 8, 5),
        ('ℓ3', 4, 7),
        ('ℓ4', 2, 9),
    ],  # Total: 134 → pad to 192

    'kappa_beta': 1.0,
    'kappa_gamma': 0.5,
    'epsilon': 1e-8,
    'alpha': 1.0,
    'lambda_phi': 0.01,

    'batch_size': 16,
    'learning_rate': 3e-4,
    'warmup_steps': 1000,
    'max_steps': 50000,
    'gradient_clip': 1.0,
    'weight_decay': 0.1,

    'use_natural_gradient': True,
    'fisher_update_freq': 10,
    'fisher_ema_decay': 0.99,

    'dtype': 'float32',
    'device': 'cpu',
    'num_workers': 4,
    'log_every': 100,
    'checkpoint_every': 5000,
}


def get_config(name='desktop'):
    """Get configuration by name."""
    configs = {
        'desktop': DESKTOP_CONFIG,
        'standard': STANDARD_CONFIG,
    }

    if name not in configs:
        raise ValueError(f"Unknown config '{name}'. Available: {list(configs.keys())}")

    return configs[name].copy()


def estimate_parameters(config):
    """Estimate total parameter count."""
    V = config['vocab_size']
    K = config['embed_dim']
    L = config['n_layers']
    H = config['hidden_dim']
    T = config['max_seq_len']

    # Token embedding
    tok_embed = V * K

    # Position embedding
    pos_embed = T * 3  # Gauge frames (φ ∈ so(3))

    # Per-layer parameters
    # Attention: Q, K, V, O projections (simplified - not accounting for irrep structure)
    attn_params = 4 * K * K

    # FFN: two linear layers
    ffn_params = K * H + H * K

    # LayerNorm: 2 * K per layer (scale + bias)
    ln_params = 2 * K

    layer_params = attn_params + ffn_params + ln_params

    # Output projection (tied with input embedding)
    # out_proj = V * K  # This is tied, so don't count

    total = tok_embed + pos_embed + L * layer_params

    return {
        'total': total,
        'token_embed': tok_embed,
        'pos_embed': pos_embed,
        'layers': L * layer_params,
        'per_layer': layer_params,
    }


if __name__ == '__main__':
    # Print configurations
    for name in ['desktop', 'standard']:
        print(f"\n{'='*70}")
        print(f"{name.upper()} CONFIGURATION")
        print('='*70)

        cfg = get_config(name)
        params = estimate_parameters(cfg)

        print(f"\nArchitecture:")
        print(f"  Vocab size:    {cfg['vocab_size']:,}")
        print(f"  Embed dim (K): {cfg['embed_dim']}")
        print(f"  Layers:        {cfg['n_layers']}")
        print(f"  Hidden dim:    {cfg['hidden_dim']}")
        print(f"  Max seq len:   {cfg['max_seq_len']}")

        print(f"\nParameters (estimate):")
        print(f"  Total:         {params['total'] / 1e6:.2f}M")
        print(f"  Token embed:   {params['token_embed'] / 1e6:.2f}M")
        print(f"  Layers:        {params['layers'] / 1e6:.2f}M")
        print(f"  Per layer:     {params['per_layer'] / 1e3:.1f}K")

        print(f"\nTraining:")
        print(f"  Batch size:    {cfg['batch_size']}")
        print(f"  Learning rate: {cfg['learning_rate']}")
        print(f"  Max steps:     {cfg['max_steps']:,}")

        memory_estimate_mb = (params['total'] * 4) / 1e6  # float32 = 4 bytes
        print(f"\nMemory (params only): ~{memory_estimate_mb:.1f} MB")