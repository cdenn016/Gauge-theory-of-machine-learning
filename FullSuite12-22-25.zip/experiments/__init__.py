# -*- coding: utf-8 -*-
"""
Created on Thu Nov 27 19:10:32 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
Research Experiments
====================

Systematic experiments for comparing Hamiltonian vs Gradient VFE dynamics.
"""