# -*- coding: utf-8 -*-
"""
Created on Sun Nov 16 21:19:49 2025

@author: chris and christine
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np

def create_architecture_comparison():
    """
    Create side-by-side comparison of three architectures for publication.
    """
    fig, axes = plt.subplots(1, 3, figsize=(18, 10))
    fig.suptitle('Progressive Architecture Evolution: From Standard Transformers to Gauge Theory', 
                 fontsize=16, fontweight='bold', y=0.98)
    
    # Color schemes
    colors = {
        'learned': '#fbbf24',  # amber
        'geometric': '#10b981', # green
        'pure_geo': '#8b5cf6',  # purple
        'standard': '#3b82f6',  # blue
        'backprop': '#ec4899'   # pink
    }
    
    # Architecture 1: Standard Transformer
    ax1 = axes[0]
    ax1.set_xlim(0, 10)
    ax1.set_ylim(0, 12)
    ax1.axis('off')
    ax1.set_title('(1) Standard Transformer\nBaseline', 
                  fontsize=14, fontweight='bold', color='#1e40af', pad=20)
    
    y_pos = 11
    # Tokens
    for i, label in enumerate(['Token 1', 'Token 2', '...', 'Token n']):
        x = 1.5 + i * 2
        ax1.add_patch(FancyBboxPatch((x-0.4, y_pos-0.3), 0.8, 0.5, 
                                      boxstyle="round,pad=0.05", 
                                      facecolor='#dbeafe', edgecolor='#2563eb', linewidth=2))
        ax1.text(x, y_pos, label, ha='center', va='center', fontsize=9)
    
    y_pos -= 1.5
    ax1.arrow(5, y_pos+0.5, 0, -0.3, head_width=0.3, head_length=0.1, fc='black', ec='black')
    
    # Learned embeddings
    y_pos -= 0.5
    ax1.add_patch(FancyBboxPatch((1, y_pos-0.4), 8, 0.8, 
                                  boxstyle="round,pad=0.05",
                                  facecolor='#fef3c7', edgecolor='#f59e0b', linewidth=2))
    ax1.text(5, y_pos, 'Learned Embeddings', ha='center', va='center', 
             fontsize=11, fontweight='bold')
    ax1.text(5, y_pos-0.25, r'$\mathbf{W}_{\mathrm{emb}} \times \mathrm{one\text{-}hot}$', 
             ha='center', va='center', fontsize=9, style='italic')
    
    y_pos -= 1.2
    ax1.arrow(5, y_pos+0.5, 0, -0.3, head_width=0.3, head_length=0.1, fc='black', ec='black')
    
    # Dot-product attention
    y_pos -= 0.5
    ax1.add_patch(FancyBboxPatch((0.5, y_pos-0.8), 9, 1.6, 
                                  boxstyle="round,pad=0.05",
                                  facecolor='#fee2e2', edgecolor='#dc2626', linewidth=2))
    ax1.text(5, y_pos+0.3, 'Dot-Product Attention', ha='center', va='center',
             fontsize=11, fontweight='bold')
    ax1.text(5, y_pos, r'$Q = XW_Q, \; K = XW_K, \; V = XW_V$', 
             ha='center', va='center', fontsize=9)
    ax1.text(5, y_pos-0.3, r'$\mathbf{softmax}(QK^\top / \sqrt{d}) \, V$',
             ha='center', va='center', fontsize=10, fontweight='bold')
    
    y_pos -= 1.8
    ax1.arrow(5, y_pos+0.5, 0, -0.3, head_width=0.3, head_length=0.1, fc='black', ec='black')
    
    # Feed-forward
    y_pos -= 0.5
    ax1.add_patch(FancyBboxPatch((1, y_pos-0.8), 8, 1.6,
                                  boxstyle="round,pad=0.05",
                                  facecolor='#dbeafe', edgecolor='#2563eb', linewidth=2))
    ax1.text(5, y_pos+0.3, 'Feed-Forward MLP', ha='center', va='center',
             fontsize=11, fontweight='bold')
    ax1.text(5, y_pos, r'$\mathbf{W}_2 \cdot \mathrm{ReLU}(\mathbf{W}_1 \cdot x + b_1) + b_2$',
             ha='center', va='center', fontsize=9)
    ax1.text(5, y_pos-0.4, 'Learned weights', ha='center', va='center',
             fontsize=9, style='italic', color='#d97706', fontweight='bold')
    
    y_pos -= 1.8
    ax1.arrow(5, y_pos+0.5, 0, -0.3, head_width=0.3, head_length=0.1, fc='black', ec='black')
    
    # Backprop
    y_pos -= 0.5
    ax1.add_patch(FancyBboxPatch((1, y_pos-0.4), 8, 0.8,
                                  boxstyle="round,pad=0.05",
                                  facecolor='#fce7f3', edgecolor='#db2777', linewidth=2))
    ax1.text(5, y_pos, 'Backpropagation', ha='center', va='center',
             fontsize=11, fontweight='bold')
    ax1.text(5, y_pos-0.25, r'$\nabla_\theta \mathcal{L}$, Adam', ha='center', va='center',
             fontsize=9)
    
    # Summary box
    ax1.add_patch(FancyBboxPatch((0.5, 0.3), 9, 0.6,
                                  boxstyle="round,pad=0.05",
                                  facecolor='#f3f4f6', edgecolor='#9ca3af', linewidth=1))
    ax1.text(5, 0.6, 'All learned • Black-box • No explicit beliefs',
             ha='center', va='center', fontsize=9, color='#374151')
    
    # Architecture 2: Gauge Attention
    ax2 = axes[1]
    ax2.set_xlim(0, 10)
    ax2.set_ylim(0, 12)
    ax2.axis('off')
    ax2.set_title('(2) Gauge Attention\nHybrid Approach',
                  fontsize=14, fontweight='bold', color='#047857', pad=20)
    
    y_pos = 11
    # Agents
    for i, label in enumerate(['Agent 1', 'Agent 2', '...', 'Agent n']):
        x = 1.5 + i * 2
        ax2.add_patch(FancyBboxPatch((x-0.4, y_pos-0.3), 0.8, 0.5,
                                      boxstyle="round,pad=0.05",
                                      facecolor='#d1fae5', edgecolor='#059669', linewidth=2))
        ax2.text(x, y_pos, label, ha='center', va='center', fontsize=9)
    
    y_pos -= 1.5
    ax2.arrow(5, y_pos+0.5, 0, -0.3, head_width=0.3, head_length=0.1, fc='black', ec='black')
    
    # Variational embeddings
    y_pos -= 0.5
    ax2.add_patch(FancyBboxPatch((1, y_pos-0.4), 8, 0.8,
                                  boxstyle="round,pad=0.05",
                                  facecolor='#fef3c7', edgecolor='#f59e0b', linewidth=2))
    ax2.text(5, y_pos, 'Variational Embeddings', ha='center', va='center',
             fontsize=11, fontweight='bold')
    ax2.text(5, y_pos-0.25, r'$(\mu_i, \Sigma_i, \phi_i)$ - learned',
             ha='center', va='center', fontsize=9, style='italic')
    
    y_pos -= 1.2
    ax2.arrow(5, y_pos+0.5, 0, -0.3, head_width=0.3, head_length=0.1, fc='black', ec='black')
    
    # KL divergence attention
    y_pos -= 0.5
    ax2.add_patch(FancyBboxPatch((0.5, y_pos-0.8), 9, 1.6,
                                  boxstyle="round,pad=0.05",
                                  facecolor='#dcfce7', edgecolor='#059669', linewidth=2))
    ax2.text(5, y_pos+0.4, 'KL Divergence Attention', ha='center', va='center',
             fontsize=11, fontweight='bold')
    ax2.text(5, y_pos+0.05, r'$\Omega_{ij} = \exp(\phi_i) \cdot \exp(-\phi_j)$',
             ha='center', va='center', fontsize=9)
    ax2.text(5, y_pos-0.3, r'$\beta_{ij} \propto \exp\!\left[-\mathrm{KL}(q_i \| \Omega_{ij}[q_j])\right]$',
             ha='center', va='center', fontsize=9, fontweight='bold')
    
    y_pos -= 1.8
    ax2.arrow(5, y_pos+0.5, 0, -0.3, head_width=0.3, head_length=0.1, fc='black', ec='black')
    
    # Standard FF
    y_pos -= 0.5
    ax2.add_patch(FancyBboxPatch((1, y_pos-0.8), 8, 1.6,
                                  boxstyle="round,pad=0.05",
                                  facecolor='#dbeafe', edgecolor='#2563eb', linewidth=2))
    ax2.text(5, y_pos+0.3, 'Standard Feed-Forward', ha='center', va='center',
             fontsize=11, fontweight='bold')
    ax2.text(5, y_pos, 'MLP with ReLU', ha='center', va='center', fontsize=9)
    ax2.text(5, y_pos-0.4, 'Still learned', ha='center', va='center',
             fontsize=9, style='italic', color='#d97706', fontweight='bold')
    
    y_pos -= 1.8
    ax2.arrow(5, y_pos+0.5, 0, -0.3, head_width=0.3, head_length=0.1, fc='black', ec='black')
    
    # Backprop
    y_pos -= 0.5
    ax2.add_patch(FancyBboxPatch((1, y_pos-0.4), 8, 0.8,
                                  boxstyle="round,pad=0.05",
                                  facecolor='#fce7f3', edgecolor='#db2777', linewidth=2))
    ax2.text(5, y_pos, 'Backpropagation', ha='center', va='center',
             fontsize=11, fontweight='bold')
    ax2.text(5, y_pos-0.25, 'Standard gradient descent', ha='center', va='center',
             fontsize=9)
    
    # Summary
    ax2.add_patch(FancyBboxPatch((0.5, 0.3), 9, 0.6,
                                  boxstyle="round,pad=0.05",
                                  facecolor='#f3f4f6', edgecolor='#9ca3af', linewidth=1))
    ax2.text(5, 0.6, 'Geometric attention • Explicit beliefs • Hybrid',
             ha='center', va='center', fontsize=9, color='#374151')
    
    # Architecture 3: Full Gauge VFE
    ax3 = axes[2]
    ax3.set_xlim(0, 10)
    ax3.set_ylim(0, 12)
    ax3.axis('off')
    ax3.set_title('(3) Full Gauge VFE\nPure Geometry',
                  fontsize=14, fontweight='bold', color='#6d28d9', pad=20)
    
    y_pos = 11
    # Agents
    for i, label in enumerate(['Agent 1', 'Agent 2', '...', 'Agent n']):
        x = 1.5 + i * 2
        ax3.add_patch(FancyBboxPatch((x-0.4, y_pos-0.3), 0.8, 0.5,
                                      boxstyle="round,pad=0.05",
                                      facecolor='#ede9fe', edgecolor='#7c3aed', linewidth=2))
        ax3.text(x, y_pos, label, ha='center', va='center', fontsize=9)
    
    y_pos -= 1.5
    ax3.arrow(5, y_pos+0.5, 0, -0.3, head_width=0.3, head_length=0.1, fc='black', ec='black')
    
    # Bundle sections
    y_pos -= 0.5
    ax3.add_patch(FancyBboxPatch((1, y_pos-0.4), 8, 0.8,
                                  boxstyle="round,pad=0.05",
                                  facecolor='#fef3c7', edgecolor='#f59e0b', linewidth=2))
    ax3.text(5, y_pos, 'Bundle Sections', ha='center', va='center',
             fontsize=11, fontweight='bold')
    ax3.text(5, y_pos-0.25, r'$(\mu_i, \Sigma_i, \phi_i)$ - optimized',
             ha='center', va='center', fontsize=9, style='italic')
    
    y_pos -= 1.2
    ax3.arrow(5, y_pos+0.5, 0, -0.3, head_width=0.3, head_length=0.1, fc='black', ec='black')
    
    # Multi-head gauge attention
    y_pos -= 0.5
    ax3.add_patch(FancyBboxPatch((0.5, y_pos-0.8), 9, 1.6,
                                  boxstyle="round,pad=0.05",
                                  facecolor='#f3e8ff', edgecolor='#7c3aed', linewidth=2))
    ax3.text(5, y_pos+0.5, 'Multi-Head Gauge Attention', ha='center', va='center',
             fontsize=11, fontweight='bold')
    ax3.text(5, y_pos+0.15, r'SO(3) irreps: $J=0,1,2,...$',
             ha='center', va='center', fontsize=8, style='italic')
    ax3.text(5, y_pos-0.15, r'$\Omega_{ij}$ via parallel transport',
             ha='center', va='center', fontsize=9)
    ax3.text(5, y_pos-0.45, r'$\beta_{ij} \propto \exp\!\left[-\mathrm{KL}(q_i \| \Omega_{ij}[q_j])\right]$',
             ha='center', va='center', fontsize=9, fontweight='bold')
    
    y_pos -= 1.8
    ax3.arrow(5, y_pos+0.5, 0, -0.3, head_width=0.3, head_length=0.1, fc='black', ec='black')
    
    # Variational inference
    y_pos -= 0.5
    ax3.add_patch(FancyBboxPatch((1, y_pos-0.8), 8, 1.6,
                                  boxstyle="round,pad=0.05",
                                  facecolor='#ddd6fe', edgecolor='#7c3aed', linewidth=2))
    ax3.text(5, y_pos+0.4, 'Variational Inference', ha='center', va='center',
             fontsize=11, fontweight='bold')
    ax3.text(5, y_pos+0.05, r'Min: $S = \mathrm{KL}(q\|p) + $ alignment',
             ha='center', va='center', fontsize=9)
    ax3.text(5, y_pos-0.35, 'No learned weights', ha='center', va='center',
             fontsize=9, style='italic', color='#059669', fontweight='bold')
    
    y_pos -= 1.8
    ax3.arrow(5, y_pos+0.5, 0, -0.3, head_width=0.3, head_length=0.1, fc='black', ec='black')
    
    # Natural gradient
    y_pos -= 0.5
    ax3.add_patch(FancyBboxPatch((1, y_pos-0.4), 8, 0.8,
                                  boxstyle="round,pad=0.05",
                                  facecolor='#e0e7ff', edgecolor='#4f46e5', linewidth=2))
    ax3.text(5, y_pos, 'Natural Gradient', ha='center', va='center',
             fontsize=11, fontweight='bold')
    ax3.text(5, y_pos-0.25, 'Fisher-Rao metric on SPD', ha='center', va='center',
             fontsize=9)
    
    # Summary
    ax3.add_patch(FancyBboxPatch((0.5, 0.3), 9, 0.6,
                                  boxstyle="round,pad=0.05",
                                  facecolor='#f3f4f6', edgecolor='#9ca3af', linewidth=1))
    ax3.text(5, 0.6, 'Pure geometry • No MLPs • Explicit inference',
             ha='center', va='center', fontsize=9, color='#374151')
    
    plt.tight_layout()
    return fig

def create_comparison_table():
    """
    Create detailed comparison table as a figure.
    """
    fig, ax = plt.subplots(figsize=(14, 8))
    ax.axis('tight')
    ax.axis('off')
    
    # Table data
    headers = ['Component', 'Standard\nTransformer', 'Gauge\nAttention', 'Full Gauge\nVFE']
    rows = [
        ['Embeddings', 'Learned $W_{emb}$', 'Variational $(\\mu,\\Sigma,\\phi)$', 'Bundle sections'],
        ['Attention', '$QK^T$ softmax', 'KL divergence', 'KL + SO(N) irreps'],
        ['Transport', 'None (implicit)', '$\\Omega_{ij} = e^{\\phi_i}e^{-\\phi_j}$', 'Parallel transport'],
        ['Feed-Forward', 'MLP + ReLU', 'MLP + ReLU', 'Variational inference'],
        ['Optimization', 'Backprop + Adam', 'Backprop + Adam', 'Natural gradient'],
        ['Learned Weights', '~67%', '~50%', '\\textbf{0\\%}'],
        ['Explicit Beliefs', 'No', 'Yes $(q,p)$', 'Yes $(q,p,\\phi)$'],
    ]
    
    # Create table
    table = ax.table(cellText=rows, colLabels=headers, 
                     cellLoc='left', loc='center',
                     colWidths=[0.2, 0.27, 0.27, 0.27])
    
    table.auto_set_font_size(False)
    table.set_fontsize(11)
    table.scale(1, 3)
    
    # Style header
    for i in range(len(headers)):
        cell = table[(0, i)]
        cell.set_facecolor('#e5e7eb')
        cell.set_text_props(weight='bold', fontsize=12)
    
    # Color code rows
    colors_map = {
        1: ('#dbeafe', '#d1fae5', '#ede9fe'),  # Embeddings
        2: ('#fee2e2', '#dcfce7', '#f3e8ff'),  # Attention
        5: ('#fef3c7', '#fef3c7', '#dcfce7'),  # Learned weights
    }
    
    for row_idx, row in enumerate(rows, 1):
        for col_idx in range(len(headers)):
            cell = table[(row_idx, col_idx)]
            if row_idx in colors_map:
                cell.set_facecolor(colors_map[row_idx][min(col_idx-1, 2)])
    
    # Highlight zero weights
    cell = table[(6, 3)]
    cell.set_facecolor('#d1fae5')
    cell.set_text_props(weight='bold', color='#047857')
    
    plt.title('Detailed Architecture Comparison', fontsize=16, fontweight='bold', pad=20)
    
    return fig

if __name__ == '__main__':
    # Generate and save figures
    
    # Main comparison figure
    fig1 = create_architecture_comparison()
    fig1.savefig('architecture_comparison.pdf', dpi=300, bbox_inches='tight')
    fig1.savefig('architecture_comparison.png', dpi=300, bbox_inches='tight')
    print("Saved: architecture_comparison.pdf/png")
    
    # Comparison table
    fig2 = create_comparison_table()
    fig2.savefig('comparison_table.pdf', dpi=300, bbox_inches='tight')
    fig2.savefig('comparison_table.png', dpi=300, bbox_inches='tight')
    print("Saved: comparison_table.pdf/png")
    
    plt.show()