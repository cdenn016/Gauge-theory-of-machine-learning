# -*- coding: utf-8 -*-
"""
Centralized, validated access to agent fields.

Works with the Agent dataclass from agent_schema.py to provide:
  - Type conversion and validation
  - Graceful fallbacks for missing fields
  - Consistent error messages
  - Extension points for meta-agents

Usage:
    from core.agent_accessor import AA
    
    # Instead of:
    i_id = int(getattr(agent, "id", -1))
    mu_q = np.asarray(agent.mu_q_field, np.float32)
    
    # Use:
    i_id = AA.get_id(agent)
    mu_q = AA.get_mu_q(agent)
"""

from __future__ import annotations
from typing import Optional, Tuple, List
import numpy as np


class AgentAccessor:
    """
    Safe, validated access to Agent fields.
    
    Complements agent_schema.Agent by providing:
      - Type guarantees (float32 for fields, float64 for covariances)
      - Sanitization (sigma via sanitize_sigma)
      - Validation (shape checks, finite checks)
      - Fallbacks (default values where appropriate)
    
    All methods are static - this is a namespace, not an instance class.
    """
    
    # ─────────────────────────────────────────────────────────────────────
    # Identity & Hierarchy (maps directly to Agent fields)
    # ─────────────────────────────────────────────────────────────────────
    
    @staticmethod
    def get_id(agent, fallback: int = -1) -> int:
        """
        Get agent ID with fallback.
        
        Args:
            agent: Agent object
            fallback: Value if id missing (default: -1)
        
        Returns:
            Agent ID as integer
        """
        return int(getattr(agent, "id", fallback))
    
    @staticmethod
    def get_level(agent) -> int:
        """
        Get hierarchical level.
        
        Returns:
            0 for base agents, ≥1 for meta-agents
        """
        return int(getattr(agent, "level", 0))
    
    @staticmethod
    def is_parent(agent) -> bool:
        """Check if agent is a parent (level ≥ 1)."""
        # Use Agent's own method if available
        if hasattr(agent, "is_parent") and callable(agent.is_parent):
            return agent.is_parent()
        return AgentAccessor.get_level(agent) >= 1
    
    @staticmethod
    def get_child_ids(agent) -> List[int]:
        """Get list of child agent IDs."""
        return list(getattr(agent, "child_ids", []))
    
    @staticmethod
    def get_parent_ids(agent) -> List[int]:
        """Get list of parent agent IDs."""
        return list(getattr(agent, "parent_ids", []))
    
    # ─────────────────────────────────────────────────────────────────────
    # Spatial Properties
    # ─────────────────────────────────────────────────────────────────────
    
    @staticmethod
    def get_mask(agent) -> np.ndarray:
        """
        Get spatial mask as boolean array.
        
        Agent.mask is float32 in [0,1], but we often need bool.
        This converts consistently.
        """
        mask = getattr(agent, "mask", None)
        if mask is None:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} has no mask")
        
        # Agent schema uses float32 mask - convert to bool
        mask = np.asarray(mask, dtype=np.float32)
        return mask > 0.5  # Threshold at 0.5
    
    @staticmethod
    def get_mask_float(agent) -> np.ndarray:
        """
        Get spatial mask as float32 (as stored in Agent).
        
        Returns raw mask without bool conversion.
        """
        mask = getattr(agent, "mask", None)
        if mask is None:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} has no mask")
        return np.asarray(mask, dtype=np.float32)
    
    @staticmethod
    def get_spatial_shape(agent) -> Tuple[int, ...]:
        """
        Get spatial dimensions (without channel dimension).
        
        Uses Agent's .spatial_shape property if available,
        otherwise infers from mask/fields.
        """
        # Use Agent's own property if available
        if hasattr(agent, "spatial_shape"):
            return tuple(agent.spatial_shape)
        
        # Fallback: infer from mask
        mask = AgentAccessor.get_mask_float(agent)
        return tuple(mask.shape)
    
    @staticmethod
    def get_center(agent) -> Tuple[int, ...]:
        """Get agent center coordinates."""
        center = getattr(agent, "center", None)
        if center is None:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} has no center")
        return tuple(center)
    
    @staticmethod
    def get_radius(agent) -> float:
        """Get agent radius."""
        radius = getattr(agent, "radius", None)
        if radius is None:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} has no radius")
        return float(radius)
    
    # ─────────────────────────────────────────────────────────────────────
    # Q-Fiber (Sensory)
    # ─────────────────────────────────────────────────────────────────────
    
    @staticmethod
    def get_mu_q(agent) -> np.ndarray:
        """
        Get q-fiber mean field, validated.
        
        Returns:
            Array (*S, K) in float32
        """
        mu = getattr(agent, "mu_q_field", None)
        if mu is None:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} has no mu_q_field")
        
        mu = np.asarray(mu, dtype=np.float32)
        if mu.ndim < 2:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} mu_q has invalid shape: {mu.shape}")
        
        return mu
    
    @staticmethod
    def get_sigma_q(agent, *, sanitize: bool = True) -> np.ndarray:
        """
        Get q-fiber covariance field, validated.
        
        Args:
            agent: Agent object
            sanitize: If True, apply sanitize_sigma (default)
        
        Returns:
            Array (*S, K, K) in float64, optionally sanitized
        """
        sigma = getattr(agent, "sigma_q_field", None)
        if sigma is None:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} has no sigma_q_field")
        
        sigma = np.asarray(sigma, dtype=np.float64)
        if sigma.ndim < 3:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} sigma_q has invalid shape: {sigma.shape}")
        
        if sanitize:
            from core.numerical_utils import sanitize_sigma
            sigma = sanitize_sigma(sigma)
        
        return sigma
    
    @staticmethod
    def get_sigma_q_inv(agent) -> Optional[np.ndarray]:
        """
        Get cached inverse of sigma_q (if available).
        
        Returns None if not computed yet.
        """
        sigma_inv = getattr(agent, "sigma_q_inv", None)
        if sigma_inv is None:
            return None
        return np.asarray(sigma_inv, dtype=np.float64)
    
    # ─────────────────────────────────────────────────────────────────────
    # P-Fiber (Motor/Generative)
    # ─────────────────────────────────────────────────────────────────────
    
    @staticmethod
    def get_mu_p(agent) -> np.ndarray:
        """Get p-fiber mean field (*S, K) in float32."""
        mu = getattr(agent, "mu_p_field", None)
        if mu is None:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} has no mu_p_field")
        
        mu = np.asarray(mu, dtype=np.float32)
        if mu.ndim < 2:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} mu_p has invalid shape: {mu.shape}")
        
        return mu
    
    @staticmethod
    def get_sigma_p(agent, *, sanitize: bool = True) -> np.ndarray:
        """Get p-fiber covariance field (*S, K, K) in float64, optionally sanitized."""
        sigma = getattr(agent, "sigma_p_field", None)
        if sigma is None:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} has no sigma_p_field")
        
        sigma = np.asarray(sigma, dtype=np.float64)
        if sigma.ndim < 3:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} sigma_p has invalid shape: {sigma.shape}")
        
        if sanitize:
            from core.numerical_utils import sanitize_sigma
            sigma = sanitize_sigma(sigma)
        
        return sigma
    
    @staticmethod
    def get_sigma_p_inv(agent) -> Optional[np.ndarray]:
        """Get cached inverse of sigma_p (if available)."""
        sigma_inv = getattr(agent, "sigma_p_inv", None)
        if sigma_inv is None:
            return None
        return np.asarray(sigma_inv, dtype=np.float64)
    
    # ─────────────────────────────────────────────────────────────────────
    # Geometry (Gauge Connection)
    # ─────────────────────────────────────────────────────────────────────
    
    @staticmethod
    def get_phi(agent, which: str = "q") -> np.ndarray:
        """
        Get Lie algebra field (gauge connection).
        
        Args:
            agent: Agent object
            which: "q" for phi, "p" for phi_model
        
        Returns:
            Array (*S, 3) in float32
        
        Note: Agent schema uses 'phi_model' for p-fiber, not 'phi_m'
        """
        if which == "q":
            field_name = "phi"
        elif which == "p":
            field_name = "phi_model"
        else:
            raise ValueError(f"which must be 'q' or 'p', got {which}")
        
        phi = getattr(agent, field_name, None)
        if phi is None:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} has no {field_name}")
        
        phi = np.asarray(phi, dtype=np.float32)
        if phi.ndim < 2 or phi.shape[-1] != 3:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} {field_name} has invalid shape: {phi.shape}")
        
        return phi
    
    @staticmethod
    def get_phi_q(agent) -> np.ndarray:
        """Get q-fiber φ field (alias for get_phi(agent, 'q'))."""
        return AgentAccessor.get_phi(agent, which="q")
    
    @staticmethod
    def get_phi_p(agent) -> np.ndarray:
        """Get p-fiber φ field (alias for get_phi(agent, 'p'))."""
        return AgentAccessor.get_phi(agent, which="p")
    
    @staticmethod
    def get_inverse_fisher_phi(agent, which: str = "q") -> Optional[np.ndarray]:
        """
        Get cached inverse Fisher metric for φ field.
        
        Args:
            agent: Agent object
            which: "q" for phi, "p" for phi_model
        
        Returns:
            Array (*S, 3, 3) or None if not computed
        """
        if which == "q":
            field_name = "inverse_fisher_phi"
        elif which == "p":
            field_name = "inverse_fisher_phi_model"
        else:
            raise ValueError(f"which must be 'q' or 'p', got {which}")
        
        inv_fisher = getattr(agent, field_name, None)
        if inv_fisher is None:
            return None
        return np.asarray(inv_fisher, dtype=np.float64)
    
    # ─────────────────────────────────────────────────────────────────────
    # Gradients (Buffer Access)
    # ─────────────────────────────────────────────────────────────────────
    
    @staticmethod
    def get_grad_mu_q(agent) -> Optional[np.ndarray]:
        """Get gradient buffer for mu_q (may be None if not computed)."""
        grad = getattr(agent, "grad_mu_q", None)
        return np.asarray(grad, dtype=np.float32) if grad is not None else None
    
    @staticmethod
    def get_grad_sigma_q(agent) -> Optional[np.ndarray]:
        """Get gradient buffer for sigma_q (may be None if not computed)."""
        grad = getattr(agent, "grad_sigma_q", None)
        return np.asarray(grad, dtype=np.float64) if grad is not None else None
    
    @staticmethod
    def get_grad_phi(agent, which: str = "q") -> np.ndarray:
        """
        Get gradient buffer for φ field.
        
        Args:
            which: "q" for grad_phi, "p" for grad_phi_tilde
        
        Returns:
            Array (*S, 3) in float32
        
        Note: Agent schema uses 'grad_phi_tilde' for p-fiber
        """
        if which == "q":
            field_name = "grad_phi"
        elif which == "p":
            field_name = "grad_phi_tilde"
        else:
            raise ValueError(f"which must be 'q' or 'p', got {which}")
        
        grad = getattr(agent, field_name, None)
        if grad is None:
            raise ValueError(f"Agent {AgentAccessor.get_id(agent)} has no {field_name}")
        
        return np.asarray(grad, dtype=np.float32)
    
    # ─────────────────────────────────────────────────────────────────────
    # Convenience: Bulk Extraction
    # ─────────────────────────────────────────────────────────────────────
    
    @staticmethod
    def extract_fields(agent, *, need_q: bool = True, need_p: bool = True) -> dict:
        """
        Extract multiple fields at once (for edge_maps_unified.py).
        
        Returns dict with:
          - shape: spatial shape
          - has_q, has_p: bool flags
          - mu_q, sigma_q: if need_q
          - mu_p, sigma_p: if need_p
          - mask: float mask (not bool, for compatibility)
        """
        out = {"has_q": False, "has_p": False}
        
        if need_q:
            out["mu_q"] = AgentAccessor.get_mu_q(agent)
            out["sigma_q"] = AgentAccessor.get_sigma_q(agent)
            out["shape"] = tuple(out["mu_q"].shape[:-1])
            out["has_q"] = True
        
        if need_p:
            out["mu_p"] = AgentAccessor.get_mu_p(agent)
            out["sigma_p"] = AgentAccessor.get_sigma_p(agent)
            if not need_q:
                out["shape"] = tuple(out["mu_p"].shape[:-1])
            out["has_p"] = True
        
        out["mask"] = AgentAccessor.get_mask_float(agent)
        
        return out


# ─────────────────────────────────────────────────────────────────────────
# Short Alias
# ─────────────────────────────────────────────────────────────────────────

AA = AgentAccessor

"""
Usage examples:

from core.agent_accessor import AA

# Identity
i_id = AA.get_id(agent)
level = AA.get_level(agent)
is_meta = AA.is_parent(agent)

# Spatial
mask = AA.get_mask(agent)  # bool
mask_float = AA.get_mask_float(agent)  # float32 as in Agent
Sshape = AA.get_spatial_shape(agent)

# Q-fiber
mu_q = AA.get_mu_q(agent)  # float32
sigma_q = AA.get_sigma_q(agent)  # float64, sanitized

# P-fiber
mu_p = AA.get_mu_p(agent)
sigma_p = AA.get_sigma_p(agent)

# Geometry
phi_q = AA.get_phi_q(agent)  # agent.phi
phi_p = AA.get_phi_p(agent)  # agent.phi_model

# Bulk
fields = AA.extract_fields(agent, need_q=True, need_p=True)
"""