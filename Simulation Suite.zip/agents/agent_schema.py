from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional
import numpy as np

@dataclass
class Agent:
    # ----------------------------------------------------------------------------------
    # Core identity & support
    # ----------------------------------------------------------------------------------
    id: int
    center: Tuple[int, ...]
    radius: float
    mask: np.ndarray                      # (S) float32 in [0,1]

    # ----------------------------------------------------------------------------------
    # Gauge fields (SO(3) algebra; last dim = 3)
    # ----------------------------------------------------------------------------------
    phi: np.ndarray                       # (S,3)
    phi_model: np.ndarray                 # (S,3)

    # ----------------------------------------------------------------------------------
    # Bundle fields (belief/model)
    # ----------------------------------------------------------------------------------
    mu_q_field: np.ndarray                # (S,Kq)
    sigma_q_field: np.ndarray             # (S,Kq,Kq)
    mu_p_field: np.ndarray                # (S,Kp)
    sigma_p_field: np.ndarray             # (S,Kp,Kp)
    
    x_obs: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Optional inverses (filled in preprocess)
    sigma_q_inv: Optional[np.ndarray] = field(default=None, init=False, repr=False)
    sigma_p_inv: Optional[np.ndarray] = field(default=None, init=False, repr=False)

    # Optional φ Fisher inverse blocks (d×d each; e.g., d=3 for so(3))
    inverse_fisher_phi: Optional[np.ndarray] = field(default=None, init=False, repr=False)         # (S,d,d)
    inverse_fisher_phi_model: Optional[np.ndarray] = field(default=None, init=False, repr=False)   # (S,d,d)

    # ----------------------------------------------------------------------------------
    # Morphisms (transported bundle maps; rebuilt in preprocess when dirty)
    # ----------------------------------------------------------------------------------
    
    morphisms_dirty: bool = field(default=True, init=False, repr=False)

    # ----------------------------------------------------------------------------------
    # Gradient buffers
    # ----------------------------------------------------------------------------------
    grad_mu_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)      # (S,Kq)
    grad_sigma_q: Optional[np.ndarray] = field(default=None, init=False, repr=False)   # (s,Kq,Kq)
    grad_mu_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)      # (s,Kp)
    grad_sigma_p: Optional[np.ndarray] = field(default=None, init=False, repr=False)   # (s,Kp,Kp)

    grad_phi: np.ndarray = field(init=False, repr=False)         
    grad_phi_tilde: np.ndarray = field(init=False, repr=False)    

       
    
    # ----------------------------------------------------------------------------------
    # Neighborhood / hierarchy
    # ----------------------------------------------------------------------------------
    neighbors: List[Dict[str, Any]] = field(default_factory=list)
    level: int = 0                                      # 0=child, >=1=parent
    parent_ids: List[int] = field(default_factory=list)
    child_ids: List[int] = field(default_factory=list)
    child_weights: Dict[int, float] = field(default_factory=dict, repr=False)
    labels: Dict[int, float] = field(default_factory=dict, repr=False)

    
    # Logging
    metrics_log: List[Dict[str, Any]] = field(default_factory=list)

    # ----------------------------------------------------------------------------------
    # Init hooks
    # ----------------------------------------------------------------------------------
    def __post_init__(self):
        self.grad_phi = np.zeros_like(self.phi, dtype=np.float32)
        self.grad_phi_tilde = np.zeros_like(self.phi_model, dtype=np.float32)

    # ----------------------------------------------------------------------------------
    # Tiny helpers
    # ----------------------------------------------------------------------------------
   

    def support(self, tau: float = 0.30) -> np.ndarray:
        return (np.asarray(self.mask, np.float32) > float(tau))

    def is_parent(self) -> bool:
        return int(getattr(self, "level", 0)) >= 1

    def is_active_parent(self, min_children: int = 2) -> bool:
        return self.is_parent() and len(getattr(self, "child_ids", ()) or ()) >= int(min_children)

    def log_metrics(self, step: int, stats: Dict[str, Any]) -> None:
        import copy
        self.metrics_log.append(copy.deepcopy({'step': int(step), **stats}))

    @property
    def spatial_shape(self):
        # mask may have channel-last singleton; strip it
        m = np.asarray(self.mask)
        return tuple(int(x) for x in m.shape if x > 1)[:len(m.shape)-(1 if m.ndim>=3 and m.shape[-1]==1 else 0)]
    
    @property
    def space_dim(self) -> int:
        return len(self.spatial_shape)
    
    # keep hw for back-compat, but route it through spatial_shape when 2-D
    @property
    def hw(self):
        S = self.spatial_shape
        if len(S) != 2:
            # fallback: return first two for legacy callers
            return (S[0], S[1]) if len(S) >= 2 else (S[0], 1)
        return S
