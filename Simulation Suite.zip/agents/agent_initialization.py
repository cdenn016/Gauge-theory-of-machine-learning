# -*- coding: utf-8 -*-
"""
Created on Thu Jul 24 17:54:26 2025

@author: chris and christine
"""
from scipy.ndimage import gaussian_filter
import config as config
import numpy as np
from agents.agent_schema import Agent
from agents.agent_accessor import AA
from numpy.random import default_rng  
from core.bundle_morphism_utils import build_intertwiner_bases, _ensure_q_to_p_shape, _ensure_p_to_q_shape
from core.omega import retract_phi_principal
from core.numerical_utils import sanitize_sigma  
from updates.gradient_utils import zero_all_gradients

def create_agent_mask_and_center(domain_size, rng, radius_range, fixed_center=None):
    radius = rng.uniform(*radius_range)
    center = fixed_center or tuple(rng.integers(0, s) for s in domain_size)
    # Return both float mask and a bool mask derived from the same cutoff rule
    mask, mask_bool = make_soft_mask(center, radius, domain_size, return_bool=True)
    return center, radius, mask, mask_bool

def ensure_stable_agent_ids(agents):
    """
    Ensure every agent has a deterministic dense integer id (0..N-1).
    Uses AA.get_id when present; assigns if missing/None/invalid.
    """
    for i, a in enumerate(agents):
        try:
            aid = AA.get_id(a)
        except Exception:
            aid = None
        if aid is None or not isinstance(aid, (int, np.integer)) or aid < 0:
            setattr(a, "id", int(i))





def initialize_agents(
    seed: int,
    domain_size: tuple[int, int],
    N: int,
    lie_algebra_dim: int,
    visualize: bool = False,
    fixed_location: bool = True,
    generators_q=None,
    generators_p=None,
    *,
    W_obs: np.ndarray,
    Lambda_obs: np.ndarray,
) -> list:
    """
    Initialize N agents over the given domain.

    With identical_models=True in config:
    - All agents share the SAME generative model parameters (mu_p, sigma_p, phi_model)
      cloned from agent 0.
    - Agents still get unique beliefs mu_q, unique phi (their local "pose"),
      unique spatial mask and unique x_obs.

    Always:
    - uses shared (W_obs, Lambda_obs) to generate a UNIQUE x_obs per agent
      and attaches that to each agent as agent.x_obs.
    """

    rng   = default_rng(seed)
    dtype = getattr(config, "dtype", np.float32)
    cfg   = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}

    # --- config / knobs ---
    phi_init         = cfg.get("phi_init")
    phi_model_offset = float(cfg.get("phi_model_offset", 0.1))
    max_neighbors    = int(cfg.get("max_neighbors", 8))
    overlap_eps      = float(cfg.get("overlap_eps", 1e-6))
    diagonal_sigma   = bool(cfg.get("diagonal_sigma", False))
    sigma_out_val    = float(cfg.get("sigma_outside_val", 1000.0))
    init_smooth_sig  = float(cfg.get("init_smooth_sigma", 2.0))

    # new flag: if True, reuse model params across agents
    identical_models = bool(cfg.get("identical_models", False))

    G_q = np.asarray(generators_q, dtype=np.float32)
    G_p = np.asarray(generators_p, dtype=np.float32)
    K_q = int(G_q.shape[1])
    K_p = int(G_p.shape[1])

    # sanity: W_obs should be (D_x, K_q)
    if W_obs.shape[1] != K_q:
        raise RuntimeError(
            f"W_obs has wrong K: expected {K_q}, got {W_obs.shape[1]}"
        )

    fixed_center = (
        (domain_size[0] // 2, domain_size[1] // 2)
        if fixed_location else None
    )

    agents: list = []

    # we'll cache the "shared model brain" after building agent 0
    shared_mu_p        = None
    shared_sigma_p     = None
    shared_phi_model   = None

    for n in range(N):
        # ---------------- geometry / support mask ----------------
        center, radius, mask, _ = create_agent_mask_and_center(
            domain_size, rng,
            radius_range=cfg.get("agent_radius_range", (5, 10)),
            fixed_center=fixed_center,
        )

        # ---------------- belief fields (agent-specific) ----------------
        mu_q, sigma_q = generate_mu_sigma_fields(
            domain_size=domain_size, rng=rng, K=K_q,
            mu_range=config.q_mu_range, sigma_range=config.q_sigma_range,
            mask=mask, sigma_outside_val=sigma_out_val,
            dtype=dtype, smooth_sigma=init_smooth_sig,
            diagonal_sigma=diagonal_sigma,
        )
        sigma_q = np.asarray(sigma_q, dtype=np.float64)

        # ---------------- model fields (may be shared) ----------------
        if (n == 0) or (not identical_models):
            # fresh sample for first agent or if we're not sharing
            mu_p, sigma_p = generate_mu_sigma_fields(
                domain_size=domain_size, rng=rng, K=K_p,
                mu_range=config.p_mu_range, sigma_range=config.p_sigma_range,
                mask=mask, sigma_outside_val=sigma_out_val,
                dtype=dtype, smooth_sigma=init_smooth_sig,
                diagonal_sigma=diagonal_sigma,
            )
            sigma_p = np.asarray(sigma_p, dtype=np.float64)

            # phi_model (the model's field / prior frame)
            phi, phi_model = initialize_phi_pair(
                domain_size, lie_algebra_dim, rng,
                phi_init, phi_model_offset, mask,
                smooth_sigma=getattr(config, "phi_init_smooth_sigma", 0.5),
                use_masked_blur=True,
            )
            phi       = retract_phi_principal(phi)
            phi_model = retract_phi_principal(phi_model)

            if identical_models:
                # cache copies so later agents reuse *exactly* these tensors
                shared_mu_p      = mu_p.astype(dtype, copy=True)
                shared_sigma_p   = np.asarray(sigma_p, dtype=np.float64).copy()
                shared_phi_model = phi_model.astype(dtype, copy=True)

        else:
            # reuse the cached "evolved model"
            # beliefs (mu_q etc.) are still agent-specific,
            # but priors / model fields are cloned bitwise
            if shared_mu_p is None or shared_sigma_p is None or shared_phi_model is None:
                raise RuntimeError(
                    "identical_models=True but shared model state was not cached from agent 0"
                )

            # clone so updates won't alias arrays between agents
            mu_p    = shared_mu_p.astype(dtype, copy=True)
            sigma_p = np.asarray(shared_sigma_p, dtype=np.float64).copy()

            # phi is still this agent's own current pose
            # but phi_model (the learned / generative field) comes from the shared brain
            phi, _ = initialize_phi_pair(
                domain_size, lie_algebra_dim, rng,
                phi_init, phi_model_offset, mask,
                smooth_sigma=getattr(config, "phi_init_smooth_sigma", 0.5),
                use_masked_blur=True,
            )
            phi       = retract_phi_principal(phi)
            phi_model = shared_phi_model.astype(dtype, copy=True)

        # ---------------- construct agent object ----------------
        agent = construct_agent_object(
            agent_id=int(n),
            center=center,
            radius=radius,
            mask=mask.astype(dtype, copy=False),
            mu_q=mu_q.astype(dtype, copy=False),
            sigma_q=sigma_q,
            mu_p=mu_p.astype(dtype, copy=False),
            sigma_p=sigma_p,
            phi=phi.astype(dtype, copy=False),
            phi_model=phi_model.astype(dtype, copy=False),
            dtype=dtype,
        )

        # shared gauge frame / generators
        agent.generators_q = G_q
        agent.generators_p = G_p

        # intertwiner maps (these are already aligned because G_q/G_p are shared)
        Phi_0_raw, Phi_tilde_0_raw, _ = build_intertwiner_bases(
            G_q, G_p,
            method="auto",
            return_meta=True,
            identity_if_square="always",
        )
        agent.Phi_0       = _ensure_q_to_p_shape(Phi_0_raw, K_p, K_q).astype(np.float32, copy=False)
        agent.Phi_tilde_0 = _ensure_p_to_q_shape(Phi_tilde_0_raw, K_q, K_p).astype(np.float32, copy=False)

        agent.morphisms_dirty = False
        zero_all_gradients(agent)

        # ---------------- private observations ----------------
        # Predict what this agent "would see" from its own μ_q
        y_pred0 = np.einsum("dk,...k->...d", W_obs, mu_q, optimize=True)  # (*S, D_x)

        # Per-agent noise + bias => different sensory worldviews
        noise = rng.normal(scale=0.1, size=y_pred0.shape).astype(dtype)
        agent_bias = rng.normal(scale=0.3, size=(1, 1, W_obs.shape[0])).astype(dtype)

        x_obs_agent = y_pred0 + noise + agent_bias  # (*S, D_x)
        agent.x_obs = x_obs_agent.astype(dtype, copy=False)

        agents.append(agent)

    ensure_stable_agent_ids(agents)

    assign_neighbors_simple(
        agents,
        overlap_eps=overlap_eps,
        max_neighbors=max_neighbors,
        symmetric=bool(cfg.get("neighbors_symmetric", True)),
    )

    return agents





def OLDinitialize_agents(
    seed: int,
    domain_size: tuple[int, int],
    N: int,
    lie_algebra_dim: int,
    visualize: bool = False,
    fixed_location: bool = True,
    generators_q=None,
    generators_p=None,
    *,
    W_obs: np.ndarray,
    Lambda_obs: np.ndarray,
) -> list:
    """
    Initialize N agents over the given domain.

    Now also:
    - uses shared (W_obs, Lambda_obs) to generate a UNIQUE x_obs per agent
      and attaches that to each agent as agent.x_obs.
    """

    rng   = default_rng(seed)
    dtype = getattr(config, "dtype", np.float32)
    cfg   = {k: getattr(config, k) for k in dir(config) if not k.startswith("__")}

    # --- config / knobs ---
    phi_init         = cfg.get("phi_init")
    phi_model_offset = float(cfg.get("phi_model_offset", 0.1))
    max_neighbors    = int(cfg.get("max_neighbors", 8))
    overlap_eps      = float(cfg.get("overlap_eps", 1e-6))
    diagonal_sigma   = bool(cfg.get("diagonal_sigma", False))
    sigma_out_val    = float(cfg.get("sigma_outside_val", 1000.0))
    init_smooth_sig  = float(cfg.get("init_smooth_sigma", 2.0))

    G_q = np.asarray(generators_q, dtype=np.float32)
    G_p = np.asarray(generators_p, dtype=np.float32)
    K_q = int(G_q.shape[1])
    K_p = int(G_p.shape[1])

    # sanity: W_obs should be (D_x, K_q)
    if W_obs.shape[1] != K_q:
        raise RuntimeError(
            f"W_obs has wrong K: expected {K_q}, got {W_obs.shape[1]}"
        )

    fixed_center = (domain_size[0] // 2, domain_size[1] // 2) if fixed_location else None
    agents: list = []

    for n in range(N):
        center, radius, mask, _ = create_agent_mask_and_center(
            domain_size, rng,
            radius_range=cfg.get("agent_radius_range", (5, 10)),
            fixed_center=fixed_center,
        )

        # --- Belief fields ---
        mu_q, sigma_q = generate_mu_sigma_fields(
            domain_size=domain_size, rng=rng, K=K_q,
            mu_range=config.q_mu_range, sigma_range=config.q_sigma_range,
            mask=mask, sigma_outside_val=sigma_out_val,
            dtype=dtype, smooth_sigma=init_smooth_sig,
            diagonal_sigma=diagonal_sigma,
        )
        sigma_q = np.asarray(sigma_q, dtype=np.float64)

        # --- Model fields ---
        mu_p, sigma_p = generate_mu_sigma_fields(
            domain_size=domain_size, rng=rng, K=K_p,
            mu_range=config.p_mu_range, sigma_range=config.p_sigma_range,
            mask=mask, sigma_outside_val=sigma_out_val,
            dtype=dtype, smooth_sigma=init_smooth_sig,
            diagonal_sigma=diagonal_sigma,
        )
        sigma_p = np.asarray(sigma_p, dtype=np.float64)

        # --- φ / φ̃ ---
        phi, phi_model = initialize_phi_pair(
            domain_size, lie_algebra_dim, rng, phi_init, phi_model_offset, mask,
            smooth_sigma=getattr(config, "phi_init_smooth_sigma", 0.5),
            use_masked_blur=True,
        )
        phi       = retract_phi_principal(phi)
        phi_model = retract_phi_principal(phi_model)

        # --- construct agent ---
        agent = construct_agent_object(
            agent_id=int(n),
            center=center,
            radius=radius,
            mask=mask.astype(dtype, copy=False),
            mu_q=mu_q.astype(dtype, copy=False),
            sigma_q=sigma_q,
            mu_p=mu_p.astype(dtype, copy=False),
            sigma_p=sigma_p,
            phi=phi.astype(dtype, copy=False),
            phi_model=phi_model.astype(dtype, copy=False),
            dtype=dtype,
        )

        agent.generators_q = G_q
        agent.generators_p = G_p

        Phi_0_raw, Phi_tilde_0_raw, _ = build_intertwiner_bases(
            G_q, G_p, method="auto", return_meta=True, identity_if_square="always"
        )
        agent.Phi_0       = _ensure_q_to_p_shape(Phi_0_raw, K_p, K_q).astype(np.float32, copy=False)
        agent.Phi_tilde_0 = _ensure_p_to_q_shape(Phi_tilde_0_raw, K_q, K_p).astype(np.float32, copy=False)

        agent.morphisms_dirty = False
        zero_all_gradients(agent)

        # -------------------------------------------------
        # NEW: generate this agent's private observation x_obs
        # -------------------------------------------------

        # y_pred0 = W_obs @ mu_q : (*S, D_x)
        y_pred0 = np.einsum("dk,...k->...d", W_obs, mu_q, optimize=True)

        # add per-agent noise and bias so each agent "saw" a different world
        noise = rng.normal(scale=0.1, size=y_pred0.shape).astype(dtype)
        agent_bias = rng.normal(scale=0.3, size=(1, 1, W_obs.shape[0])).astype(dtype)

        x_obs_agent = y_pred0 + noise + agent_bias  # (*S, D_x)

        agent.x_obs = x_obs_agent.astype(dtype, copy=False)

        agents.append(agent)

    ensure_stable_agent_ids(agents)

    assign_neighbors_simple(
        agents,
        overlap_eps=overlap_eps,
        max_neighbors=max_neighbors,
        symmetric=bool(cfg.get("neighbors_symmetric", False)),
    )

    return agents




def construct_agent_object(
    agent_id,
    center,
    radius,
    mask,
    mu_q, sigma_q,
    mu_p, sigma_p,
    phi, phi_model,
    dtype=np.float32
) -> Agent:
    """
    Build a level-0 Agent (no parents, no cross-scale maps yet).
    """
    a = Agent(
        id=agent_id,
        center=center,
        radius=radius,
        mask=mask.astype(dtype),

        mu_q_field=mu_q.astype(dtype),
        sigma_q_field=sigma_q.astype(np.float64),
        mu_p_field=mu_p.astype(dtype),
        sigma_p_field=sigma_p.astype(np.float64),

        phi=phi.astype(dtype),
        phi_model=phi_model.astype(dtype),

        neighbors=[],
    )
    # Ensure level-0 & empty relations
    a.level = 0
    a.parent_ids = []
    a.child_ids = []
        
    return a


def _logm_spd(S, eps=1e-12):
    """Symmetric log for SPD matrices; vectorized over leading dims."""
    import numpy as np
    S = 0.5 * (S + np.swapaxes(S, -1, -2))
    # float64 for stability
    w, V = np.linalg.eigh(S.astype(np.float64, copy=False))
    w = np.maximum(w, eps)
    L = (V * np.log(w)[..., None, :]) @ np.swapaxes(V, -1, -2)
    # keep symmetric
    return 0.5 * (L + np.swapaxes(L, -1, -2))

def _expm_spd(L):
    """Symmetric exp for SPD matrices in log domain; vectorized."""
    import numpy as np
    L = 0.5 * (L + np.swapaxes(L, -1, -2))
    w, V = np.linalg.eigh(L.astype(np.float64, copy=False))
    S = (V * np.exp(w)[..., None, :]) @ np.swapaxes(V, -1, -2)
    return 0.5 * (S + np.swapaxes(S, -1, -2))



def generate_mu_sigma_fields(
    domain_size,
    rng,
    K,
    mu_range,
    sigma_range,
    mask=None,
    sigma_outside_val=None,   # <- retained for compatibility; not used directly below
    dtype=np.float32,
    smooth_sigma=None,
    diagonal_sigma=None,
    eps=None,
    floor=None,
    *,
    cond0: float = 10,
    trace_match: bool = False,
):
    import numpy as np
    from scipy.ndimage import gaussian_filter

    # --- helpers (as you had) ---
    def blur_scalar_or_channels(arr, sigma):
        if mask is None:
            if arr.ndim == len(S):
                return gaussian_filter(arr, sigma=sigma, mode="wrap")
            out = np.empty_like(arr)
            tail = int(np.prod(arr.shape[len(S):])) or 1
            flat = arr.reshape(S + (tail,))
            for c in range(tail):
                out.reshape(S + (tail,))[..., c] = gaussian_filter(
                    flat[..., c], sigma=sigma, mode="wrap"
                )
            return out
        else:
            return masked_normalized_blur(arr, mask, sigma=sigma)

    # --- defaults ---
    eps = 1e-6 if eps is None else float(eps)
    smooth_sigma = 2.0 if smooth_sigma is None else float(smooth_sigma)
    diagonal_sigma = bool(False if diagonal_sigma is None else diagonal_sigma)

    # --- shapes / targets ---
    S = tuple(int(s) for s in domain_size)
    D = len(S)
    lo_s, hi_s = float(sigma_range[0]), float(sigma_range[1])
    target_scale = 0.5 * (lo_s + hi_s)
    target_trace = K * target_scale

    # --- μ field ---
    mu = rng.uniform(*mu_range, size=S + (K,)).astype(dtype)
    mu = blur_scalar_or_channels(mu, smooth_sigma)

    # --- build Σ_in (your existing logic) ---
    if diagonal_sigma:
        diag_raw = rng.uniform(lo_s, hi_s, size=S + (K,)).astype(dtype)
        diag_raw = blur_scalar_or_channels(diag_raw, smooth_sigma)
        lam_min = np.maximum(eps, diag_raw.min(axis=-1, keepdims=True))
        lam_min = np.maximum(lam_min, target_scale / max(cond0, 1.0))
        diag = np.clip(diag_raw, lam_min, lam_min * max(cond0, 1.0))
        if trace_match:
            tr_now = np.sum(diag, axis=-1, keepdims=True)
            diag = diag * (target_trace / np.maximum(tr_now, eps))
        sigma_in = np.zeros(S + (K, K), dtype=np.float64)
        for k in range(K):
            sigma_in[..., k, k] = diag[..., k].astype(np.float64, copy=False)
    else:
        B = rng.normal(0.0, 1.0, size=S + (K, K)).astype(dtype)
        for i in range(K):
            for j in range(K):
                B[..., i, j] = blur_scalar_or_channels(B[..., i, j], smooth_sigma)
        # polar / orthogonalize
        U, _, Vt = np.linalg.svd(B, full_matrices=False)
        Q = (U @ Vt).astype(np.float64, copy=False)
        detQ = np.linalg.det(Q)
        neg = detQ < 0
        if np.any(neg):
            U = U.copy()
            U[neg, :, -1] *= -1.0
            Q = (U @ Vt).astype(np.float64, copy=False)

        lam_min_base = rng.uniform(
            max(eps, lo_s / max(cond0, 1.0)),
            max(target_scale / max(cond0, 1.0), hi_s / max(cond0, 1.0)),
            size=S,
        ).astype(dtype)
        lam_min = blur_scalar_or_channels(lam_min_base, smooth_sigma)[..., None]
        lam_min = np.clip(lam_min, eps, None)
        u = rng.uniform(0.0, 1.0, size=S + (K,)).astype(dtype)
        r = (max(cond0, 1.0)) ** u
        lam = (lam_min * r).astype(np.float64, copy=False)
        if trace_match:
            tr_now = np.sum(lam, axis=-1, keepdims=True)
            lam = lam * (target_trace / np.maximum(tr_now, eps))
        sigma_in = (Q * lam[..., None, :]) @ np.swapaxes(Q, -1, -2)
        sigma_in = 0.5 * (sigma_in + np.swapaxes(sigma_in, -1, -2))

    # --- SPD sanitization inside (just in case) ---
    sigma_in = sanitize_sigma(sigma_in, eps=eps).astype(np.float64, copy=False)

    # --- PRINCIPLED OUTSIDE BEHAVIOR: log-Euclidean blend ---
    if mask is not None:
        # soft weight in [0,1]; if your mask is hard/binary, it's still fine
        w = mask.astype(np.float64)
        W = w.reshape(S + (1, 1))

        # choose a neutral outside SPD: scaled identity with target scale
        # (you can change sigma0 if you prefer a different neutral outside variance)
        sigma0 = float(target_scale)
        # log( sigma0 * I ) = (log sigma0) * I
        log_sigma0 = np.log(max(sigma0, eps))
        eyeK64 = np.eye(K, dtype=np.float64).reshape((1,) * D + (K, K))

        # log Σ_in per pixel
        Lin = _logm_spd(sigma_in, eps=max(eps, 1e-12))
        # convex combination in log domain
        L = (1.0 - W) * (log_sigma0 * eyeK64) + W * Lin
        # back to SPD
        sigma_field = _expm_spd(L)
        sigma_field = sanitize_sigma(sigma_field, eps=eps)  # final safety

        # μ “nonexistence” outside: taper by the same soft mask if desired
        mu = (w[..., None] * mu).astype(dtype, copy=False)
    else:
        sigma_field = sigma_in  # full-domain init, no blending

    # keep Σ in float64 for downstream Fisher/natural grads
    return mu.astype(dtype, copy=False), sigma_field














def masked_normalized_blur(x, m, sigma, eps_local=1e-6, mode="wrap"):
    """
    Soft-mask version (taper via m):
      y = [ blur(x*m) / blur(m) ] * m
    - Blur only over spatial axes, NOT across channels.
    - Uses float64 internally for stability, casts back to x.dtype at the end.
    - Final soft multiply is wrapped in errstate(under='ignore') so global
      seterr(under='raise') won't trip when m has tiny values.
    """
    import numpy as np
    from scipy.ndimage import gaussian_filter

    x = np.asarray(x)
    m = np.asarray(m)

    S_nd = m.ndim
    trailing = x.ndim - S_nd
    if trailing < 0:
        raise ValueError("mask must not have more dims than x")

    # Build sigma over all axes: blur spatial, no blur on channels
    if np.isscalar(sigma):
        sigma_full    = (float(sigma),) * S_nd + (0.0,) * trailing
        sigma_spatial = (float(sigma),) * S_nd
    else:
        sigma = tuple(float(s) for s in sigma)
        if len(sigma) != S_nd:
            raise ValueError(f"sigma length {len(sigma)} must match spatial dims {S_nd}")
        sigma_full    = sigma + (0.0,) * trailing
        sigma_spatial = sigma

    # Promote to float64 for stable filtering & masking
    x64 = x.astype(np.float64, copy=False)
    m64 = m.astype(np.float64, copy=False)

    m_expand64 = m64[(...,) + (None,) * trailing] if trailing > 0 else m64

    # Blur with periodic boundaries; guard divisions
    with np.errstate(under='ignore', over='ignore', invalid='ignore', divide='ignore'):
        num = gaussian_filter(x64 * m_expand64, sigma=sigma_full,    mode=mode)
        den = gaussian_filter(m64,               sigma=sigma_spatial, mode=mode)
        den_expand = den[(...,) + (None,) * trailing] if trailing > 0 else den
        y = num / np.maximum(den_expand, eps_local)

    # Soft taper via mask (in float64); ignore underflow on purpose here
    with np.errstate(under='ignore'):
        y = y * m_expand64

    return y.astype(x.dtype, copy=False)





# --- main initializers ---

def initialize_phi_field(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    init_scale: float,
    mask: np.ndarray,
    smooth_sigma: float | tuple[float, ...] | None = None,
    *,
    use_masked_blur: bool = False,
) -> np.ndarray:
    """
    Initialize and smooth a φ field with Gaussian noise and apply mask.
    Uses periodic blur by default for toroidal domains.
    """
    if lie_algebra_dim != 3:
        raise ValueError(f"SO(3) frames expect lie_algebra_dim=3, got {lie_algebra_dim}")

    dtype = getattr(config, "dtype", mask.dtype)
    sigma = smooth_sigma if (smooth_sigma is not None) else getattr(config, "phi_init_smooth_sigma", 0.5)

    phi_raw = rng.normal(scale=init_scale, size=(*domain_size, lie_algebra_dim)).astype(dtype)
    if use_masked_blur:
        phi_smooth = masked_normalized_blur(phi_raw, mask, sigma)
        # masked_normalized_blur already zeroes outside, so nothing else needed.
    else:
        phi_smooth = gaussian_filter(phi_raw, sigma=sigma, mode="wrap")
        phi_smooth *= mask[..., None]
    return phi_smooth
    
    return phi_smooth


def initialize_phi_pair(
    domain_size: tuple[int, ...],
    lie_algebra_dim: int,
    rng: np.random.Generator,
    phi_init: float,
    phi_model_offset: float,
    mask: np.ndarray,
    *,
    smooth_sigma: float | tuple[float, ...] | None = None,
    use_masked_blur: bool = False,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Initialize φ (belief) and φ̃ (model).
      - If config.identical_models: φ̃ = 0
      - Else: φ̃ = Smooth[ φ + R·ξ ], where R ~ SO(3) (adjoint) and ξ ~ N(0, φ_model_offset^2 I)
    """
    phi = initialize_phi_field(
        domain_size, lie_algebra_dim, rng, phi_init, mask,
        smooth_sigma=smooth_sigma, use_masked_blur=use_masked_blur
    )

    if getattr(config, "identical_models", False) or phi_model_offset == 0.0:
        print("USING IDENTITICAL model phi~")
        phi_model = np.zeros_like(phi)
        return phi, phi_model

    # perturb in the Lie algebra using a single adjoint rotation (global frame twist)
    delta = rng.normal(scale=phi_model_offset, size=(*domain_size, lie_algebra_dim)).astype(phi.dtype)

    # Adjoint action of SO(3) on so(3) ≅ R^3 is an ordinary rotation
    from scipy.spatial.transform import Rotation
    R = Rotation.random(random_state=rng).as_matrix()  # (3, 3)
    delta_rot = np.einsum("ab,...b->...a", R, delta)   # (...,3)

    phi_model_raw = phi + delta_rot

    if use_masked_blur:
        phi_model = masked_normalized_blur(
            phi_model_raw,
            mask,
            smooth_sigma or getattr(config, "phi_init_smooth_sigma", 0.5),
        )  # already zero outside
    else:
        phi_model = gaussian_filter(
            phi_model_raw,
            sigma=smooth_sigma or getattr(config, "phi_init_smooth_sigma", 0.5),
            mode="wrap",
        )
        phi_model *= mask[..., None]

    return phi, phi_model


def assign_neighbors_simple(
    agents,
    overlap_eps: float = 1e-6,
    *,
    symmetric: bool = True,
    max_neighbors: int | None = None,
    topk_margin: int = 8,
) -> None:
    """
    Two agents are neighbors iff their supports overlap at any site:
      support_i(x) = (mask_i(x) > overlap_eps), x ∈ *S (N-D grid)

    Builds: a.neighbors = [{"id": <neighbor_id>, "overlap": <count>}, ...]
    If max_neighbors is set, keep the top-K by overlap (ties broken by id).
    Note: with symmetric=True we require mutual nonzero overlap, but the
    top-K selection is still performed per-receiver (lists need not be identical).
    """
    import numpy as np
    from core.utils import mask_hw  

    if not agents:
        return

    # Flattened boolean supports once (N-D → 1-D)
    mvecs: list[np.ndarray] = []
    ids:   list[int] = []
    HW = None

    for a in agents:
        # Use AA to read mask and id (do not touch fields directly)
        mv = mask_hw(AA.get_mask_float(a), tau=overlap_eps, mode="vec")  # (HW,) bool
        if HW is None:
            HW = mv.shape[0]
        elif mv.shape[0] != HW:
            raise ValueError(f"All masks must share the same flattened size; got {mv.shape[0]} vs {HW}.")
        mvecs.append(mv.astype(np.int32, copy=False))  # int32 to avoid overflow in dot
        ids.append(int(AA.get_id(a)))

    ids_arr = np.asarray(ids, dtype=np.int64)
    M = np.stack(mvecs, axis=0)      # (N, HW) int32
    inter = (M @ M.T).astype(np.int64, copy=False)
    np.fill_diagonal(inter, 0)

    N = len(agents)
    for i in range(N):
        row = inter[i]
        js = np.flatnonzero(row > 0)
        if js.size == 0:
            agents[i].neighbors = []
            continue

        if symmetric:
            # keep only mutual overlaps
            js = js[inter[js, i] > 0]
            if js.size == 0:
                agents[i].neighbors = []
                continue

        if (max_neighbors is not None) and (js.size > max_neighbors):
            counts = row[js]
            # Overfetch to soften tie bias, then stable sort by (-overlap, id)
            k_fetch = min(js.size, max_neighbors + max(1, int(topk_margin)))
            part = np.argpartition(-counts, kth=k_fetch - 1)[:k_fetch]
            cands = js[part]
            counts_c = row[cands]
            ids_c    = ids_arr[cands]
            order = np.lexsort((ids_c, -counts_c))
            chosen = cands[order][:max_neighbors]
        else:
            counts = row[js]
            order = np.lexsort((ids_arr[js], -counts))
            chosen = js[order]

        agents[i].neighbors = [
            {"id": int(ids_arr[j]), "overlap": int(row[j])} for j in chosen.tolist()
        ]




def make_soft_mask(
    center, radius, domain_size, *,
    cutoff=None, dtype=None, return_bool=False, feather=None, soft_cut=True
):
    
    import config
    """
    N-D soft (Gaussian-like) mask on a periodic hypercube.
    m(x) = exp( - sum_d (δ_d / r_d)^2 ), with periodic min-image δ_d.

    radius semantics:
      r_d is the 1/e falloff along axis d (m=exp(-1) at |δ_d|=r_d).
      If you want m=cutoff at |δ|=R, use r = R / sqrt(log(1/cutoff)).
    """
    S = tuple(int(s) for s in domain_size)
    D = len(S)

    if dtype is None:
        dtype = getattr(config, "dtype", np.float64)

    if cutoff is None:
        cutoff = float(getattr(config, "support_tau", 1e-6))
    cutoff = float(cutoff)

    # center → length D, periodic
    if center is None:
        c = tuple(s // 2 for s in S)
    elif np.isscalar(center):
        c = (int(center),) * D
    else:
        c = tuple(int(x) for x in center)
        if len(c) < D:
            c = tuple(c) + tuple(S[i] // 2 for i in range(len(c), D))
        elif len(c) > D:
            c = tuple(c[:D])
    c = tuple((ci % si) for ci, si in zip(c, S))

    # radius → length D
    if np.isscalar(radius):
        r = (float(radius),) * D
    else:
        r = tuple(float(x) for x in radius)
        if len(r) < D:
            r = tuple(r) + (float(r[-1]),) * (D - len(r))
        elif len(r) > D:
            r = tuple(r[:D])
    eps = np.finfo(dtype).eps
    r = tuple(max(abs(x), eps) for x in r)

    grids = np.ogrid[tuple(slice(0, s) for s in S)]
    rho2 = 0.0
    for d in range(D):
        g = grids[d]
        sz = S[d]
        delta = np.abs(g - c[d])
        delta = np.minimum(delta, sz - delta)
        rho2 = rho2 + (delta / r[d])**2

    m = np.exp(-rho2, dtype=dtype).astype(dtype, copy=False)

    if soft_cut and cutoff > 0.0:
        delta_val = 0.5 * (1.0 - cutoff) if feather is None else min(0.49, float(feather))
        lo = max(0.0, cutoff - delta_val)
        hi = min(1.0, cutoff + delta_val)
        t = (m - lo) / max(1e-12, (hi - lo))
        t = np.clip(t, 0.0, 1.0)
        smooth = t*t*(3.0 - 2.0*t)
        m = m * smooth
    elif (not soft_cut) and cutoff > 0.0:
        m = np.where(m < cutoff, 0.0, m)

    m = m.astype(dtype, copy=False)
    if return_bool:
        return m, (m > cutoff)
    return m








        
