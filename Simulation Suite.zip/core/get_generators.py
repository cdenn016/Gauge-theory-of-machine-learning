from __future__ import annotations
import numpy as np
from typing import Iterable, List, Tuple, Dict


Array = np.ndarray
_generator_cache: Dict[tuple, tuple[np.ndarray, dict]] = {}




def get_generators(agent, which: str):
    """
    Return the agent's generator array for the requested side.
    Conventions: (3, K, K), float32.
    which ∈ {'q','p'}.
    """
    import numpy as np
    from core.utils import _aid
    
    if which == "q":
        attr = "generators_q"
    elif which == "p":
        attr = "generators_p"
    else:
        raise ValueError(f"get_generators: which must be 'q' or 'p', got {which!r}")

    G = getattr(agent, attr, None)
    
    if G is None:
        aid = _aid(agent)
        raise ValueError(f"[transport] {attr} missing on agent {aid!r}")

    A = np.asarray(G, dtype=np.float32)
    # Optional invariant check; keep if you want to fail fast on bad shapes:
    if A.ndim != 3 or A.shape[0] != 3 or A.shape[1] != A.shape[2]:
        raise ValueError(f"[transport] {attr} expected shape (3,K,K), got {A.shape}")
    return A

# ----------------------- Irrep construction (real tesseral basis) -----------------------

def so3_irrep(K: int) -> dict:
    if K % 2 == 0:
        raise ValueError("K must be odd for SO(3) irreps (K = 2ℓ + 1).")
    ℓ = (K - 1) // 2

    # Use complex128 for higher accuracy during basis transforms
    Jp = np.zeros((K, K), dtype=np.complex128)
    Jm = np.zeros((K, K), dtype=np.complex128)
    Jz = np.zeros((K, K), dtype=np.complex128)
    for m in range(-ℓ, ℓ + 1):
        i = m + ℓ
        Jz[i, i] = m
        if m < ℓ:
            a = np.sqrt((ℓ - m) * (ℓ + m + 1))
            Jp[i, i + 1] = a
            Jm[i + 1, i] = a
    Jx = (Jp + Jm) / 2.0
    Jy = (Jp - Jm) / (2.0j)

    # Complex->real tesseral transform (unitary), in complex128
    S = np.zeros((K, K), dtype=np.complex128)
    S[0, ℓ] = 1.0
    r = 1
    for m in range(1, ℓ + 1):
        phase = (-1) ** m
        S[r,   ℓ + m] = 1 / np.sqrt(2)
        S[r,   ℓ - m] = phase / np.sqrt(2)
        S[r+1, ℓ + m] = -1j / np.sqrt(2)
        S[r+1, ℓ - m] =  1j * phase / np.sqrt(2)
        r += 2
    Sinv = S.conj().T

    def real_skew(iJ):
        G = (S @ iJ @ Sinv).real
        return 0.5 * (G - G.T)  # enforce skew

    Gx = real_skew(1j * Jx)
    Gy = real_skew(1j * Jy)
    Gz = real_skew(1j * Jz)
    return {"E": Gx, "F": Gy, "H": Gz}



# ----------------------- Reducible assembly -----------------------

def make_reducible_generators(
    spec: Iterable[Tuple[int, int]],
    *,
    mix: bool = False,
    rng: np.random.Generator | None = None,
    dtype=np.float32,
    return_meta: bool = False,
):
    """
    Build generators G = (Gx, Gy, Gz) for a real reducible SO(3) rep.

    spec: iterable of (ell, multiplicity), ell>=0, multiplicity>=1
    """
    
    blocks: List[Array] = []
    total_dim = 0
    for ell, mult in spec:
        if ell < 0 or mult <= 0:
            raise ValueError(f"Invalid (ell,mult)=({ell},{mult}).")
        d = 2 * ell + 1
        Gi_dict = so3_irrep(d)
        Gi = np.stack([Gi_dict["E"], Gi_dict["F"], Gi_dict["H"]], axis=0).astype(np.float64, copy=False)
        for _ in range(mult):
            blocks.append(Gi)
            total_dim += d

    if total_dim == 0:
        raise ValueError("Empty spec: total dimension is zero.")

    # Block-diagonal (float64 for accurate traces)
    G = _block_diag_generators(blocks)  # (3, K, K) float64

    # Diagnostics BEFORE mixing
    block_dims = [b.shape[1] for b in blocks]
    bounds, o = [], 0
    for d in block_dims:
        bounds.append((o, o + d))
        o += d

    casimir_per_block = []
    for (lo, hi) in bounds:
        Gblk = G[:, lo:hi, lo:hi]
        casimir_per_block.append(casimir_scalar(Gblk))
    casimir_total = float(sum(casimir_per_block))

    # Sanity check vs spec
    expected_total = sum(m * (ell * (ell + 1)) for (ell, m) in spec)
   
    eps = 1e-8 * max(1.0, expected_total)
    if abs(casimir_total - expected_total) > eps:
        raise AssertionError(f"Casimir(total) mismatch: expected {expected_total}, got {casimir_total}")

    # Optional orthogonal mixing
    if mix:
        if rng is None:
            rng = np.random.default_rng()
        Q = _random_orthogonal(total_dim, rng=rng)
        for a in range(3):
            G[a] = Q @ G[a] @ Q.T

    # Cast and validate
    G = G.astype(dtype, copy=False)
    ok, resid = check_so3_relations(G, rtol=5e-6, atol=5e-7, return_resid=True)
    if not ok:
        raise RuntimeError(f"SO(3) commutator check failed, residual {resid:.3e}")

    if not return_meta:
        return G
    meta = {
        "blocks": block_dims,
        "spec": list(spec),
        "casimir_per_block": casimir_per_block,
        "casimir_total": casimir_total,
        }
    return G, meta


# ----------------------- Helpers -----------------------

def check_so3_relations(
    G: Array, *, rtol: float = 1e-7, atol: float = 1e-8, return_resid: bool = False
) -> bool | Tuple[bool, float]:
    Gx, Gy, Gz = G[0], G[1], G[2]
    errs = []
    errs.append(float(np.linalg.norm(Gx @ Gy - Gy @ Gx - Gz, ord="fro")))

    errs.append(float(np.linalg.norm(Gy @ Gz - Gz @ Gy - Gx, ord="fro")))
    errs.append(float(np.linalg.norm(Gz @ Gx - Gx @ Gz - Gy, ord="fro")))
    
    Gx_n = float(np.linalg.norm(Gx, ord="fro"))
    Gy_n = float(np.linalg.norm(Gy, ord="fro"))
    Gz_n = float(np.linalg.norm(Gz, ord="fro"))
    
    target_norm = max(Gx_n, Gy_n, Gz_n, 1.0)
    thresh = atol + rtol * target_norm
    ok = all(e <= thresh for e in errs)
    if return_resid:
        res = float(np.sqrt(sum(e * e for e in errs)))
        return ok, res
    return ok


def _block_diag_generators(blocks: List[Array]) -> Array:
    if not blocks:
        raise ValueError("No blocks to assemble.")
    sizes = [b.shape[1] for b in blocks]
    K = int(sum(sizes))
    G = np.zeros((3, K, K), dtype=np.float64)
    r0 = 0
    for b in blocks:
        d = b.shape[1]
        r1 = r0 + d
        for a in range(3):
            G[a, r0:r1, r0:r1] = b[a]
        r0 = r1
    return G

def _random_orthogonal(n: int, rng: np.random.Generator) -> Array:
    A = rng.standard_normal((n, n))
    Q, R = np.linalg.qr(A)
    s = np.sign(np.diag(R))
    s[s == 0] = 1.0
    Q = Q * s
    return Q

def casimir_operator(G: np.ndarray) -> np.ndarray:
    """C2 = -sum_a G_a G_a  (shape (K,K)); symmetric by construction."""
    import numpy as np
    G = np.asarray(G, np.float64)  # (3,K,K) or (d,K,K)
    d = G.shape[0]
    C = np.zeros((G.shape[1], G.shape[2]), dtype=np.float64)
    for a in range(d):
        C -= G[a] @ G[a]
    # numerical symmetrization
    return 0.5 * (C + C.T)

def casimir_scalar(G_block: np.ndarray) -> float:
    """
    Casimir eigenvalue c for a (possibly irrep) block:
    c = Tr( -sum_a G_a G_a ) / K
    G_block: (d, K, K) with d=3 for SO(3).
    """
    import numpy as np
    G = np.asarray(G_block, np.float64)
    d, K, K2 = G.shape
    assert K == K2, f"expected square blocks, got {G.shape}"
    s = -sum(np.trace(G[a] @ G[a]) for a in range(d))
    return float(s / K)



