# core/shared_cache.py
from __future__ import annotations

from pathlib import Path
from typing import Any
import numpy as np
import os, time,  uuid, pickle, hashlib, json



_REPLACE_RETRIES = 20
_REPLACE_SLEEP_S = 0.01

def _atomic_replace_with_retry(tmp_path: Path, final_path: Path):
    """Windows-friendly atomic replace with retry/backoff."""
    tmp_path = Path(tmp_path)
    final_path = Path(final_path)

    if final_path.exists():
        # Someone else won the race; cleanup tmp if present
        try: tmp_path.unlink(missing_ok=True)
        except Exception: pass
        return

    last_err = None
    for _ in range(_REPLACE_RETRIES):
        try:
            os.replace(str(tmp_path), str(final_path))  # atomic
            return
        except PermissionError as e:
            last_err = e
            if final_path.exists():
                try: tmp_path.unlink(missing_ok=True)
                except Exception: pass
                return
            time.sleep(_REPLACE_SLEEP_S)
        except FileExistsError:
            try: tmp_path.unlink(missing_ok=True)
            except Exception: pass
            return
        except OSError as e:
            last_err = e
            time.sleep(_REPLACE_SLEEP_S)

    if final_path.exists():
        try: tmp_path.unlink(missing_ok=True)
        except Exception: pass
        return
    raise last_err or PermissionError("Failed to atomically replace cache file.")







class SharedDiskCache:
    """
    Process-safe cache for arrays & small dicts (of arrays/scalars).
    - get(ns, key): returns np.memmap/np.ndarray or dict
    - put(ns, key, val): atomic write
    """
    def __init__(self, root: str | os.PathLike):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _digest(ns: str, key: Any) -> str:
        try:
            b = pickle.dumps((ns, key), protocol=pickle.HIGHEST_PROTOCOL)
        except Exception:
            b = repr((ns, key)).encode("utf-8")
        return hashlib.sha1(b).hexdigest()

    def _paths(self, ns: str, key: Any):
        h = self._digest(ns, key)
        d = self.root / ns / h[:2] / h[2:4]
        return {
            "dir": d,
            "meta": d / f"{h}.json",
            "npy":  d / f"{h}.npy",
            "npz":  d / f"{h}.npz",
            "pkl":  d / f"{h}.pkl",
        }

    def get(self, ns: str, key: Any):
        p = self._paths(ns, key)
        if not p["dir"].exists():
            return None
        if p["npy"].exists():
            try:
                return np.load(p["npy"], mmap_mode="r")  # read-only memmap
            except Exception:
                return None
        if p["npz"].exists():
            try:
                z = np.load(p["npz"], mmap_mode="r")
                out = {k: z[k] for k in z.files}
                # unbox scalars saved as __sc_*
                for k in list(out.keys()):
                    if k.startswith("__sc_"):
                        out[k[5:]] = out.pop(k).item()
                return out
            except Exception:
                return None
        if p["pkl"].exists():
            try:
                with open(p["pkl"], "rb") as f:
                    return pickle.load(f)
            except Exception:
                return None
        return None

    def put(self, ns: str, key: Any, val: Any):
        p = self._paths(ns, key)
        p["dir"].mkdir(parents=True, exist_ok=True)
    
        # ---- ndarray -> .npy ----
        if isinstance(val, np.ndarray):
            if p["npy"].exists():
                return  # already written
            # IMPORTANT: temp must end with .npy so np.save doesn't append
            tmp_path = Path(p["dir"]) / f"{uuid.uuid4().hex}.npy"
            # write
            np.save(str(tmp_path), val, allow_pickle=False)
            # atomic replace to final
            _atomic_replace_with_retry(tmp_path, p["npy"])
            self._write_meta(p, kind="npy", shape=tuple(val.shape), dtype=str(val.dtype))
            return
    
        # ---- dict of arrays/scalars -> .npz ----
        if isinstance(val, dict) and all(isinstance(v, (np.ndarray, np.number, float, int)) for v in val.values()):
            if p["npz"].exists():
                return
            arrays  = {k: v for k, v in val.items() if isinstance(v, np.ndarray)}
            scalars = {f"__sc_{k}": np.array(v) for k, v in val.items() if not isinstance(v, np.ndarray)}
            # temp must end with .npz so np.savez doesn't append
            tmp_path = Path(p["dir"]) / f"{uuid.uuid4().hex}.npz"
            np.savez(str(tmp_path), **arrays, **scalars)
            _atomic_replace_with_retry(tmp_path, p["npz"])
            self._write_meta(p, kind="npz", keys=list(val.keys()))
            return
    
        # ---- fallback pickle (small Python objects) -> .pkl ----
        if p["pkl"].exists():
            return
        tmp_path = Path(p["dir"]) / f"{uuid.uuid4().hex}.pkl"
        with open(tmp_path, "wb") as f:
            pickle.dump(val, f, protocol=pickle.HIGHEST_PROTOCOL)
        _atomic_replace_with_retry(tmp_path, p["pkl"])
        self._write_meta(p, kind="pkl")


    def nsp(self, ns: str):
        cache = self
        class _NS:
            def __init__(self, ns): self._ns = ns
            def get(self, key): return cache.get(self._ns, key)
            def __setitem__(self, key, val): cache.put(self._ns, key, val)
            def __getitem__(self, key):
                v = cache.get(self._ns, key)
                if v is None: raise KeyError(key)
                return v
        return _NS(ns)

    def _write_meta(self, paths, **meta):
        try:
            with open(paths["meta"], "w") as f:
                json.dump(meta, f)
        except Exception:
            pass
    # --- optional maintenance -------------------------------------------------
    def clear_on_step(self, step_now: int):
        """
        Compatibility no-op. Old caches purged per-step entries.
        With a content-addressed disk cache (keys include step in most call sites),
        obsolete entries naturally stop being hit. Keep this as a stub so callers
        like synchronous_step(...) don't crash.
        """
        return
    
    def clear_namespace(self, ns: str):
        """Delete an entire namespace directory on disk (manual maintenance)."""
        p = self.root / ns
        if p.exists():
            # best-effort, ignore errors
            try:
                import shutil
                shutil.rmtree(p)
            except Exception:
                pass
    
    def clear_all(self):
        """Dangerous: wipe all cached files."""
        try:
            import shutil
            shutil.rmtree(self.root)
        except Exception:
            pass
        self.root.mkdir(parents=True, exist_ok=True)


    


