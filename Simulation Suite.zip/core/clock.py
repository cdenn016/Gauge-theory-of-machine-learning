
# updates/clock.py
from __future__ import annotations
import numpy as np
from core.runtime_context import cfg_get, ensure_clock_defaults



def update_intrinsic_clock(
    ctx,
    children,
    q_updates,
    p_updates,
    phi_grads,
    phi_m_grads,
    A_bucket=None,
    *,
    measure_in_bits: bool = True,  # if True, convert nats→bits so 1 unit ≡ 1 bit of inference
) -> float:
    """
    Compute and accumulate the intrinsic 'inference time' increment for this step.

    Args:
      ctx: runtime_ctx
      children: list of agents
      q_updates: iterable of (dmu_q, dS_q) per agent
      p_updates: iterable of (dmu_p, dS_p) per agent
      phi_grads: iterable of so(3) algebra steps per agent (already in descent direction)
      phi_m_grads: iterable of so(3) algebra steps per agent for φ̃
      A_bucket: optional dict containing 'dA' map for global A descent direction
      measure_in_bits: if True, convert the natural-time increment from nats to bits

    Returns:
      dt_clock (float): the increment added to ctx.clock_t
    """
    ensure_clock_defaults(ctx)

    ccfg   = ctx.clock_cfg
    eps    = float(ccfg.get("eps", 1e-8))
    agg    = str(ccfg.get("aggregate", "max_agent_mean"))
    w_mu   = float(ccfg.get("w_mu", 1.0))
    w_S    = float(ccfg.get("w_S", 1.0))
    w_phi  = float(ccfg.get("w_phi", 1.0))
    w_tphi = float(ccfg.get("w_tphi", 1.0))
    w_A    = float(ccfg.get("w_A", 0.5))

    dt_mu_q = float(cfg_get(ctx, "tau_mu_belief", 1e-2))
    dt_S_q  = float(cfg_get(ctx, "tau_sigma_belief", 1e-2))
    dt_mu_p = float(cfg_get(ctx, "tau_mu_model", 1e-2))
    dt_S_p  = float(cfg_get(ctx, "tau_sigma_model", 1e-2))
    dt_phi  = float(cfg_get(ctx, "tau_phi", 1e-2))
    dt_tphi = float(cfg_get(ctx, "tau_phi_model", 1e-2))
    dt_A    = float(cfg_get(ctx, "A_lr", 1e-3))

    acc_mu_q = []; acc_S_q = []; acc_mu_p = []; acc_S_p = []; acc_phi = []; acc_tphi = []

    for ai, uq, up, gphi, gtphi in zip(children, q_updates, p_updates, phi_grads, phi_m_grads):
        dmu_q, dS_q = uq
        dmu_p, dS_p = up
        mask = np.asarray(ai.mask, np.bool_)  # (...,)

        # belief gaussian speed
        v_mu_q = gaussian_speed(dmu_q, 0.0*dS_q, ai.sigma_q_field, eps=eps, w_mu=w_mu, w_S=0.0, mask=mask)
        v_S_q  = gaussian_speed(0.0*dmu_q, dS_q,  ai.sigma_q_field, eps=eps, w_mu=0.0, w_S=w_S, mask=mask)

        # model gaussian speed
        v_mu_p = gaussian_speed(dmu_p, 0.0*dS_p, ai.sigma_p_field, eps=eps, w_mu=w_mu, w_S=0.0, mask=mask)
        v_S_p  = gaussian_speed(0.0*dmu_p, dS_p,  ai.sigma_p_field, eps=eps, w_mu=0.0, w_S=w_S, mask=mask)

        # lie (φ, φ̃)
        v_phi  = lie_speed(0.0 if gphi  is None else gphi,  mask=mask)
        v_tphi = lie_speed(0.0 if gtphi is None else gtphi, mask=mask)

        # reduce per agent (mean over mask)
        acc_mu_q.append(field_reduce(v_mu_q, mask, mode="mean_agent_mean"))
        acc_S_q .append(field_reduce(v_S_q,  mask, mode="mean_agent_mean"))
        acc_mu_p.append(field_reduce(v_mu_p, mask, mode="mean_agent_mean"))
        acc_S_p .append(field_reduce(v_S_p,  mask, mode="mean_agent_mean"))
        acc_phi .append(field_reduce(v_phi,  mask, mode="mean_agent_mean"))
        acc_tphi.append(field_reduce(v_tphi, mask, mode="mean_agent_mean"))

    def _agg(xs):
        return max(xs) if agg == "max_agent_mean" else (sum(xs)/max(1,len(xs)))

    v_mu_q = _agg(acc_mu_q); v_S_q = _agg(acc_S_q)
    v_mu_p = _agg(acc_mu_p); v_S_p = _agg(acc_S_p)
    v_phi  = _agg(acc_phi);  v_tphi = _agg(acc_tphi)

    # optional A term
    v_A = 0.0
    if bool(cfg_get(ctx, "use_global_A", True)) and isinstance(A_bucket, dict) and "dA" in A_bucket:
        gA = np.asarray(A_bucket["dA"], np.float32)
        vA_map = np.linalg.norm(gA.reshape(gA.shape[:-1]+(-1,)), axis=-1)
        v_A = float(np.mean(vA_map))

    # time increment (nats)
    dt_clock = (
        dt_mu_q * v_mu_q + dt_S_q * v_S_q +
        dt_mu_p * v_mu_p + dt_S_p * v_S_p +
        dt_phi  * w_phi  * v_phi +
        dt_tphi * w_tphi * v_tphi +
        dt_A    * w_A    * v_A
    )

    # convert to bits if requested (so 1 unit ≡ 1 bit)
    if measure_in_bits:
        dt_clock *= (1.0 / np.log(2.0))

    ctx.clock_t = float(getattr(ctx, "clock_t", 0.0)) + float(dt_clock)
    ctx.clock_last = {
        "v_mu_q": v_mu_q, "v_S_q": v_S_q, "v_mu_p": v_mu_p, "v_S_p": v_S_p,
        "v_phi": v_phi, "v_tphi": v_tphi, "v_A": v_A,
        "dt_increment": float(dt_clock), "t": float(ctx.clock_t),
        "units": "bits" if measure_in_bits else "nats",
    }
    return float(dt_clock)













def _eigh_sandwich_mats(S, eps):
    S = 0.5*(S + S.swapaxes(-1,-2))
    w, V = np.linalg.eigh(S.astype(np.float64))
    w = np.clip(w, eps, None)
    S12  = (V * np.sqrt(w)[...,None,:]) @ V.swapaxes(-1,-2)
    Smin = (V * (1.0/np.sqrt(w))[...,None,:]) @ V.swapaxes(-1,-2)
    return S12.astype(np.float32), Smin.astype(np.float32)

def gaussian_speed(mu_delta, S_delta, S, *, eps=1e-8, w_mu=1.0, w_S=1.0, mask=None):
    """
    v^2 = w_mu * || Σ^{1/2} Δμ ||^2  +  w_S * || Σ^{-1/2} ΔΣ Σ^{-1/2} ||_F^2
    Returns per-site scalar speed (...,).
    """
    mu_delta = np.asarray(mu_delta, np.float32)              # (...,K)
    S_delta  = np.asarray(S_delta,  np.float32)              # (...,K,K)
    S        = np.asarray(S,        np.float32)              # (...,K,K)
    S12, Smin = _eigh_sandwich_mats(S, eps)

    x = S12 @ mu_delta[..., None]                            # (...,K,1)
    mu_term = np.sum(np.squeeze(x, -1)**2, axis=-1)          # (...,)

    T = Smin @ S_delta @ Smin                                # (...,K,K)
    S_term = np.sum((T.reshape(T.shape[:-2]+(-1,)))**2, axis=-1)

    v2 = w_mu * mu_term + w_S * S_term                       # (...)
    if mask is not None:
        v2 = np.where(mask.astype(bool), v2, 0.0)
    return np.sqrt(np.maximum(v2, 0.0)).astype(np.float32)

def lie_speed(vec, mask=None):
    """
    For φ/φ̃ in so(3) with identity metric on algebra (post J^{-1}/Fisher projection).
    vec: (...,3)
    """
    v = np.linalg.norm(np.asarray(vec, np.float32), axis=-1) # (...,)
    if mask is not None:
        v = np.where(mask.astype(bool), v, 0.0)
    return v.astype(np.float32)

def field_reduce(v_map, mask=None, mode="mean_agent_mean"):
    """
    Reduce a per-site speed map to a scalar per-agent.
    - "mean_agent_mean": mean over masked sites.
    - "max_agent_mean":  mean over masked sites per agent, then take max over agents.
    """
    v = np.asarray(v_map, np.float32)
    if mask is not None:
        m = mask.astype(bool)
        denom = np.maximum(1, np.count_nonzero(m))
        v_agent = np.sum(v * m) / float(denom)
    else:
        v_agent = float(np.mean(v))
    return float(v_agent)
