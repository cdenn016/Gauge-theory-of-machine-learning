# -*- coding: utf-8 -*-
"""
Created on Sun Aug 24 13:40:38 2025

@author: chris and christine
"""

