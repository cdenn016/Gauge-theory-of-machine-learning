
from __future__ import annotations
import numpy as np
from typing import Dict,Tuple, Optional

from core.get_generators import casimir_operator

# =============================================================================
#                            Morphism field generators
# =============================================================================



def _ensure_q_to_p_shape(X, Kp, Kq):
    """Φ0: q→p must be (Kp, Kq). Auto-transpose if (Kq, Kp)."""
    X = np.asarray(X, np.float32)
    if X.shape == (Kp, Kq): return X
    if X.shape == (Kq, Kp): return X.T
    raise ValueError(f"Φ0 wrong shape {X.shape}; expected {(Kp, Kq)} or {(Kq, Kp)}")

def _ensure_p_to_q_shape(X, Kq, Kp):
    """Φ̃0: p→q must be (Kq, Kp). Auto-transpose if (Kp, Kq)."""
    X = np.asarray(X, np.float32)
    if X.shape == (Kq, Kp): return X
    if X.shape == (Kp, Kq): return X.T
    raise ValueError(f"Φ̃0 wrong shape {X.shape}; expected {(Kq, Kp)} or {(Kp, Kq)}")





def _canon_generators(G):
    # accept (3,K,K) or (K,K,3); return (3,K,K), float64
    G = np.asarray(G)
    if G.ndim != 3:
        raise ValueError("Generators must be rank-3: (3,K,K) or (K,K,3).")
    if G.shape[0] != 3 and G.shape[-1] == 3:
        G = np.moveaxis(G, -1, 0)
    if G.shape[0] != 3:
        raise ValueError("First axis must have length 3 after normalization.")
    G = G.astype(np.float64, copy=False)
    # optional: enforce antisymmetry softly
    G = 0.5 * (G - np.swapaxes(G, -1, -2))
    return G

def _morph_finalize_and_check(ctx, Gq, Gp, Phi0_in, Phit0_in, *, Kq: int, Kp: int):
    """
    Normalize types/shapes, sanity-check finiteness/nonzero, optional residual note.
    Returns (Phi0, Phit0) as float32 with shapes (Kp,Kq) and (Kq,Kp).
    """
    import numpy as np
    from core.runtime_context import cfg_get
    
    
    Phi0  = _ensure_q_to_p_shape(np.asarray(Phi0_in),  Kp, Kq).astype(np.float32, copy=False)
    Phit0 = _ensure_p_to_q_shape(np.asarray(Phit0_in), Kq, Kp).astype(np.float32, copy=False)

    if not (np.isfinite(Phi0).all() and np.isfinite(Phit0).all()):
        raise ValueError("[morph] Φ0/Φ̃0 contain non-finite values")
    # forbid identically-zero bases
    if max(np.linalg.norm(Phi0, 'fro'), np.linalg.norm(Phit0, 'fro')) == 0.0:
        raise ValueError("[morph] Φ0/Φ̃0 are zero")

    # Optional residual check (non-fatal, once per call-site)
    tol_rel = float(cfg_get(ctx, "intertwiner_rel_tol", 1e-7))
    try:
        r1 = _intertwining_resid(Gp, Gq, Phi0)    # || Gp Φ0 - Φ0 Gq ||
        r2 = _intertwining_resid(Gq, Gp, Phit0)   # || Gq Φ̃0 - Φ̃0 Gp ||
        scale = max(np.linalg.norm(Gq, 'fro'), np.linalg.norm(Gp, 'fro'), 1.0)
        rel = (r1 + r2) / (1e-6 + scale)
        if rel > tol_rel:
            print(f"[morph] note: relative intertwiner residual ≈ {rel:.2e}")
    except Exception:
        pass

    return Phi0, Phit0


def _intertwining_resid(G_left, G_right, X):
    """
    Residual || G_left[a] X - X G_right[a] ||_F summed over a=0..2.
    Shapes: G_left(Kout,Kout,3), G_right(Kin,Kin,3), X(Kout,Kin)
    """
    
    X  = np.asarray(X, np.float32)
    Kout = G_left.shape[0]; Kin = G_right.shape[0]
    if X.shape != (Kout, Kin):
        raise ValueError(f"X has shape {X.shape}, expected {(Kout, Kin)}")
    r = 0.0
    for a in range(3):
        r += float(np.linalg.norm(G_left[..., a] @ X - X @ G_right[..., a]))
    return r




def build_intertwiner_bases(
    G_q: np.ndarray,
    G_p: np.ndarray,
    *,
    method: str = "auto",
    data: Optional[Dict[str, np.ndarray]] = None,
    l_tol: float = 1e-6,
    nullspace_tol: float = 1e-9,
    max_rank: Optional[int] = None,
    return_meta: bool = False,
    on_hom0: str = "zero",
    # NEW:
    identity_if_square: str = "safe",   # {"never","always","safe"}
    identity_tol: float = 1e-8,         # used when identity_if_square=="safe"
) -> Tuple[np.ndarray, np.ndarray, Optional[dict]]:
    """
    Returns (Phi0, Phit0[, meta]) between two real SO(3) reps (3,K,K) each.
    NEW: if K_q == K_p and identity_if_square != "never", optionally return
         identity bases immediately.
         - "always": Phi0 = I, Phit0 = I when Kq==Kp
         - "safe":   do it only if G_q and G_p are numerically equal (≈)
    """
    method = method.lower()
    if method not in ("casimir", "casimir_strict", "nullspace", "auto"):
        method = "casimir"

    def _hom0_return(Kp: int, Kq: int, *, reason: str):
        meta = {"hom_dim": 0, "matches": [], "reason": reason, "dims": {"Kq": Kq, "Kp": Kp}}
        if on_hom0 == "raise":
            raise ValueError(f"No nonzero intertwiner: {reason} (Kq={Kq}, Kp={Kp})")
        Phi0 = np.zeros((Kp, Kq), dtype=np.float32)
        Phit0 = np.zeros((Kq, Kp), dtype=np.float32)
        return Phi0, Phit0, meta

    # --- canonicalize to (3,K,K), float64 ---
    G_q = _canon_generators(G_q)
    G_p = _canon_generators(G_p)
    Kq, Kp = G_q.shape[-1], G_p.shape[-1]

    # --- NEW: identity shortcut when square ---
    if Kq == Kp and identity_if_square != "never":
        use_identity = (identity_if_square == "always")
        if identity_if_square == "safe":
            # only use I if reps are already in the same basis (numerically equal)
            use_identity = np.allclose(G_q, G_p, rtol=0.0, atol=identity_tol)

        if use_identity:
            
            I = np.eye(Kq, dtype=np.float32)
            meta = {"hom_dim": Kq, "matches": "identity", "reason": "square_identity",
                    "dims": {"Kq": Kq, "Kp": Kp}}
            return I, I.T, (meta if return_meta else None)


    # 1) Casimir
    if method in ("casimir", "casimir_strict", "auto"):
        Phi0, meta = _build_intertwiner_casimir(G_q, G_p, data=data, l_tol=l_tol, max_rank=max_rank)
        if Phi0 is not None:
            Phit0, Phi0 = _choose_tilde_from_base_safe(Phi0)
            out_meta = meta if return_meta else None
            return (Phi0, Phit0, out_meta)

        if method == "casimir_strict":
            return _hom0_return(Kp, Kq, reason="no_shared_ell_casimir")

        # 2) Fallback: exact nullspace only
        Phi0_ns, meta_ns = _build_intertwiner_nullspace(G_q, G_p, data=data, tol=nullspace_tol, max_rank=max_rank)
        if meta_ns.get("hom_dim", 0) > 0:
            Phit0_ns, Phi0_ns = _choose_tilde_from_base_safe(Phi0_ns)
            out_meta = meta_ns if return_meta else None
            return (Phi0_ns, Phit0_ns, out_meta)

        return _hom0_return(Kp, Kq, reason="no_shared_ell_and_nullspace_empty")

    if method == "nullspace":
        Phi0_ns, meta_ns = _build_intertwiner_nullspace(G_q, G_p, data=data, tol=nullspace_tol, max_rank=max_rank)
        if meta_ns.get("hom_dim", 0) == 0:
            return _hom0_return(Kp, Kq, reason="nullspace_empty")
        Phit0_ns, Phi0_ns = _choose_tilde_from_base_safe(Phi0_ns)
        out_meta = meta_ns if return_meta else None
        return (Phi0_ns, Phit0_ns, out_meta)


def _choose_tilde_from_base_safe(Phi0, *, rcond=1e-8, clip_opnorm=1.0):
    """
    Return (Φ̃, Φ0) with Φ̃ ≈ left-pinv(Φ0). Caps operator norms if requested.
    Always returns exactly two arrays.
    """
    Phi0 = np.asarray(Phi0, np.float64, order="C")
    U, s, Vt = np.linalg.svd(Phi0, full_matrices=False)

    keep = s > (rcond * s.max() if s.size else 0.0)
    if not np.any(keep):
        Phit_z = np.zeros((Phi0.shape[1], Phi0.shape[0]), dtype=np.float32)
        Phi0_z = np.zeros_like(Phi0, dtype=np.float32)
        return Phit_z, Phi0_z

    s_inv = np.zeros_like(s)
    s_inv[keep] = 1.0 / s[keep]
    Phit = (Vt.T * s_inv) @ U.T

    if clip_opnorm is not None:
        def _opnorm(A):
            return np.linalg.svd(A, compute_uv=False)[0] if A.size else 0.0
        nP, nPt = _opnorm(Phi0), _opnorm(Phit)
        scale = 1.0
        if nP  > clip_opnorm: scale = min(scale, clip_opnorm / nP)
        if nPt > clip_opnorm: scale = min(scale, clip_opnorm / nPt)
        if scale < 1.0:
            Phi0 = scale * Phi0
            Phit = scale * Phit

    return Phit.astype(np.float32, copy=False), Phi0.astype(np.float32, copy=False)



# --------------------------- Casimir (ℓ-block) path -------------------------------

def _build_intertwiner_casimir(G_q, G_p, *, data=None, l_tol=1e-6, max_rank=None):
    
   
    Cq = casimir_operator(G_q); λq, Wq = np.linalg.eigh(Cq)
    Cp = casimir_operator(G_p); λp, Wp = np.linalg.eigh(Cp)

    # NEW: use rel-tol degeneracy clustering (scale-invariant)
    blocks_q = _cluster_into_l_blocks(λq, Wq, rel_tol=1e-4)
    blocks_p = _cluster_into_l_blocks(λp, Wp, rel_tol=1e-4)

    # Match blocks by d (2l+1); don’t rely on absolute λ
    by_dim_q = {}
    for b in blocks_q.values():
        by_dim_q.setdefault(b["d"], []).append(b["W"])
    by_dim_p = {}
    for b in blocks_p.values():
        by_dim_p.setdefault(b["d"], []).append(b["W"])

    common_ds = sorted(set(by_dim_q.keys()).intersection(by_dim_p.keys()))
    if not common_ds:
        return (None, {"reason": "no_l_overlap"})  # will be handled by caller

    Kq = G_q.shape[-1]; Kp = G_p.shape[-1]
    Phi0 = np.zeros((Kp, Kq), dtype=np.float64)
    meta = {"used_dims": [], "rank_by_dim": {}, "path": "casimir"}

    # Optional data-aware mixing on multiplicities can be kept as before.
    for d in common_ds:
        Q_list = by_dim_q[d]   # each (Kq, m_q*d) with orthonormal cols
        P_list = by_dim_p[d]   # each (Kp, m_p*d)
        # concatenate copies -> treat multiplicity collectively
        Wq_d = np.concatenate(Q_list, axis=1)
        Wp_d = np.concatenate(P_list, axis=1)
        # multiplicities
        m_q = Wq_d.shape[1] // d
        m_p = Wp_d.shape[1] // d
        m   = min(m_q, m_p)
        if m == 0:
            continue
        # split into per-copy blocks
        Q_blocks = [Wq_d[:, i*d:(i+1)*d] for i in range(m_q)]
        P_blocks = [Wp_d[:, i*d:(i+1)*d] for i in range(m_p)]
        # identity mixer on multiplicities (orthogonal per copy)
        for i in range(m):
            Phi0 += P_blocks[i] @ Q_blocks[i].T
        meta["used_dims"].append(d)
        meta["rank_by_dim"][d] = m * d

    if max_rank is not None:
        Phi0 = _best_rank_approx(Phi0, rank=max_rank)

    return (Phi0, meta)


# ------------------------------ Nullspace path -----------------------------------

def _build_intertwiner_nullspace(G_q: np.ndarray, G_p: np.ndarray, *, tol: float = 1e-9,
                                 data: Optional[Dict[str, np.ndarray]] = None,
                                 max_rank: Optional[int] = None) -> Tuple[np.ndarray, dict]:
    
    Kq, Kp = G_q.shape[-1], G_p.shape[-1]
    Iq = np.eye(Kq); Ip = np.eye(Kp)
    rows = []
    for a in range(3):
        A = np.kron(Iq, G_p[a]) - np.kron(G_q[a].T, Ip)
        rows.append(A)
    M = np.concatenate(rows, axis=0)

    # Nullspace via SVD
    U, S, Vh = np.linalg.svd(M, full_matrices=False)
    mask = (S <= tol)
    if not np.any(mask):
        # numerically tiny but nonzero; take the smallest singular vector
        basis = Vh[-1:, :]
    else:
        basis = Vh[mask, :]        # (m, Kp*Kq)
    # Orthonormalize nullspace basis vectors (Frobenius) via QR
    Q, _ = np.linalg.qr(basis.T)   # (Kp*Kq, m) -> Q has orthonormal columns
    B = Q                          # (Kp*Kq, m_eff)

    # Default: pick the first basis vector -> simplest nonzero intertwiner
    coeff = np.zeros((B.shape[1],), dtype=np.float64)
    coeff[0] = 1.0

    # Data-aware LS in span(B): minimize Σ ||Φ0 μ_q - μ_p||_2^2
    if data is not None:
        mu_q = np.asarray(data.get("mu_q", None))
        mu_p = np.asarray(data.get("mu_p", None))
        if mu_q is not None and mu_q.size and mu_p is not None and mu_p.size:
            Qs = _thin_samples(mu_q.reshape(-1, mu_q.shape[-1]), max_samples=4096)  # (N, Kq)
            Ps = _thin_samples(mu_p.reshape(-1, mu_p.shape[-1]), max_samples=4096)  # (N, Kp)
            # Build design matrix A * coeff ≈ b, with A = [ (Bi mat) @ Qs^T ] stacked
            # We solve per-sample in Kp, so do least squares per output dim jointly:
            # vec(Φ0) = B @ coeff  =>  Φ0 = reshape(B@coeff, (Kp, Kq))
            # We choose coeff that minimizes ||Φ0 Qs^T - Ps^T||_F^2
            # This is linear in coeff:
            # Let Zi = reshape(B[:,i], Kp,Kq) @ Qs^T  -> (Kp,N)
            # Stack Zi along i to get (Kp*N, m), target vec(Ps^T) = vec(Ps.T)
            Z_blocks = []
            for i in range(B.shape[1]):
                Zi = (B[:, i].reshape(Kp, Kq) @ Qs.T)  # (Kp, N)
                Z_blocks.append(Zi.reshape(-1, 1))     # (Kp*N, 1)
            A_ls = np.concatenate(Z_blocks, axis=1)    # (Kp*N, m)
            b_ls = Ps.T.reshape(-1)                    # (Kp*N,)
            # regularized least squares to avoid degeneracy
            reg = 1e-8
            coeff, *_ = np.linalg.lstsq(A_ls.T @ A_ls + reg*np.eye(A_ls.shape[1]), A_ls.T @ b_ls, rcond=None)

    vecPhi = (B @ coeff).reshape(Kp, Kq)
    Phi0 = vecPhi
    if max_rank is not None:
        Phi0 = _best_rank_approx(Phi0, rank=max_rank)

    meta = {"nullspace_dim": B.shape[1]}
    return (Phi0, meta)




def _cluster_into_l_blocks(λ: np.ndarray, W: np.ndarray, rel_tol: float = 1e-4):
    """
    Scale-invariant clustering of Casimir eigenpairs by degeneracy.
    Groups consecutive eigenvalues whose relative gap ≤ rel_tol.
    For each cluster of size g, pick d = largest odd divisor of g;
    set multiplicity m = g // d and split the cluster into m blocks of size d.
    Returns dict: l -> {"W": (K, m*d), "d": d, "m": m}
    """
    
    # sort by eigenvalue
    idx = np.argsort(λ)
    λs  = λ[idx]
    Ws  = W[:, idx]

    # cluster by relative tolerance
    clusters = []
    start = 0
    for i in range(1, len(λs) + 1):
        if i == len(λs):
            clusters.append((start, i))
            break
        # relative gap
        denom = max(abs(λs[i-1]), abs(λs[i]), 1.0)
        if abs(λs[i] - λs[i-1]) > rel_tol * denom:
            clusters.append((start, i))
            start = i

    blocks = {}
    # helper: largest odd divisor
    def largest_odd_divisor(n: int) -> int:
        while n % 2 == 0 and n > 0:
            n //= 2
        return max(1, n)

    l_counter = 0
    for (lo, hi) in clusters:
        g = hi - lo                     # cluster size
        if g <= 0:
            continue
        d = largest_odd_divisor(g)      # irrep dim = 2l+1 (odd)
        m = g // d
        if d <= 0 or m <= 0:
            continue
        # take this cluster’s eigenvectors
        Wc = Ws[:, lo:hi]               # (K, g)
        # split into m blocks of size d
        keep = Wc[:, : m*d]             # truncate if any tiny overhang
        l_val = (d - 1) // 2
        blocks[l_counter] = {"W": keep, "d": d, "m": m, "ell": l_val}
        l_counter += 1

    return blocks




# ------------------------------ Internal Helpers ---------------------------------


def _thin_samples(X: np.ndarray, max_samples: int = 4096) -> np.ndarray:
    """Uniformly sub-sample rows to at most max_samples."""
    N = X.shape[0]
    if N <= max_samples:
        return X
    idx = np.linspace(0, N-1, num=max_samples, dtype=int)
    return X[idx]




def _best_rank_approx(M: np.ndarray, rank: int) -> np.ndarray:
    """Best Frobenius-norm rank-k approximation via SVD."""
    U, S, Vt = np.linalg.svd(M, full_matrices=False)
    k = min(rank, len(S))
    return (U[:, :k] * S[:k]) @ Vt[:k, :]




