# -*- coding: utf-8 -*-
"""
Numerical utilities (SPD, cache-hub friendly, no legacy prints)

Author: c&c
"""
from __future__ import annotations
import numpy as np

import inspect
import os
# -----------------------------------------------------------------------------
#  Kullback_Liebler
# -----------------------------------------------------------------------------

def kl_gaussian(
    mu1: np.ndarray,
    S1: np.ndarray,
    mu2: np.ndarray,
    S2: np.ndarray,
    *,
    eps: float = 1e-8,
    return_terms: bool = False,
) -> np.ndarray | tuple[np.ndarray, dict]:
    mu1 = np.asarray(mu1, dtype=float)
    mu2 = np.asarray(mu2, dtype=float)
    S1 = np.asarray(S1)
    S2 = np.asarray(S2)
 
    S1 = sanitize_sigma(S1, eps=eps)  # ensure SPD (prefer float64)
    S2 = sanitize_sigma(S2, eps=eps)
  
    L2, logdet2 = _chol_logdet(S2)
    _,  logdet1 = _chol_logdet(S1)
   
    K = mu1.shape[-1]
    dmu = mu2 - mu1                                     # (..., K)

    # Solve L2 * y = dmu  -> y shape (..., K, 1)
    y = np.linalg.solve(L2, dmu[..., None])             # (..., K, 1)
    # Solve L2^T * z = y
    z = np.linalg.solve(np.swapaxes(L2, -1, -2), y)     # (..., K, 1)
    term_quad = np.sum(dmu * np.squeeze(z, axis=-1), axis=-1)  # (...,)

    # term_trace = tr(S2^{-1} S1) via two triangular solves (no explicit inverse)
    Y = np.linalg.solve(L2, S1)                         # (..., K, K)
    X = np.linalg.solve(np.swapaxes(L2, -1, -2), Y)     # (..., K, K)
    term_trace = np.trace(X, axis1=-2, axis2=-1)        # (...,)

    kl = 0.5 * (term_trace + term_quad - K + (logdet2 - logdet1))
    # Only shave tiny negatives from roundoff; 
    kl = np.where(kl < 0, np.maximum(kl, -1e-12), kl)
 
    if not np.all(np.isfinite(kl)):
        raise FloatingPointError("Nonfinite KL encountered (NaN/Inf).")
    
    if return_terms:
        return kl, {"term_trace": term_trace, "term_quad": term_quad,
                    "logdet1": logdet1, "logdet2": logdet2}
    return kl





def push_gaussian(
    mu: np.ndarray,
    Sigma: np.ndarray,
    M: np.ndarray,
    *,
    eps: float = 1e-8,
    return_inv: bool = False,
    Sigma_inv: np.ndarray | None = None,     # precomputed precision (same shape as Sigma)
    assume_orthogonal: bool = False,         # set True if you *know* M is orthogonal
    sanitize_input: bool = True,             # you can turn off if you already sanitized upstream
):
    """
    Exact pushforward of N(mu, Σ) under y = M x.
      μ' = M μ
      Σ' = M Σ Mᵀ
    If return_inv and Sigma_inv is provided, compute Σ'^{-1} via
      Σ'^{-1} = M^{-T} Σ^{-1} M^{-1}
    with a cheap path for orthogonal M: Σ'^{-1} = M Σ^{-1} Mᵀ.
    """
    import numpy as np

    mu32    = np.asarray(mu,    dtype=np.float32, order="C")
    Sigma32 = np.asarray(Sigma, dtype=np.float32, order="C")
    M32     = np.asarray(M,     dtype=np.float32, order="C")

    K_in = int(mu32.shape[-1])
    if Sigma32.shape[-2:] != (K_in, K_in):
        raise ValueError(f"[push_gaussian] Σ dims {Sigma32.shape[-2:]} incompatible with μ dim {K_in}")
    if M32.shape[-1] != K_in:
        raise ValueError(f"[push_gaussian] M last dim {M32.shape[-1]} != μ dim {K_in}")

    # Broadcast M to the leading batch
    lead_mu, lead_S, lead_M = mu32.shape[:-1], Sigma32.shape[:-2], M32.shape[:-2]
    lead = np.broadcast_shapes(lead_mu, lead_S, lead_M)
    if lead_M != lead:
        M32 = np.broadcast_to(M32, lead + M32.shape[-2:])

    # (optional) trust upstream sanitization
    if sanitize_input:
        Sigma32 = sanitize_sigma(Sigma32)
        if eps and eps > 0.0:
            d = np.clip(np.diagonal(Sigma32, axis1=-2, axis2=-1), 0.0, None)
            scale = float(max(1.0, np.nanmean(d)))
            Sigma32 = Sigma32 + (max(eps, 1e-12) * scale) * np.eye(K_in, dtype=Sigma32.dtype)

    # μ' = M μ
    mu_out = np.einsum("...ik,...k->...i", M32, mu32, optimize=True)

    # Σ' = M Σ Mᵀ
    Sigma_out = np.einsum("...ik,...kl,...jl->...ij", M32, Sigma32, M32, optimize=True)
    Sigma_out = sanitize_sigma(Sigma_out) if sanitize_input else Sigma_out

    if not return_inv:
        return (mu_out.astype(mu.dtype, copy=False),
                Sigma_out.astype(Sigma.dtype, copy=False))

    # ---------- fast path for Σ'^{-1} ----------
    Sigma_inv32 = None if Sigma_inv is None else np.asarray(Sigma_inv, dtype=np.float32, order="C")
    if Sigma_inv32 is not None:
        # Broadcast Σ^{-1} to lead shape if needed
        if Sigma_inv32.shape[:-2] != lead:
            Sigma_inv32 = np.broadcast_to(Sigma_inv32, lead + Sigma_inv32.shape[-2:])

        # Quick orthogonality check (sample once if not asserted)
        def _near_ortho(Mtile, tol=1e-4):
            I = np.eye(K_in, dtype=Mtile.dtype)
            r = np.linalg.norm(Mtile.T @ Mtile - I, ord='fro') / K_in
            return r < tol

        use_ortho = assume_orthogonal
        
        if not use_ortho:
            # sample first batch item cheaply
            Mflat = M32.reshape(-1, K_in, K_in)
            use_ortho = _near_ortho(Mflat[0])

        if use_ortho:
            # Σ'^{-1} = M Σ^{-1} Mᵀ
            Sigma_out_inv = np.einsum("...ik,...kl,...jl->...ij", M32, Sigma_inv32, M32, optimize=True)
        else:
            # Σ'^{-1} = M^{-T} Σ^{-1} M^{-1} via two solves (no explicit inverse)
            K = K_in
            Mflat      = M32.reshape(-1, K, K)
            SigInvFlat = Sigma_inv32.reshape(-1, K, K)
            out = np.empty_like(SigInvFlat)
            for n in range(Mflat.shape[0]):
                # Z = solve(M^T, Σ^{-1})  ->  Z = M^{-T} Σ^{-1}
                Z = np.linalg.solve(Mflat[n].T, SigInvFlat[n])
                # out = Z @ M^{-1}  via solve on the right: solve(M, out^T) = Z^T
                out[n] = np.linalg.solve(Mflat[n], Z.T).T
            Sigma_out_inv = out.reshape(lead + (K, K))
    else:
        # Fallback: invert Σ' directly (Cholesky inside safe_inv)
        Sigma_out_inv = safe_inv(Sigma_out, eps=max(eps, 1e-12))

    return (mu_out.astype(mu.dtype, copy=False),
            Sigma_out.astype(Sigma.dtype, copy=False),
            Sigma_out_inv.astype(Sigma.dtype, copy=False))



def _chol_logdet(S):
    # Be explicit about dtype to avoid tiny→0 underflow in float32
    S = np.asarray(S, dtype=np.float64)           # robust and cheap at these sizes
    L = np.linalg.cholesky(S)                     # (..., K, K)
    diag = np.diagonal(L, axis1=-2, axis2=-1)     # (..., K)
    tiny = np.finfo(diag.dtype).tiny              # dtype-aware lower bound
    logdet = 2.0 * np.sum(np.log(np.clip(diag, tiny, None)), axis=-1)
    return L, logdet






def _caller_info(levels_back=4):
    """Return short 'module:func:line' string of caller `levels_back` up."""
    try:
        frame = inspect.stack()[levels_back]
        fname = os.path.basename(frame.filename)
        return f"{fname}:{frame.function}:{frame.lineno}"
    except Exception:
        return "<?>"
    
    

def safe_inv(
    Sigma: np.ndarray,
    eps: float = 1e-10,
    max_eig: float | None = None,
    debug: bool = False,
    *,
    method: str = "chol",
    use_float64: bool = True,
    mask: np.ndarray | None = None,
    strict_spd: bool = False,
) -> np.ndarray:
    import numpy as np
    caller = _caller_info(2)

    A = np.asarray(Sigma, dtype=(np.float64 if use_float64 else np.float32))
    A = 0.5 * (A + np.swapaxes(A, -1, -2))
    *batch, K, _ = A.shape
    I = np.eye(K, dtype=A.dtype)

    if mask is not None:
        m = np.asarray(mask, dtype=bool).reshape(*batch, 1, 1)
        A = A.copy()
        A[~m] = I

    if method == "chol":
        eps_dtype = np.finfo(A.dtype).eps
        jitter = max(eps, eps_dtype)
        with np.errstate(invalid="ignore"):
            avg_diag = np.nanmean(np.diagonal(A, axis1=-2, axis2=-1))
        jitter_cap = (1e-6 if np.isfinite(avg_diag) and avg_diag > 0 else 1e-6)

        for attempt in range(4):
            try:
                L = np.linalg.cholesky(A + jitter * I)
                Y = np.linalg.solve(L, I)
                X = np.linalg.solve(np.swapaxes(L, -1, -2), Y)
                invA = 0.5 * (X + np.swapaxes(X, -1, -2))
                return invA.astype(Sigma.dtype, copy=False)
            except Exception as e:
                print(f"[safe_inv:{caller}] chol failed (attempt {attempt+1}): {e}")
                jitter = min(jitter * 10.0, jitter_cap)
                continue

        if strict_spd:
            raise np.linalg.LinAlgError(f"[safe_inv:{caller}] strict_spd: Cholesky failed.")

    flat = A.reshape(-1, K, K)
    evals, evecs = np.linalg.eigh(flat)
    lo = max(eps, np.finfo(A.dtype).eps)
    hi = None if max_eig is None else float(max_eig)
    evals = np.clip(evals, a_min=lo, a_max=hi)
    inv_evals = 1.0 / evals
    Vinv = evecs * inv_evals[..., None, :]
    invA = Vinv @ np.swapaxes(evecs, -1, -2)
    invA = 0.5 * (invA + np.swapaxes(invA, -1, -2))
    return invA.reshape(*batch, K, K).astype(Sigma.dtype, copy=False)






def safe_omega_inv(M: np.ndarray, eps: float = 1e-10, debug: bool = False) -> np.ndarray:
    """
    Invert ~orthogonal matrices slice-wise with a stable tolerance:
      - fast path per slice: return M^T if ||M^T M - I||_F <= tol
      - else repair that slice via QR, then return Q^T
    tol is based on float32 machine epsilon (source numerics), not the promoted dtype.
    """
    M = np.asarray(M)
    *batch, K, _ = M.shape
    if K != M.shape[-2]:
        raise ValueError("safe_omega_inv: last two dims must be square")

    # Promote for the check, but base tol on float32 since sources are f32
    M64 = M.astype(np.float64, copy=False)
    MT  = np.swapaxes(M64, -1, -2)
    I64 = np.eye(K, dtype=np.float64)

    dev = MT @ M64 - I64
    dev_fro = np.linalg.norm(dev.reshape(-1, K*K), axis=1)  # (B,)
    

    # Stable absolute tolerance (float32-based), scaled by size
    eps32 = np.finfo(np.float32).eps  # ~1.19e-7
    tol = max(float(eps), 100.0 * float(eps32) * np.sqrt(K))

    ok = dev_fro <= tol
    flat_M = M64.reshape(-1, K, K)
    outT   = np.empty_like(flat_M)

    # Fast path: transpose
    outT[ok] = np.swapaxes(flat_M[ok], -1, -2)

    # Repair only failing slices (usually none)
    if np.any(~ok):
        print("[safe_omega_inv] repaired")
        bad = np.where(~ok)[0]
        for idx in bad:
            A = flat_M[idx]
            Q, R = np.linalg.qr(A)
            s = np.sign(np.diag(R)); s[s == 0.0] = 1.0
            Q = Q * s
            # enforce det +1
            if np.linalg.det(Q) < 0:
                Q[:, -1] *= -1.0
            outT[idx] = Q.T

    return outT.reshape(*batch, K, K).astype(M.dtype, copy=False)




# -----------------------------------------------------------------------------
# Sigma sanitation (vectorized)
# -----------------------------------------------------------------------------

def sanitize_sigma(
    Sigma: np.ndarray,
    debug: bool = True,
    eig_floor: float | None = None,
    cond_cap: float | None = None,
    eig_cap: float | None = None,
    trace_target: float | None = None,
    eps: float | None = None,
) -> np.ndarray:
    """
    Symmetrize, scrub NaN/Inf, and project to SPD via eigen clipping.
    Prints caller info on failure or diagnostic messages.
    """
    import config 

    caller = _caller_info(2)  # identify where sanitize_sigma was called from
    in_dtype = Sigma.dtype
    S = np.asarray(Sigma, dtype=np.float64)  # work in fp64 for eig, cast back at end

    eig_floor = float(eig_floor if eig_floor is not None else getattr(config, "sigma_eig_floor", 1e-6))
    cond_cap  = None if cond_cap is None else float(cond_cap)
    eig_cap   = None if eig_cap   is None else float(eig_cap)
    trace_target = None if trace_target is None else float(trace_target)

    # --- symmetrize ---
    S = 0.5 * (S + np.swapaxes(S, -1, -2))

    # --- scrub NaN/Inf ---
    bad = ~np.isfinite(S).all(axis=(-2, -1))
    if np.any(bad):
        print(f"[sanitize_sigma:{caller}] {int(bad.sum())} matrices had NaN/Inf; replaced with floor*I")
        K = S.shape[-1]
        eye = np.eye(K, dtype=S.dtype)
        S = S.copy()
        S[bad] = eig_floor * eye

    # --- eigen projection (batched) ---
    try:
        w, V = np.linalg.eigh(S)
    except Exception as e:
        raise FloatingPointError(f"[sanitize_sigma:{caller}] eigh failed: {e}")

    # floor eigenvalues
    w = np.maximum(w, eig_floor)

    # --- optional condition-number cap ---
    if cond_cap is not None:
        lam_min = np.min(w, axis=-1, keepdims=True)
        lam_min_flat = lam_min.reshape(-1)
        w_flat = w.reshape(-1)
        tau = 1e-8
        floored_frac = np.mean(w_flat <= 1.001 * tau)
        before = w.copy()
        w = np.minimum(w, lam_min * cond_cap)
        capped_frac = np.mean((w < before).astype(np.float32))
        if debug:
            print(
                f"[sanitize_sigma:{caller}] "
                f"λ_min min={lam_min_flat.min():.3e} med={np.median(lam_min_flat):.3e} "
                f"p90={np.percentile(lam_min_flat,90):.3e} max={lam_min_flat.max():.3e} "
                f"| floored_frac={floored_frac:.3f} capped_frac={capped_frac:.3f}",
                flush=True,
            )

    # --- optional absolute cap ---
    if eig_cap is not None:
        w = np.minimum(w, eig_cap)

    # --- reconstruct SPD ---
    S_proj = (V * w[..., None, :]) @ np.swapaxes(V, -1, -2)

    # --- optional trace normalization ---
    if trace_target is not None:
        tr = np.trace(S_proj, axis1=-2, axis2=-1)[..., None, None]
        S_proj = S_proj * (trace_target / np.clip(tr, 1e-12, None))

    # --- final symmetrize + SPD check ---
    S_proj = 0.5 * (S_proj + np.swapaxes(S_proj, -1, -2))
    min_eig = np.min(np.linalg.eigvalsh(S_proj))

    if not np.isfinite(min_eig) or min_eig <= 0:
        raise FloatingPointError(f"[sanitize_sigma:{caller}] non-SPD result (min eig={min_eig:.3e})")

    return S_proj.astype(in_dtype, copy=False)






def _expand_for(ref: np.ndarray, base: np.ndarray) -> np.ndarray:
    """Expand 'base' with as many trailing None as needed to multiply 'ref'."""
    k = ref.ndim - base.ndim
    if k < 0:
        raise ValueError(f"expand_for: base has higher ndim than ref: {base.ndim} > {ref.ndim}")
    return base[(...,) + (None,) * k]




def plain_rule(weight, KL, kappa, grad):
    """
    d/dθ [ w * KL ] with w = exp(-KL/κ)
    → w * (1 - KL/κ) * ∂θ KL
    Broadcasting-safe for grad shapes (*S,Ki) or (*S,Ki,Ki).
    """
    w   = np.asarray(weight, dtype=np.float32)
    KL  = np.asarray(KL,      dtype=np.float32)
    gij = np.asarray(grad,    dtype=np.float32)
    k   = float(kappa) if float(kappa) > 0 else 1e-12

    wE     = _expand_for(gij, w)
    factor = _expand_for(gij, (w * (KL / k)).astype(np.float32))
    return wE * (gij - factor * gij)    # w * gij - w*(KL/κ)*gij




def softmax_align_rule_receiver(beta_ij, KL_ij, kappa, grad_ij, grad_bar_i):
    """
    Receiver-side per-sender:
      ∂θ L_ij = β_ij * ∂θ KL_ij + (β_ij*KL_ij/κ) * (grad_bar_i - ∂θ KL_ij)
    Shapes:
      beta_ij, KL_ij : (*S,)
      grad_ij, grad_bar_i : (*S, Ki)  OR  (*S, Ki, Ki)
    """
    b   = np.asarray(beta_ij, dtype=np.float32)
    KL  = np.asarray(KL_ij,   dtype=np.float32)
    gij = np.asarray(grad_ij, dtype=np.float32)
    gbr = np.asarray(grad_bar_i, dtype=np.float32)
    kappa = float(kappa) if float(kappa) > 0 else 1e-12

    bE   = _expand_for(gij, b)                     # (*S, 1) or (*S, 1, 1)
    fac  = _expand_for(gij, (b * (KL / kappa)).astype(np.float32))  # same shape as bE

    return bE * gij + fac * (gbr - gij)



def softmax_align_rule_sender(beta_ij, KL_ij, kappa, grad_sender_ij):
    """
    Sender-side per-sender (your current formula):
      add = β * ∂θ KL_sender + (β*KL/κ) * (β - 1) * ∂θ KL_sender
    Shapes:
      beta_ij, KL_ij : (*S,)
      grad_sender_ij : (*S, Ki)  OR  (*S, Ki, Ki)
    """
    b   = np.asarray(beta_ij, dtype=np.float32)
    KL  = np.asarray(KL_ij,   dtype=np.float32)
    gij = np.asarray(grad_sender_ij, dtype=np.float32)
    kappa = float(kappa) if float(kappa) > 0 else 1e-12

    bE    = _expand_for(gij, b)                                    # (*S,1) or (*S,1,1)
    fac   = _expand_for(gij, (b * (KL / kappa)).astype(np.float32))
    scale = _expand_for(gij, (b - 1.0).astype(np.float32))

    return bE * gij + (fac * scale) * gij




