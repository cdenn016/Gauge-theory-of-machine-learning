from __future__ import annotations
"""
Created on Sun Sep 14 14:24:12 2025

@author: chris and christine
"""

import numpy as np
import os, pickle
import json, pathlib
from typing import Any


# ============================================================================
# Overlap Iteration (Pure)
# ============================================================================

def _get_phi(agent: Any, which: str) -> np.ndarray:
    if which == "q":
        phi = getattr(agent, "phi", None)
    else:
        phi = getattr(agent, "phi_model", None)
    if phi is None:
        raise ValueError(f"[transport_cache] phi field ({which}) missing")
    return phi



def _zeros_mu_S_like(mu):
    mu = np.asarray(mu, np.float32)
    S  = mu.shape[:-1]
    K  = mu.shape[-1]
    return (np.zeros(S + (K,),    np.float32),
            np.zeros(S + (K, K), np.float32))



def _to32_no_underflow(x):
    """
    Cast to float32 but zero out sub-f32-tiny magnitudes to avoid denorm underflow
    in later ops. Preserves sign on non-tiny entries.
    """
    x64 = np.asarray(x, dtype=np.float64)
    tiny32 = np.finfo(np.float32).tiny
    with np.errstate(under="ignore"):
        x64 = np.where(np.abs(x64) < tiny32, 0.0, x64)
    return x64.astype(np.float32, copy=False)




def _roll_spatial_axis(a, axis_m: int, shift: int, *, trailing: int = 2):
    """
    Periodic roll along the m-th spatial axis (0-based among spatial axes).
    trailing: number of non-spatial trailing dims (e.g., 2 for (...,K,K), 1 for (...,3)).
    Pure / loky-safe.
    """
    import numpy as np
    a = np.asarray(a)
    if trailing < 0 or trailing > a.ndim:
        raise ValueError(f"trailing={trailing} invalid for shape {a.shape}")
    spatial_rank = a.ndim - trailing
    if spatial_rank <= 0:
        return a  # nothing to roll

    # normalize axis index
    m = int(axis_m)
    if m < 0:
        m += spatial_rank
    if not (0 <= m < spatial_rank):
        raise IndexError(f"axis_m={axis_m} out of range for spatial rank {spatial_rank} (shape {a.shape}, trailing={trailing})")

    ax = m  # among leading spatial axes [0..spatial_rank-1]
    n = a.shape[ax]
    if n == 0:
        return a
    # normalize shift
    s = int(shift) % n
    if s == 0:
        return a
    return np.roll(a, shift=s, axis=ax)




def _assert_finite(tag, *arrs):
    import numpy as np
    for a in arrs:
        if a is None:
            continue
        A = np.asarray(a)
        # Skip non-numeric types (e.g., strings, objects)
        if not np.issubdtype(A.dtype, np.number):
            continue
        if not np.all(np.isfinite(A)):
            n_nan = int(np.isnan(A).sum())
            n_inf = int(np.isinf(A).sum())
            raise FloatingPointError(f"[{tag}] non-finite values (nan={n_nan}, inf={n_inf})")






# =========================
# Basic, stable miscellany
# =========================

def _aid(agent) -> int:
    # Strict: never use id(obj); enforce a real, stable id
    try:
        return int(getattr(agent, "id"))
    except Exception:
        raise RuntimeError("Agent missing stable .id; call ensure_stable_agent_ids(...) before Parallel.")





def _safe_vector_norm(x: np.ndarray) -> np.ndarray:
    """
    Robust vector 2-norm along the last axis, tolerant to underflow.
    Uses float64 and hypot (when small last-dim) to avoid tiny* tiny raises.
    Returns an array of norms (same shape as x without the last axis).
    """
    x = np.asarray(x)
    if x.ndim == 0:
        return np.abs(x.astype(np.float64))

    # Prefer hypot for 2D/3D vectors (most common in your fields)
    with np.errstate(under='ignore', over='ignore', invalid='ignore'):
        if x.shape[-1] == 2:
            a = x[..., 0].astype(np.float64, copy=False)
            b = x[..., 1].astype(np.float64, copy=False)
            return np.hypot(a, b)
        elif x.shape[-1] == 3:
            a = x[..., 0].astype(np.float64, copy=False)
            b = x[..., 1].astype(np.float64, copy=False)
            c = x[..., 2].astype(np.float64, copy=False)
            return np.hypot(np.hypot(a, b), c)
        else:
            # General case: float64 accumulation; safe underflow handling
            x64 = x.astype(np.float64, copy=False)
            # sum(..., dtype=float64) keeps the accumulator wide
            return np.sqrt(np.sum(x64 * x64, axis=-1, dtype=np.float64))


def mean_norm(x) -> float:
    """
    Mean 2-norm along the last axis, NaN-safe, and underflow-safe.
    Returns 0.0 if there are no finite entries (so plots don’t disappear).
    """
    if x is None:
        return 0.0
    n = _safe_vector_norm(x)
    n = np.asarray(n, dtype=np.float64)
    m = np.isfinite(n)
    if not np.any(m):
        
        return 0.0
    return float(np.mean(n[m]))




# =========================
#         Masks
# =========================




# --- small helpers ------------------------------------------------------------
def _broadcast_mask_to_S(S, m_raw, tau: float):
    import numpy as np
    if m_raw is None:
        return np.ones(S, dtype=bool)
    m = np.asarray(m_raw)
    if m.shape != S:
        pad = (1,) * max(0, len(S) - m.ndim)
        try:
            m = np.broadcast_to(m.reshape(pad + m.shape), S)
        except Exception as e:
            raise ValueError(f"AA.get_mask_float(agent) shape {m_raw.shape} not broadcastable to {S}") from e
    return (m > tau)


def mask_hw(x, *, tau: float, mode: str = "float3"):
    """
    N-D mask normalizer (broadcast- & dtype-safe).

    Accepts x.mask or x (array-like) in shapes (*S,) or (*S,1).
    Modes:
      - "bool2"  -> (*S,)   bool
      - "float3" -> (*S,1)  float32 (broadcast-friendly channel)
      - "vec"    -> (|S|,)  bool (raveled)
    """
    m = getattr(x, "mask", x)
    m = np.asarray(m)

    # Squeeze trailing singleton channel if present
    if m.ndim >= 1 and m.shape[-1] == 1:
        m = m[..., 0]

    if m.ndim == 0:
        m = m.reshape(1)

    if np.issubdtype(m.dtype, np.floating) or np.issubdtype(m.dtype, np.integer):
        if not np.isfinite(m).all():
            n_bad = int(m.size - np.isfinite(m).sum())
            raise FloatingPointError(f"mask_hw: non-finite values in mask ({n_bad} cells).")

    mb = m if (m.dtype == bool) else (m.astype(np.float32, copy=False) > float(tau))

    if mode == "bool2":
        return mb.astype(bool, copy=False)
    if mode == "float3":
        return mb.astype(np.float32, copy=False)[..., None]
    if mode == "vec":
        return mb.astype(bool, copy=False).ravel()

    raise ValueError(f"mask_hw: unknown mode={mode!r}")


def _joint_mask(a, b, *, tau: float, as_vector: bool = True):
    """
    Joint support of two agents' masks (broadcast-safe, N-D).
    Returns:
      - (*S,1) float32 if as_vector=True
      - (*S,)  bool    if as_vector=False
    """
    ma = mask_hw(a, tau=tau, mode="bool2")
    mb = mask_hw(b, tau=tau, mode="bool2")

    try:
        S = np.broadcast(ma, mb).shape
    except Exception as e:
        raise ValueError(f"joint_mask: shapes not broadcastable: {ma.shape} vs {mb.shape}") from e

    if ma.shape != S: ma = np.broadcast_to(ma, S)
    if mb.shape != S: mb = np.broadcast_to(mb, S)

    m = ma & mb
    return (m[..., None].astype(np.float32, copy=False)) if as_vector else m



def joint_masks(ctx, ai, aj, *, tau: float | None = None):
    """
    Canonical joint mask over the base manifold C (N-D, broadcast-safe).

    Returns:
      m_bool  : (*S,)   bool      – for indexing/guarding loops
      m_float : (*S,1)  float32   – for weighting/broadcast-safe math

    Notes:
      • Uses ctx.support_tau (default 1e-6). The 'tau' argument is deprecated.
      • Masks live on the base lattice C and are shared by all fibers (q/p).
    """
    import warnings
    from core.runtime_context import cfg_get
    
    if tau is not None and not _MASK_WARNED["joint_masks_tau"]:
        warnings.warn("joint_masks: 'tau' arg is deprecated; using ctx.support_tau instead.",
                      RuntimeWarning, stacklevel=2)
        _MASK_WARNED["joint_masks_tau"] = True

    m_bool  = _joint_mask(ai, aj, tau=float(cfg_get(ctx, "support_tau", 1e-6)), as_vector=False)
    m_float = _joint_mask(ai, aj, tau=float(cfg_get(ctx, "support_tau", 1e-6)), as_vector=True)

    # Guarantee writeable arrays for downstream in-place ops
    if isinstance(m_bool, np.ndarray) and not m_bool.flags.writeable:
        m_bool = np.array(m_bool, copy=True)
    if isinstance(m_float, np.ndarray) and not m_float.flags.writeable:
        m_float = np.array(m_float, copy=True)
    return m_bool, m_float




# utils.py  --- masks section

_MASK_WARNED = {"joint_masks_tau": False}




def assert_mask_shapes(mbool, mfloat, Sshape):
    """
    Dev-time sanity: masks have expected shapes/dtypes.
    """
    if mbool.shape != Sshape or mbool.dtype != np.bool_:
        raise AssertionError(f"mbool shape/dtype mismatch: {mbool.shape}, {mbool.dtype} vs {Sshape}, bool")
    if mfloat.shape != (Sshape + (1,)) or mfloat.dtype != np.float32:
        raise AssertionError(f"mfloat shape/dtype mismatch: {mfloat.shape}, {mfloat.dtype} vs {Sshape+(1,)}, float32")


# ------------------------------ Agents ---------------------------------------








# =========================
# Logging
# =========================



def _pre_checkpoint_cleanup(agents):
    """
    Drop/clear large transient caches so checkpoints stay small.
    Calls common methods if present; otherwise clears known attributes.
    Safe no-ops if attributes/methods don't exist.
    """
    for A in agents:
        # Try explicit compactors first
        for meth in (
            "compact_for_checkpoint",
            "clear_omega_cache",
            "clear_fisher_caches",
            "clear_transport_cache",
            "clear_theta_cache",
            "clear_misc_cache",
        ):
            if hasattr(A, meth):
                try:
                    getattr(A, meth)()
                except Exception:
                    pass

        # Then try to clear/delete typical cache attributes
        for attr in (
            "omega_cache",
            "fisher_cache",
            "transport_cache",
            "theta_cache",
            "misc_cache",
        ):
            if hasattr(A, attr):
                try:
                    obj = getattr(A, attr)
                    if hasattr(obj, "clear"):
                        obj.clear()
                    else:
                        setattr(A, attr, None)
                except Exception:
                    pass




def _extract_global_from_Q(Q) -> dict:
    """
    Accepts a dict-like or object 'Q' from compute_total_action(...) and
    returns ONLY numeric fields for logging. Skips strings/bools and metadata.
    Also supports tiny dicts like {'value': 1.23, 'w': 1, 'src': 'cached'}.
    """
   
    import numbers as _numbers

    def _is_num(x):
        # true for Python/NumPy numbers, false for bools
        if isinstance(x, (bool, np.bool_)):
            return False
        return isinstance(x, _numbers.Number) or (isinstance(x, np.generic) and np.issubdtype(type(x), np.number))

    def _coerce_num(x):
        # dict with 'value' → extract; tuple/list → first numeric element; else None
        if _is_num(x):
            return float(x)
        if isinstance(x, dict) and "value" in x and _is_num(x["value"]):
            return float(x["value"])
        if isinstance(x, (list, tuple)) and len(x) > 0 and _is_num(x[0]):
            return float(x[0])
        return None

    out = {}
    if Q is None:
        return out

    if isinstance(Q, dict):
        for k, v in Q.items():
            val = _coerce_num(v)
            if val is not None:
                out[k] = val
        return out

    # object-like fallback: pick common attributes if numeric
    for k in ("Action_total","Geom_total","VFE_acc","A_curv","A_cov","ModelPrior","Curv","Frame","Comm_KL","Transp_KL"):
        if hasattr(Q, k):
            val = _coerce_num(getattr(Q, k))
            if val is not None:
                out[k] = val
    return out





def log_and_viz_after_step(runtime_ctx, agents, step, outdir,
                           parent_metrics, metric_log, num_cores,
                           precomputed_metrics=None,
                           precomputed_Q=None):
    
    ctx = runtime_ctx
    from diagnostics import compute_global_metrics, print_energy_breakdown, total_energy
    from core.runtime_context import cfg_get
    
    print_energy_every = int(cfg_get(ctx, "print_energy_every", 1))
    log_metrics_every  = int(cfg_get(ctx, "log_metrics_every", 1))
    
    
    rid   = int(getattr(ctx, "run_id", 1))
    rname = str(getattr(ctx, "run_label", f"run {rid}"))

    # ---- 1) reuse precomputed metrics OR compute once ----
    mg = precomputed_metrics if precomputed_metrics is not None else compute_global_metrics(ctx, agents)

    if (step % print_energy_every) == 0:
        print_energy_breakdown(ctx, mg)

    # ---- 2) reuse precomputed Q OR compute from metrics (no recompute of metrics) ----
    if precomputed_Q is None:
        E, terms = total_energy(ctx, agents, return_breakdown=True, precomputed_metrics=mg)
        Q = {"Action_total": float(E), **terms}
    else:
        Q = dict(precomputed_Q)

    # ---- 3) append to metric_log (throttled) ----
    if (step % log_metrics_every) == 0:
        metric_log.append({
            "run_id": rid,
            "run_name": rname,
            "run_label": rname,
            "step": int(getattr(ctx, "global_step", step)),

            # totals
            "E_total":    float(Q.get("Action_total", 0.0)),
            "mean_total": float(mg.get("mean_total", 0.0)),

            # weighted sums used in the action (fallbacks kept for robustness)
            "self_sum":       float(mg.get("self_sum_w",     mg.get("self_sum", 0.0))),
            "feedback_sum":   float(mg.get("feedback_sum_w", mg.get("feedback_sum", 0.0))),
            "align_q_sum":    float(mg.get("align_q_sum_w",  mg.get("align_q_sum", 0.0))),
            "align_p_sum":    float(mg.get("align_p_sum_w",  mg.get("align_p_sum", 0.0))),

            # NEW: gamma terms (already “weighted” by gamma; if diagnostics haven’t been patched yet,
            # fall back to raw sums or 0)
            "gamma_A_sum":    float(mg.get("gamma_A_sum_w",  mg.get("gamma_A_sum", 0.0))),
            "gamma_B_sum":    float(mg.get("gamma_B_sum_w",  mg.get("gamma_B_sum", 0.0))),
        })

   



def load_checkpoint(outdir: str):
    # prefer compressed if present
    for name in ("checkpoint.pkl.xz", "checkpoint.pkl.gz", "checkpoint.pkl"):
        p = os.path.join(outdir, name)
        if os.path.exists(p):
            if name.endswith(".xz"):
                import lzma
                with lzma.open(p, "rb") as f:
                    return pickle.load(f), name
            if name.endswith(".gz"):
                import gzip
                with gzip.open(p, "rb") as f:
                    return pickle.load(f), name
            with open(p, "rb") as f:
                return pickle.load(f), name

    # fall back to last step_XXXX
    step_files = sorted(
        f for f in os.listdir(outdir)
        if f.startswith("step_") and (f.endswith(".pkl") or f.endswith(".pkl.xz") or f.endswith(".pkl.gz"))
    )
    if not step_files:
        return (None, None)
    last = step_files[-1]
    p = os.path.join(outdir, last)
    if last.endswith(".xz"):
        import lzma
        with lzma.open(p, "rb") as f:
            return pickle.load(f), last
    if last.endswith(".gz"):
        import gzip
        with gzip.open(p, "rb") as f:
            return pickle.load(f), last
    with open(p, "rb") as f:
        return pickle.load(f), last


def find_resume_step(outdir: str) -> int:
    step_files = sorted(
        f for f in os.listdir(outdir)
        if f.startswith("step_") and (f.endswith(".pkl") or f.endswith(".pkl.xz") or f.endswith(".pkl.gz"))
    )
    if not step_files:
        return 0
    last = step_files[-1]
    num = (last.replace("step_", "")
               .replace(".pkl.xz", "")
               .replace(".pkl.gz", "")
               .replace(".pkl", ""))
    try:
        return int(num) + 1
    except Exception:
        return 0





# ------------------------------ Generator prep ------------------------------

# ------------------------------ Generator prep ------------------------------
def prepare_generators(ctx):
    """
    Resolve (Gq, Gp) in canonical shape (3, K, K), float32.

    Priority:
     
      1) SO(3) specs:    spec_q / spec_p (+ optional mix_generators_q / mix_generators_p)

    Side effect: writes K_q, K_p into ctx.config (runtime-scoped).
    """
    from core.get_generators import make_reducible_generators
    from core.runtime_context import cfg_get
    spec_q = cfg_get(ctx, "spec_q", None)
    spec_p = cfg_get(ctx, "spec_p", None)
        
    if (spec_q is None) or (spec_p is None):
        raise ValueError(
            "prepare_generators: provide either "
            "generators_q/generators_p, or so3_spec_q/so3_spec_p, "
            "or spec_q/spec_p in ctx/config."
        )
    mix_q = bool(cfg_get(ctx, "mix_generators_q", False))
    mix_p = bool(cfg_get(ctx, "mix_generators_p", False))
    
    Gq = make_reducible_generators(spec_q, mix=mix_q).astype(np.float32, copy=False)
    Gp = make_reducible_generators(spec_p, mix=mix_p).astype(np.float32, copy=False)
   
    # ---- record K into ctx.config (runtime-scoped) ----
    Kq, Kp = int(Gq.shape[1]), int(Gp.shape[1])
    rcfg = dict(getattr(ctx, "config", {}) or {})
    rcfg["K_q"] = Kq
    rcfg["K_p"] = Kp
    ctx.config = rcfg

    return Gq, Gp



def initialize_or_resume(outdir: str, resume: bool, runtime_ctx, clear_agent_logs: bool = True):
    """
    Initialize a fresh run or resume from checkpoints.
    Returns: (agents, step_start)
    """
    from agents.agent_initialization import initialize_agents
    import config as config
    from core.runtime_context import cfg_get
    import numpy as np

    if resume:
        agents, _ = load_checkpoint(outdir)
        step_start = find_resume_step(outdir)
        return agents, int(step_start)

    # ---------- fresh init ----------
    if clear_agent_logs and os.path.isdir(outdir):
        # optional: wipe agent logs or temp dirs specific to a fresh start
        pass

    # Generators must be available; prefer those already persisted on ctx
    G_q = cfg_get(runtime_ctx, "generators_q", None)
    G_p = cfg_get(runtime_ctx, "generators_p", None)
    if (G_q is None) or (G_p is None):
        G_q, G_p = prepare_generators(runtime_ctx)
        rcfg = dict(getattr(runtime_ctx, "config", {}) or {})
        rcfg["generators_q"] = G_q
        rcfg["generators_p"] = G_p
        runtime_ctx.config = rcfg

    # ---- N-D domain size ----
    S_run = cfg_get(runtime_ctx, "domain_size", 0)

    # ---- Build global observation model ONCE ----
    # ---- Build global observation model ONCE ----
    K_q = int(G_q.shape[1])
    D_x = 3
    
    rng_obs = np.random.default_rng(cfg_get(runtime_ctx, "agent_seed", 0) + 10)
    
    W_obs = rng_obs.normal(scale=0.5, size=(D_x, K_q)).astype(np.float32)
    
    # Full SPD precision matrix (Λ = AᵀA ensures positive-definiteness)
    A = rng_obs.normal(scale=0.3, size=(D_x, D_x)).astype(np.float32)
    Lambda_obs = (A.T @ A).astype(np.float32)
    
    # Optional: normalize condition number for stability
    Lambda_obs /= np.linalg.norm(Lambda_obs)
    
    

    #rng_obs = np.random.default_rng(cfg_get(runtime_ctx, "agent_seed", 0) + 10)

   # W_obs = rng_obs.normal(scale=0.5, size=(D_x, K_q)).astype(np.float32)
    #Lambda_obs = np.eye(D_x, dtype=np.float32)

    # expose this on runtime_ctx so workers can read it in _obs_grads_for_agent
    runtime_ctx.W_obs = W_obs
    runtime_ctx.Lambda_obs = Lambda_obs

    # ---- Build agents, each with its own x_obs consistent with W_obs ----
    agents = initialize_agents(
        seed=cfg_get(runtime_ctx, "agent_seed", 0),
        domain_size=S_run,
        N=cfg_get(runtime_ctx, "N", config.N),
        lie_algebra_dim=cfg_get(runtime_ctx, "lie_algebra_dim", 3),
        fixed_location=cfg_get(runtime_ctx, "fixed_location", True),
        generators_q=G_q,
        generators_p=G_p,
        W_obs=W_obs,
        Lambda_obs=Lambda_obs,
    )

    step_start = 0
    return agents, step_start


def save_step(agents, outdir, step, *, save_every=1, compress=True):
    import os, pickle
    os.makedirs(outdir, exist_ok=True)
    if step is not None and (step % int(save_every)) != 0:
        return

    # prune big transient state before serializing
    try:
        _pre_checkpoint_cleanup(agents)
    except Exception:
        pass

    base = os.path.join(outdir, f"step_{(step if step is not None else 0):04d}.pkl")

    if compress:
        # Try LZMA first (lower preset for smaller working set), then fall back to gzip.
        try:
            import lzma
            with lzma.open(base + ".xz", "wb", preset=2) as f:  # preset=2 keeps memory modest
                pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)
            return
        except MemoryError:
            # Fall back to gzip (much smaller memory overhead) and still continue the run.
            import gzip
            with gzip.open(base + ".gz", "wb", compresslevel=1) as f:
                pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)
            return

    # Uncompressed as last resort
    with open(base, "wb") as f:
        pickle.dump(agents, f, protocol=pickle.HIGHEST_PROTOCOL)


  

def _write_metric_artifacts(outdir: str, metric_log: list[dict]):
    if not metric_log: return
    out = pathlib.Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    # pickle (legacy) + jsonl (human/tooling-friendly)
    with open(out / "metric_log.pkl", "wb") as f:
        pickle.dump(metric_log, f, protocol=pickle.HIGHEST_PROTOCOL)
    with open(out / "metrics.jsonl", "w", encoding="utf-8") as f:
        for rec in metric_log:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")

def wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log):
    # flush metrics & a lightweight “run.json” context stub
    try:
        _write_metric_artifacts(outdir, metric_log or [])
        with open(os.path.join(outdir, "run.json"), "w", encoding="utf-8") as f:
            json.dump({
                "steps": int(getattr(getattr(runtime_ctx, "config", {}), "steps", len(metric_log)) 
                             if hasattr(runtime_ctx, "config") else len(metric_log)),
                "global_step": int(getattr(runtime_ctx, "global_step", -1)),
            }, f)
    except Exception as e:
        print(f"[WRAP] failed to write artifacts: {e}")