"""
metrics_viz_professional.py - ACADEMIC-QUALITY VISUALIZATION
-------------------------------------------------------------
Professional, publication-ready plotting for multi-agent systems.

KEY IMPROVEMENTS FOR 12+ AGENTS:
1. Smart legend management (auto-hide, separate panels, or external)
2. Academic typography (larger fonts, LaTeX-style labels)
3. Multi-panel layouts (faceting by agent)
4. Color schemes optimized for distinguishability
5. Professional figure sizing for publications
6. Grid layouts for comparison plots
7. Statistical summaries instead of individual traces when needed

@author: Enhanced for academic presentation
"""

from __future__ import annotations

import json
import csv
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any, Literal
from collections import defaultdict

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec

# ═══════════════════════════════════════════════════════════════════════════
# Professional Styling Constants
# ═══════════════════════════════════════════════════════════════════════════

# Typography (academic standard)
FONT_SIZE_TITLE = 14
FONT_SIZE_LABEL = 12
FONT_SIZE_TICK = 10
FONT_SIZE_LEGEND = 9

# Figure sizes (inches) - optimized for papers
FIGSIZE_SINGLE = (8, 5)          # Single plot
FIGSIZE_WIDE = (12, 4)           # Wide single panel
FIGSIZE_DOUBLE = (12, 5)         # Two-panel
FIGSIZE_GRID = (14, 10)          # Multi-panel grid
FIGSIZE_TALL = (8, 10)           # Tall stack

# DPI settings
DPI_SCREEN = 100
DPI_PRINT = 300

# Color schemes
COLORMAP_SEQUENTIAL = 'viridis'
COLORMAP_DIVERGING = 'RdBu_r'
COLORMAP_QUALITATIVE = 'tab20'  # Good for up to 20 distinct items

# Professional color palette (distinguishable for colorblind)
COLORS_DISTINGUISHABLE = [
    '#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd',
    '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf',
    '#aec7e8', '#ffbb78', '#98df8a', '#ff9896', '#c5b0d5',
    '#c49c94', '#f7b6d2', '#c7c7c7', '#dbdb8d', '#9edae5'
]

# Layout
LEGEND_MAX_ITEMS = 8  # Auto-hide legend if more items
GRID_MAX_COLS = 4     # Max columns in grid layouts
LINE_ALPHA = 0.75
LINE_WIDTH = 1.5
MARKER_SIZE = 4

# ═══════════════════════════════════════════════════════════════════════════
# Matplotlib Style Configuration
# ═══════════════════════════════════════════════════════════════════════════

def setup_publication_style():
    """Configure matplotlib for publication-quality plots."""
    plt.rcParams.update({
        # Figure
        'figure.facecolor': 'white',
        'figure.dpi': DPI_SCREEN,
        'savefig.dpi': DPI_PRINT,
        'savefig.bbox': 'standard',
        'savefig.pad_inches': 0.1,
        
        # Font
        'font.family': 'sans-serif',
        'font.sans-serif': ['DejaVu Sans', 'Arial', 'Helvetica'],
        'font.size': FONT_SIZE_TICK,
        'axes.titlesize': FONT_SIZE_TITLE,
        'axes.labelsize': FONT_SIZE_LABEL,
        'xtick.labelsize': FONT_SIZE_TICK,
        'ytick.labelsize': FONT_SIZE_TICK,
        'legend.fontsize': FONT_SIZE_LEGEND,
        
        # Lines
        'lines.linewidth': LINE_WIDTH,
        'lines.markersize': MARKER_SIZE,
        
        # Axes
        'axes.linewidth': 1.0,
        'axes.grid': True,
        'axes.axisbelow': True,
        'grid.alpha': 0.3,
        'grid.linestyle': '--',
        
        # Legend
        'legend.frameon': True,
        'legend.framealpha': 0.9,
        'legend.fancybox': False,
        'legend.edgecolor': 'gray',
    })

# ═══════════════════════════════════════════════════════════════════════════
# Utility Functions
# ═══════════════════════════════════════════════════════════════════════════

def _to_num(x, default=np.nan) -> float:
    """Convert to float, return default if not numeric."""
    if x is None:
        return default
    try:
        val = float(x)
        return val if np.isfinite(val) else default
    except (ValueError, TypeError):
        return default


# ═══════════════════════════════════════════════════════════════════════════
# Enhanced Field Name Formatting (LaTeX-style)
# ═══════════════════════════════════════════════════════════════════════════

# Greek letter mapping
GREEK_LETTERS = {
    'alpha': 'α', 'beta': 'β', 'gamma': 'γ', 'Gamma': 'Γ',
    'delta': 'δ', 'Delta': 'Δ', 'epsilon': 'ε', 'zeta': 'ζ',
    'eta': 'η', 'theta': 'θ', 'Theta': 'Θ', 'iota': 'ι',
    'kappa': 'κ', 'lambda': 'λ', 'Lambda': 'Λ', 'mu': 'μ',
    'nu': 'ν', 'xi': 'ξ', 'Xi': 'Ξ', 'pi': 'π', 'Pi': 'Π',
    'rho': 'ρ', 'sigma': 'σ', 'Sigma': 'Σ', 'tau': 'τ',
    'upsilon': 'υ', 'Upsilon': 'Υ', 'phi': 'φ', 'Phi': 'Φ',
    'chi': 'χ', 'psi': 'ψ', 'Psi': 'Ψ', 'omega': 'ω', 'Omega': 'Ω',
}

# Unicode subscript/superscript maps
SUBSCRIPT_MAP = {
    '0': '₀', '1': '₁', '2': '₂', '3': '₃', '4': '₄', '5': '₅',
    '6': '₆', '7': '₇', '8': '₈', '9': '₉', 'a': 'ₐ', 'e': 'ₑ',
    'h': 'ₕ', 'i': 'ᵢ', 'j': 'ⱼ', 'k': 'ₖ', 'l': 'ₗ', 'm': 'ₘ',
    'n': 'ₙ', 'o': 'ₒ', 'p': 'ₚ', 'r': 'ᵣ', 's': 'ₛ', 't': 'ₜ',
    'u': 'ᵤ', 'v': 'ᵥ', 'x': 'ₓ',
}

SUPERSCRIPT_MAP = {
    '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴', '5': '⁵',
    '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹', '+': '⁺', '-': '⁻',
    '=': '⁼', '(': '⁽', ')': '⁾', 'n': 'ⁿ', 'i': 'ⁱ',
}

def _to_subscript(text: str) -> str:
    """Convert text to Unicode subscript."""
    return ''.join(SUBSCRIPT_MAP.get(c, c) for c in text)

def _to_superscript(text: str) -> str:
    """Convert text to Unicode superscript."""
    return ''.join(SUPERSCRIPT_MAP.get(c, c) for c in text)


def _format_field_name(field: str) -> str:
    """
    Convert field name to publication-ready LaTeX-style format.
    
    Examples:
        'mu_q_center_dim1' → 'μq Center (Dim 1)'
        'phi_norm_mean' → '‖φ‖ (Mean)'
        'model_alignment_kl' → 'Model Alignment KL'
        'sigma_2' → 'σ²'
        'grad_norm' → '‖∇‖'
    """
    if not field:
        return ""
    
    import re
    label = field
    
    # Step 1: Dimension indicators
    label = re.sub(r'_dim(\d+)', lambda m: f' (Dim {m.group(1)})', label)
    
    # Step 2: Gradient notation
    label = label.replace('grad_', '∇_')
    label = re.sub(r'\bgrad\b', '∇', label)
    
    # Step 3: Greek letters (sorted by length to avoid partial matches)
    greek_sorted = sorted(GREEK_LETTERS.items(), key=lambda x: len(x[0]), reverse=True)
    for greek, symbol in greek_sorted:
        label = re.sub(
            r'(^|_)' + greek + r'($|_)',
            r'\1' + symbol + r'\2',
            label,
            flags=re.IGNORECASE
        )
    
    # Step 4: Norm patterns → ‖...‖
    def replace_norm(match):
        prefix = match.group(1)
        suffix = match.group(2) if match.lastindex >= 2 else ''
        parts = prefix.split('_')
        if len(parts) == 2:
            base, sub = parts
            if len(sub) == 1 and sub.islower():
                prefix_clean = base + _to_subscript(sub)
            else:
                prefix_clean = base + ' ' + sub
        else:
            prefix_clean = ' '.join(parts) if len(parts) > 2 else parts[0]
        
        result = f'‖{prefix_clean}‖'
        if suffix == '_mean':
            result += ' (Mean)'
        elif suffix == '_std':
            result += ' (Std)'
        return result
    
    label = re.sub(r'([a-zA-Zα-ωΑ-Ω_∇]+?)_norm(_mean|_std)?$', replace_norm, label)
    
    # Step 5: Subscripts for Greek letters
    label = re.sub(r'([α-ωΑ-Ω∇])_([a-z])', lambda m: m.group(1) + _to_subscript(m.group(2)), label)
    
    # Step 6: Superscripts for powers
    label = re.sub(r'([α-ωΑ-Ω])_(\d)', lambda m: m.group(1) + _to_superscript(m.group(2)), label)
    
    # Step 7: Common suffixes
    replacements = {
        '_mean': ' (Mean)', '_std': ' (Std)', '_avg': ' (Avg)',
        '_min': ' (Min)', '_max': ' (Max)', '_sum': ' (Sum)',
        '_total': ' Total', '_kl': ' KL', '_divergence': ' Divergence',
        '_alignment': ' Alignment', '_center': ' Center',
        '_model': ' Model', '_belief': ' Belief', '_self': ' Self',
        'self_': 'Self ',
    }
    for old, new in replacements.items():
        label = label.replace(old, new)
    
    # Step 8: Prefixes
    if label.startswith('E_') or (label.startswith('E') and len(label) > 1 and label[1].isupper()):
        label = re.sub(r'^E_?', 'E', label)
    label = re.sub(r'^Action_', 'Action ', label)
    label = re.sub(r'^Geom_', 'Geometric ', label)
    label = re.sub(r'\bcurv\b', 'Curvature', label, flags=re.IGNORECASE)
    label = re.sub(r'\balign_([a-z])', lambda m: 'Align' + _to_subscript(m.group(1)), label, flags=re.IGNORECASE)
    
    # Step 9: Remaining underscores
    label = re.sub(
        r'([a-zA-Zα-ωΑ-Ω0-9₀-₉⁰-⁹∇])_([a-zA-Z0-9])',
        lambda m: m.group(1) + (' ' if not any(0x2070 <= ord(c) <= 0x209F for c in m.group(1) + m.group(2)) else '') + m.group(2),
        label
    )
    
    # Step 10: Clean up and capitalize
    label = re.sub(r'\s+', ' ', label)
    words = []
    for word in label.split():
        if not word:
            continue
        first = word[0]
        if word.startswith('('):
            words.append(word)
        elif ord(first) >= 0x370 or ord(first) >= 0x2070 or first in '‖∇∂∫∑∏√':
            words.append(word)
        elif first.isalpha() and first.islower() and ord(first) < 128:
            words.append(first.upper() + word[1:])
        else:
            words.append(word)
    
    label = ' '.join(words)
    label = re.sub(r'\bKl\b', 'KL', label)
    label = re.sub(r'\bkl\b', 'KL', label)
    
    return label.strip()


def _get_color_cycle(n: int) -> List[str]:
    """Get n distinguishable colors."""
    if n <= len(COLORS_DISTINGUISHABLE):
        return COLORS_DISTINGUISHABLE[:n]
    else:
        # Fall back to colormap for many items
        cmap = plt.cm.get_cmap(COLORMAP_QUALITATIVE)
        return [cmap(i / n) for i in range(n)]


# ═══════════════════════════════════════════════════════════════════════════
# STRATEGY 1: Faceted Time Series (One subplot per agent)
# ═══════════════════════════════════════════════════════════════════════════

def plot_timeseries_faceted(
    field: str,
    rows: List[Dict],
    output_path: Path,
    *,
    title: str | None = None,
    max_cols: int = GRID_MAX_COLS,
    figsize: tuple | None = None,
    dpi: int = DPI_SCREEN
):
    """
    Create faceted time series plot - one subplot per agent.
    
    Perfect for: Comparing agent behaviors side-by-side
    
    Args:
        field: Metric to plot
        rows: Data rows with 'step', 'agent', and field
        output_path: Save path
        title: Overall title (auto-generated if None)
        max_cols: Max columns in grid
        figsize: Figure size override
        dpi: Resolution
    """
    setup_publication_style()
    
    # Group by agent
    agents = defaultdict(list)
    for r in rows:
        agent_id = r.get('agent')
        if agent_id is not None:
            agents[agent_id].append(r)
    
    if not agents:
        return
    
    agent_ids = sorted(agents.keys())
    n_agents = len(agent_ids)
    
    # Calculate grid layout
    n_cols = min(max_cols, n_agents)
    n_rows = int(np.ceil(n_agents / n_cols))
    
    # Create figure
    if figsize is None:
        figsize = (4 * n_cols, 3 * n_rows)
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=figsize, dpi=dpi,
                             squeeze=False, sharex=True, sharey=True)
    axes = axes.flatten()
    
    # Plot each agent
    for idx, agent_id in enumerate(agent_ids):
        ax = axes[idx]
        agent_rows = sorted(agents[agent_id], key=lambda r: r.get('step', 0))
        
        steps = np.array([r['step'] for r in agent_rows], dtype=float)
        values = np.array([_to_num(r.get(field)) for r in agent_rows], dtype=float)
        
        mask = np.isfinite(steps) & np.isfinite(values)
        if np.any(mask):
            ax.plot(steps[mask], values[mask], color=COLORS_DISTINGUISHABLE[idx % 20],
                   linewidth=LINE_WIDTH, alpha=LINE_ALPHA)
        
        # Styling
        ax.set_title(f'Agent {agent_id}', fontsize=FONT_SIZE_LEGEND, fontweight='bold')
        ax.grid(True, alpha=0.3)
        
        # Labels only on edge subplots
        if idx >= n_agents - n_cols:  # Bottom row
            ax.set_xlabel('Step', fontsize=FONT_SIZE_LABEL)
        if idx % n_cols == 0:  # Left column
            ax.set_ylabel(_format_field_name(field), fontsize=FONT_SIZE_LABEL)
    
    # Hide unused subplots
    for idx in range(n_agents, len(axes)):
        axes[idx].axis('off')
    
    # Overall title
    if title is None:
        title = f'{_format_field_name(field)} Across Agents'
    fig.suptitle(title, fontsize=FONT_SIZE_TITLE, fontweight='bold', y=0.995)
    
    plt.tight_layout(rect=[0, 0, 1, 0.99])
    fig.savefig(output_path, dpi=dpi, bbox_inches='tight')
    plt.close(fig)


# ═══════════════════════════════════════════════════════════════════════════
# STRATEGY 2: Summary Statistics (Mean ± Std envelope)
# ═══════════════════════════════════════════════════════════════════════════

def plot_timeseries_summary(
    field: str,
    rows: List[Dict],
    output_path: Path,
    *,
    title: str | None = None,
    show_individual: bool = False,
    figsize: tuple = FIGSIZE_SINGLE,
    dpi: int = DPI_SCREEN
):
    """
    Plot mean and std envelope across agents, optionally with individual traces.
    
    Perfect for: Showing aggregate behavior with uncertainty
    
    Args:
        field: Metric to plot
        rows: Data rows
        output_path: Save path
        title: Plot title
        show_individual: Show faded individual agent traces
        figsize: Figure size
        dpi: Resolution
    """
    setup_publication_style()
    
    # Group by agent and step
    data_by_step = defaultdict(list)
    agents_by_step = defaultdict(dict)
    
    for r in rows:
        step = r.get('step')
        agent_id = r.get('agent')
        value = _to_num(r.get(field))
        
        if step is not None and np.isfinite(value):
            data_by_step[step].append(value)
            if agent_id is not None:
                agents_by_step[step][agent_id] = value
    
    if not data_by_step:
        return
    
    # Compute statistics
    steps = sorted(data_by_step.keys())
    means = [np.mean(data_by_step[s]) for s in steps]
    stds = [np.std(data_by_step[s]) for s in steps]
    mins = [np.min(data_by_step[s]) for s in steps]
    maxs = [np.max(data_by_step[s]) for s in steps]
    
    steps = np.array(steps)
    means = np.array(means)
    stds = np.array(stds)
    mins = np.array(mins)
    maxs = np.array(maxs)
    
    # Create figure
    fig, ax = plt.subplots(figsize=figsize, dpi=dpi)
    
    # Individual traces (if requested)
    if show_individual:
        # Get all agent IDs
        all_agent_ids = set()
        for step_agents in agents_by_step.values():
            all_agent_ids.update(step_agents.keys())
        agent_ids = sorted(all_agent_ids)
        colors = _get_color_cycle(len(agent_ids))
        
        for agent_id, color in zip(agent_ids, colors):
            agent_steps = []
            agent_values = []
            for step in steps:
                if agent_id in agents_by_step[step]:
                    agent_steps.append(step)
                    agent_values.append(agents_by_step[step][agent_id])
            
            if agent_steps:
                ax.plot(agent_steps, agent_values, color=color, 
                       alpha=0.15, linewidth=0.8, zorder=1)
    
    # Mean line with std envelope
    ax.plot(steps, means, color='navy', linewidth=2.5, label='Mean', zorder=3)
    ax.fill_between(steps, means - stds, means + stds, 
                     color='navy', alpha=0.2, label='±1 Std', zorder=2)
    
    # Min/max envelope (lighter)
    ax.fill_between(steps, mins, maxs, 
                     color='navy', alpha=0.05, label='Min-Max Range', zorder=1)
    
    # Styling
    ax.set_xlabel('Step', fontsize=FONT_SIZE_LABEL)
    ax.set_ylabel(_format_field_name(field), fontsize=FONT_SIZE_LABEL)
    
    if title is None:
        title = f'{_format_field_name(field)} - Population Summary'
    ax.set_title(title, fontsize=FONT_SIZE_TITLE, fontweight='bold', pad=15)
    
    ax.legend(loc='best', frameon=True, fancybox=False)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    fig.savefig(output_path, dpi=dpi, bbox_inches='tight')
    plt.close(fig)


# ═══════════════════════════════════════════════════════════════════════════
# STRATEGY 3: Ranked by Final Value
# ═══════════════════════════════════════════════════════════════════════════

def plot_timeseries_ranked(
    field: str,
    rows: List[Dict],
    output_path: Path,
    *,
    title: str | None = None,
    top_n: int = 5,
    bottom_n: int = 3,
    figsize: tuple = FIGSIZE_SINGLE,
    dpi: int = DPI_SCREEN
):
    """
    Plot only top N and bottom N agents by final value.
    
    Perfect for: Highlighting best and worst performers
    
    Args:
        field: Metric to plot
        rows: Data rows
        output_path: Save path
        title: Plot title
        top_n: Number of best agents to show
        bottom_n: Number of worst agents to show
        figsize: Figure size
        dpi: Resolution
    """
    setup_publication_style()
    
    # Group by agent
    agents = defaultdict(list)
    for r in rows:
        agent_id = r.get('agent')
        if agent_id is not None:
            agents[agent_id].append(r)
    
    if not agents:
        return
    
    # Get final values
    final_values = {}
    for agent_id, agent_rows in agents.items():
        agent_rows = sorted(agent_rows, key=lambda r: r.get('step', 0))
        final_val = _to_num(agent_rows[-1].get(field))
        if np.isfinite(final_val):
            final_values[agent_id] = final_val
    
    if not final_values:
        return
    
    # Rank
    ranked = sorted(final_values.items(), key=lambda x: x[1], reverse=True)
    
    # Select top and bottom
    selected = []
    if top_n > 0:
        selected.extend(ranked[:top_n])
    if bottom_n > 0:
        selected.extend(ranked[-bottom_n:])
    
    selected_ids = [aid for aid, _ in selected]
    
    # Create figure
    fig, ax = plt.subplots(figsize=figsize, dpi=dpi)
    
    colors = _get_color_cycle(len(selected_ids))
    
    for idx, agent_id in enumerate(selected_ids):
        agent_rows = sorted(agents[agent_id], key=lambda r: r.get('step', 0))
        
        steps = np.array([r['step'] for r in agent_rows], dtype=float)
        values = np.array([_to_num(r.get(field)) for r in agent_rows], dtype=float)
        
        mask = np.isfinite(steps) & np.isfinite(values)
        if np.any(mask):
            # Label with rank
            if idx < top_n:
                rank = idx + 1
                label = f'#{rank}: Agent {agent_id} ({final_values[agent_id]:.3f})'
                linestyle = '-'
            else:
                rank = len(final_values) - (len(selected_ids) - idx - 1)
                label = f'#{rank}: Agent {agent_id} ({final_values[agent_id]:.3f})'
                linestyle = '--'
            
            ax.plot(steps[mask], values[mask], color=colors[idx],
                   linewidth=LINE_WIDTH, alpha=LINE_ALPHA, 
                   linestyle=linestyle, label=label)
    
    # Styling
    ax.set_xlabel('Step', fontsize=FONT_SIZE_LABEL)
    ax.set_ylabel(_format_field_name(field), fontsize=FONT_SIZE_LABEL)
    
    if title is None:
        title = f'{_format_field_name(field)} - Top {top_n} & Bottom {bottom_n} Agents'
    ax.set_title(title, fontsize=FONT_SIZE_TITLE, fontweight='bold', pad=15)
    
    ax.legend(loc='best', frameon=True, ncol=1, fontsize=FONT_SIZE_LEGEND-1)
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    fig.savefig(output_path, dpi=dpi, bbox_inches='tight')
    plt.close(fig)


# ═══════════════════════════════════════════════════════════════════════════
# STRATEGY 4: Heatmap over Time
# ═══════════════════════════════════════════════════════════════════════════

def plot_timeseries_heatmap(
    field: str,
    rows: List[Dict],
    output_path: Path,
    *,
    title: str | None = None,
    figsize: tuple = FIGSIZE_WIDE,
    dpi: int = DPI_SCREEN,
    cmap: str = COLORMAP_SEQUENTIAL
):
    """
    Create heatmap showing field value for each agent over time.
    
    Perfect for: Dense visualization of all agents
    
    Args:
        field: Metric to plot
        rows: Data rows
        output_path: Save path
        title: Plot title
        figsize: Figure size
        dpi: Resolution
        cmap: Colormap
    """
    setup_publication_style()
    
    # Build matrix: agents × steps
    agents = defaultdict(dict)
    all_steps = set()
    
    for r in rows:
        agent_id = r.get('agent')
        step = r.get('step')
        value = _to_num(r.get(field))
        
        if agent_id is not None and step is not None and np.isfinite(value):
            agents[agent_id][step] = value
            all_steps.add(step)
    
    if not agents or not all_steps:
        return
    
    agent_ids = sorted(agents.keys())
    steps = sorted(all_steps)
    
    # Create matrix
    matrix = np.full((len(agent_ids), len(steps)), np.nan)
    for i, agent_id in enumerate(agent_ids):
        for j, step in enumerate(steps):
            if step in agents[agent_id]:
                matrix[i, j] = agents[agent_id][step]
    
    # Create figure
    fig, ax = plt.subplots(figsize=figsize, dpi=dpi)
    
    # Heatmap
    im = ax.imshow(matrix, aspect='auto', cmap=cmap, interpolation='nearest')
    
    # Colorbar
    cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label(_format_field_name(field), fontsize=FONT_SIZE_LABEL)
    
    # Ticks
    # Show subset of steps if too many
    n_ticks = min(10, len(steps))
    tick_indices = np.linspace(0, len(steps)-1, n_ticks, dtype=int)
    ax.set_xticks(tick_indices)
    ax.set_xticklabels([steps[i] for i in tick_indices], rotation=45, ha='right')
    
    # Show all agents if reasonable, else subsample
    if len(agent_ids) <= 20:
        ax.set_yticks(range(len(agent_ids)))
        ax.set_yticklabels([f'Agent {aid}' for aid in agent_ids])
    else:
        n_yticks = 10
        tick_indices = np.linspace(0, len(agent_ids)-1, n_yticks, dtype=int)
        ax.set_yticks(tick_indices)
        ax.set_yticklabels([f'Agent {agent_ids[i]}' for i in tick_indices])
    
    # Labels
    ax.set_xlabel('Step', fontsize=FONT_SIZE_LABEL)
    ax.set_ylabel('Agent', fontsize=FONT_SIZE_LABEL)
    
    if title is None:
        title = f'{_format_field_name(field)} Heatmap'
    ax.set_title(title, fontsize=FONT_SIZE_TITLE, fontweight='bold', pad=15)
    
    plt.tight_layout()
    fig.savefig(output_path, dpi=dpi, bbox_inches='tight')
    plt.close(fig)


# ═══════════════════════════════════════════════════════════════════════════
# STRATEGY 5: Multi-field Comparison (Small Multiples)
# ═══════════════════════════════════════════════════════════════════════════

def plot_multifield_comparison(
    fields: List[str],
    rows: List[Dict],
    output_path: Path,
    *,
    title: str | None = None,
    mode: Literal['summary', 'faceted'] = 'summary',
    figsize: tuple | None = None,
    dpi: int = DPI_SCREEN
):
    """
    Compare multiple fields in a grid layout.
    
    Args:
        fields: List of metrics to compare
        rows: Data rows
        output_path: Save path
        title: Overall title
        mode: 'summary' for mean±std, 'faceted' for agent subplots
        figsize: Figure size override
        dpi: Resolution
    """
    setup_publication_style()
    
    n_fields = len(fields)
    if n_fields == 0:
        return
    
    # Calculate layout
    n_cols = min(2, n_fields)
    n_rows = int(np.ceil(n_fields / n_cols))
    
    if figsize is None:
        figsize = (7 * n_cols, 4 * n_rows)
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=figsize, dpi=dpi, squeeze=False)
    axes = axes.flatten()
    
    for idx, field in enumerate(fields):
        ax = axes[idx]
        
        if mode == 'summary':
            # Plot mean ± std
            data_by_step = defaultdict(list)
            for r in rows:
                step = r.get('step')
                value = _to_num(r.get(field))
                if step is not None and np.isfinite(value):
                    data_by_step[step].append(value)
            
            if data_by_step:
                steps = sorted(data_by_step.keys())
                means = [np.mean(data_by_step[s]) for s in steps]
                stds = [np.std(data_by_step[s]) for s in steps]
                
                steps = np.array(steps)
                means = np.array(means)
                stds = np.array(stds)
                
                ax.plot(steps, means, color='navy', linewidth=2)
                ax.fill_between(steps, means - stds, means + stds,
                               color='navy', alpha=0.2)
        
        elif mode == 'faceted':
            # Plot all agents
            agents = defaultdict(list)
            for r in rows:
                agent_id = r.get('agent')
                if agent_id is not None:
                    agents[agent_id].append(r)
            
            colors = _get_color_cycle(len(agents))
            for (agent_id, agent_rows), color in zip(sorted(agents.items()), colors):
                agent_rows = sorted(agent_rows, key=lambda r: r.get('step', 0))
                steps = np.array([r['step'] for r in agent_rows], dtype=float)
                values = np.array([_to_num(r.get(field)) for r in agent_rows], dtype=float)
                
                mask = np.isfinite(steps) & np.isfinite(values)
                if np.any(mask):
                    ax.plot(steps[mask], values[mask], color=color, 
                           alpha=0.5, linewidth=1)
        
        # Styling
        ax.set_xlabel('Step', fontsize=FONT_SIZE_LABEL)
        ax.set_ylabel(_format_field_name(field), fontsize=FONT_SIZE_LABEL)
        ax.set_title(_format_field_name(field), fontsize=FONT_SIZE_LEGEND+1, 
                    fontweight='bold')
        ax.grid(True, alpha=0.3)
    
    # Hide unused
    for idx in range(n_fields, len(axes)):
        axes[idx].axis('off')
    
    # Overall title
    if title is None:
        title = 'Multi-Field Comparison'
    fig.suptitle(title, fontsize=FONT_SIZE_TITLE, fontweight='bold', y=0.995)
    
    plt.tight_layout(rect=[0, 0, 1, 0.99])
    fig.savefig(output_path, dpi=dpi, bbox_inches='tight')
    plt.close(fig)


# ═══════════════════════════════════════════════════════════════════════════
# Global Metrics (No Agent Dimension)
# ═══════════════════════════════════════════════════════════════════════════

def plot_global_metrics(
    fields: List[str],
    rows: List[Dict],
    output_path: Path,
    *,
    title: str | None = None,
    figsize: tuple | None = None,
    dpi: int = DPI_SCREEN
):
    """
    Plot global metrics (no agent dimension) in clean multi-panel layout.
    
    Args:
        fields: Metrics to plot
        rows: Data rows with 'step' and field values
        output_path: Save path
        title: Overall title
        figsize: Figure size
        dpi: Resolution
    """
    setup_publication_style()
    
    n_fields = len(fields)
    if n_fields == 0:
        return
    
    # Layout
    n_cols = min(2, n_fields)
    n_rows = int(np.ceil(n_fields / n_cols))
    
    if figsize is None:
        figsize = (7 * n_cols, 4 * n_rows)
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=figsize, dpi=dpi, squeeze=False)
    axes = axes.flatten()
    
    for idx, field in enumerate(fields):
        ax = axes[idx]
        
        # Extract data
        sorted_rows = sorted(rows, key=lambda r: r.get('step', 0))
        steps = np.array([r['step'] for r in sorted_rows], dtype=float)
        values = np.array([_to_num(r.get(field)) for r in sorted_rows], dtype=float)
        
        mask = np.isfinite(steps) & np.isfinite(values)
        
        if np.any(mask):
            ax.plot(steps[mask], values[mask], color='darkblue', 
                   linewidth=LINE_WIDTH+0.5, alpha=0.9)
        
        # Styling
        ax.set_xlabel('Step', fontsize=FONT_SIZE_LABEL)
        ax.set_ylabel(_format_field_name(field), fontsize=FONT_SIZE_LABEL)
        ax.set_title(_format_field_name(field), fontsize=FONT_SIZE_LEGEND+1,
                    fontweight='bold')
        ax.grid(True, alpha=0.3)
    
    # Hide unused
    for idx in range(n_fields, len(axes)):
        axes[idx].axis('off')
    
    # Overall title
    if title is None:
        title = 'Global Metrics'
    fig.suptitle(title, fontsize=FONT_SIZE_TITLE, fontweight='bold', y=0.995)
    
    plt.tight_layout(rect=[0, 0, 1, 0.99])
    fig.savefig(output_path, dpi=dpi, bbox_inches='tight')
    plt.close(fig)


# ═══════════════════════════════════════════════════════════════════════════
# Example Usage & Integration Helper
# ═══════════════════════════════════════════════════════════════════════════

def auto_visualize_metrics(
    agent_rows: List[Dict],
    global_rows: List[Dict],
    output_dir: Path,
    *,
    agent_fields: List[str] | None = None,
    global_fields: List[str] | None = None,
    strategies: List[str] = ['faceted', 'summary', 'ranked'],
    dpi: int = DPI_SCREEN
):
    """
    Automatically generate all visualization types for agent and global metrics.
    
    Args:
        agent_rows: Per-agent metric rows
        global_rows: Global metric rows
        output_dir: Output directory
        agent_fields: Fields to visualize (auto-detect if None)
        global_fields: Global fields to visualize
        strategies: Which strategies to use ['faceted', 'summary', 'ranked', 'heatmap']
        dpi: Resolution
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Auto-detect fields
    if agent_fields is None and agent_rows:
        exclude = {'step', 'agent', 'run_id', 'ts'}
        agent_fields = [k for k in agent_rows[0].keys() 
                       if k not in exclude and _to_num(agent_rows[0][k]) == _to_num(agent_rows[0][k])]
    
    if global_fields is None and global_rows:
        exclude = {'step', 'run_id', 'ts'}
        global_fields = [k for k in global_rows[0].keys()
                        if k not in exclude and _to_num(global_rows[0][k]) == _to_num(global_rows[0][k])]
    
    # Agent visualizations
    for field in agent_fields or []:
        field_safe = field.replace('/', '_').replace(' ', '_')
        
        if 'faceted' in strategies:
            plot_timeseries_faceted(
                field, agent_rows,
                output_dir / f'{field_safe}_faceted.png',
                dpi=dpi
            )
        
        if 'summary' in strategies:
            plot_timeseries_summary(
                field, agent_rows,
                output_dir / f'{field_safe}_summary.png',
                dpi=dpi
            )
        
        if 'ranked' in strategies:
            plot_timeseries_ranked(
                field, agent_rows,
                output_dir / f'{field_safe}_ranked.png',
                dpi=dpi
            )
        
        if 'heatmap' in strategies:
            plot_timeseries_heatmap(
                field, agent_rows,
                output_dir / f'{field_safe}_heatmap.png',
                dpi=dpi
            )
    
    # Global visualizations
    if global_fields:
        plot_global_metrics(
            global_fields, global_rows,
            output_dir / 'global_metrics.png',
            dpi=dpi
        )
    
    # Multi-field comparisons
    if agent_fields and len(agent_fields) >= 2:
        plot_multifield_comparison(
            agent_fields[:6],  # Limit to prevent overcrowding
            agent_rows,
            output_dir / 'multifield_summary.png',
            mode='summary',
            dpi=dpi
        )


if __name__ == '__main__':
    print("Professional metrics visualization module loaded.")
    print("Key functions:")
    print("  - plot_timeseries_faceted(): One subplot per agent")
    print("  - plot_timeseries_summary(): Mean ± std with envelope")
    print("  - plot_timeseries_ranked(): Top/bottom performers")
    print("  - plot_timeseries_heatmap(): Dense heatmap view")
    print("  - plot_multifield_comparison(): Compare multiple metrics")
    print("  - auto_visualize_metrics(): Generate all visualizations")