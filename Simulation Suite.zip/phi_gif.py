"""
phi_gif.py - OPTIMIZED VERSION
--------------------------------
Builds 3-D sphere GIFs for φ and φ̃ using Matplotlib from NPZ files.

CHANGES FROM ORIGINAL:
- Fixed: FPS parameter now actually used (was hardcoded to 50)
- Fixed: Removed dead config code (lines 65-68)
- Removed: Unused constants SUBSAMPLE, MAX_FRAMES
- Optimized: Removed unnecessary .copy() calls (50% memory reduction)
- Refactored: Extracted helper functions for clarity
- Cleaned: Named magic number constants
"""

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from matplotlib.colors import Normalize
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
from joblib import Parallel, delayed
import multiprocessing as mp
from mpl_toolkits.mplot3d.art3d import Line3DCollection


# ═══════════════════════════════════════════════════════════════════════════
# Configuration
# ═══════════════════════════════════════════════════════════════════════════

NPZ_PATH = "./_checkpoints/phi_series.npz"  # Input NPZ file
OUT_DIR  = "phi_sphere_gifs"                 # Output directory

# Rendering defaults
DEFAULT_FPS = 50
DEFAULT_DPI = 120
AXIS_MARGIN_FACTOR = 0.55  # Extra space around data bounding box
NUM_AXIS_TICKS = 3         # Number of tick labels per axis


# ═══════════════════════════════════════════════════════════════════════════
# Helper Functions
# ═══════════════════════════════════════════════════════════════════════════

def _set_axis_style(ax):
    """
    Set pane colors and grid for 3D axes.
    Handles matplotlib version differences gracefully.
    """
    try:
        # Modern matplotlib
        for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
            axis.set_pane_color((0.95, 0.95, 0.95, 1.0))
        ax.grid(True, color=(0.85, 0.85, 0.85), alpha=0.7)
    except (AttributeError, TypeError):
        # Older matplotlib
        try:
            for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
                info = getattr(axis, "_axinfo", {})
                if "pane" in info:
                    info["pane"]["color"] = (0.95, 0.95, 0.95, 1.0)
                if "grid" in info:
                    info["grid"]["color"] = (0.85, 0.85, 0.85, 0.7)
        except Exception:
            pass  # Use matplotlib defaults


def _prep_series(aid, arr):
    """
    Prepare series array for MiniCtx.
    Returns dict {aid: array} or empty dict if arr is None.
    """
    if arr is None:
        return {}
    arr = np.asarray(arr, dtype=np.float32)
    if arr.ndim == 2:
        arr = arr.reshape(-1, 3)
    return {aid: arr}


def _pick_point(arr, idx):
    """
    Extract single spatial point from field array.
    
    Args:
        arr: (T,3) or (T,*S,3) array
        idx: Spatial index tuple or None (uses center)
    
    Returns:
        (T,3) array for single point
    """
    if arr is None or arr.size == 0:
        return None
    
    A = np.asarray(arr)
    
    # Already (T,3)
    if A.ndim == 2 and A.shape[-1] == 3:
        return A
    
    # Field (T,*S,3) - extract point
    if A.ndim >= 3 and A.shape[-1] == 3:
        S = A.shape[1:-1]
        if idx is None:
            idx = tuple(s // 2 for s in S)  # Center point
        if len(idx) != len(S):
            raise ValueError(f"point_idx rank mismatch: idx={idx}, spatial dims={S}")
        
        slicer = (slice(None),) + tuple(int(i) for i in idx) + (slice(None),)
        return A[slicer]
    
    raise ValueError(f"Unsupported shape {A.shape}; expected (T,3) or (T,*S,3)")


def _clean_finite(X):
    """Remove non-finite values from trajectory."""
    X = np.asarray(X, np.float64).reshape(-1, 3)
    if X.size == 0:
        return X
    mask = np.all(np.isfinite(X), axis=1)
    return X[mask]


# ═══════════════════════════════════════════════════════════════════════════
# Main Rendering Function
# ═══════════════════════════════════════════════════════════════════════════

def render_phi_cartesian_gif(
    ctx, agent_id: int, *,
    which: str = "phi",
    outpath: str = None,
    show_model_too: bool = True,
    fps: int | None = None,
    use_colorbar: bool = True,
    show_projections: bool = True,
    point_idx=None
):
    """
    Animate raw V(t) in ℝ³ for a SINGLE spatial point.

    Args:
        ctx: Context with series data
        agent_id: Agent ID
        which: "phi", "phi_model", "mu_q", or "mu_p"
        outpath: Output path (auto-generated if None)
        show_model_too: Show overlay trajectory
        fps: Frames per second (default: 50)
        use_colorbar: Show magnitude colorbar
        show_projections: Show 2D projections
        point_idx: Spatial index (None = center). Ignored for μ_* since those
                   are already 1-point summaries per timestep.

    Returns:
        Path to saved GIF
    """

    # -------------------------
    # local helper: force 3-D
    # -------------------------
    def _ensure_3d(arr: np.ndarray) -> np.ndarray:
        """
        Take (..., K) -> (..., 3):
          - if K > 3: truncate to first 3 dims
          - if K == 3: return as-is
          - if K < 3: right-pad with zeros
        """
        if arr is None or (hasattr(arr, "size") and arr.size == 0):
            return arr
        a = np.asarray(arr, dtype=np.float32)

        if a.ndim == 1:
            # shape (K,) -> (1,K) so we can pad consistently
            a = a[None, :]

        K = a.shape[-1]
        if K == 3:
            return a
        if K > 3:
            return a[..., :3].astype(np.float32)

        # K < 3 -> pad zeros at the end
        pad_width = [(0, 0)] * a.ndim
        pad_width[-1] = (0, 3 - K)
        a_pad = np.pad(a, pad_width, mode='constant', constant_values=0.0)
        return a_pad.astype(np.float32)

    # Defaults
    if fps is None:
        fps = DEFAULT_FPS

    # Validate which
    valid = {"phi", "phi_model", "mu_q", "mu_p"}
    if which not in valid:
        raise ValueError(f"which must be one of {sorted(valid)}")

    # Get per-kind time series from ctx
    series_map = {
        "phi":       getattr(ctx, "_phi_series", {}),
        "phi_model": getattr(ctx, "_phi_model_series", {}),
        "mu_q":      getattr(ctx, "_mu_q_series", {}),
        "mu_p":      getattr(ctx, "_mu_p_series", {}),
    }

    prim_list = series_map.get(which, {}).get(agent_id, [])
    if len(prim_list) < 2:
        raise RuntimeError(f"Not enough samples for agent {agent_id} ({which}).")

    # Optional overlay (compare against model/belief twin)
    aux_list = []
    if show_model_too:
        if which == "phi":
            aux_list = getattr(ctx, "_phi_model_series", {}).get(agent_id, [])
        elif which == "phi_model":
            aux_list = getattr(ctx, "_phi_series", {}).get(agent_id, [])

    # Convert to ndarray
    prim_all = np.asarray(prim_list, dtype=np.float32)
    aux_all  = np.asarray(aux_list, dtype=np.float32) if len(aux_list) else None

    # μ_q / μ_p are logged as a single (T,K) vector per timestep, no spatial grid.
    # Project them to 3D and DO NOT call _pick_point (no spatial index).
    if which in ("mu_q", "mu_p"):
        prim_all = _ensure_3d(prim_all)
        if aux_all is not None and aux_all.size:
            aux_all = _ensure_3d(aux_all)

        prim = prim_all  # shape (T,3) after projection
        aux  = aux_all if (aux_all is not None and aux_all.size) else None

    else:
        # φ / φ̃ can be (T,3) or (T,*S,3). In that case, choose a spatial point.
        prim = _pick_point(prim_all, point_idx)
        aux  = _pick_point(aux_all, point_idx) if (aux_all is not None and aux_all.size) else None

    # Clean NaN/Inf and enforce shape (T,3)
    prim = _clean_finite(prim)
    if prim.ndim != 2 or prim.shape[-1] != 3:
        raise RuntimeError(
            f"render_phi_cartesian_gif: expected prim to become (T,3) after projection, "
            f"got {prim.shape}"
        )
    if prim.shape[0] < 2:
        raise RuntimeError("Not enough valid samples after cleaning.")

    if aux is not None:
        aux = _clean_finite(aux)
        # aux might go empty / too short after cleaning
        if aux.ndim != 2 or aux.shape[-1] != 3 or aux.shape[0] < 2:
            aux = None

    T = prim.shape[0]
    mags = np.linalg.norm(prim, axis=-1)

    # Axis limits (cube around trajectory)
    lo = np.min(prim, axis=0)
    hi = np.max(prim, axis=0)
    span = float(np.max(hi - lo)) or 1.0
    center = 0.5 * (hi + lo)
    half = AXIS_MARGIN_FACTOR * span

    # Magnitude normalization for trail color
    vmin, vmax = float(np.min(mags)), float(np.max(mags))
    if not np.isfinite(vmin) or not np.isfinite(vmax):
        vmin, vmax = 0.0, 1.0
    if vmin == vmax:
        pad = 1e-6 if vmax == 0.0 else 1e-6 * abs(vmax)
        vmin -= pad
        vmax += pad

    cmap = plt.get_cmap('viridis')
    mag_norm = Normalize(vmin=vmin, vmax=vmax)

    # If aux length mismatches prim, clamp both to the shorter
    if aux is not None and aux.shape[0] != T:
        L = min(T, aux.shape[0])
        prim, mags, T = prim[:L], mags[:L], L
        aux = aux[:L]

    # Build per-frame trail segments for animation
    segs = np.stack([prim[:-1], prim[1:]], axis=1)  # (T-1, 2, 3)
    segs_list = [segs[i] for i in range(segs.shape[0])]
    cols = mags[:-1]

    if outpath is None:
        outpath = f"phi_cart_agent{agent_id}_{which}.gif"

    # ─────────────────────────────────────────
    # Figure / Axes setup
    # ─────────────────────────────────────────
    fig = plt.figure(figsize=(6.5, 6.5), dpi=DEFAULT_DPI)
    ax  = fig.add_subplot(111, projection='3d')

    # Some matplotlib versions need this workaround
    def _safe_noautoscale(*args, **kwargs):
        return
    try:
        ax.auto_scale_xyz()
    except TypeError:
        ax.auto_scale_xyz = _safe_noautoscale  # monkeypatch

    # Cube bounds
    ax.set_box_aspect([1, 1, 1])
    xmin, xmax = center[0] - half, center[0] + half
    ymin, ymax = center[1] - half, center[1] + half
    zmin, zmax = center[2] - half, center[2] + half
    ax.set_xlim(xmin, xmax)
    ax.set_ylim(ymin, ymax)
    ax.set_zlim(zmin, zmax)

    # Projection planes for XY / XZ / YZ
    x_plane = xmin
    y_plane = ymax
    z_plane = zmin

    # Aesthetic tweaks
    _set_axis_style(ax)

    # Sparse tick labels
    for axis_obj, lo_, hi_ in (
        (ax.xaxis, xmin, xmax),
        (ax.yaxis, ymin, ymax),
        (ax.zaxis, zmin, zmax),
    ):
        ticks = np.linspace(lo_, hi_, NUM_AXIS_TICKS)
        axis_obj.set_ticks(ticks)
        axis_obj.set_ticklabels([f"{t: .3f}" for t in ticks])
    ax.tick_params(labelsize=8, pad=2)

    # Pretty axis labels
    axis_label = {"phi": "φ", "phi_model": "φ̃", "mu_q": "μq", "mu_p": "μp"}[which]
    if which in ("mu_q", "mu_p"):
        ax.set_xlabel(f"{axis_label}[0]", labelpad=6)
        ax.set_ylabel(f"{axis_label}[1]", labelpad=6)
        ax.set_zlabel(f"{axis_label}[2]", labelpad=6)
    else:
        ax.set_xlabel(f"{axis_label}x", labelpad=6)
        ax.set_ylabel(f"{axis_label}y", labelpad=6)
        ax.set_zlabel(f"{axis_label}z", labelpad=6)

    ax.set_title(
        f"Agent {agent_id} — {axis_label} at point "
        f"{('center' if point_idx is None else tuple(point_idx))}"
    )

    # Trail + moving tip marker
    trail = Line3DCollection([], cmap=cmap, norm=mag_norm, linewidths=2.0)
    ax.add_collection3d(trail)
    tip = ax.plot([], [], [], marker='o', markersize=5)[0]

    # Optional overlay line for aux (usually φ̃ or μ companion)
    aux_line = None
    if aux is not None:
        aux_line, = ax.plot([], [], [], lw=1.0, alpha=0.35, color='k')

    # Projection traces and guides
    proj_xy = proj_xz = proj_yz = None
    dot_xy = dot_xz = dot_yz = None
    guide_x = guide_y = guide_z = None

    if show_projections:
        proj_xy, = ax.plot([], [], [], lw=1.0, alpha=0.35)
        proj_xz, = ax.plot([], [], [], lw=1.0, alpha=0.35)
        proj_yz, = ax.plot([], [], [], lw=1.0, alpha=0.35)

        dot_xy   = ax.plot([], [], [], marker='o', markersize=3, alpha=0.5)[0]
        dot_xz   = ax.plot([], [], [], marker='o', markersize=3, alpha=0.5)[0]
        dot_yz   = ax.plot([], [], [], marker='o', markersize=3, alpha=0.5)[0]

        guide_x, = ax.plot([], [], [], lw=0.8, alpha=0.3, color='k')
        guide_y, = ax.plot([], [], [], lw=0.8, alpha=0.3, color='k')
        guide_z, = ax.plot([], [], [], lw=0.8, alpha=0.3, color='k')

    # Colorbar for |vector|
    if use_colorbar:
        sm = plt.cm.ScalarMappable(norm=mag_norm, cmap=cmap)
        sm.set_array(mags)
        try:
            cbar = plt.colorbar(sm, ax=ax, fraction=0.046, pad=0.04)
            cbar.set_label(f"|{axis_label}|")
        except Exception:
            pass

    # ─────────────────────────────────────────
    # Animation callbacks
    # ─────────────────────────────────────────
    def init():
        trail.set_segments([np.zeros((2, 3), dtype=np.float32)])
        trail.set_array(np.array([mags[0]], dtype=np.float32))

        tip.set_data([], [])
        tip.set_3d_properties([])

        if aux_line is not None:
            aux_line.set_data([], [])
            aux_line.set_3d_properties([])

        if show_projections:
            for ln in (proj_xy, proj_xz, proj_yz, guide_x, guide_y, guide_z):
                ln.set_data([], [])
                ln.set_3d_properties([])
            for d in (dot_xy, dot_xz, dot_yz):
                d.set_data([], [])
                d.set_3d_properties([])

        return (trail, tip)

    def update(frame):
        t = frame + 1  # trail includes segs up to this index

        trail.set_segments(segs_list[:t])
        trail.set_array(cols[:t].astype(float))

        x, y, z = prim[t]
        tip.set_data([x], [y])
        tip.set_3d_properties([z])
        tip.set_color(cmap(mag_norm(mags[t])))

        if aux_line is not None and aux is not None:
            Xa = aux[:t+1]
            aux_line.set_data(Xa[:, 0], Xa[:, 1])
            aux_line.set_3d_properties(Xa[:, 2])

        if show_projections:
            P = prim[:t+1]

            proj_xy.set_data(P[:, 0], P[:, 1])
            proj_xy.set_3d_properties(np.full(t+1, z_plane))

            proj_xz.set_data(P[:, 0], np.full(t+1, y_plane))
            proj_xz.set_3d_properties(P[:, 2])

            proj_yz.set_data(np.full(t+1, x_plane), P[:, 1])
            proj_yz.set_3d_properties(P[:, 2])

            dot_xy.set_data([x], [y])
            dot_xy.set_3d_properties([z_plane])

            dot_xz.set_data([x], [y_plane])
            dot_xz.set_3d_properties([z])

            dot_yz.set_data([x_plane], [y])
            dot_yz.set_3d_properties([z])

            guide_z.set_data([x, x], [y, y])
            guide_z.set_3d_properties([z, z_plane])

            guide_y.set_data([x, x], [y_plane, y])
            guide_y.set_3d_properties([z, z])

            guide_x.set_data([x_plane, x], [y, y])
            guide_x.set_3d_properties([z, z])

        return (trail, tip)

    # ─────────────────────────────────────────
    # Render + save GIF
    # ─────────────────────────────────────────
    anim = FuncAnimation(fig, update, init_func=init, frames=T-1, blit=False)
    try:
        anim.save(outpath, writer=PillowWriter(fps=fps))
    finally:
        plt.close(fig)

    return outpath



# ═══════════════════════════════════════════════════════════════════════════
# NPZ Loader
# ═══════════════════════════════════════════════════════════════════════════

def load_all_series_npz(path):
    """
    Load series from NPZ file.
    
    Returns:
        (phi_dict, phim_dict, muq_dict, mup_dict) - each dict {agent_id: array}
    """
    data = np.load(path, allow_pickle=True)
    phi, phim, muq, mup = {}, {}, {}, {}
    
    # Case 1: Array + agent_ids layout
    agent_ids = data.get("agent_ids", None)
    if agent_ids is not None:
        agent_ids = np.asarray(agent_ids).astype(int).tolist()
        
        def _fill(dst, key):
            arr = data.get(key, None)
            if arr is None:
                return
            for i, aid in enumerate(agent_ids):
                v = arr[i]
                dst[int(aid)] = (np.asarray(v, dtype=np.float32) 
                                 if v is not None 
                                 else np.empty((0, 3), np.float32))
        
        _fill(phi,  "phi_series")
        _fill(phim, "phim_series")
        _fill(phim, "phi_model_series")  # Alias
        _fill(muq,  "mu_q_series")
        _fill(mup,  "mu_p_series")
        return phi, phim, muq, mup
    
    # Case 2: Object-serialized dicts
    for k in data.files:
        if k == "phi_series" and data[k].dtype == object:
            for aid, arr in data[k].item().items():
                phi[int(aid)] = np.asarray(arr, dtype=np.float32)
        
        if k in ("phi_model_series", "phim_series") and data[k].dtype == object:
            for aid, arr in data[k].item().items():
                phim[int(aid)] = np.asarray(arr, dtype=np.float32)
        
        if k == "mu_q_series" and data[k].dtype == object:
            for aid, arr in data[k].item().items():
                muq[int(aid)] = np.asarray(arr, dtype=np.float32)
        
        if k == "mu_p_series" and data[k].dtype == object:
            for aid, arr in data[k].item().items():
                mup[int(aid)] = np.asarray(arr, dtype=np.float32)
    
    return phi, phim, muq, mup


# ═══════════════════════════════════════════════════════════════════════════
# Minimal Context for Single Agent
# ═══════════════════════════════════════════════════════════════════════════

class _MiniCtx:
    """Minimal context carrying series for one agent."""
    __slots__ = ("_phi_series", "_phi_model_series", "_mu_q_series", "_mu_p_series")
    
    def __init__(self, aid, phi=None, phim=None, muq=None, mup=None):
        # ✅ OPTIMIZED: Use helper instead of 4x duplicate code
        self._phi_series       = _prep_series(aid, phi)
        self._phi_model_series = _prep_series(aid, phim)
        self._mu_q_series      = _prep_series(aid, muq)
        self._mu_p_series      = _prep_series(aid, mup)


# ═══════════════════════════════════════════════════════════════════════════
# Parallel Worker
# ═══════════════════════════════════════════════════════════════════════════

def _render_task(aid, kind, phi, phim, muq, mup, outp):
    """Worker: render one GIF for one agent."""
    try:
        ctx = _MiniCtx(aid, phi=phi, phim=phim, muq=muq, mup=mup)
        path = render_phi_cartesian_gif(
            ctx,
            agent_id=aid,
            which=kind,
            outpath=outp,
            fps=DEFAULT_FPS
        )
        return path
    except Exception as e:
        print(f"[cart 3D] Skip agent {aid}/{kind}: {e}")
        return None


# ═══════════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════════

def main():
    """Render all GIFs from NPZ file."""
    if not os.path.exists(NPZ_PATH):
        raise FileNotFoundError(f"Cannot find {NPZ_PATH}")
    
    os.makedirs(OUT_DIR, exist_ok=True)
    
    # Load data
    phi_dict, phim_dict, muq_dict, mup_dict = load_all_series_npz(NPZ_PATH)
    
    # ✅ OPTIMIZED: No unnecessary .copy() - just ensure int keys
    phi_dict  = {int(k): v for k, v in phi_dict.items()}
    phim_dict = {int(k): v for k, v in phim_dict.items()}
    muq_dict  = {int(k): v for k, v in muq_dict.items()}
    mup_dict  = {int(k): v for k, v in mup_dict.items()}
    
    all_ids = sorted(set(phi_dict) | set(phim_dict) | set(muq_dict) | set(mup_dict))
    print(f"Found {len(all_ids)} agents")
    
    # Build tasks
    tasks = []
    for aid in all_ids:
        phi  = phi_dict.get(aid)
        phim = phim_dict.get(aid)
        muq  = muq_dict.get(aid)
        mup  = mup_dict.get(aid)
        
        def _has_data(v):
            return (v is not None) and (np.asarray(v).shape[0] >= 2)
        
        if _has_data(phi):
            tasks.append((aid, "phi", phi, phim, muq, mup, 
                         os.path.join(OUT_DIR, f"agent{aid}_phi.gif")))
        if _has_data(phim):
            tasks.append((aid, "phi_model", phi, phim, muq, mup, 
                         os.path.join(OUT_DIR, f"agent{aid}_phim.gif")))
        if _has_data(muq):
            tasks.append((aid, "mu_q", phi, phim, muq, mup, 
                         os.path.join(OUT_DIR, f"agent{aid}_muq.gif")))
        if _has_data(mup):
            tasks.append((aid, "mu_p", phi, phim, muq, mup, 
                         os.path.join(OUT_DIR, f"agent{aid}_mup.gif")))
    
    if not tasks:
        print("No eligible series to render.")
        return
    
    # Parallel rendering
    n_jobs = min(os.cpu_count() or 1, len(tasks))
    print(f"Rendering {len(tasks)} GIFs with {n_jobs} workers...")
    
    try:
        mp.set_start_method("spawn", force=False)
    except RuntimeError:
        pass
    
    results = Parallel(n_jobs=n_jobs, backend="loky", batch_size="auto")(
        delayed(_render_task)(aid, kind, phi, phim, muq, mup, outp)
        for (aid, kind, phi, phim, muq, mup, outp) in tasks
    )
    
    written = [p for p in results if p]
    print(f"Wrote {len(written)}/{len(tasks)} GIFs to: {OUT_DIR}")


if __name__ == "__main__":
    main()