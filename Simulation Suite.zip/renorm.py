#!/usr/bin/env python3
"""
Continuous Block Renormalization for Overlapping Agents (CORRECTED)

CRITICAL UPDATE: Now includes the internal KL term D_KL(q_i || p_i) in the
generalized free energy. This is the proper "vacuum theory" before observations.

Implements the CORRECT theory for agents as sections of associated bundles
with overlapping receptive fields in continuous base space.

Geometric Framework:
- Base manifold M with coordinates x
- Principal SO(3) bundle P → M with gauge connection A
- Associated vector bundle E = P ×_SO(3) R^K → M (representation space)
- Agents are sections: μ^q, μ^p : M → E (valued in R^K, NOT Lie algebra!)
- Gauge fields: φ, φ_model : M → so(3) ≅ R^3 (Lie algebra)
- Parallel transport: Ω_ij : R^K → R^K (K×K matrix)

Key concepts:
- Blocks partition SPACE (base manifold M), not agents
- Multiple overlapping agents contribute to each block
- Agent-block overlap weighted by mask integral: w_iα = ∫_{B_α} m_i(x) dx
- Block collective variables (Euclidean means in R^K):
  * Q̃_α = weighted_mean(μ_i^q) ∈ R^K (belief)
  * P̃_α = weighted_mean(μ_i^p) ∈ R^K (prior)
- Block internal free energy: n_α^eff × D_KL(N(Q̃_α, Σ̃_α^q) || N(P̃_α, Σ̃_α^p))
- Block alignment free energy: Γ̃_αβ × D_KL(Q̃_α || Q̃_β)
- Variance reduction: σ̃²_α ≈ σ²/n_α^eff for BOTH beliefs and priors
- Renormalized coupling: Γ̃_αβ = ∫_Overlap(i,j) m_i(x) m_j(x) Γ_ij dx

This properly handles:
1. Overlapping receptive fields in continuous space
2. Internal free energy from priors (beliefs vs priors trade-off)
3. Correct bundle geometry (μ ∈ R^K representation, φ ∈ so(3) gauge)
"""

import sys
sys.path.insert(0, '/mnt/project')

import numpy as np
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle

from agent_schema import Agent
from agent_accessor import AA


@dataclass
class SpatialBlock:
    """
    A spatial block in the base manifold.
    
    Blocks partition space (not agents!). Multiple agents can contribute
    to each block based on their receptive field overlap.
    
    CORRECTED: Now tracks both collective beliefs and collective priors.
    """
    index: int                          # Block index
    region: Tuple[slice, ...]           # Spatial slices (x_start:x_end, y_start:y_end)
    center: Tuple[float, ...]           # Block center coordinates
    
    # Agent contributions
    contributing_agents: List[int]      # IDs of agents overlapping this block
    overlap_weights: List[float]        # w_iα = ∫_{B_α} m_i(x) dx for each agent
    
    # Block collective variables (computed during coarse-graining)
    Q_mean: Optional[np.ndarray] = None             # Collective BELIEF field Q̃_α
    P_mean: Optional[np.ndarray] = None             # Collective PRIOR field P̃_α
    Q_sigma: Optional[np.ndarray] = None            # Emergent belief covariance
    P_sigma: Optional[np.ndarray] = None            # Emergent prior covariance (should be tighter!)
    n_eff: Optional[float] = None                   # Effective number of agents
    
    # Free energy components
    internal_kl: Optional[float] = None             # D_KL(Q̃_α || P̃_α)
    

def partition_space(
    domain_shape: Tuple[int, ...],
    block_shape: Tuple[int, ...],
) -> List[SpatialBlock]:
    """
    Partition the base manifold M into non-overlapping spatial blocks.
    
    Args:
        domain_shape: Shape of base space, e.g. (L, L) for L×L grid
        block_shape: Size of each block, e.g. (ℓ, ℓ) for ℓ×ℓ patches
        
    Returns:
        List of SpatialBlock objects covering M
        
    Example:
        For domain_shape=(5,5) and block_shape=(2,2):
        Creates blocks B₀, B₁, B₂, ... covering space:
        ┌───┬───┬─┐
        │B₀ │B₁ │ │
        ├───┼───┼─┤
        │B₂ │B₃ │ │
        └───┴───┴─┘
    """
    blocks = []
    ndim = len(domain_shape)
    
    # Number of blocks per dimension
    n_blocks = tuple(
        (d + b - 1) // b  # Ceiling division to cover remainder
        for d, b in zip(domain_shape, block_shape)
    )
    
    # Generate all block indices
    from itertools import product
    block_idx = 0
    
    for block_pos in product(*[range(n) for n in n_blocks]):
        # Define spatial region
        region = tuple(
            slice(
                bp * bs,
                min((bp + 1) * bs, ds)  # Don't exceed domain boundary
            )
            for bp, bs, ds in zip(block_pos, block_shape, domain_shape)
        )
        
        # Block center (continuous coordinates)
        center = tuple(
            region[d].start + (region[d].stop - region[d].start) / 2.0
            for d in range(ndim)
        )
        
        blocks.append(SpatialBlock(
            index=block_idx,
            region=region,
            center=center,
            contributing_agents=[],
            overlap_weights=[]
        ))
        
        block_idx += 1
    
    return blocks


def compute_agent_block_overlap(
    agent: Agent,
    block: SpatialBlock,
    threshold: float = 1e-6
) -> float:
    """
    Compute overlap weight w_iα = ∫_{B_α} m_i(x) dx.
    
    This is the integral of agent i's mask over block α's spatial region.
    Measures "how much" of the agent's receptive field lies in this block.
    
    Args:
        agent: Agent with mask field
        block: Spatial block with region slices
        threshold: Minimum weight to consider non-zero
        
    Returns:
        Overlap weight (scalar)
    """
    mask = AA.get_mask_float(agent)  # Shape (*S,)
    
    # Extract mask values in block's spatial region
    block_mask = mask[block.region]
    
    # Integrate (sum for discrete approximation)
    # In continuous limit: ∫_{B_α} m_i(x) d^d x
    # Discrete: Σ_{x ∈ B_α} m_i(x) Δx^d where Δx = 1
    overlap = float(np.sum(block_mask))
    
    return overlap if overlap > threshold else 0.0


def assign_agents_to_blocks(
    agents: List[Agent],
    blocks: List[SpatialBlock],
    threshold: float = 1e-6,
    verbose: bool = False
) -> List[SpatialBlock]:
    """
    Determine which agents contribute to which blocks based on mask overlap.
    
    Computes overlap weights w_iα for all agent-block pairs and populates
    the contributing_agents and overlap_weights lists in each block.
    
    Note: An agent can contribute to MULTIPLE blocks if its receptive field
    spans multiple regions.
    
    Args:
        agents: List of agents with mask fields
        blocks: List of spatial blocks
        threshold: Minimum overlap to consider
        verbose: Print statistics
        
    Returns:
        Modified blocks list with agent assignments
    """
    if verbose:
        print(f"Assigning {len(agents)} agents to {len(blocks)} blocks...")
    
    # Track statistics
    total_assignments = 0
    agents_per_block = []
    blocks_per_agent = np.zeros(len(agents), dtype=int)
    
    for agent in agents:
        agent_id = AA.get_id(agent)
        agent_block_count = 0
        
        for block in blocks:
            # Compute overlap
            overlap = compute_agent_block_overlap(agent, block, threshold)
            
            if overlap > threshold:
                block.contributing_agents.append(agent_id)
                block.overlap_weights.append(overlap)
                total_assignments += 1
                agent_block_count += 1
        
        blocks_per_agent[agent_id] = agent_block_count
    
    # Compute statistics
    for block in blocks:
        agents_per_block.append(len(block.contributing_agents))
    
    if verbose:
        print(f"  Total agent-block assignments: {total_assignments}")
        print(f"  Mean agents per block: {np.mean(agents_per_block):.2f}")
        print(f"  Mean blocks per agent: {np.mean(blocks_per_agent):.2f}")
        print(f"  Blocks with no agents: {sum(1 for n in agents_per_block if n == 0)}")
    
    return blocks


def compute_effective_agent_count(
    overlap_weights: List[float]
) -> float:
    """
    Compute effective number of independent agents: participation ratio.
    
    n_eff = (Σ w_i)² / Σ w_i²
    
    This accounts for uneven contributions:
    - All agents equal weight: n_eff = n
    - One dominant agent: n_eff → 1
    - Many small contributors: n_eff < n
    
    Args:
        overlap_weights: List of w_iα values
        
    Returns:
        Effective agent count (scalar)
    """
    if len(overlap_weights) == 0:
        return 0.0
    
    weights = np.array(overlap_weights)
    W_total = np.sum(weights)
    W_squared = np.sum(weights ** 2)
    
    if W_squared < 1e-12:
        return 0.0
    
    n_eff = (W_total ** 2) / W_squared
    return float(n_eff)


def compute_block_mean_field(
    agents: List[Agent],
    block: SpatialBlock,
    field_name: str = "mu_q_field",
    use_frechet: bool = False
) -> Tuple[Optional[np.ndarray], Optional[float]]:
    """
    Compute block collective variable as weighted mean over contributing agents.
    
    CORRECTED: Computes weighted Euclidean mean in representation space R^K.
    Since μ^q, μ^p ∈ R^K (not Lie algebra!), we use standard weighted averaging.
    
    For each agent i contributing to block α:
    1. Extract agent's field values in block region: μ_i(x) for x ∈ B_α
    2. Compute spatial average: μ̄_i^α = (1/w_iα) ∫_{B_α} m_i(x) μ_i(x) dx ∈ R^K
    3. Compute weighted mean: result = Σ w_iα μ̄_i^α / Σ w_iα (standard Euclidean)
    
    Args:
        agents: List of all agents
        block: Block to compute collective variable for
        field_name: Name of field to average ("mu_q_field" for beliefs, "mu_p_field" for priors)
        use_frechet: If True, use Fréchet mean (for future manifold-valued extensions)
                     If False, use arithmetic mean (current: Euclidean R^K)
    
    Returns:
        (mean_field, variance) where:
        - mean_field: Block collective mean field Q̃_α or P̃_α ∈ R^K
        - variance: Empirical variance across contributing agents
    
    Note:
        The gauge fields φ, φ_model ∈ so(3) ≅ R^3 are Lie algebra valued,
        but the belief/prior fields μ^q, μ^p ∈ R^K are representation space valued.
        We only need manifold geometry (Fréchet mean) for the gauge fields, not for μ.
    """
    if len(block.contributing_agents) == 0:
        return None, None
    
    # Build agent lookup
    agent_by_id = {AA.get_id(a): a for a in agents}
    
    # Collect spatially-averaged fields from each contributing agent
    agent_means = []
    weights = np.array(block.overlap_weights)
    
    for agent_id, weight in zip(block.contributing_agents, block.overlap_weights):
        agent = agent_by_id[agent_id]
        
        # Get field values (belief or prior)
        field = getattr(agent, field_name, None)
        if field is None:
            continue
        
        # Extract values in block region
        mask = AA.get_mask_float(agent)
        block_field = field[block.region]  # Shape: (*block_shape, K)
        block_mask = mask[block.region]    # Shape: (*block_shape,)
        
        # Compute weighted spatial average: μ̄_i^α = (1/w_iα) ∫ m_i(x) μ_i(x) dx
        # Expand mask to broadcast with field
        block_mask_expanded = block_mask[..., np.newaxis]  # (*block_shape, 1)
        
        weighted_field = block_field * block_mask_expanded
        spatial_avg = np.sum(weighted_field, axis=tuple(range(block_field.ndim - 1)))  # (K,)
        spatial_avg = spatial_avg / weight  # Normalize by total weight
        
        agent_means.append(spatial_avg)
    
    if len(agent_means) == 0:
        return None, None
    
    # Stack: (n_agents, K)
    agent_means = np.stack(agent_means, axis=0)
    
    # Normalize weights
    weights = weights / np.sum(weights)
    
    if use_frechet and hasattr(agents[0], 'generators_q'):
        # NOTE: For μ fields, we're in Euclidean R^K, so weighted mean IS the Fréchet mean.
        # Fréchet mean only differs from arithmetic mean on curved manifolds.
        # The gauge fields φ ∈ so(3) would need true Fréchet mean, but μ ∈ R^K does not.
        mean_field = np.sum(agent_means * weights[:, np.newaxis], axis=0)
    else:
        # Weighted arithmetic mean in R^K: result = Σ w_iα μ̄_i^α / Σ w_iα
        mean_field = np.sum(agent_means * weights[:, np.newaxis], axis=0)
    
    # Compute variance: measure spread across agents
    deviations = agent_means - mean_field[np.newaxis, :]
    variance = np.sum(weights[:, np.newaxis] * deviations ** 2)
    
    return mean_field, variance


def compute_kl_divergence_gaussian(
    mu_q: np.ndarray,
    Sigma_q: np.ndarray,
    mu_p: np.ndarray,
    Sigma_p: np.ndarray
) -> float:
    """
    Compute KL divergence D_KL(q || p) for Gaussian distributions.
    
    D_KL(N(μ_q, Σ_q) || N(μ_p, Σ_p)) = 
        1/2 [tr(Σ_p^{-1} Σ_q) + (μ_p - μ_q)^T Σ_p^{-1} (μ_p - μ_q) - K - log|Σ_q|/|Σ_p|]
    
    Args:
        mu_q: Mean of q (K,)
        Sigma_q: Covariance of q (K, K)
        mu_p: Mean of p (K,)
        Sigma_p: Covariance of p (K, K)
        
    Returns:
        KL divergence (scalar)
    """
    K = len(mu_q)
    
    # Regularize covariances
    Sigma_q_reg = Sigma_q + 1e-8 * np.eye(K)
    Sigma_p_reg = Sigma_p + 1e-8 * np.eye(K)
    
    # Compute Σ_p^{-1} Σ_q
    Sigma_p_inv = np.linalg.inv(Sigma_p_reg)
    term1 = np.trace(Sigma_p_inv @ Sigma_q_reg)
    
    # Compute (μ_p - μ_q)^T Σ_p^{-1} (μ_p - μ_q)
    delta_mu = mu_p - mu_q
    term2 = delta_mu @ Sigma_p_inv @ delta_mu
    
    # Compute log|Σ_q|/|Σ_p|
    sign_q, logdet_q = np.linalg.slogdet(Sigma_q_reg)
    sign_p, logdet_p = np.linalg.slogdet(Sigma_p_reg)
    term3 = logdet_q - logdet_p
    
    kl = 0.5 * (term1 + term2 - K - term3)
    
    return float(kl)


def compute_block_statistics(
    agents: List[Agent],
    blocks: List[SpatialBlock],
    verbose: bool = False
) -> List[SpatialBlock]:
    """
    Compute collective variables and statistics for all blocks (CORRECTED).
    
    For each block α:
    1. Q̃_α: Weighted mean belief field over contributing agents
    2. P̃_α: Weighted mean prior field over contributing agents
    3. σ̃²_q_α: Emergent belief variance (should be reduced from individual agents)
    4. σ̃²_p_α: Emergent prior variance (should be reduced from individual agents)
    5. n_eff_α: Effective number of independent contributors
    6. D_KL(Q̃_α || P̃_α): Block internal free energy (per effective agent)
    
    Args:
        agents: List of agents
        blocks: List of blocks with agent assignments
        verbose: Print progress
        
    Returns:
        Modified blocks with statistics populated
    """
    if verbose:
        print(f"Computing block statistics for {len(blocks)} blocks...")
    
    for block in blocks:
        if len(block.contributing_agents) == 0:
            block.n_eff = 0.0
            continue
        
        # Effective agent count
        block.n_eff = compute_effective_agent_count(block.overlap_weights)
        
        # Block collective BELIEF Q̃_α
        Q_mean, Q_var = compute_block_mean_field(
            agents, block, field_name="mu_q_field"
        )
        block.Q_mean = Q_mean
        if Q_var is not None:
            block.Q_sigma = Q_var
        
        # Block collective PRIOR P̃_α
        P_mean, P_var = compute_block_mean_field(
            agents, block, field_name="mu_p_field"
        )
        block.P_mean = P_mean
        if P_var is not None:
            block.P_sigma = P_var
        
        # Compute block internal KL: D_KL(Q̃_α || P̃_α)
        if Q_mean is not None and P_mean is not None:
            # Get representative covariances from first contributing agent
            agent_by_id = {AA.get_id(a): a for a in agents}
            first_agent_id = block.contributing_agents[0]
            first_agent = agent_by_id[first_agent_id]
            
            # Use agent's covariances as approximation
            # In full implementation, should compute block-level covariances
            Sigma_q = getattr(first_agent, 'Sigma_q', np.eye(len(Q_mean)))
            Sigma_p = getattr(first_agent, 'Sigma_p', np.eye(len(P_mean)))
            
            block.internal_kl = compute_kl_divergence_gaussian(
                Q_mean, Sigma_q, P_mean, Sigma_p
            )
    
    if verbose:
        valid_blocks = [b for b in blocks if b.n_eff > 0]
        if len(valid_blocks) > 0:
            mean_n_eff = np.mean([b.n_eff for b in valid_blocks])
            mean_kl = np.mean([b.internal_kl for b in valid_blocks if b.internal_kl is not None])
            print(f"  Mean effective agent count: {mean_n_eff:.2f}")
            print(f"  Mean block internal KL: {mean_kl:.4f}")
    
    return blocks


def compute_total_free_energy(
    blocks: List[SpatialBlock],
    coupling_matrix: Optional[np.ndarray] = None
) -> Dict[str, float]:
    """
    Compute the total generalized free energy at block level (CORRECTED).
    
    F_total = F_internal + F_alignment
    
    where:
    - F_internal = Σ_α n_α^eff × D_KL(Q̃_α || P̃_α)
    - F_alignment = Σ_{α<β} Γ̃_αβ × D_KL(Q̃_α || Q̃_β)
    
    Args:
        blocks: List of blocks with collective variables computed
        coupling_matrix: Renormalized coupling matrix Γ̃_αβ (optional)
        
    Returns:
        Dictionary with free energy components
    """
    F_internal = 0.0
    F_alignment = 0.0
    
    # Internal free energy: Σ_α n_α^eff × D_KL(Q̃_α || P̃_α)
    for block in blocks:
        if block.internal_kl is not None and block.n_eff is not None:
            F_internal += block.n_eff * block.internal_kl
    
    # Alignment free energy (if coupling matrix provided)
    if coupling_matrix is not None:
        for i, block_i in enumerate(blocks):
            if block_i.Q_mean is None:
                continue
            for j, block_j in enumerate(blocks):
                if j <= i or block_j.Q_mean is None:
                    continue
                
                # D_KL(Q̃_i || Q̃_j)
                # Use identity covariance as approximation
                K = len(block_i.Q_mean)
                Sigma_eye = np.eye(K)
                kl_ij = compute_kl_divergence_gaussian(
                    block_i.Q_mean, Sigma_eye,
                    block_j.Q_mean, Sigma_eye
                )
                
                F_alignment += coupling_matrix[i, j] * kl_ij
    
    return {
        'F_internal': F_internal,
        'F_alignment': F_alignment,
        'F_total': F_internal + F_alignment
    }


def compute_renormalized_coupling(
    agents: List[Agent],
    block_alpha: SpatialBlock,
    block_beta: SpatialBlock,
    base_coupling: float = 1.0
) -> float:
    """
    Compute renormalized inter-block coupling Γ̃_αβ.
    
    Γ̃_αβ = Σ_{i∈A_α, j∈A_β} ∫_{Ω_ij} m_i(x) m_j(x) Γ_ij dx
    
    This is a continuous integral over the overlap region between agents
    from different blocks, NOT a discrete sum!
    
    Args:
        agents: List of all agents
        block_alpha: First block
        block_beta: Second block  
        base_coupling: Base coupling strength Γ_ij (assumed uniform)
        
    Returns:
        Renormalized coupling strength (scalar)
    """
    agent_by_id = {AA.get_id(a): a for a in agents}
    
    total_coupling = 0.0
    
    # Iterate over all pairs (i ∈ A_α, j ∈ A_β)
    for id_i in block_alpha.contributing_agents:
        agent_i = agent_by_id[id_i]
        mask_i = AA.get_mask_float(agent_i)
        
        # Check if agent i has j as a neighbor
        neighbors_i = getattr(agent_i, 'neighbors', [])
        neighbor_ids = {nb['id'] if isinstance(nb, dict) else nb for nb in neighbors_i}
        
        for id_j in block_beta.contributing_agents:
            if id_j not in neighbor_ids:
                continue  # Only coupled if neighbors
            
            agent_j = agent_by_id[id_j]
            mask_j = AA.get_mask_float(agent_j)
            
            # Compute ∫ m_i(x) m_j(x) dx over full domain
            # (masks are zero outside agent supports)
            overlap_integral = float(np.sum(mask_i * mask_j))
            
            # Add contribution: Γ_ij * overlap
            total_coupling += base_coupling * overlap_integral
    
    return total_coupling


def test_variance_reduction(
    agents: List[Agent],
    blocks: List[SpatialBlock],
) -> Dict[str, Dict[str, float]]:
    """
    Test the variance reduction scaling: σ̃²_α ≈ σ²/n_α^eff (CORRECTED).
    
    Tests BOTH belief and prior variance reduction:
    1. Individual agent variance (baseline)
    2. Block collective variance (should be reduced)
    3. Predicted reduction from n_eff
    
    Returns:
        Dictionary with test results for beliefs and priors
    """
    results = {}
    
    # Test for beliefs (mu_q_field)
    agent_q_variances = []
    for agent in agents:
        field = getattr(agent, 'mu_q_field', None)
        if field is not None:
            agent_q_variances.append(np.var(field))
    
    mean_agent_q_var = np.mean(agent_q_variances) if agent_q_variances else 0.0
    
    valid_blocks = [b for b in blocks if b.Q_sigma is not None and b.n_eff > 0]
    
    if len(valid_blocks) > 0:
        block_q_variances = [b.Q_sigma for b in valid_blocks]
        mean_block_q_var = np.mean(block_q_variances)
        mean_n_eff = np.mean([b.n_eff for b in valid_blocks])
        
        predicted_q_var = mean_agent_q_var / mean_n_eff if mean_n_eff > 0 else 0.0
        predicted_q_reduction = np.sqrt(mean_n_eff) if mean_n_eff > 0 else 0.0
        observed_q_reduction = np.sqrt(mean_agent_q_var / mean_block_q_var) if mean_block_q_var > 0 else 0.0
        ratio_q = observed_q_reduction / predicted_q_reduction if predicted_q_reduction > 0 else 0.0
        
        results['beliefs'] = {
            'mean_agent_var': mean_agent_q_var,
            'mean_block_var': mean_block_q_var,
            'predicted_block_var': predicted_q_var,
            'mean_n_eff': mean_n_eff,
            'predicted_reduction': predicted_q_reduction,
            'observed_reduction': observed_q_reduction,
            'ratio': ratio_q
        }
    else:
        results['beliefs'] = {
            'mean_agent_var': mean_agent_q_var,
            'mean_block_var': 0.0,
            'predicted_block_var': 0.0,
            'mean_n_eff': 0.0,
            'predicted_reduction': 0.0,
            'observed_reduction': 0.0,
            'ratio': 0.0
        }
    
    # Test for priors (mu_p_field)
    agent_p_variances = []
    for agent in agents:
        field = getattr(agent, 'mu_p_field', None)
        if field is not None:
            agent_p_variances.append(np.var(field))
    
    mean_agent_p_var = np.mean(agent_p_variances) if agent_p_variances else 0.0
    
    valid_blocks_p = [b for b in blocks if b.P_sigma is not None and b.n_eff > 0]
    
    if len(valid_blocks_p) > 0:
        block_p_variances = [b.P_sigma for b in valid_blocks_p]
        mean_block_p_var = np.mean(block_p_variances)
        mean_n_eff_p = np.mean([b.n_eff for b in valid_blocks_p])
        
        predicted_p_var = mean_agent_p_var / mean_n_eff_p if mean_n_eff_p > 0 else 0.0
        predicted_p_reduction = np.sqrt(mean_n_eff_p) if mean_n_eff_p > 0 else 0.0
        observed_p_reduction = np.sqrt(mean_agent_p_var / mean_block_p_var) if mean_block_p_var > 0 else 0.0
        ratio_p = observed_p_reduction / predicted_p_reduction if predicted_p_reduction > 0 else 0.0
        
        results['priors'] = {
            'mean_agent_var': mean_agent_p_var,
            'mean_block_var': mean_block_p_var,
            'predicted_block_var': predicted_p_var,
            'mean_n_eff': mean_n_eff_p,
            'predicted_reduction': predicted_p_reduction,
            'observed_reduction': observed_p_reduction,
            'ratio': ratio_p
        }
    else:
        results['priors'] = {
            'mean_agent_var': mean_agent_p_var,
            'mean_block_var': 0.0,
            'predicted_block_var': 0.0,
            'mean_n_eff': 0.0,
            'predicted_reduction': 0.0,
            'observed_reduction': 0.0,
            'ratio': 0.0
        }
    
    return results


def visualize_continuous_blocks(
    agents: List[Agent],
    blocks: List[SpatialBlock],
    domain_shape: Tuple[int, int],
    save_path: Optional[str] = None
):
    """
    Visualize overlapping agents and spatial blocks (CORRECTED).
    
    Creates three panels:
    A) Agents (circles) with their receptive fields overlaid on block grid
    B) Effective agent count per block (heatmap)
    C) Block internal KL divergence D_KL(Q̃_α || P̃_α)
    """
    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(18, 6))
    
    # Panel A: Agents and block boundaries
    ax1.set_xlim(-0.5, domain_shape[0] + 0.5)
    ax1.set_ylim(-0.5, domain_shape[1] + 0.5)
    ax1.set_aspect('equal')
    ax1.set_title('(A) Overlapping Agents + Spatial Blocks', fontsize=12, fontweight='bold')
    ax1.set_xlabel('$x$')
    ax1.set_ylabel('$y$')
    
    # Draw block boundaries
    for block in blocks:
        rect = Rectangle(
            (block.region[0].start, block.region[1].start),
            block.region[0].stop - block.region[0].start,
            block.region[1].stop - block.region[1].start,
            fill=False, edgecolor='red', linewidth=2, linestyle='--', alpha=0.7
        )
        ax1.add_patch(rect)
        
        # Label block center with index
        ax1.text(
            block.center[0], block.center[1], f'{block.index}',
            fontsize=8, ha='center', va='center',
            bbox=dict(boxstyle='round,pad=0.2', facecolor='yellow', alpha=0.5)
        )
    
    # Draw agents as circles
    for agent in agents:
        center = AA.get_center(agent)
        radius = AA.get_radius(agent)
        
        circle = Circle(
            center, radius,
            fill=False, edgecolor='blue', linewidth=1.5, alpha=0.6
        )
        ax1.add_patch(circle)
        
        # Mark center
        ax1.plot(center[0], center[1], 'bo', markersize=4)
        ax1.text(
            center[0], center[1] + radius + 0.2,
            f'{AA.get_id(agent)}',
            fontsize=7, ha='center', color='blue'
        )
    
    ax1.grid(True, alpha=0.3)
    
    # Panel B: Effective agent count per block
    ax2.set_title('(B) Effective Agent Count $n_\\alpha^{\\mathrm{eff}}$', 
                  fontsize=12, fontweight='bold')
    ax2.set_xlabel('Block $x$')
    ax2.set_ylabel('Block $y$')
    
    # Determine grid shape for blocks
    if len(blocks) > 0:
        block_x = [b.center[0] for b in blocks]
        block_y = [b.center[1] for b in blocks]
        unique_x = sorted(set(block_x))
        unique_y = sorted(set(block_y))
        
        n_blocks_x = len(unique_x)
        n_blocks_y = len(unique_y)
        
        # Create grid for n_eff
        n_eff_grid = np.zeros((n_blocks_y, n_blocks_x))
        
        for block in blocks:
            ix = unique_x.index(block.center[0])
            iy = unique_y.index(block.center[1])
            n_eff_grid[iy, ix] = block.n_eff if block.n_eff is not None else 0.0
        
        # Plot heatmap
        im2 = ax2.imshow(
            n_eff_grid,
            cmap='viridis',
            origin='lower',
            interpolation='nearest',
            extent=[-0.5, n_blocks_x - 0.5, -0.5, n_blocks_y - 0.5]
        )
        plt.colorbar(im2, ax=ax2)
        
        # Annotate with values
        for block in blocks:
            ix = unique_x.index(block.center[0])
            iy = unique_y.index(block.center[1])
            n_eff_val = block.n_eff if block.n_eff is not None else 0.0
            ax2.text(
                ix, iy, f'{n_eff_val:.1f}',
                ha='center', va='center',
                color='white' if n_eff_val > 2 else 'black',
                fontweight='bold', fontsize=9
            )
    
    # Panel C: Block internal KL
    ax3.set_title('(C) Block Internal KL $D_{\\mathrm{KL}}(\\tilde{Q}_\\alpha \\| \\tilde{P}_\\alpha)$',
                  fontsize=12, fontweight='bold')
    ax3.set_xlabel('Block $x$')
    ax3.set_ylabel('Block $y$')
    
    if len(blocks) > 0:
        # Create grid for internal KL
        kl_grid = np.zeros((n_blocks_y, n_blocks_x))
        
        for block in blocks:
            ix = unique_x.index(block.center[0])
            iy = unique_y.index(block.center[1])
            kl_grid[iy, ix] = block.internal_kl if block.internal_kl is not None else 0.0
        
        # Plot heatmap
        im3 = ax3.imshow(
            kl_grid,
            cmap='plasma',
            origin='lower',
            interpolation='nearest',
            extent=[-0.5, n_blocks_x - 0.5, -0.5, n_blocks_y - 0.5]
        )
        plt.colorbar(im3, ax=ax3)
        
        # Annotate with values
        for block in blocks:
            ix = unique_x.index(block.center[0])
            iy = unique_y.index(block.center[1])
            kl_val = block.internal_kl if block.internal_kl is not None else 0.0
            ax3.text(
                ix, iy, f'{kl_val:.2f}',
                ha='center', va='center',
                color='white' if kl_val > 0.1 else 'black',
                fontweight='bold', fontsize=8
            )
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Saved to {save_path}")
    
    return fig


# ============================================================================
# Example usage / test harness
# ============================================================================

if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("CONTINUOUS BLOCK RENORMALIZATION (CORRECTED)")
    print("Now with internal KL term D_KL(q_i || p_i)")
    print("=" * 70 + "\n")
    
    print("Key concepts:")
    print("  • CORRECTED: Total FE = Σ_i ∫ m_i(x) D_KL(q_i || p_i) dx + Σ_{ij} F_align")
    print("  • Blocks partition SPACE (base manifold M), not agents")
    print("  • μ^q, μ^p ∈ R^K (representation space, NOT Lie algebra)")
    print("  • φ, φ_model ∈ so(3) ≅ R^3 (Lie algebra, gauge connection)")
    print("  • Two collective variables per block: Q̃_α, P̃_α ∈ R^K (Euclidean means)")
    print("  • Block internal FE: n_α^eff × D_KL(N(Q̃_α, Σ̃_α^q) || N(P̃_α, Σ̃_α^p))")
    print("  • Block alignment FE: Γ̃_αβ × D_KL(Q̃_α || Q̃_β)")
    print("  • n_α^eff = (Σw_i)²/Σw_i² is effective agent count (participation ratio)")
    print("  • Variance reduction: σ̃²_α ≈ σ²/n_α^eff for BOTH beliefs and priors")
    print("  • Renormalized coupling: Γ̃_αβ = ∫_Overlap(i,j) m_i m_j Γ_ij dx\n")
    
    print("To use with your agents:")
    print("  from renorm_corrected import *")
    print("  blocks = partition_space(domain_shape=(5, 5), block_shape=(2, 2))")
    print("  blocks = assign_agents_to_blocks(agents, blocks, verbose=True)")
    print("  blocks = compute_block_statistics(agents, blocks, verbose=True)")
    print("  fe = compute_total_free_energy(blocks)")
    print("  results = test_variance_reduction(agents, blocks)")
    print("  fig = visualize_continuous_blocks(agents, blocks, (5, 5))")
    print()