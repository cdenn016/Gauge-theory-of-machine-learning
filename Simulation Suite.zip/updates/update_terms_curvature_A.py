# -*- coding: utf-8 -*-
"""
Created on Wed Sep 10 12:40:31 2025

@author: chris and christine
"""
import numpy as np
from core.runtime_context import cfg_get
from core.utils import _to32_no_underflow
from agents.agent_accessor import AA
from updates.gradient_utils import get_curvature_config




def _safe_mul_mask(Dm, m3):
    # Works for boolean or float masks; suppresses underflow on multiply and cast
    if m3.dtype == np.bool_:
        return np.where(m3, Dm, 0.0).astype(np.float32, copy=False)
    with np.errstate(under='ignore'):
        prod = Dm.astype(np.float64) * np.asarray(m3, np.float64)
    return _to32_no_underflow(prod)




def _sqnorm64(x) -> float:
    x64 = np.asarray(x, dtype=np.float64).ravel()
    return float(np.dot(x64, x64))



def _cross64(a, b):
    a64 = np.asarray(a, dtype=np.float64)
    b64 = np.asarray(b, dtype=np.float64)
    with np.errstate(under='ignore'):
        c64 = np.cross(a64, b64)
    return _to32_no_underflow(c64)



# --- safe centered difference and its adjoint (periodic) ---

def _cdiff_centered(x, *, axis: int, h: float):
    """
    Periodic centered difference: (roll-1 - roll+1) / (2h)
    Computed in float64; underflow-suppressed; cast with subnormals zeroed.
    """
    import numpy as np
    x64   = np.asarray(x, dtype=np.float64)
    inv2h = 0.5 / float(h)  # float64
    with np.errstate(under='ignore'):
        diff64 = (np.roll(x64, -1, axis=axis) - np.roll(x64, +1, axis=axis)) * inv2h
    return _to32_no_underflow(diff64)


def _cdiff_centered_adj(y, *, axis: int, h: float):
    """
    Adjoint of centered difference under periodic BCs.
    For the periodic centered stencil, adjoint = - centered difference.
    """
    import numpy as np
    y64   = np.asarray(y, dtype=np.float64)
    inv2h = 0.5 / float(h)  # float64
    with np.errstate(under='ignore'):
        # minus sign makes this the adjoint of _cdiff_centered under the standard inner product
        adj64 = -(np.roll(y64, -1, axis=axis) - np.roll(y64, +1, axis=axis)) * inv2h
    return _to32_no_underflow(adj64)



def _fft_gaussian_filter_wrap_nd(x, sigma):
    """
    SciPy-free periodic Gaussian smoothing for any dimensional array.
    Applies the same sigma to all spatial axes of x.
    """
    x = np.asarray(x, np.float64)
    if sigma <= 0:
        return x

    # spatial axes = all except the last two: (..., M, 3)
    spatial_ndim = x.ndim - 2
    if spatial_ndim <= 0:
        return x

    S = x.shape[:spatial_ndim]
    # frequency grids with wrap/periodic boundary
    k_grids = np.meshgrid(*[np.fft.fftfreq(n) for n in S], indexing="ij")
    k2 = np.zeros(S, dtype=np.float64)
    for kg in k_grids:
        k2 += kg**2

    # Continuous-time Gaussian filter in frequency domain:
    # H(k) = exp(-2 * (pi*sigma)^2 * |k|^2)
    H = np.exp(-2.0 * (np.pi * sigma)**2 * k2)

    # Apply per last-2 axes slices
    X = np.fft.fftn(x, axes=tuple(range(spatial_ndim)))
    Y = X * H[(...,) + (None, None)]
    y = np.fft.ifftn(Y, axes=tuple(range(spatial_ndim))).real
    return y

def _smooth_wrap(x, sigma):
    """Use SciPy if present; otherwise fall back to FFT smoothing."""
    try:
        from scipy.ndimage import gaussian_filter
        return gaussian_filter(x, sigma=sigma, mode="wrap")
    except Exception:
        return _fft_gaussian_filter_wrap_nd(x, sigma)

def _record_A_spec(ctx, spatial_shape, *, init_scale, smooth_sigma, dtype, seed):
    """Store a minimal spec so workers can reconstruct A deterministically."""
    if not hasattr(ctx, "fields"):
        ctx.fields = {}
    ctx.fields["_A_spec"] = {
        "spatial_shape": tuple(int(s) for s in spatial_shape),
        "init_scale": float(init_scale),
        "smooth_sigma": float(smooth_sigma),
        "dtype": np.dtype(dtype).name,
        "seed": int(seed),
    }

def _load_A_spec(ctx):
    return getattr(ctx, "fields", {}).get("_A_spec", None)

def make_global_A(spatial_shape, *, init_scale=0.0, smooth_sigma=2.0,
                  dtype=np.float32, seed=0):
    """
    PURE factory (loky-safe): returns A with shape (*S, M, 3)
    No ctx access, no mutation.
    """
    S = tuple(int(s) for s in spatial_shape)
    M = len(S)
    want = S + (M, 3)

    if init_scale > 0.0:
        rng = np.random.default_rng(int(seed))
        A = rng.normal(0.0, init_scale, size=want).astype(np.float64)
        # Smooth each algebra component per spatial direction
        for m in range(M):
            for c in range(3):
                A[..., m, c] = _smooth_wrap(A[..., m, c], sigma=float(smooth_sigma))
    else:
        A = np.zeros(want, dtype=np.float64)

    # Optional normalization: keep local magnitudes ~ init_scale * sqrt(3)
    mag = np.sqrt(np.sum(A**2, axis=-1, keepdims=True))
    target = float(init_scale) * np.sqrt(3.0)
    A = np.where(mag > 0, A * (target / (mag + 1e-12)), A)

    return A.astype(dtype, copy=False)

def get_global_A(ctx):
    """
    Worker-friendly accessor:
      1) If ctx.fields['A'] exists, return it.
      2) Else, if a spec exists, reconstruct A PURELY and return it (no mutation).
      3) Else, raise with a clear message.
    """
    A = getattr(ctx, "fields", {}).get("A", None)
    if A is not None:
        return np.asarray(A)

    spec = _load_A_spec(ctx)
    if spec is not None:
        A = make_global_A(
            spec["spatial_shape"],
            init_scale=spec["init_scale"],
            smooth_sigma=spec["smooth_sigma"],
            dtype=np.dtype(spec["dtype"]),
            seed=spec["seed"],
        )
        return A
    raise RuntimeError("Global A not available: call ensure_global_A(...) on master first "
                       "or record a spec via _record_A_spec(...)")

# --- Replace your ensure_global_A with this loky-safe, master-only version ---
def ensure_global_A(ctx, spatial_shape, *, init_scale=0.0, smooth_sigma=2.0,
                    dtype=np.float32, seed=0):
    """
    MASTER-ONLY initializer (idempotent).
    Ensures ctx.fields['A'] exists with shape (*S, M, 3) and records a spec so
    workers can reconstruct A without touching ctx.

    Config:
      A_backend: "ctx" (default) stores in ctx.fields
                 "pure" builds via make_global_A and still stores in ctx.fields
                 (backend controls how A is built; both paths end with ctx.fields['A'])
      A_validation: if True, rebuild via the other backend and compare (non-fatal).
    """
    if not hasattr(ctx, "fields"):
        raise RuntimeError("ctx.fields missing; update RuntimeCtx to include a fields dict.")

    # Read optional toggles
    backend = str(cfg_get(ctx, "A_backend", "ctx")).lower()   # "ctx" | "pure"
    validate = bool(cfg_get(ctx, "A_validation", False))
    rtol = float(cfg_get(ctx, "A_valid_rtol", 1e-6))
    atol = float(cfg_get(ctx, "A_valid_atol", 1e-6))

    S = tuple(int(s) for s in spatial_shape)
    M = len(S)
    want = S + (M, 3)

    # Idempotent: if already present with correct shape/dtype, just return it
    A_curr = ctx.fields.get("A", None)
    if A_curr is not None:
        A_curr = np.asarray(A_curr)
        if A_curr.shape == want and A_curr.dtype == np.dtype(dtype):
            # Ensure spec exists for workers
            if _load_A_spec(ctx) is None:
                _record_A_spec(ctx, S, init_scale=init_scale, smooth_sigma=smooth_sigma,
                               dtype=dtype, seed=seed)
            return A_curr

    # Build A via selected backend (both pure functions under the hood)
    if backend == "pure":
        A_main = make_global_A(S, init_scale=init_scale, smooth_sigma=smooth_sigma,
                               dtype=dtype, seed=seed)
        # Shadow path for validation uses the same pure builder (kept simple/consistent)
        A_shadow = make_global_A(S, init_scale=init_scale, smooth_sigma=smooth_sigma,
                                 dtype=dtype, seed=seed)
    else:
        # "ctx" backend kept for symmetry (here it just calls the same pure builder).
        # If in the future you add a different ctx-based path, you can switch it here.
        A_main = make_global_A(S, init_scale=init_scale, smooth_sigma=smooth_sigma,
                               dtype=dtype, seed=seed)
        A_shadow = make_global_A(S, init_scale=init_scale, smooth_sigma=smooth_sigma,
                                 dtype=dtype, seed=seed)

    # Validation (non-fatal): compare main vs shadow
    if validate:
        try:
            np.testing.assert_allclose(A_main, A_shadow, rtol=rtol, atol=atol)
        except AssertionError as e:
            print(f"[A-check] ensure_global_A mismatch between backends: "
                  f"{str(e).splitlines()[0]} (rtol={rtol}, atol={atol})")

    # Commit to ctx (master-only mutation)
    ctx.fields["A"] = np.asarray(A_main, dtype=dtype, order="C")
    _record_A_spec(ctx, S, init_scale=init_scale, smooth_sigma=smooth_sigma,
                   dtype=dtype, seed=seed)
    return ctx.fields["A"]




def step_global_A(ctx, agents, A_buckets=None):
    """
    One gradient step on global A:
      - curvature term (lambda_A_curv)
      - optional extra coupling grad via A_buckets (preferred)
        or ctx.fields["A_grad_accum"] (back-compat).
    A_buckets may be:
      - None
      - np.ndarray shaped like A  (already-summed gradient)
      - Iterable of np.ndarray    (sum will be taken)
      - Iterable of legacy objects with .dA and optional .notes["energy"]
    Returns: total A-related energy = A_curv + A_cov.
    """
    import numpy as np
    from core.runtime_context import cfg_get

    # infer spatial shape & ensure A exists
    if not agents:
        raise ValueError("step_global_A: empty agents list.")
    a0 = agents[0]
    S  = tuple(np.asarray(a0.mu_q_field).shape[:-1])  # (*S, Kq)
    init_scale = float(cfg_get(ctx, "A_init_scale", 0.0))
    A = ensure_global_A(ctx, spatial_shape=S, init_scale=init_scale)  # (*S, M, 3)

    # --- curvature term ---
    lam_A = float(cfg_get(ctx, "lambda_A_curv", 0.0))
    if lam_A > 0.0:
        E_curv, F, g_curv = curvature_energy_and_grad(A, weight=lam_A)
    else:
        E_curv = 0.0
        F      = np.zeros_like(A, dtype=np.float32)
        g_curv = np.zeros_like(A, dtype=np.float32)

    # publish curvature diagnostics
    ctx.fields = getattr(ctx, "fields", {}) or {}
    ctx.fields["A_curv_weight"] = float(lam_A)
    ctx.fields["A_curv_energy"] = float(E_curv)
    # unweighted norm (mean Frobenius) for scale visibility
    ctx.fields["A_curv_normF"]  = float(np.sqrt(np.mean(F * F))) if F.size else 0.0

    # --- extra coupling grad (covariant A–phi energy path) ---
    E_cov   = 0.0
    acc64   = None

    if A_buckets is not None:
        if isinstance(A_buckets, np.ndarray):
            acc64 = np.asarray(A_buckets, np.float64)
            # optional: sanity check shape
            if acc64.shape != A.shape:
                raise ValueError(f"A_buckets ndarray shape {acc64.shape} != A {A.shape}")
        else:
            acc64 = np.zeros_like(A, dtype=np.float64)
            for b in A_buckets:
                if b is None:
                    continue
                dA = getattr(b, "dA", None)
                if dA is not None:  # legacy bucket
                    acc64 += np.asarray(dA, np.float64)
                    notes = getattr(b, "notes", None)
                    if isinstance(notes, dict):
                        E_cov += float(notes.get("energy", 0.0))
                else:
                    acc64 += np.asarray(b, np.float64)
        g_extra = acc64.astype(np.float32, copy=False)
    else:
        # back-compat: read any pre-accumulated grad/energy without destroying them
        g_extra = None
        if hasattr(ctx, "fields"):
            maybe = ctx.fields.get("A_grad_accum", None)
            if maybe is not None:
                g_extra = np.asarray(maybe, np.float32)
            E_cov = float(ctx.fields.get("A_cov_energy_last", ctx.fields.get("A_cov_energy", 0.0)))

    # total grad
    g_total = g_curv if g_extra is None else (g_curv + g_extra)

    # --- step (global norm clip + lr) ---
    lr   = float(cfg_get(ctx, "A_lr", 1e-2))
    gcap = float(cfg_get(ctx, "A_grad_clip", -1))
    n    = float(np.linalg.norm(g_total.reshape(-1))) if g_total.size else 0.0

    if n > 0.0 and lr > 0.0:
        s = 1.0 if gcap <= 0.0 else min(1.0, gcap / (n + 1e-9))
        A[...] = A - (lr * s) * g_total

    # --- publish diagnostics (what the printers read) ---
    ctx.fields["A_grad_norm"]        = float(n)
    ctx.fields["A_cov_energy_last"]  = float(E_cov)  # <— consistent key, always set

    return float(E_curv + E_cov)








def curvature_energy_and_grad(A, weight=1.0):
    """
    Non-Abelian curvature on an M-D periodic grid (SO(3) frame):
      F_{ab} = ∂_a A_b − ∂_b A_a + A_a × A_b,  for 0 ≤ a < b < M
      E = 1/2 * weight * sum_{a<b} ||F_{ab}||^2

    Shapes:
      A : (*S, M, 3)
      F : (*S, M, M, 3)   (antisymmetric: F[...,a,b,:] = -F[...,b,a,:])
      grad w.r.t A: (*S, M, 3)

    Notes:
      - Uses centered differences with unit spacing (h=1.0). If you need anisotropic
        spacings, wrap this with a version that passes h per-axis to the stencils.
      - All potentially-underflowing ops are performed in float64 under a local
        np.errstate(under='ignore'), then safely cast back to float32 using
        _to32_no_underflow to zero subnormals.
    """
    import numpy as np

    A = np.asarray(A, np.float32)
    if not (A.ndim >= 2 and A.shape[-2] >= 1 and A.shape[-1] == 3):
        raise AssertionError(f"A must be (*S, M, 3), got {A.shape}")
    S = A.shape[:-2]
    M = int(A.shape[-2])

    # --- compute all pairwise curvatures F_{ab} ---
    F = np.zeros(S + (M, M, 3), dtype=np.float32)
    for a in range(M):
        for b in range(a + 1, M):
            Aa = A[..., a, :]                       # (*S, 3)
            Ab = A[..., b, :]
            # centered differences with h=1.0 (safe implementations)
            d_a_Ab = _cdiff_centered(Ab, axis=a, h=1.0)   # ∂_a A_b
            d_b_Aa = _cdiff_centered(Aa, axis=b, h=1.0)   # ∂_b A_a
            # non-abelian term A_a × A_b (safe cross)
            Fab = d_a_Ab - d_b_Aa + _cross64(Aa, Ab)      # (*S, 3)
            F[..., a, b, :] = Fab
            F[..., b, a, :] = -Fab

    # --- energy (float64 accumulation; underflow-suppressed) ---
    with np.errstate(under='ignore'):
        E = 0.5 * float(weight) * _sqnorm64(F)

    # Scale F for gradient seed in float64 then safe-cast to float32
    with np.errstate(under='ignore'):
        G = _to32_no_underflow(np.asarray(weight, np.float64) * F.astype(np.float64, copy=False))

    # --- gradient wrt A: accumulate contributions from all pairs ---
    grad = np.zeros_like(A, dtype=np.float32)       # (*S, M, 3)
    for a in range(M):
        for b in range(a + 1, M):
            Gab = G[..., a, b, :]                   # (*S, 3)
            Aa  = A[..., a, :]
            Ab  = A[..., b, :]

            # from ∂_a A_b: + bwd_a(Gab) goes to A_b
            grad[..., b, :] += _cdiff_centered_adj(Gab, axis=a, h=1.0)

            # from −∂_b A_a: − bwd_b(Gab) goes to A_a
            grad[..., a, :] += -_cdiff_centered_adj(Gab, axis=b, h=1.0)

            # from A_a × A_b:  d/dA_a -> (A_b × Gab),  d/dA_b -> (Gab × A_a)
            grad[..., a, :] += _cross64(Ab, Gab)
            grad[..., b, :] += _cross64(Gab, Aa)

    if not (np.isfinite(E) and np.all(np.isfinite(grad)) and np.all(np.isfinite(F))):
        raise FloatingPointError("curvature_energy_and_grad produced non-finite outputs")

    return float(E), F, grad


def covariant_frame_energy_and_grads(phi, A, *, weight=1.0, mask=None, dx=1.0):
    """
    Gauge-covariant φ smoothness on an arbitrary-D periodic grid.

      E_cov = (weight/2) * sum_{m=0}^{M-1} || D_m φ ||^2
      D_m φ = ∂_m φ - A_m × φ        (SO(3): × is cross product)

    Args:
      phi   : (*S, 3)        Lie-algebra coords at each site (agent frame)
      A     : (*S, M, 3)     global connection components along each spatial axis
      weight: float          scalar weight for this term (already included in grads)
      mask  : (*S,) or (*S,1) or broadcastable to (*S,)   spatial mask (True/1 = active)
      dx    : float or tuple length M   grid spacing(s) per axis

    Returns:
      E_cov : float
      g_phi : (*S, 3)
      g_A   : (*S, M, 3)
    """
    import numpy as np

    # ---- inputs & basic checks ----
    phi = np.asarray(phi, np.float32)            # (*S,3)
    A   = np.asarray(A,   np.float32)            # (*S,M,3)
    if phi.ndim < 2 or A.ndim < 3 or A.shape[-1] != 3:
        raise ValueError(f"bad inputs: phi {phi.shape}, A {A.shape}")
    if phi.shape[:-1] != A.shape[:-2]:
        raise ValueError(f"shape mismatch: phi {phi.shape}, A {A.shape}")

    Sshape = phi.shape[:-1]
    M = int(A.shape[-2])

    # ---- spacings (anisotropic allowed) ----
    if isinstance(dx, (tuple, list, np.ndarray)):
        if len(dx) != M:
            raise ValueError(f"dx length ({len(dx)}) must match spatial rank M={M}")
        hs = tuple(float(v) for v in dx)
    else:
        h = float(dx)
        if not (h > 0):
            raise ValueError("dx must be positive")
        hs = (h,) * M
    if not all(h > 0 for h in hs):
        raise ValueError("all dx entries must be positive")

    # ---- mask: normalize to (*S,) bool, minimal fuss ----
    def _coerce_mask(m, S):
        if m is None:
            return None
        m = np.asarray(m)
        # squeeze optional last singleton
        if m.ndim == len(S) + 1 and m.shape[-1] == 1:
            m = m[..., 0]
        # booleanize: nonzero & finite → True
        if m.dtype != np.bool_:
            m = np.isfinite(m) & (m != 0)
        # broadcast to S if needed
        if m.shape != S:
            try:
                m = np.broadcast_to(m, S, subok=True)
            except Exception as e:
                raise ValueError(f"mask shape {np.shape(m)} not broadcastable to {S}") from e
        # ensure writeable array for in-place ops down the line
        return np.array(m, dtype=np.bool_, copy=True)

    mb = _coerce_mask(mask, Sshape)

    # ---- build D_m φ (masked once), accumulate energy in float64 ----
    D_list = []
    for ax in range(M):
        Am = A[..., ax, :]                              # (*S,3)
        # D_m φ = ∂_m φ − A_m × φ   (work in f64 for stability)
        Dm_raw64 = _cdiff_centered(phi, axis=ax, h=hs[ax]).astype(np.float64, copy=False) \
                   - _cross64(Am, phi)
        if mb is not None:
            Dm_raw64[~mb, :] = 0.0                      # boolean index, no multiply/where
        D_list.append(Dm_raw64.astype(np.float32, copy=False))

    # energy (float64 accumulator, then scale)
    with np.errstate(under='ignore'):
        E64 = 0.0
        for Dm in D_list:
            E64 += _sqnorm64(Dm)                        # sum of squared norms in f64
        E = 0.5 * float(weight) * E64

    # ---- gradients ----
    g_phi = np.zeros_like(phi, dtype=np.float32)
    g_A   = np.zeros_like(A,   dtype=np.float32)

    for ax in range(M):
        # scale residual in f64 then cast without subnormals
        with np.errstate(under='ignore'):
            Gm = _to32_no_underflow(np.asarray(weight, np.float64) * D_list[ax].astype(np.float64, copy=False))

        # φ-grad: adjoint(∂_m) + adjoint(−A_m×·) = −∂_m^* + (A_m×·)
        g_phi += -_cdiff_centered_adj(Gm, axis=ax, h=hs[ax]) + _cross64(A[..., ax, :], Gm)

        # A-grad from −A_m×φ term: − (φ × Gm)
        g_A[..., ax, :] += -_cross64(phi, Gm)

    # final mask on grads (single application)
    if mb is not None:
        g_phi[~mb, :] = 0.0
        g_A[~mb, :, :] = 0.0

    # safe downcast on exit
    g_phi = _to32_no_underflow(g_phi)
    g_A   = _to32_no_underflow(g_A)



    if not (np.isfinite(E) and np.all(np.isfinite(g_phi)) and np.all(np.isfinite(g_A))):
        raise FloatingPointError("covariant_frame_energy_and_grads produced non-finite outputs")

    return float(E), g_phi, g_A



