# -*- coding: utf-8 -*-
"""
Created on Mon Sep  8 16:26:26 2025

@author: chris and christine
"""

import numpy as np
from core.numerical_utils import safe_inv, sanitize_sigma  
from core.transport_cache import inverse_fisher_metric_field
from agents.agent_accessor import AA

# --- Unified dirty manager ----------------------------------------------------
class DirtyManager:
    """
    Single source of truth for 'dirty' state.

    Responsibilities:
      - Track dirty agents across categories: fields, kl, morphisms
      - Provide stable IDs (no object-id fallbacks)
      - Materialize a target agent subset by category
      - Clear agent-side flags only after successful processing
      - Bump ctx cache_version exactly when work happened
    """
    __slots__ = ("_fields", "_kl", "_morph",)

    def __init__(self):
        self._fields: set[int] = set()
        self._kl: set[int] = set()
        self._morph: set[int] = set()

    # ---- Stable ID helpers -------------------------------------------------
    @staticmethod
    def _aid(agent) -> int:
        aid = getattr(agent, "id", None)
        if aid is None:
            raise ValueError("DirtyManager: agent has no stable `id` attribute")
        return int(aid)

    # ---- Marking -----------------------------------------------------------
    def mark(self, *agents: object, kl: bool = False, morphism: bool = False) -> None:
        for a in agents:
            if a is None:
                continue
            aid = self._aid(a)
            # Always mark fields when any aspect of the agent changed
            self._fields.add(aid)
            setattr(a, "_dirty_fields", True)
            if kl:
                self._kl.add(aid)
                setattr(a, "_dirty_kl", True)
            if morphism:
                self._morph.add(aid)
                setattr(a, "morphisms_dirty", True)

    def mark_morphism_only(self, *agents: object) -> None:
        self.mark(*agents, morphism=True)

    def mark_kl_only(self, *agents: object) -> None:
        self.mark(*agents, kl=True)

    # ---- Selection ---------------------------------------------------------
    def take(self, all_agents: list, category: str = "fields") -> list:
        if   category == "fields": bag = self._fields
        elif category == "kl":     bag = self._kl
        elif category == "morph":  bag = self._morph
        else:
            raise ValueError(f"DirtyManager.take: unknown category {category!r}")

        if not bag:
            return []
        wanted = {int(x) for x in bag}
        subset = [a for a in (all_agents or []) if a is not None and self._aid(a) in wanted]
        bag.clear()
        return subset

    # ---- Post-processing cleanup ------------------------------------------
    def clear_agent_flags(self, *agents: object) -> None:
        for a in agents:
            if a is None:
                continue
            if hasattr(a, "_dirty_fields"): a._dirty_fields = False
            if hasattr(a, "_dirty_kl"):     a._dirty_kl = False
            if hasattr(a, "morphisms_dirty"): a.morphisms_dirty = False


# Attach/get from ctx (one per runtime context)
def dirty_manager(ctx) -> DirtyManager:
    d = getattr(ctx, "_dirty_manager", None)
    if d is None:
        d = DirtyManager()
        setattr(ctx, "_dirty_manager", d)
    return d



def ensure_dirty(ctx, generators_q, generators_p, scope="all"):
    """
    Resolve and process dirty agents for the given scope.

    Performs, in order:
      1) Select dirty targets via dirty_manager (category='kl' to match step mark).
      2) Ensure global intertwiner bases (Φ0, Φ̃0) exist in cache.
      3) Refresh dirty agents' Gaussian stats (sanitize Σ, compute inverses).
      4) Ensure Fisher information tensors exist for q/p fibers.
      5) Warm per-agent caches needed by edge/gradient code:
         - Local energy Hessians E and their inverses Jinv (q/p).
         - Per-agent morphisms Φ_i and Φ̃_i (q/p).
      6) Clear dirty flags and bump ctx.cache_version iff work happened.

    Returns
    -------
    targets : list[Agent]
        The list of agents that were processed (possibly empty).
    """
    DM = dirty_manager(ctx)

    # --- 1) Select targets by scope ---
    if scope not in ("all", "children"):
        raise ValueError(f"[ensure_dirty] unknown scope={scope!r}")

    all_children = list(getattr(ctx, "children_latest", []))
    # NOTE: match category with the mark() in synchronous_step (kl=True)
    targets = DM.take(all_children, category="kl")
    targets = [t for t in targets if t is not None]
    if not targets:
        return []

    # Whether any agent had flags set prior to processing (for version bump)
    had_flags = any(
        getattr(a, "_dirty_fields", False)
        or getattr(a, "_dirty_kl", False)
        or getattr(a, "morphisms_dirty", False)
        for a in targets
    )

    did_any = False

    # --- 2) Ensure global intertwiner bases in cache (Φ0, Φ̃0) ---
    try:
        from core.transport_cache import get_morphism_bases
        _ = get_morphism_bases(ctx, generators_q, generators_p)
        did_any = True
    except Exception:
        pass

    # --- 3) Refresh dirty agents' Gaussian stats (sanitize/invert) ---
    try:
        refresh_agents(targets, generators_q, generators_p, ctx=ctx)
        did_any = True
    except Exception:
        pass

    # --- 4) Ensure Fisher information tensors (q/p) ---
    from core.runtime_context import cfg_get
    eps = float(cfg_get(ctx, "eps", 1e-8))

    for a in targets:
        try:
            _ensure_fisher(a, which="q", generators=generators_q, ctx=ctx, eps=eps)
            _ensure_fisher(a, which="p", generators=generators_p, ctx=ctx, eps=eps)
            did_any = True
        except Exception:
            continue

    # --- 5) Warm per-agent caches needed downstream ---
    try:
        from core.transport_cache import warm_E, warm_Jinv, Phi
        warm_E(ctx, targets, fibers=("q", "p"), n_jobs=12, backend="threading")
        warm_Jinv(ctx, targets, fibers=("q", "p"), n_jobs=12, backend="threading")
        for a in targets:
            try:
                _ = Phi(ctx, a, which="q")
            except Exception:
                pass
            try:
                _ = Phi(ctx, a, which="p")
            except Exception:
                pass
        did_any = True
    except Exception:
        pass

    # --- 6) Clear dirty flags & bump cache version if work happened ---
    if did_any:
        DM.clear_agent_flags(*targets)

    if did_any and had_flags:
        setattr(ctx, "cache_version", int(getattr(ctx, "cache_version", 0)) + 1)

    return targets




# ---------------------------------------------------------------------
# Per-agent preprocessing
# ---------------------------------------------------------------------


def refresh_agents(agents, Gq, Gp, *, ctx=None):
    """
    Lightweight, permissive preprocessing for a batch of agents.
    No strict shape policing—just make fields usable this step.

    Per agent (idempotent per-step):
      • ensure a mask exists (soft or binary), broadcast if needed
      • sanitize Σ_q / Σ_p to SPD and compute Σ^{-1}
      • refresh Fisher preconditioners (q/p)
      • tag `_preprocessed_step` to skip repeated work this step
    """
    
    from core.runtime_context import cfg_get
    
    from updates.update_helpers import _ensure_fisher  # uses inverse_fisher_metric_field under the hood

    if not agents:
        return []

    eps = float(cfg_get(ctx, "eps", 1e-8))
    step_tag = int(getattr(ctx, "global_step", -1))

    # Trust generator shapes; no hard assertions
    Gq = np.asarray(Gq);  Kq = int(Gq.shape[-1])
    Gp = np.asarray(Gp);  Kp = int(Gp.shape[-1])

    for a in agents:
        # Idempotent within the step
        if getattr(a, "_preprocessed_step", None) == step_tag and step_tag >= 0:
            continue

        # ---- spatial shape S (best-effort, no strict checks) ----
        S = ()
        if getattr(a, "sigma_q_field", None) is not None:
            S = AA.get_sigma_q(a, sanitize=False).shape[:-2]
        elif getattr(a, "mu_q_field", None) is not None:
            S = AA.get_mu_q(a).shape[:-1]
        elif getattr(a, "sigma_p_field", None) is not None:
            S = AA.get_sigma_p(a, sanitize=False).shape[:-2]
        elif getattr(a, "mu_p_field", None) is not None:
            S = AA.get_mu_p(a).shape[:-1]
        elif getattr(a, "mask", None) is not None:
            m0 = AA.get_mask_float(a)
            if m0.ndim >= 1 and m0.shape[-1] == 1:
                m0 = m0[..., 0]
            S = m0.shape

        # ---- mask: ensure exists, float32 in [0,1] ----
        m = getattr(a, "mask", None)
        if m is None:
            a.mask = (np.ones(S, np.float32) if len(S) > 0 else np.array(1.0, np.float32))
        else:
            m = np.asarray(m)
            if m.ndim == len(S) + 1 and m.shape[-1] == 1:
                m = m[..., 0]
            if m.dtype == np.bool_:
                m = m.astype(np.float32, copy=False)
            else:
                m = np.clip(m.astype(np.float32, copy=False), 0.0, 1.0)
            a.mask = m

        # ---- μ fields: just coerce dtype to float32 if present ----
        if getattr(a, "mu_q_field", None) is not None:
            a.mu_q_field = AA.get_mu_q(a)
        if getattr(a, "mu_p_field", None) is not None:
            a.mu_p_field = AA.get_mu_p(a)

        # ---- Σ_q: sanitize → inverse (fallback to eye if missing) ----
        if getattr(a, "sigma_q_field", None) is not None:
            Sq64 = sanitize_sigma(AA.get_sigma_q(a, sanitize=False).astype(np.float64), eps=eps)
            a.sigma_q_field = Sq64.astype(np.float32, copy=False)
            inv_q64 = safe_inv(Sq64, eps=eps)
            a.sigma_q_inv = inv_q64.astype(np.float32, copy=False)
        else:
            eye_q = np.eye(Kq, dtype=np.float32)
            a.sigma_q_field = np.broadcast_to(eye_q, tuple(S) + (Kq, Kq)).copy()
            a.sigma_q_inv   = np.broadcast_to(eye_q, tuple(S) + (Kq, Kq)).copy()

        # ---- Σ_p: sanitize → inverse (fallback to eye if missing) ----
        if getattr(a, "sigma_p_field", None) is not None:
            Sp64 = sanitize_sigma(AA.get_sigma_p(a, sanitize=False).astype(np.float64), eps=eps)
            a.sigma_p_field = Sp64.astype(np.float32, copy=False)
            inv_p64 = safe_inv(Sp64, eps=eps)
            a.sigma_p_inv = inv_p64.astype(np.float32, copy=False)
        else:
            eye_p = np.eye(Kp, dtype=np.float32)
            a.sigma_p_field = np.broadcast_to(eye_p, tuple(S) + (Kp, Kp)).copy()
            a.sigma_p_inv   = np.broadcast_to(eye_p, tuple(S) + (Kp, Kp)).copy()

        # ---- Fisher preconditioners (q/p) ----
        try:
            _ensure_fisher(a, which="q", generators=Gq, ctx=ctx, eps=eps)
        except Exception:
            pass
        try:
            _ensure_fisher(a, which="p", generators=Gp, ctx=ctx, eps=eps)
        except Exception:
            pass

        # mark preprocessed
        a._preprocessed_step = step_tag

    return agents



def _ensure_fisher(agent, *, which, generators, ctx, eps):
    # choose field names by fiber
    if which == "q":
        attr = "inverse_fisher_phi"
    else:
        attr = "inverse_fisher_phi_model"

    Finv = getattr(agent, attr, None)
    if Finv is not None:
        return  # already present

    # Optional: central cache by (agent_id, which) to avoid recompute in parallel
    cache_key = ("fisher", which, int(getattr(agent, "id", -1)))
    try:
        cache = ctx._cache  # if you have a context cache dict
    except AttributeError:
        cache = None

    if cache is not None and cache_key in cache:
        setattr(agent, attr, cache[cache_key])
        return

    Finv = inverse_fisher_metric_field(ctx, agent, generators, which=which, eps=eps)
    setattr(agent, attr, Finv)
    if cache is not None:
        cache[cache_key] = Finv























def apply_global_phi_gauge_fix(
    agents,
    *,
    include_model_in_mean: bool = True,
    mask_weighted: bool = True,
    zero_outside_mask: bool = True,
    max_iters: int = 15,
    tol: float = 1e-7,
):
    """
    Compute Karcher mean rotation R_bar from masked pixels of BOTH phi and (optionally) phi_model,
    then left-multiply all frames by R_bar^{-1}. Finally (optionally) set both to zero outside mask.

    This treats phi and phi_model symmetrically:
      - If include_model_in_mean=True, the mean uses {phi} ∪ {phi_model where present} with the same mask.
      - The same R_bar^{-1} is applied to both.
      - Both are re-zeroed outside mask if requested.

    Invariants inside support are preserved; hard zeros outside support are preserved when zero_outside_mask=True.
    """
    import numpy as np

    # --- so(3) helpers ---
    def _hat(v):
        x, y, z = float(v[0]), float(v[1]), float(v[2])
        return np.array([[0, -z,  y],
                         [z,  0, -x],
                         [-y, x,  0]], dtype=np.float64)

    def _so3_exp(v):
        t = float(np.linalg.norm(v))
        if t < 1e-12:
            K = _hat(v)
            return np.eye(3, dtype=np.float64) + K + 0.5 * (K @ K)
        K = _hat(v); s, c = np.sin(t), np.cos(t)
        return np.eye(3) + (s / t) * K + ((1.0 - c) / (t * t)) * (K @ K)

    def _so3_log(R):
        tr = float(np.clip(np.trace(R), -1.0, 3.0))
        ct = 0.5 * (tr - 1.0)
        ct = np.clip(ct, -1.0, 1.0)
        t = float(np.arccos(ct))
        if t < 1e-12:
            # small-angle: use antisymmetric part
            return np.array([R[2, 1] - R[1, 2],
                             R[0, 2] - R[2, 0],
                             R[1, 0] - R[0, 1]], dtype=np.float64) * 0.5
        v = np.array([R[2, 1] - R[1, 2],
                      R[0, 2] - R[2, 0],
                      R[1, 0] - R[0, 1]], dtype=np.float64)
        return (t / (2.0 * np.sin(t))) * v

    # --- collect rotations and weights from masked pixels of phi (+ phi_model if enabled) ---
    Rs, ws = [], []
    for a in agents:
        # common shape and mask
        phi = np.asarray(getattr(a, "phi"), np.float64)  # (*S,3)
        shp = phi.shape[:-1]
        if mask_weighted:
            m = getattr(a, "mask", None)
            if m is not None:
                m = np.asarray(m, np.float64)
                if m.shape != shp:
                    pad = (1,) * max(0, len(shp) - m.ndim)
                    m = np.broadcast_to(m.reshape(pad + m.shape), shp)
                w_base = m.reshape(-1)  # (N,)
            else:
                w_base = np.ones(np.prod(shp, dtype=int), np.float64)
        else:
            w_base = np.ones(np.prod(shp, dtype=int), np.float64)

        # helper to add a field to the mean
        def _add_field(field_arr, w_arr):
            f = np.asarray(field_arr, np.float64).reshape(-1, 3)
            for v, ww in zip(f, w_arr):
                if ww <= 0.0:
                    continue
                Rs.append(_so3_exp(v))
                ws.append(float(ww))

        # always include phi
        _add_field(phi, w_base)

        # optionally also include phi_model (if present)
        if include_model_in_mean and getattr(a, "phi_model", None) is not None:
            _add_field(getattr(a, "phi_model"), w_base)

    if not Rs:
        return  # nothing active to define a mean

    # --- Karcher mean (left-invariant) ---
    Rbar = np.eye(3, dtype=np.float64)
    wsum = float(np.sum(ws))
    for _ in range(max_iters):
        mu = np.zeros(3, np.float64)
        for R, w in zip(Rs, ws):
            mu += w * _so3_log(Rbar.T @ R)
        mu /= max(wsum, 1e-12)
        if float(np.linalg.norm(mu)) < tol:
            break
        Rbar = Rbar @ _so3_exp(mu)
    
    
    if np.linalg.norm(mu) < 1e-6:   # radians; tune
        return  # nothing to do this step

    Rbar_inv = Rbar.T  # orthogonal inverse

    # --- apply to phi and phi_model, then zero outside mask if requested ---
    def _apply_log_left(R_left_inv, phi_field):
        x = np.asarray(phi_field, np.float64).reshape(-1, 3)
        out = np.zeros_like(x)
        for i, v in enumerate(x):
            R = _so3_exp(v)
            out[i] = _so3_log(R_left_inv @ R)
        return out.reshape(phi_field.shape).astype(np.float32)

    for a in agents:
        a.phi = _apply_log_left(Rbar_inv, getattr(a, "phi"))
        if getattr(a, "phi_model", None) is not None:
            a.phi_model = _apply_log_left(Rbar_inv, getattr(a, "phi_model"))

        if zero_outside_mask:
            m = getattr(a, "mask", None)
            if m is not None:
                m = np.asarray(m, np.float32)
                shp = a.phi.shape[:-1]
                if m.shape != shp:
                    pad = (1,) * max(0, len(shp) - m.ndim)
                    m = np.broadcast_to(m.reshape(pad + m.shape), shp)
                m3 = m[..., None]  # (*S,1)
                a.phi = (a.phi * m3).astype(np.float32)
                if getattr(a, "phi_model", None) is not None:
                    a.phi_model = (a.phi_model * m3).astype(np.float32)