# -*- coding: utf-8 -*-
"""
Created on Thu Oct 23 13:57:54 2025

@author: chris and christine
"""

import numpy as np
import config as config
from core.transport_cache import Omega, Phi
from agents.agent_accessor import AA
from core.utils import _zeros_mu_S_like
from core.numerical_utils import sanitize_sigma, safe_inv, push_gaussian,safe_omega_inv
from core.omega import d_exp_exact, matrix_cograd_to_param_covector_irrep


#==============================================================================
#
#                    DISPATCHERS
#                       
#==============================================================================


def grad_gamma_mu_sigma_dispatch(
    ctx, agent_i, agent_j, *, basis,
    Omega_ij=None,         # Ω^q_{ij} : Q_j→Q_i  (… ,Kq,Kq)
    Phi_i=None,            # Φ_i      : Q_i→P_i  (… ,Kp,Kq)
    Phi_tilde_i=None,      # Φ̃_i     : P_i→Q_i  (… ,Kq,Kp)
    eps: float = 1e-8,
):
    """
    Return dict with receiver/sender μ/Σ grads for γ-basis in {"A","B","align","align_q","align_p"}.
    Prefers passed-in maps; falls back to ctx to fetch them if missing.
    """

    b = str(basis).lower()

    # ---- trivial align* → zeros (no cross-fiber μ/Σ grads) ----
    if b in {"align", "align_q", "align_p"}:
        mu_i_any = getattr(agent_i, "mu_p_field", None) or getattr(agent_i, "mu_q_field", None)
        mu_j_any = getattr(agent_j, "mu_q_field", None) or getattr(agent_j, "mu_p_field", None)
        mu_rec_0, S_rec_0   = _zeros_mu_S_like(mu_i_any)
        mu_send_0, S_send_0 = _zeros_mu_S_like(mu_j_any)
        return {"mu_rec": mu_rec_0, "S_rec": S_rec_0,
                "mu_send": mu_send_0, "S_send": S_send_0}

    # ---- maps (prefer explicit, fallback to ctx) ----
    if Omega_ij is None:
        Omega_ij = Omega(ctx, agent_i, agent_j, which="q")  # Q_j→Q_i
    if b == "a" and (Phi_tilde_i is None):
        Phi_tilde_i = Phi(ctx, agent_i, kind="p_to_q")      # P→Q
    if b == "b" and (Phi_i is None):
        Phi_i = Phi(ctx, agent_i, kind="q_to_p")            # Q→P

    # ---- cast once to float64 (stable math), keep originals for shape if needed ----
    Om_ij64   = np.asarray(Omega_ij,  np.float64, order="C")
    Phi_i64   = None if Phi_i is None else np.asarray(Phi_i, np.float64, order="C")
    Phit_i64  = None if Phi_tilde_i is None else np.asarray(Phi_tilde_i, np.float64, order="C")

    mu_q_j64  = np.asarray(agent_j.mu_q_field,    np.float64, order="C")
    Sig_q_j64 = np.asarray(agent_j.sigma_q_field, np.float64, order="C")
    mu_p_i64  = AA.get_mu_p(agent_i).astype(np.float64, order="C")
    Sig_p_i64 = AA.get_sigma_p(agent_i, sanitize=False).astype(np.float64, order="C")

    # ---- helper: Ω_ji from Ω_ij with a cheap ortho check ----
    def _omega_ji_from_ij(Om_ij):
        Om_t = np.swapaxes(Om_ij, -1, -2)
        I = Om_t @ Om_ij
        eye = np.eye(I.shape[-1], dtype=Om_ij.dtype)
        dev = np.max(np.abs(I - eye))
        if np.all(np.isfinite(I)) and dev < 1e-6:
            return Om_t
        return np.linalg.inv(Om_ij)

    if b == "a":
      

        Om_ji64 = _omega_ji_from_ij(Om_ij64)

        # --- receiver (i) ---
        dmu_rec, dS_rec = grad_gamma_A_mu_sigma_i(
            Phit_i=Phit_i64, Om_ji=Om_ji64,
            mu_q_j=mu_q_j64,  Sigma_q_j=Sig_q_j64,
            mu_p_i=mu_p_i64,  Sigma_p_i=Sig_p_i64,
            eps=eps,
        )

        # --- sender (j) ---
        dmu_send, dS_send = grad_gamma_A_mu_sigma_j(
            mu_q_j64,  Sig_q_j64,
            mu_p_i64,  Sig_p_i64,
            Phit_i=Phit_i64, Om_ji=Om_ji64,
            eps=eps, assume_sanitized=True,
        )

    elif b == "b":
        
        # --- receiver (i) ---
        dmu_rec, dS_rec = grad_gamma_B_mu_sigma_i(
            Phi_i=Phi_i64, Om_ij=Om_ij64,
            mu_q_j=mu_q_j64,  Sigma_q_j=Sig_q_j64,
            mu_p_i=mu_p_i64,  Sigma_p_i=Sig_p_i64,
            eps=eps,
        )

        # --- sender (j) ---   (precompute R once; pass along)
        R64 = np.einsum("...ik,...kj->...ij", Phi_i64, Om_ij64, optimize=True)
        dmu_send, dS_send = grad_gamma_B_mu_sigma_j(
            mu_j=mu_q_j64,  Sigma_j=Sig_q_j64,
            mu_p_i=mu_p_i64, Sigma_p_i=Sig_p_i64,
            Omega_ij=Om_ij64, Phi_i=Phi_i64,
            R=R64,
            eps=eps, assume_sanitized=True,
        )

    else:
        raise ValueError(f"Unknown gamma basis: {basis}")

    # ---- symmetry & final dtype ----
    dS_rec  = 0.5 * (dS_rec  + np.swapaxes(dS_rec,  -1, -2))
    dS_send = 0.5 * (dS_send + np.swapaxes(dS_send, -1, -2))

    return {
        "mu_rec":  np.asarray(dmu_rec,  np.float32, order="C"),
        "S_rec":   np.asarray(dS_rec,   np.float32, order="C"),
        "mu_send": np.asarray(dmu_send, np.float32, order="C"),
        "S_send":  np.asarray(dS_send,  np.float32, order="C"),
    }




def grad_gamma_phi_covectors(
    *,  # <-- require kwargs, pure path only
    basis: str,
    Eqi, Eqj, Epi,
    mu_q_j, Sigma_q_j,
    mu_p_i, Sigma_p_i,
    generators_irrep,
    eps: float = 1e-8,
):
    b = str(basis).lower()
    
    
    if b == "a":
        return grad_gamma_A_phi_covectors(
            Eqi=Eqi, Eqj=Eqj, Epi=Epi,
            mu_q_j=mu_q_j, Sigma_q_j=Sigma_q_j,
            mu_p_i=mu_p_i, Sigma_p_i=Sigma_p_i,
            generators_irrep=generators_irrep, eps=eps,
        )
    if b == "b":
        return grad_gamma_B_phi_covectors(
            Eqi=Eqi, Eqj=Eqj, Epi=Epi,
            mu_p_i=mu_p_i, Sigma_p_i=Sigma_p_i,
            mu_q_j=mu_q_j, Sigma_q_j=Sigma_q_j,
            generators_irrep=generators_irrep, eps=eps,
        )
    raise ValueError(f"basis must be 'a' or 'b', got {basis!r}")
    

def _self_and_feedback_grads(
    mode: str,
    mu_q, sigma_q, mu_p, sigma_p,
    mu_q_push, Sigma_q_push, inv_q_push,
    mu_p_push, Sigma_p_push, inv_p_push,
    Phi_mat, Phi_tilde_mat, eps: float,
    *, sigma_q_inv=None, sigma_p_inv=None, mask=None
):
    if mode == "belief":
        g_self_mu, g_self_S = grad_self_energy_belief(
            mu_q, sigma_q, mu_p_push, inv_p_push,
            sigma_q_inv=sigma_q_inv, mask=mask
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_belief(
            mu_q, sigma_q, mu_p, mu_q_push,
            Sigma_q_push, inv_q_push, sigma_p, Phi_mat
        )
        #print(f"{g_self_mu}")    
    
    elif mode == "model":
        g_self_mu, g_self_S = grad_self_energy_model(
            mu_q, sigma_q, mu_p_push, inv_p_push, Phi_tilde_mat, mask=mask
        )
        g_fb_mu, g_fb_S = grad_feedback_energy_model(
            mu_p, sigma_p, mu_q_push, Sigma_q_push, inv_q_push,
            sigma_p_inv=sigma_p_inv
        )
    else:
        raise ValueError(f"Unsupported mode: {mode}")
    return g_self_mu, g_self_S, g_fb_mu, g_fb_S





#==============================================================================
#
#                   MU/SIGMA TERMS
#
#==============================================================================

def grad_alignment_energy_source(
    mu_i, sigma_i, mu_j_t, sigma_j_t_inv, eps=1e-8,
    *, sigma_i_inv=None, assume_sanitized=True
):
    """
    Faster: reuse precomputed sigma_i_inv if provided; optionally skip sanitize.
    """
    mu_i       = np.asarray(mu_i,       dtype=np.float32, order="C")
    mu_j_t     = np.asarray(mu_j_t,     dtype=np.float32, order="C")
    sigma_j_t_inv = np.asarray(sigma_j_t_inv, dtype=np.float32, order="C")

    dmu = mu_i - mu_j_t
    # grad_mu_i = S'^-1 (μ_i - μ_j')
    grad_mu = np.einsum("...ij,...j->...i", sigma_j_t_inv, dmu, optimize=True)

    if sigma_i_inv is None:
        Si = np.asarray(sigma_i, dtype=np.float32, order="C")
        if not assume_sanitized:
            Si = sanitize_sigma(Si, eps=eps)
        sigma_i_inv = safe_inv(Si)   # batched cholesky-inv

    grad_sigma = 0.5 * (sigma_j_t_inv - sigma_i_inv)
    # symmetrize
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_alignment_energy_target(
    mu_i, sigma_i, mu_j_t, sigma_j_t_inv, Omega_ij, eps: float = 1e-8,
    *, assume_sanitized=True
):
    """
    Faster: use v = S'^-1 dμ  ->  v vᵀ for the middle term; skip repeated sanitize.
    """
    mu_i       = np.asarray(mu_i,       dtype=np.float32, order="C")
    mu_j_t     = np.asarray(mu_j_t,     dtype=np.float32, order="C")
    Omega_ij   = np.asarray(Omega_ij,   dtype=np.float32, order="C")
    sigma_jinv = np.asarray(sigma_j_t_inv, dtype=np.float32, order="C")

    dmu = mu_i - mu_j_t

    # ∂_{μ_j'} KL = - S'^-1 dμ  ;  map back with Ωᵀ
    gmu_jp    = -np.einsum("...ij,...j->...i", sigma_jinv, dmu, optimize=True)
    grad_mu_j = np.einsum("...ji,...j->...i", Omega_ij, gmu_jp, optimize=True)

    # Σ_i only appears (not inverted); assume sanitized upstream
    Si = np.asarray(sigma_i, dtype=np.float32, order="C")
    if not assume_sanitized:
        Si = sanitize_sigma(Si)

    # v = S'^-1 dμ  ->  v vᵀ
    v   = np.einsum("...ij,...j->...i", sigma_jinv, dmu, optimize=True)
    vvT = np.einsum("...i,...j->...ij", v, v, optimize=True)

    # gΣ' = 1/2( -S'^-1 Σ_i S'^-1 - vvᵀ + S'^-1 )
    t0 = -np.einsum("...ij,...jk,...kl->...il", sigma_jinv, Si, sigma_jinv, optimize=True)
    gSp = 0.5 * (t0 - vvT + sigma_jinv)

    # map back: Ωᵀ gΣ' Ω, then symmetrize
    grad_sigma_j = np.einsum("...ji,...jk,...kl->...il",
                             Omega_ij, gSp, np.swapaxes(Omega_ij, -1, -2), optimize=True)
    grad_sigma_j = 0.5 * (grad_sigma_j + np.swapaxes(grad_sigma_j, -1, -2))

    return grad_mu_j.astype(np.float32, copy=False), grad_sigma_j.astype(np.float32, copy=False)



def grad_feedback_energy_belief(
    mu_q, sigma_q, mu_p, mu_q_push,
    sigma_q_push, sigma_q_push_inv, sigma_p, Phi, eps=1e-8, *,
    assume_sanitized=True,
):
    """
    ∂ wrt (μ_q, Σ_q) of KL(p || Φ·q), evaluated in q-fiber.
    Uses v = S'^-1 Δ and v v^T instead of S'^-1 ΔΔ^T S'^-1 to cut temps.
    """
    # Δ = μ_p - μ_q'
    delta = (mu_p - mu_q_push).astype(np.float32, copy=False)

    # v = S'^-1 Δ  (matvec)
    v = np.matmul(sigma_q_push_inv, delta[..., None])[..., 0]  # (...,K)

    # grad_μ = - Φ^T v
    Phi_T = np.swapaxes(Phi, -1, -2)
    grad_mu = -np.matmul(Phi_T, v[..., None])[..., 0]

    # M = S'^-1  - v v^T  - S'^-1 Σ_p S'^-1
    term1 = sigma_q_push_inv
    term2 = np.matmul(v[..., :, None], v[..., None, :])        # v v^T
    term3 = np.matmul(np.matmul(sigma_q_push_inv, sigma_p), sigma_q_push_inv)

    M = term1 - term2 - term3

    # grad_Σ = 1/2 Φ^T M Φ (symmetrized)
    grad_sigma = 0.5 * np.matmul(np.matmul(Phi_T, M), Phi)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_feedback_energy_model(
    mu_p, sigma_p, mu_q_push,
    sigma_q_push, sigma_q_push_inv, Phi=None, eps=1e-8, *,
    sigma_p_inv=None, assume_sanitized=True,
):
    """
    ∂ wrt (μ_p, Σ_p) of KL(p || q'), evaluated in p-fiber.
    Avoids inverting Σ_p if sigma_p_inv is provided.
    """
    delta = (mu_p - mu_q_push).astype(np.float32, copy=False)

    # grad_μ = S'^-1 Δ
    grad_mu = np.matmul(sigma_q_push_inv, delta[..., None])[..., 0]

    # grad_Σ = 1/2 (S'^-1 - Σ_p^{-1})
    if sigma_p_inv is None:
        # assume Σ_p already sanitized upstream; we only invert if caller didn’t pass inv
        sigma_p_inv = safe_inv(sigma_p.astype(np.float32, copy=False))
    grad_sigma = 0.5 * (sigma_q_push_inv - sigma_p_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_belief(
    mu_q, sigma_q, mu_p_push, sigma_p_push_inv, eps=1e-8, *,
    sigma_q_inv=None, mask=None, assume_sanitized=True,
):
    """
    ∂ wrt (μ_q, Σ_q) of KL(q || p'), evaluated in q-fiber.
    Reuses sigma_q_inv if provided.
    """
    delta = (mu_q - mu_p_push).astype(np.float32, copy=False)

    # grad_μ = S_p'^-1 Δ
    grad_mu = np.matmul(sigma_p_push_inv, delta[..., None])[..., 0]

    # grad_Σ = 1/2 (S_p'^-1 - Σ_q^{-1})
    if sigma_q_inv is None:
        sigma_q_inv = safe_inv(sigma_q.astype(np.float32, copy=False))
    
    grad_sigma = 0.5 * (sigma_p_push_inv - sigma_q_inv)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)


def grad_self_energy_model(
    mu_q, sigma_q, mu_p_push, sigma_p_push_inv, Phi_tilde, eps=1e-8, *,
    assume_sanitized=True, mask=None,
):
    """
    ∂ wrt (μ_p, Σ_p) of KL(q || p'), evaluated in p-fiber.
    Uses v = M Δ and v v^T to avoid an extra large einsum.
    """
    delta = (mu_q - mu_p_push).astype(np.float32, copy=False)

    # tmp = M Δ
    v = np.matmul(sigma_p_push_inv, delta[..., None])[..., 0]

    # grad_μ = - Φ̃^T v
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)
    grad_mu = -np.matmul(Phi_tilde_T, v[..., None])[..., 0]

    # G = M - v v^T - M Σ_q M
    vvT = np.matmul(v[..., :, None], v[..., None, :])
    M_Sq = np.matmul(sigma_p_push_inv, sigma_q.astype(np.float32, copy=False))
    G = sigma_p_push_inv - vvT - np.matmul(M_Sq, sigma_p_push_inv)

    # grad_Σ = 1/2 Φ̃^T G Φ̃  (symmetrized)
    grad_sigma = 0.5 * np.matmul(np.matmul(Phi_tilde_T, G), Phi_tilde)
    grad_sigma = 0.5 * (grad_sigma + np.swapaxes(grad_sigma, -1, -2))

    if mask is not None:
        m = (np.asarray(mask) > float(getattr(config, "support_tau", 0.0)))
        grad_mu    = grad_mu * m[..., None]
        grad_sigma = grad_sigma * m[..., None, None]

    return grad_mu.astype(np.float32, copy=False), grad_sigma.astype(np.float32, copy=False)





# ---------------- A (receiver i): KL( q_j || Ω_ji[ Φ̃_i p_i ] ) — grads wrt (μ_p_i, Σ_p_i)
def grad_gamma_A_mu_sigma_i(
    *,
    Phit_i,                  # Φ̃_i : P_i→Q_i        (..., Kq, Kp)
    Om_ji,                   # Ω^q_{ji} : Q_i→Q_j    (..., Kq, Kq)
    mu_q_j,  Sigma_q_j,      # sender q_j            (..., Kq), (..., Kq,Kq)
    mu_p_i,  Sigma_p_i,      # receiver p_i          (..., Kp), (..., Kp,Kp)
    eps: float = 1e-8,
):
    """
    ∂/∂(μ_{p_i}, Σ_{p_i}) of KL_A = KL( q_j || Ω_ji[ Φ̃_i p_i ] ).
    Uses push_gaussian for all linear pushes. Returns: dμ_p_i (*S,Kp), dΣ_p_i (*S,Kp,Kp)
    """
  
    # ---- cast/sanitize inputs (once) ----
    Phit_i = np.asarray(Phit_i,   np.float64, order="C")
    Om_ji  = np.asarray(Om_ji,    np.float64, order="C")
    mu_j   = np.asarray(mu_q_j,   np.float64, order="C")
    Sj     = sanitize_sigma(np.asarray(Sigma_q_j, np.float64), eps=eps)

    mu_p = np.asarray(mu_p_i,   np.float64, order="C")
    Sp   = sanitize_sigma(np.asarray(Sigma_p_i, np.float64), eps=eps)

    Rt = np.swapaxes

    # ---- push p_i to Q_i via Φ̃_i using push_gaussian ----
    # First push: inputs already sanitized (Sp), so skip extra sanitation here.
    mu_qhat, S_qhat = push_gaussian(
        mu_p, Sp, Phit_i,
        eps=eps, return_inv=False,
        Sigma_inv=None, assume_orthogonal=False,
        sanitize_input=False,
    )

    # ---- land in Q_j via Ω_ji; get Σ_L^{-1} directly from push_gaussian ----
    # Second push: allow push_gaussian to sanitize the landing covariance.
    mu_L, S_L, S_L_inv = push_gaussian(
        mu_qhat, S_qhat, Om_ji,
        eps=eps, return_inv=True,
        Sigma_inv=None, assume_orthogonal=False,
        sanitize_input=True,
    )

    # ---- KL(q_j || N(mu_L, S_L)) partials wrt (μ_L, Σ_L) ----
    d   = mu_L - mu_j
    v   = np.einsum("...ij,...j->...i", S_L_inv, d, optimize=True)
    vvT = np.einsum("...i,...j->...ij", v, v, optimize=True)
    term = np.einsum("...ij,...jk->...ik", S_L_inv,
                     np.einsum("...jk,...kl->...jl", Sj, S_L_inv, optimize=True),
                     optimize=True)
    dSL = 0.5 * (-term - vvT + S_L_inv)
    dSL = 0.5 * (dSL + Rt(dSL, -1, -2))

    # ---- backprop to (μ_p, Σ_p) through Ω_ji then Φ̃_i ----
    g_mu_qhat = np.einsum("...ji,...j->...i", Om_ji, v, optimize=True)                     # Ω_ji^T v
    g_S_qhat  = np.einsum("...ji,...jk,...kl->...il", Om_ji, dSL, Om_ji, optimize=True)   # Ω_ji^T dSL Ω_ji
    dmu_p     = np.einsum("...ji,...j->...i", Phit_i, g_mu_qhat, optimize=True)           # Φ̃_i^T g
    dS_p      = np.einsum("...ji,...jk,...kl->...il", Phit_i, g_S_qhat, Phit_i, optimize=True)
    dS_p      = 0.5 * (dS_p + Rt(dS_p, -1, -2))

    return dmu_p.astype(np.float32, copy=False), dS_p.astype(np.float32, copy=False)


    
def grad_gamma_A_mu_sigma_j(
    mu_q_j,  Sigma_q_j,          # sender q_j         (...,Kq), (...,Kq,Kq)
    mu_p_i,  Sigma_p_i,          # receiver p_i       (...,Kp), (...,Kp,Kp)
    *,
    Phit_i,  Om_ji,              # Φ̃_i: P→Q,  Ω_ji: Q_i→Q_j
    mask=None,
    eps: float = 1e-8,
    assume_sanitized: bool = True,
):
    """
    ∂/∂(μ_j, Σ_j) for KL_A = KL( q_j || Ω_ji[ Φ̃_i p_i ] ).
    Uses push_gaussian for linear pushes.
    Returns: (dμ_j, dΣ_j) in the sender q_j frame.
    """
   

    # ---- cast (optionally sanitize inputs) ----
    mu_j   = np.asarray(mu_q_j,    np.float64, order="C")
    Sj     = np.asarray(Sigma_q_j, np.float64, order="C")
    mu_pi  = np.asarray(mu_p_i,    np.float64, order="C")
    Sp     = np.asarray(Sigma_p_i, np.float64, order="C")
    Phit_i = np.asarray(Phit_i,    np.float64, order="C")
    Om_ji  = np.asarray(Om_ji,     np.float64, order="C")
    Rt     = np.swapaxes

    if not assume_sanitized:
        Sj = sanitize_sigma(Sj, eps=eps)
        Sp = sanitize_sigma(Sp, eps=eps)

    # ---- landing distribution: q̂_j = Ω_ji[ Φ̃_i p_i ] ----
    # 1) push to Q_i via Φ̃_i (trust input Σ_p if assume_sanitized=True)
    mu_qhat_i, S_qhat_i = push_gaussian(
        mu_pi, Sp, Phit_i,
        eps=eps, return_inv=False,
        Sigma_inv=None, assume_orthogonal=False,
        sanitize_input=False,             # don't sanitize on this hop
    )

    # 2) push to Q_j via Ω_ji, and sanitize landing Σ_hat
    mu_hat, S_hat = push_gaussian(
        mu_qhat_i, S_qhat_i, Om_ji,
        eps=eps, return_inv=False,
        Sigma_inv=None, assume_orthogonal=False,
        sanitize_input=True,              # sanitize Σ_hat for KL stability
    )

    # ---- KL(P||Q) with P=N(mu_j,Sj), Q=N(mu_hat,S_hat) — grads wrt P=(μ_j,Σ_j) ----
    Sj_inv = safe_inv(Sj, eps=max(eps, 1e-12))

    diff   = (mu_j - mu_hat)
    vj     = np.einsum("...ij,...j->...i", Sj_inv, diff, optimize=True)     # Σ_j^{-1}(μ_j-μ_hat)
    dmu_j  = vj

    # dΣ_j = 1/2( -Σ_j^{-1} + Σ_j^{-1} Σ_hat Σ_j^{-1} - Σ_j^{-1}(μ_j-μ_hat)(μ_j-μ_hat)^T Σ_j^{-1} )
    vvT    = np.einsum("...i,...j->...ij", vj, vj, optimize=True)
    term   = np.einsum("...ij,...jk,...kl->...il", Sj_inv, S_hat, Sj_inv, optimize=True)
    dS_j   = 0.5 * (-Sj_inv + term - vvT)
    dS_j   = 0.5 * (dS_j + Rt(dS_j, -1, -2))

    # ---- optional mask ----
    if mask is not None:
        m = (np.asarray(mask) > 0).astype(np.float64, copy=False)
        dmu_j = dmu_j * m[..., None]
        dS_j  = dS_j  * m[..., None, None]

    return dmu_j.astype(np.float32, copy=False), dS_j.astype(np.float32, copy=False)





def grad_gamma_B_mu_sigma_i(
    *,
    Phi_i,                 # Φ_i : Q_i→P_i        (..., Kp, Kq)
    Om_ij,                 # Ω^q_{ij} : Q_j→Q_i   (..., Kq, Kq)
    mu_q_j, Sigma_q_j,     # sender q_j stats     (..., Kq), (..., Kq,Kq)
    mu_p_i, Sigma_p_i,     # receiver p_i stats   (..., Kp), (..., Kp,Kp)
    eps: float = 1e-8,
):
    """
    ∂/∂(μ_{p_i}, Σ_{p_i}) of KL_B = KL( p_i || Φ_i[Ω_ij q_j] ), all tensors passed in.
    Returns:
      gμ_p: (*S, Kp),  gΣ_p: (*S, Kp, Kp)
    """
    
    # ---- cast/sanitize once ----
    Phi_i     = np.asarray(Phi_i,     np.float64, order="C")   # (...,Kp,Kq)
    Om_ij     = np.asarray(Om_ij,     np.float64, order="C")   # (...,Kq,Kq)
    mu_q_j    = np.asarray(mu_q_j,    np.float64, order="C")   # (...,Kq)
    Sigma_q_j = sanitize_sigma(np.asarray(Sigma_q_j, np.float64), eps=eps)
    mu_p_i    = np.asarray(mu_p_i,    np.float64, order="C")   # (...,Kp)
    Sigma_p_i = sanitize_sigma(np.asarray(Sigma_p_i, np.float64), eps=eps)
    Rt = np.swapaxes

    # ---- 1) push q_j → Q_i via Ω_ij (trust input Σ_q_j already sanitized) ----
    mu_t, Sigma_t = push_gaussian(
        mu_q_j, Sigma_q_j, Om_ij,
        eps=eps, return_inv=False,
        Sigma_inv=None, assume_orthogonal=False,
        sanitize_input=False,
    )

    # ---- 2) land in P_i via Φ_i; get Σ_L^{-1} directly and sanitize landing ----
    mu_L, Sigma_L, S_L_inv = push_gaussian(
        mu_t, Sigma_t, Phi_i,
        eps=eps, return_inv=True,
        Sigma_inv=None, assume_orthogonal=False,
        sanitize_input=True,
    )

    # ---- KL( N(μ_p,Σ_p) || N(μ_L,Σ_L) ) source-form grads in P_i ----
    S_p_inv = safe_inv(Sigma_p_i, eps=max(eps, 1e-12))

    dmu   = mu_p_i - mu_L
    gmu_p = np.einsum("...ab,...b->...a", S_L_inv, dmu, optimize=True)      # Σ_L^{-1}(μ_p−μ_L)

    
    gS_p  = 0.5 * (S_L_inv - S_p_inv)

    gS_p  = 0.5 * (gS_p + Rt(gS_p, -1, -2))                                  # symmetrize

    return gmu_p.astype(np.float32, copy=False), gS_p.astype(np.float32, copy=False)



def grad_gamma_B_mu_sigma_j(
    mu_j, Sigma_j,                  # sender q_j stats (...,Kq), (...,Kq,Kq)
    mu_p_i, Sigma_p_i,              # receiver p_i stats (...,Kp), (...,Kp,Kp)  (KL's N0)
    Omega_ij, Phi_i,                # linear maps: Ω_ij (...,Kq,Kq), Φ_i (...,Kp,Kq)
    *,
    R=None,                         # optional precomputed R = Φ_i @ Ω_ij  (...,Kp,Kq)
    mu_1=None,                      # optional landing mean:  μ_1 = R μ_j  (...,Kp)
    Sigma_1=None,                   # optional landing cov:   Σ_1 = R Σ_j R^T (...,Kp,Kp)
    Sigma_1_inv=None,               # optional Σ_1^{-1}      (...,Kp,Kp)
    Sigma_p_inv=None,               # optional Σ_p_i^{-1}    (...,Kp,Kp)
    
    eps: float = 1e-8,
    assume_sanitized: bool = True,
):
    """
    Sender-side μ/Σ gradients for Case B gating:
        KL_B = KL( p_i || Φ_i[Ω_ij q_j] ).
    Returns (dμ_j, dΣ_j) in the *sender q_j* frame.
    Uses push_gaussian for the linear pushes and sanitizes only the landing Σ_1.
    """

    # ---- cast to float64 for stable math ----
    mu_j      = np.asarray(mu_j,      np.float64, order="C")
    Sigma_j   = np.asarray(Sigma_j,   np.float64, order="C")
    mu_p_i    = np.asarray(mu_p_i,    np.float64, order="C")
    Sigma_p_i = np.asarray(Sigma_p_i, np.float64, order="C")
    Phi_i     = np.asarray(Phi_i,     np.float64, order="C")   # (...,Kp,Kq)
    Omega_ij  = np.asarray(Omega_ij,  np.float64, order="C")   # (...,Kq,Kq)
    Rt = np.swapaxes

    # Optional input sanitation (usually already sanitized upstream)
    if not assume_sanitized:
        Sigma_j   = sanitize_sigma(Sigma_j,   eps=eps)
        Sigma_p_i = sanitize_sigma(Sigma_p_i, eps=eps)

    # ---- mapping matrix for chain rule ----
# ---- mapping matrix for chain rule ----
    if R is None:
        R = np.einsum("...ik,...kj->...ij", Phi_i, Omega_ij, optimize=True)
    

    R_T = Rt(R, -1, -2)

    # ---- landing stats (μ_1, Σ_1, Σ_1^{-1}) via push_gaussian ----
    if (mu_1 is None) or (Sigma_1 is None and Sigma_1_inv is None):
        # 1) q_j -> Q_i via Ω_ij (trust input Σ_j; no extra sanitization)
        mu_t, Sigma_t = push_gaussian(
            mu_j, Sigma_j, Omega_ij,
            eps=eps, return_inv=False,
            Sigma_inv=None, assume_orthogonal=False,
            sanitize_input=False,
        )
        # 2) Q_i -> P_i via Φ_i (sanitize landing; also get Σ_1^{-1})
        mu_1_calc, Sigma_1_calc, Sigma_1_inv_calc = push_gaussian(
            mu_t, Sigma_t, Phi_i,
            eps=eps, return_inv=True,
            Sigma_inv=None, assume_orthogonal=False,
            sanitize_input=True,
        )
        if mu_1 is None:          mu_1 = mu_1_calc
        if Sigma_1 is None:       Sigma_1 = Sigma_1_calc
        if Sigma_1_inv is None:   Sigma_1_inv = Sigma_1_inv_calc
    else:
        # Ensure provided landing tensors are arrays and sanitize/invert if needed
        mu_1    = np.asarray(mu_1,    np.float64, order="C")
        Sigma_1 = None if Sigma_1 is None else np.asarray(Sigma_1, np.float64, order="C")
        if Sigma_1_inv is None:
            S1 = sanitize_sigma(Sigma_1, eps=eps)
            Sigma_1_inv = safe_inv(S1, eps=max(eps, 1e-12))

    # ---- precompute Σ_p^{-1} if not provided ----
    if Sigma_p_inv is None:
        Sp = Sigma_p_i if assume_sanitized else sanitize_sigma(Sigma_p_i, eps=eps)
        Sigma_p_inv = safe_inv(Sp, eps=max(eps, 1e-12))

    # ---- landing-frame partials for KL(N0||N1) with N0=(μ_p,Σ_p), N1=(μ_1,Σ_1) ----
    # ∂KL/∂μ_1 = - Σ_1^{-1} (μ_p - μ_1)
    dmu_1 = -np.einsum("...ij,...j->...i", Sigma_1_inv, (mu_p_i - mu_1), optimize=True)

    # ∂KL/∂Σ_1 = 1/2 ( -Σ_1^{-1} + Σ_1^{-1} Σ_p Σ_1^{-1} )
    dS_1  = -Sigma_1_inv
    dS_1 += np.einsum("...ij,...jk,...kl->...il", Sigma_1_inv, Sigma_p_i, Sigma_1_inv, optimize=True)
    dS_1 *= 0.5
    dS_1  = 0.5 * (dS_1 + Rt(dS_1, -1, -2))  # symmetrize

    # ---- map back to sender frame (q_j) ----
    dmu_j = np.einsum("...ij,...j->...i", R_T, dmu_1, optimize=True)             # (...,Kq)
    dS_j  = np.einsum("...ik,...kl,...jl->...ij", R_T, dS_1, R, optimize=True)   # (...,Kq,Kq)
    dS_j  = 0.5 * (dS_j + Rt(dS_j, -1, -2))                                       # symmetrize


    return dmu_j.astype(np.float32, copy=False), dS_j.astype(np.float32, copy=False)


#==============================================================================
#
#                     PHI TERMS
#                       
#==============================================================================



def grad_kl_wrt_phi_i(
    mu_i, sigma_i,
    mu_j, sigma_j,                 
    phi_i, phi_j,                  
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,                        
    sigma_j_t_inv,                 
    eps=1e-8,
    exp_neg_phi_j=None,
    Q_all=None,
):
        
    # ---- cast to f64 for internal math ----
    mu_i   = np.asarray(mu_i,   np.float64)
    mu_j_t = np.asarray(mu_j_t, np.float64)

    Sigma_i = sanitize_sigma(np.asarray(sigma_i, np.float64), eps=eps)
   
    # Q_all → (..., a, K, K)
    if Q_all is None:
        Q_all = d_exp_exact(np.asarray(phi_i, np.float64), generators)
    
    Q = np.stack([np.asarray(x, np.float64) for x in Q_all], axis=-3)

    # exp(-phi_j) broadcast to Q lead dims
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(np.asarray(exp_phi_j, np.float64))
   
    # Ω and Ω^{-1}
    Om   = np.asarray(Omega_ij, np.float64)
    Oinv = safe_omega_inv(Om).astype(np.float64, copy=False)

    # Sanity on provided precision
    Sj_inv = np.asarray(sigma_j_t_inv, np.float64)
    
    Sj_inv = 0.5 * (Sj_inv + np.swapaxes(Sj_inv, -1, -2))
    
    # Core pieces
    delta_mu = (mu_i - mu_j_t)                     # (..., K)
    mu_j_src = np.einsum("...ij,...j->...i", Oinv, mu_j_t, optimize=True)  # (..., K)

    # dΩ/dφ_i^a = Q[a] @ e^{-φ_j}
    Q = np.einsum("...aik,...kj->...aij", Q, exp_neg_phi_j, optimize=True)
    Q_T = np.swapaxes(Q, -1, -2)
   
    # dΩ Ω^{-1}
    Q_tilde   = np.einsum("...aik,...kj->...aij", Q, Oinv, optimize=True)  
    Qtilde_T  = np.swapaxes(Q_tilde, -1, -2)
    
    # ---- precision (trace) term:  -1/2 * ⟨ A, Q̃ Σ_i + Σ_i Q̃^T ⟩
    t1 = np.einsum("...ij,...ajk,...ki->...a", Sj_inv, Q_tilde,  Sigma_i, optimize=True)
    t2 = np.einsum("...aij,...jk, ...ki->...a", Qtilde_T, Sj_inv, Sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)
    
    # mean term
    tmp1 = np.einsum("...aij,...j->...ai", Q_T,    delta_mu, optimize=True)
    tmp2 = np.einsum("...ij,...aj->...ai", Sj_inv, tmp1,     optimize=True)
    mean_term = -np.einsum("...i,...ai->...a", mu_j_src, tmp2, optimize=True)
    
    # ---- Mahalanobis (through ∂A) term: +1/2 * Δμ^T ( A Q̃ + Q̃^T A ) Δμ
    v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)          # A Δμ
    part1 = np.einsum("...aij,...j->...ai", Qtilde_T, v1, optimize=True)         # Q̃^T A Δμ
    v2    = np.einsum("...aij,...j->...ai", Q_tilde,  delta_mu, optimize=True)   # Q̃ Δμ
    part2 = np.einsum("...ij,...aj->...ai", Sj_inv,   v2, optimize=True)         # A Q̃ Δμ
    mahal_term = 0.5 * np.einsum("...i,...ai->...a", delta_mu, part1 + part2, optimize=True)

    grad = (trace_term + mean_term + mahal_term)

    return grad


def grad_kl_wrt_phi_j(
    mu_i, sigma_i,
    mu_j, sigma_j,                  # not used directly; kept for parity
    phi_i, phi_j,                   # not used directly here; we use exp(phi_*)
    Omega_ij,
    generators,
    exp_phi_i,
    exp_phi_j,
    mu_j_t,                         # μ_j' = Ω_ij μ_j
    sigma_j_t_inv,                  # Σ_j'^(-1) (already pushed)
    eps=1e-8,
    exp_neg_phi_j=None,
    R_all=None,                     # d exp(φ_j)/d φ_j^b (list/array of matrices); if None, we compute
):
    """
    ∂/∂φ_j KL(q_i || Ω_ij q_j). Mirrors grad_kl_wrt_phi_i but with:
      dΩ/dφ_j^b = - Ω  * ( R_j[b] @ e^{-φ_j} ).
    We work with U := dΩ and Ũ := (dΩ) Ω^{-1} = - Ω R̃ Ω^{-1}.
    """
    import numpy as np
    mu_i   = np.asarray(mu_i,   np.float64)
    mu_j_t = np.asarray(mu_j_t, np.float64)

    # sanitize Σ_i only once here
    Sigma_i = sanitize_sigma(np.asarray(sigma_i, np.float64), eps=eps)

    Om   = np.asarray(Omega_ij, np.float64)
    Oinv = safe_omega_inv(Om).astype(np.float64, copy=False)

    Sj_inv = np.asarray(sigma_j_t_inv, np.float64)
    Sj_inv = 0.5 * (Sj_inv + np.swapaxes(Sj_inv, -1, -2))

    # Δμ and μ_j in source coords
    delta_mu = (mu_i - mu_j_t)                                     # (..., K)
    mu_j_src = np.einsum("...ij,...j->...i", Oinv, mu_j_t, optimize=True)

    # exp(-φ_j)
    if exp_neg_phi_j is None:
        exp_neg_phi_j = safe_omega_inv(np.asarray(exp_phi_j, np.float64))

    # R_all: d exp(φ_j)/d φ_j^b  → stack as (..., b, K, K)
    if R_all is None:
        R_all = d_exp_exact(np.asarray(phi_j, np.float64), generators)
    R = np.stack([np.asarray(x, np.float64) for x in R_all], axis=-3)   # (..., b, K, K)

    # R̃_b = R_b @ e^{-φ_j}
    R_tilde = np.einsum("...bik,...kj->...bij", R, exp_neg_phi_j, optimize=True)  # (..., b, K, K)

    # U := dΩ = - Ω R̃ ;   U^T;  and Ũ := (dΩ) Ω^{-1} = - Ω R̃ Ω^{-1}
    U       = -np.einsum("...ik,...bkj->...bij", Om, R_tilde, optimize=True)      # (..., b, K, K)
    U_T     = np.swapaxes(U, -1, -2)
    U_tilde = -np.einsum("...ik,...bkj,...jl->...bil", Om, R_tilde, Oinv, optimize=True)
    Utilde_T= np.swapaxes(U_tilde, -1, -2)

    # -------- precision (trace) term:  -1/2 ⟨ A, Ũ Σ_i + Σ_i Ũ^T ⟩
    t1 = np.einsum("...ij,...bij,...jk->...b", Sj_inv, U_tilde, Sigma_i, optimize=True)
    t2 = np.einsum("...bij,...jk,...ki->...b", Utilde_T, Sj_inv, Sigma_i, optimize=True)
    trace_term = -0.5 * (t1 + t2)

    # -------- mean term (through dμ' = U μ_j_src)
    # tmp1_bi = U^T_bij Δμ_j'^j
    tmp1 = np.einsum("...bij,...j->...bi", U_T, delta_mu, optimize=True)
    # tmp2_bi = A_{ik} tmp1_bk
    tmp2 = np.einsum("...ij,...bj->...bi", Sj_inv, tmp1, optimize=True)
    mean_term = -np.einsum("...i,...bi->...b", mu_j_src, tmp2, optimize=True)

    # -------- Mahalanobis term: +1/2 Δμ^T ( A Ũ + Ũ^T A ) Δμ
    v1 = np.einsum("...ij,...j->...i", Sj_inv, delta_mu, optimize=True)            # A Δμ
    part1 = np.einsum("...bij,...j->...bi", Utilde_T, v1, optimize=True)           # Ũ^T A Δμ
    v2    = np.einsum("...bij,...j->...bi", U_tilde,  delta_mu, optimize=True)     # Ũ Δμ
    part2 = np.einsum("...ij,...bj->...bi", Sj_inv,   v2, optimize=True)           # A Ũ Δμ
    mahal_term = 0.5 * np.einsum("...i,...bi->...b", delta_mu, part1 + part2, optimize=True)

    grad = (trace_term + mean_term + mahal_term)    # (..., b)
    return grad




def grad_self_phi_direct(
    mu_q, sigma_q, mu_p, sigma_p, Phi_tilde_0,
    phi, phi_tilde, generators_q, generators_p,
    exp_phi, exp_phi_tilde, *,
    eps=1e-8,
    
    Phi_tilde=None,          # (H,W,K_q,K_p) from cache
    A_inv_cached=None,       # (H,W,K_q,K_q)  inverse of Φ̃ Σ_p Φ̃ᵀ
    mu_t_cached=None,        # (H,W,K_q)      Φ̃ μ_p
    Q_all=None,
    exp_neg_phi_tilde=None
):
    d, K_q, _ = generators_q.shape

    # Inverse of exp_phi_tilde if needed for dΦ̃
    if exp_neg_phi_tilde is None:
        #print("exp-phi~ is none\n\n\n")
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)

    # Derivative blocks (still need these)
    if Q_all is None:
        #print("q-all is none\n\n\n")
        Q_all = np.stack(d_exp_exact(phi, generators_q), axis=-3)  # (..., d, K_q, K_q)

    # Pull Φ̃ from cache (or build only if missing)
    if Phi_tilde is None:
        #print("Phi~ is none\n\n\n")
        Phi_tilde = np.einsum("...ik,...kj,...jl->...il",
                              exp_phi, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)

    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    # A^{-1} and Φ̃ μ_p: reuse when provided
    if (A_inv_cached is None) or (mu_t_cached is None):
        #print("pushes are none\n\n\n")
        mu_t, _, A_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
    else:
        mu_t, A_inv = mu_t_cached, A_inv_cached

    delta_mu = mu_q - mu_t

    # ∂Φ̃_a = Q_a Φ̃₀ e^{-φ̃}
    dPhi = np.einsum("...aik,...kj,...jl->...ail", Q_all, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA = dΦ̃ Σ_p Φ̃ᵀ + Φ̃ Σ_p dΦ̃ᵀ
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi,       sigma_p, Phi_tilde_T, optimize=True) +
        np.einsum("...ik, ...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T,      optimize=True)
    )

    # term1: - (∂Φ̃ μ_p)^T A^{-1} Δμ
    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p, optimize=True)
    term1 = -np.einsum("...ai,...i->...a",
                       dPhi_mu_p,
                       np.einsum("...ij,...j->...i", A_inv, delta_mu, optimize=True),
                       optimize=True)

    # term2: + 1/2 tr(A^{-1} dA)
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA, optimize=True)

    # M = A^{-1} dA A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv, optimize=True)

    # term3: - 1/2 Δμ^T M Δμ
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu, optimize=True)

    # term4: - 1/2 tr(M Σ_q)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q, optimize=True)

    return (term1 + term2 + term3 + term4).astype(np.float32, copy=False)




def grad_self_phi_tilde_direct(
    mu_q, sigma_q, mu_p, sigma_p, Phi_tilde_0,
    phi, phi_tilde, generators_q, generators_p,
    exp_phi, exp_phi_tilde, *,
    eps=1e-8,
    Phi_tilde=None,          # cached (S*,K_q,K_p)
    A_inv_cached=None,       # cached (S*,K_q,K_q)
    mu_t_cached=None,        # cached Φ̃ μ_p
    Q_tilde_all=None,
    exp_neg_phi_tilde=None
):
    d, K_p, _ = generators_p.shape

    if exp_neg_phi_tilde is None:
        #print("e^-phi~ is none\n\n\n")
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)

    if Q_tilde_all is None:
        #print("Q~-all is none\n\n\n")
        Q_tilde_all = np.stack(d_exp_exact(phi_tilde, generators_p), axis=-3)

    if Phi_tilde is None:
        #print("Phi~ is none\n\n\n")
        Phi_tilde = np.einsum("...ik,...kj,...jl->...il",
                              exp_phi, Phi_tilde_0, exp_neg_phi_tilde, optimize=True)
    Phi_tilde_T = np.swapaxes(Phi_tilde, -1, -2)

    if (A_inv_cached is None) or (mu_t_cached is None):
        mu_t, _, A_inv = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
    else:
        mu_t, A_inv = mu_t_cached, A_inv_cached

    delta_mu = mu_q - mu_t

    # R_a = Q̃_a e^{-φ̃}, dΦ̃_a = - Φ̃ R_a
    R    = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde, optimize=True)
    dPhi = -np.einsum("...ik,...akj->...aij", Phi_tilde, R, optimize=True)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi,       sigma_p, Phi_tilde_T, optimize=True) +
        np.einsum("...ik, ...kl,...alj->...aij", Phi_tilde, sigma_p, dPhi_T,      optimize=True)
    )

    dPhi_mu_p = np.einsum("...aij,...j->...ai", dPhi, mu_p, optimize=True)
    term1 = -np.einsum("...ai,...i->...a",
                       dPhi_mu_p,
                       np.einsum("...ij,...j->...i", A_inv, delta_mu, optimize=True),
                       optimize=True)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA, optimize=True)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv, optimize=True)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu, optimize=True)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_q, optimize=True)

    return (term1 + term2 + term3 + term4).astype(np.float32, copy=False)







def grad_feedback_phi_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi,                # (..., d)
    phi_tilde,          # (..., d)
    generators_q,       # (d, K_q, K_q)
    generators_p,
    exp_phi,            # (..., K_q, K_q)
    exp_phi_tilde,      # (..., K_p, K_p)
    eps=1e-8,
    Q_all=None,         # (..., d, K_q, K_q) = d_exp_exact(phi, generators_q)
    exp_neg_phi=None    # (..., K_q, K_q) = e^{-φ}
):
    """
    Vectorized over 'a': returns (..., d)
    Φ = e^{φ̃} Φ₀ e^{-φ}, ∂Φ = - Φ · (e^{-φ} (∂ e^{φ}) e^{-φ})
    """
    
    d, K_q, _ = generators_q.shape

    if exp_neg_phi is None:
        exp_neg_phi = safe_omega_inv(exp_phi)
    if Q_all is None:
        # stack as (..., d, K_q, K_q)
        Q_list = d_exp_exact(phi, generators_q)
        Q_all = np.stack(Q_list, axis=-3)  # assuming list of d arrays

    # Φ and Φᵀ
    Phi = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    # A, A^{-1}
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    # Δμ and v
    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)  # (..., K_p)

    # Q̄_a = e^{-φ} Q_a e^{-φ}
    Q_bar = np.einsum("...ik,...akl,...lj->...aij", exp_neg_phi, Q_all, exp_neg_phi)

    # dΦ_a = - Φ Q̄_a
    dPhi = -np.einsum("...ik,...akj->...aij", Phi, Q_bar)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    # dA_a
    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    # Term 1
    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)       # (..., a, K_p)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    # Term 2
    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    # M_a = A^{-1} dA_a A^{-1}
    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    # Term 3
    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)

    # Term 4
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = (term1 + term2 + term3 + term4).astype(np.float32, copy=False)
    return grad




def grad_feedback_phi_tilde_direct(
    mu_p, sigma_p,
    mu_q, sigma_q,
    Phi_0,
    phi, 
    phi_tilde,
    generators_q, 
    generators_p,
    exp_phi, 
    exp_phi_tilde,
    eps=1e-8,
    Q_tilde_all=None,       # (..., d, K_p, K_p) = d_exp_exact(phi_tilde, generators_p)
    exp_neg_phi_tilde=None  # (..., K_p, K_p) = e^{-φ̃}
):
    """
    Vectorized over 'a': returns (..., d)
    Left-trivialize: dΦ_a = L_a Φ,  L_a = (∂e^{φ̃}/∂φ̃^a) e^{-φ̃}.
    """
    
    d, K_p, _ = generators_p.shape
    
    if exp_neg_phi_tilde is None:
        exp_neg_phi_tilde = safe_omega_inv(exp_phi_tilde)
    if Q_tilde_all is None:
        Q_list = d_exp_exact(phi_tilde, generators_p)
        Q_tilde_all = np.stack(Q_list, axis=-3)

    # Φ
    exp_neg_phi = safe_omega_inv(exp_phi)
    Phi   = np.einsum("...ik,...kj,...jl->...il", exp_phi_tilde, Phi_0, exp_neg_phi)
    Phi_T = np.swapaxes(Phi, -1, -2)

    
    A = np.einsum("...ik,...kl,...lj->...ij", Phi, sigma_q, Phi_T)
    A = sanitize_sigma(A, eps=eps)
    A_inv = safe_inv(A, eps=eps)

    Phi_mu_q = np.einsum("...ij,...j->...i", Phi, mu_q)
    delta_mu = mu_p - Phi_mu_q
    v = np.einsum("...ij,...j->...i", A_inv, delta_mu)

    # L_a = Q̃_a e^{-φ̃}
    L = np.einsum("...aik,...kj->...aij", Q_tilde_all, exp_neg_phi_tilde)

    # dΦ_a = L_a Φ
    dPhi = np.einsum("...aik,...kj->...aij", L, Phi)
    dPhi_T = np.swapaxes(dPhi, -1, -2)

    dA = (
        np.einsum("...aik,...kl,...lj->...aij", dPhi, sigma_q, Phi_T) +
        np.einsum("...ik,...kl,...alj->...aij", Phi,  sigma_q, dPhi_T)
    )

    dPhi_mu = np.einsum("...aij,...j->...ai", dPhi, mu_q)
    term1 = -np.einsum("...ai,...i->...a", dPhi_mu, v)

    term2 = 0.5 * np.einsum("...ij,...aij->...a", A_inv, dA)

    M = np.einsum("...ij,...ajk,...kl->...ail", A_inv, dA, A_inv)

    term3 = -0.5 * np.einsum("...i,...aij,...j->...a", delta_mu, M, delta_mu)
    term4 = -0.5 * np.einsum("...aij,...ji->...a", M, sigma_p)

    grad = term1 + term2 + term3 + term4
    return grad




def grad_gamma_A_phi_covectors(
    *,
    Eqi, Eqj, Epi,
    mu_q_j, Sigma_q_j,
    mu_p_i, Sigma_p_i,
    generators_irrep,
    eps: float = 1e-8,
    orthonormalize: bool = True,
    **_ignored,
):
    """
    Case A (dual): KL_gamma = KL( q_j || Ω^q_{ji} Φ̃_i p_i )  in Q_j.
    Using frame factorization R = Eq(j) @ Ep(i)^T.
    Returns (g_phi_i_q_cov, g_phi_j_q_cov, g_phi_i_p_cov) each (*S,3).
    """
   
    # -------------------------------------------------------------------------
    # Exact factorization for Case B:
    # Φ_i = E_p(i) E_q(i)^T,  Ω_ij = E_q(i) E_q(j)^T  ⇒  R = Φ_i Ω_ij = E_p(i) E_q(j)^T
    # Landing in P_i:  μ_L = R μ_j,  Σ_L = R Σ_j R^T
    # KL: KL( N(μ_p,Σ_p) || N(μ_L,Σ_L) )
    # Target-form partials:
    #   v = Σ_L^{-1}(μ_p - μ_L)
    #   ∂KL/∂μ_L = -v
    #   ∂KL/∂Σ_L = 1/2( -Σ_L^{-1} Σ_p Σ_L^{-1} - v v^T + Σ_L^{-1} )
    # Chain rule:
    #   ∂KL/∂R = (∂KL/∂μ_L) μ_j^T + 2 (∂KL/∂Σ_L) R Σ_j
    # Split:
    #   dR = dE_p E_q(j)^T + E_p dE_q(j)^T  ⇒
    #   <G_R, dR> = <G_R E_q(j), dE_p> + <G_R^T E_p, dE_q(j)> ;  G_Eq(i) = 0 exactly.
    # -------------------------------------------------------------------------

    # float64 for stability
    Eqi = np.asarray(Eqi, np.float64, order="C")
    Eqj = np.asarray(Eqj, np.float64, order="C")
    Epi = np.asarray(Epi, np.float64, order="C")
    mu_j = np.asarray(mu_q_j,    np.float64, order="C")
    Sj   = sanitize_sigma(np.asarray(Sigma_q_j, np.float64), eps=eps)
    mu_p = np.asarray(mu_p_i,    np.float64, order="C")
    Sp   = sanitize_sigma(np.asarray(Sigma_p_i, np.float64), eps=eps)

    if orthonormalize:
        # push frames gently back to O(K) to better match ctx Ω/Φ path
        U, _, Vt = np.linalg.svd(Eqj, full_matrices=False);  Eqj = np.einsum("...ik,...kj->...ij", U, Vt, optimize=True)
        U, _, Vt = np.linalg.svd(Epi, full_matrices=False);  Epi = np.einsum("...ik,...kj->...ij", U, Vt, optimize=True)

    Rt = np.swapaxes

    # R = Eq(j) Ep(i)^T : (*S, Kq, Kp)
    R = np.einsum("...ik,...jk->...ij", Eqj, Rt(Epi, -1, -2), optimize=True)

    # Landed in Q_j
    mu_Q = np.einsum("...ij,...j->...i", R, mu_p, optimize=True)                       # (*S,Kq)
    S_Q  = np.einsum("...ij,...jk,...lk->...il", R, Sp, R, optimize=True)              # R Σ_p R^T
    S_Q  = sanitize_sigma(S_Q, eps=eps)
    S_Qi = safe_inv(S_Q, eps=max(eps, 1e-12))

    # KL(P||Q): P=N(mu_j,Sj), Q=N(mu_Q,S_Q)
    d     = mu_Q - mu_j
    v     = np.einsum("...ij,...j->...i", S_Qi, d, optimize=True)   # = dmuQ
    vvT   = np.einsum("...i,...j->...ij", v, v, optimize=True)
    term  = np.einsum("...ij,...jk->...ik", S_Qi,
                      np.einsum("...jk,...kl->...jl", Sj, S_Qi, optimize=True),
                      optimize=True)
    dSQ   = 0.5 * (-term - vvT + S_Qi)
    dSQ   = 0.5 * (dSQ + Rt(dSQ, -1, -2))

    # ∂KL/∂R
    G_R  = (np.einsum("...i,...j->...ij", v, mu_p, optimize=True)
            + 2.0 * np.einsum("...ij,...jk,...kl->...il", dSQ, R, Sp, optimize=True))  # (*S,Kq,Kp)

    # Split co-grads
    G_Eqj = np.einsum("...ij,...jk->...ik", G_R, Epi, optimize=True)                   # (*S,Kq,Kq)
    G_Epi = np.einsum("...ji,...jk->...ik", Rt(G_R, -1, -2), Eqj, optimize=True)       # (*S,Kp,Kp)
    G_Eqi = np.zeros_like(Eqi, dtype=np.float64)

    # Mat co-grads → parameter covectors
    g_phi_i_q_cov = matrix_cograd_to_param_covector_irrep(Eqi, G_Eqi, generators_irrep)  # zeros
    g_phi_j_q_cov = matrix_cograd_to_param_covector_irrep(Eqj, G_Eqj, generators_irrep)
    g_phi_i_p_cov = matrix_cograd_to_param_covector_irrep(Epi, G_Epi, generators_irrep)

    return (np.asarray(g_phi_i_q_cov, np.float32, order="C"),
            np.asarray(g_phi_j_q_cov, np.float32, order="C"),
            np.asarray(g_phi_i_p_cov, np.float32, order="C"))



def grad_gamma_B_phi_covectors(
    *,
    Eqi, Eqj, Epi,
    mu_p_i, Sigma_p_i,
    mu_q_j, Sigma_q_j,
    generators_irrep,
    eps: float = 1e-8,
    orthonormalize: bool = True,
    **_ignored,
):
    """
    Case B (P_i): KL_gamma = KL( p_i || Φ_i[Ω^q_ij q_j] )
    Using frame factorization R = E_p(i) @ E_q(j)^T.
    Returns (g_phi_i_q_cov, g_phi_j_q_cov, g_phi_i_p_cov) each (*S,3).
    """
    
    Eqi = np.asarray(Eqi, np.float64, order="C")
    Eqj = np.asarray(Eqj, np.float64, order="C")
    Epi = np.asarray(Epi, np.float64, order="C")
    mu_p = np.asarray(mu_p_i,    np.float64, order="C")
    Sp   = sanitize_sigma(np.asarray(Sigma_p_i, np.float64), eps=eps)
    mu_j = np.asarray(mu_q_j,    np.float64, order="C")
    Sj   = sanitize_sigma(np.asarray(Sigma_q_j, np.float64), eps=eps)

    if orthonormalize:
        U, _, Vt = np.linalg.svd(Eqj, full_matrices=False);  Eqj = np.einsum("...ik,...kj->...ij", U, Vt, optimize=True)
        U, _, Vt = np.linalg.svd(Epi, full_matrices=False);  Epi = np.einsum("...ik,...kj->...ij", U, Vt, optimize=True)

    Rt = np.swapaxes

    # R = E_p(i) @ E_q(j)^T : (*S, Kp, Kq)
    R = np.einsum("...ik,...jk->...ij", Epi, Rt(Eqj, -1, -2), optimize=True)

    # Landed in P_i
    mu_L = np.einsum("...ij,...j->...i", R, mu_j, optimize=True)

    RS   = np.einsum("...ij,...jk->...ik", R, Sj, optimize=True)
    S_L  = np.einsum("...ik,...jk->...ij", RS, R, optimize=True)   # R Σ_j R^T
    S_L  = 0.5 * (S_L + Rt(S_L, -1, -2))
    S_L  = sanitize_sigma(S_L, eps=eps)
    S_L_inv = safe_inv(S_L, eps=max(eps, 1e-12))

    # Target-form partials
    delta = (mu_p - mu_L)
    v     = np.einsum("...ij,...j->...i", S_L_inv, delta, optimize=True)
    dmuL  = -v

    vvT   = np.einsum("...i,...j->...ij", v, v, optimize=True)
    t0    = -np.einsum("...ij,...jk,...kl->...il", S_L_inv, Sp, S_L_inv, optimize=True)
    dSL   = 0.5 * (t0 - vvT + S_L_inv)
    dSL   = 0.5 * (dSL + Rt(dSL, -1, -2))

    # ∂KL/∂R
    G_R = (np.einsum("...i,...j->...ij", dmuL, mu_j, optimize=True)
           + 2.0 * np.einsum("...ij,...jk,...kl->...il", dSL, R, Sj, optimize=True))

    # Split
    G_Epi = np.einsum("...ij,...jk->...ik", G_R, Eqj, optimize=True)                 # (*,Kp,Kp)
    G_Eqj = np.einsum("...ji,...jk->...ik", Rt(G_R, -1, -2), Epi, optimize=True)     # (*,Kq,Kq)
    G_Eqi = np.zeros_like(Eqi, dtype=np.float64)                                     # exact 0

    # To parameter covectors
    g_phi_i_q_cov = matrix_cograd_to_param_covector_irrep(Eqi, G_Eqi, generators_irrep)  # zeros
    g_phi_j_q_cov = matrix_cograd_to_param_covector_irrep(Eqj, G_Eqj, generators_irrep)
    g_phi_i_p_cov = matrix_cograd_to_param_covector_irrep(Epi, G_Epi, generators_irrep)

    return (np.asarray(g_phi_i_q_cov, np.float32, order="C"),
            np.asarray(g_phi_j_q_cov, np.float32, order="C"),
            np.asarray(g_phi_i_p_cov, np.float32, order="C"))





