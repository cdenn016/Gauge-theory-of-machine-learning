# alignment_metrics.py
"""
Compute alignment metrics for agents in SO(3) Suite.

Uses geometrically correct KL divergence on fiber distributions:
- Belief alignment: KL(q_i || Ω_ij q_j) on SO(3) fibers
- Model alignment: KL(q_i || p_i) between belief and model

This respects the bundle geometry and parallel transport structure.

Uses existing numerical_utils functions:
- kl_gaussian() for KL divergence computation
- push_gaussian() for parallel transport of distributions

Usage in your simulation loop:
    from alignment_metrics import compute_belief_alignment, compute_model_alignment
    
    for step in range(steps):
        # ... update agents ...
        
        for agent in agents:
            # Belief alignment (KL-based)
            belief_align = compute_belief_alignment(agent, agents, ctx)
            
            # Model alignment (KL-based)
            model_align = compute_model_alignment(agent)
            
            # Log to metrics_viz
            mv.log_agent(step, agent.id, {
                "belief_alignment_kl": belief_align,        # Lower = better alignment
                "model_alignment_kl": model_align,          # Lower = better fit
                # ... other metrics ...
            })
        
        mv.maybe_plot(step)  # Will auto-generate alignment plots
"""
# --- at top of alignments.py ---
from agents.agent_accessor import AgentAccessor as AA
import numpy as np
from typing import List, Any, Optional
from core.numerical_utils import kl_gaussian, push_gaussian




def compute_belief_alignment(
    agent: Any,
    all_agents: List[Any],
    ctx: Any,
    *,
    method: str = "mean",
    eps: float = 1e-8
) -> float:
    """KL(q_i || Ω_ij q_j) aggregated over neighbors."""
    try:
        mu_i = AA.get_mu_q(agent)           # (*S, Kq) float32
        Sig_i = AA.get_sigma_q(agent)       # (*S, Kq, Kq) float64 (sanitized)
    except Exception:
        return np.inf

    neighbors = _find_neighbors(agent, all_agents, ctx=ctx)
    if not neighbors:
        return np.inf

    kl_divs = []
    for nb in neighbors:
        try:
            mu_j = AA.get_mu_q(nb)
            Sig_j = AA.get_sigma_q(nb)
        except Exception:
            continue

        # Ω_ij
        omega_ij = _get_parallel_transport(agent, nb, ctx)
        if omega_ij is None:
            continue
        omega_ij = np.asarray(omega_ij, np.float32)

        # push neighbor q_j to i-frame
        try:
            mu_j_T, Sig_j_T = push_gaussian(mu_j, Sig_j, omega_ij, eps=eps)
        except Exception:
            continue

        # KL(q_i || Ω_ij q_j)
        try:
            kl = kl_gaussian(mu_i, Sig_i, mu_j_T, Sig_j_T, eps=eps)
            kl = float(kl) if np.isscalar(kl) else float(np.mean(np.asarray(kl)))
            if np.isfinite(kl) and kl >= 0:
                kl_divs.append(kl)
        except Exception:
            continue

    if not kl_divs:
        return np.inf
    return float(np.min(kl_divs) if method == "min" else np.mean(kl_divs))



def compute_model_alignment(
    agent: Any,
    all_agents: List[Any],
    ctx: Any,
    *,
    method: str = "mean",
    eps: float = 1e-8
) -> float:
    """KL(p_i || Ω_ij p_j) aggregated over neighbors."""
    try:
        mu_i = AA.get_mu_p(agent)           # (*S, Kq) float32
        Sig_i = AA.get_sigma_p(agent)       # (*S, Kq, Kq) float64 (sanitized)
    except Exception:
        return np.inf

    neighbors = _find_neighbors(agent, all_agents, ctx=ctx)
    if not neighbors:
        return np.inf

    kl_divs = []
    for nb in neighbors:
        try:
            mu_j = AA.get_mu_p(nb)
            Sig_j = AA.get_sigma_p(nb)
        except Exception:
            continue

        # Ω_ij
        omega_ij = _get_parallel_transport(agent, nb, ctx)
        if omega_ij is None:
            continue
        omega_ij = np.asarray(omega_ij, np.float32)

        # push neighbor q_j to i-frame
        try:
            mu_j_T, Sig_j_T = push_gaussian(mu_j, Sig_j, omega_ij, eps=eps)
        except Exception:
            continue

        # KL(q_i || Ω_ij q_j)
        try:
            kl = kl_gaussian(mu_i, Sig_i, mu_j_T, Sig_j_T, eps=eps)
            kl = float(kl) if np.isscalar(kl) else float(np.mean(np.asarray(kl)))
            if np.isfinite(kl) and kl >= 0:
                kl_divs.append(kl)
        except Exception:
            continue

    if not kl_divs:
        return np.inf
    return float(np.min(kl_divs) if method == "min" else np.mean(kl_divs))


def compute_self_alignment(agent: Any, eps: float = 1e-8) -> float:
    """KL(q_i || p_i) per agent."""
    try:
        mu_q = AA.get_mu_q(agent)
        Sig_q = AA.get_sigma_q(agent)
        mu_p = AA.get_mu_p(agent)
        Sig_p = AA.get_sigma_p(agent)
    except Exception:
        return np.inf

    try:
        kl = kl_gaussian(mu_q, Sig_q, mu_p, Sig_p, eps=eps)
        return float(kl) if np.isscalar(kl) else float(np.mean(np.asarray(kl)))
    except Exception:
        return np.inf





def _get_parallel_transport(agent_i: Any, agent_j: Any, ctx: Any) -> Optional[np.ndarray]:
    """
    Get parallel transport operator Ω_ij from agent j to agent i.
    
    Works with your existing transport infrastructure:
    - EdgeMaps structure
    - transport_cache (Omega class)
    - Fallback to identity if not available
    
    Args:
        agent_i: Target agent
        agent_j: Source agent
        ctx: Runtime context with transport cache
    
    Returns:
        Ω_ij matrix (d×d), or None if not available
    """
    from core.transport_cache import Omega
    
    
    # Try to get agent IDs
    try:
        i_id = getattr(agent_i, 'id', None)
        j_id = getattr(agent_j, 'id', None)
        
        if i_id is None or j_id is None:
            return None
    except Exception:
        return None
    
    # Method 1: Use EdgeMaps if available
    if hasattr(ctx, 'edge') and ctx.edge is not None:
        try:
            # EdgeMaps stores Ω for each fiber type
            # Try 'q' fiber first (belief)
            omega_q = ctx.edge.get_omega('q', i_id, j_id)
            if omega_q is not None:
                return np.asarray(omega_q, dtype=np.float32)
        except Exception:
            pass
    
    # Method 2: Use transport_cache directly
    try:
        # Get agent phi values for transport lookup
        phi_i = getattr(agent_i, 'phi', None)
        phi_j = getattr(agent_j, 'phi', None)
        
        if phi_i is not None and phi_j is not None:
            # Use Omega class from transport_cache
            omega_ij = Omega(ctx, 'q', i_id, j_id, phi_i, phi_j)
            if omega_ij is not None:
                return np.asarray(omega_ij, dtype=np.float32)
    except Exception:
        pass
    
    # Method 3: Check if agents have precomputed edge_maps
    if hasattr(agent_i, 'edge_maps') and agent_i.edge_maps is not None:
        omega = agent_i.edge_maps.get(j_id)
        if omega is not None:
            return np.asarray(omega, dtype=np.float32)
    
    # Method 4: Fallback - identity matrix (small angle approximation)
    # This allows the code to run even without full transport infrastructure
    if hasattr(agent_i, 'mu_q_field') and agent_i.mu_q_field is not None:
        mu_i = np.asarray(agent_i.mu_q_field, dtype=np.float32)
        d = mu_i.shape[-1] if mu_i.ndim >= 1 else 3
        return np.eye(d, dtype=np.float32)
    
    return None


def compute_mean_field_alignment(agent: Any, ctx: Any) -> float:
    """
    Compute KL divergence between agent's distribution and global mean field.
    
    Args:
        agent: Agent with mu_q, sigma_q attributes
        ctx: Runtime context with mean field distributions
    
    Returns:
        KL(q_i || q_mean) where q_mean is global mean distribution
    """
    if not hasattr(agent, 'mu_q_field') or agent.mu_q_field is None:
        return np.inf
    
    mu_i = np.asarray(agent.mu_q_field, dtype=np.float64).flatten()
    
    if hasattr(agent, 'sigma_q_field') and agent.sigma_q_field is not None:
        sigma_i = np.asarray(agent.sigma_q_field, dtype=np.float64)
        if sigma_i.ndim == 1:
            sigma_i = np.diag(sigma_i)
    else:
        d = len(mu_i)
        sigma_i = np.eye(d) * 0.1
    
    # Get global mean field
    mu_mean = None
    sigma_mean = None
    
    if hasattr(ctx, 'mu_q_mean') and ctx.mu_q_mean is not None:
        mu_mean = np.asarray(ctx.mu_q_mean, dtype=np.float64).flatten()
    
    if hasattr(ctx, 'sigma_q_mean') and ctx.sigma_q_mean is not None:
        sigma_mean = np.asarray(ctx.sigma_q_mean, dtype=np.float64)
        if sigma_mean.ndim == 1:
            sigma_mean = np.diag(sigma_mean)
    
    if mu_mean is None:
        return np.inf
    
    if sigma_mean is None:
        d = len(mu_mean)
        sigma_mean = np.eye(d) * 0.1
    
    return kl_gaussian(mu_i, sigma_i, mu_mean, sigma_mean)


def compute_all_alignments(
    agent: Any,
    all_agents: List[Any],
    ctx: Any
) -> dict:
    """
    Compute all alignment metrics for an agent using KL divergence.
    
    Returns:
        Dictionary with KL-based alignment metrics ready for logging.
        Lower values = better alignment.
    """
    return {
        "belief_alignment_kl": compute_belief_alignment(agent, all_agents, ctx),
        "self_alignment_kl": compute_self_alignment(agent),
        "mean_field_alignment_kl": compute_mean_field_alignment(agent, ctx),
    }



def _find_neighbors(agent_i, agents, *, ctx=None, dedup=True, exclude_self=True, min_overlap_frac=0.01):
    """
    Resolve neighbors:
      1) If agent_i.neighbors provided, accept dicts with 'id' or 'agent_id', or raw ints.
      2) Else, fall back to spatial overlap using masks (≥ min_overlap_frac of i's support).
    """
    # Normalize agent lookup
    if isinstance(agents, dict):
        lookup = {int(k): v for k, v in agents.items()}
        agent_list = list(lookup.values())
    else:
        agent_list = list(agents)
        lookup = {int(getattr(a, "id", i)): a for i, a in enumerate(agent_list)}

    out, seen = [], set()
    self_id = int(getattr(agent_i, "id", -1))
    raw = (getattr(agent_i, "neighbors", []) or [])

    # (1) Explicit list
    for nb in raw:
        try:
            if isinstance(nb, dict):
                j = int(nb.get("id", nb.get("agent_id")))
            else:
                j = int(nb)
        except Exception:
            continue
        if exclude_self and j == self_id:
            continue
        if dedup and j in seen:
            continue
        a = lookup.get(j)
        if a is not None:
            out.append(a)
            if dedup:
                seen.add(j)

    if out:
        return out

    # (2) Overlap fallback (mask-based)
    try:
        mask_i = AA.get_mask(agent_i)  # bool
        area_i = float(mask_i.sum())
        if area_i <= 0:
            return out
        thresh = max(1.0, min_overlap_frac * area_i)
        for a in agent_list:
            if a is agent_i:
                continue
            try:
                mask_j = AA.get_mask(a)
                inter = float((mask_i & mask_j).sum())
                if inter >= thresh:
                    j_id = int(getattr(a, "id", -1))
                    if not (exclude_self and j_id == self_id):
                        if not (dedup and j_id in seen):
                            out.append(a)
                            if dedup:
                                seen.add(j_id)
            except Exception:
                continue
    except Exception:
        pass

    return out





# ═══════════════════════════════════════════════════════════════════════════
# Integration Example
# ═══════════════════════════════════════════════════════════════════════════

def example_integration_in_simulation():
    """
    Example showing how to integrate alignment metrics into your simulation.
    """
    from pathlib import Path
    from metrics_viz import MetricsViz, VizConfig
    
    # Setup
    cfg = VizConfig(
        outdir=Path("output"),
        run_name="alignment_test",
        enable_plots=True,
        plot_every_steps=10
    )
    mv = MetricsViz(cfg)
    mv.start_run(meta={"test": "alignment_visualization"})
    
    # Simulation loop
    agents = []  # Your agent list
    ctx = None   # Your runtime context
    
    for step in range(1000):
        # ... update agent states ...
        
        # Log metrics with alignment
        for agent in agents:
            # Compute alignments
            alignments = compute_all_alignments(agent, agents, ctx)
            
            # Log to metrics_viz
            mv.log_agent(step, agent.id, {
                **alignments,  # phi_alignment, phi_model_alignment, etc.
                "E_self": agent.energy,
                "phi_norm_mean": np.linalg.norm(agent.phi),
                # ... other metrics ...
            })
        
        # Generate plots (including alignment bar charts)
        mv.maybe_plot(step)
    
    mv.end_run()
    
    # Result: Two new plots will be automatically generated:
    # - plots/agent_belief_alignments.png     (φ with neighbors)
    # - plots/agent_model_alignments.png      (φ̃ with φ)


# ═══════════════════════════════════════════════════════════════════════════
# Advanced: Alignment Evolution Over Time
# ═══════════════════════════════════════════════════════════════════════════

def compute_alignment_timeseries(agent_rows: List[dict]) -> dict:
    """
    Extract alignment evolution for each agent.
    
    Args:
        agent_rows: List of logged agent metrics
    
    Returns:
        Dict mapping agent_id -> (steps, alignments)
    """
    from collections import defaultdict
    
    alignments_by_agent = defaultdict(lambda: {"steps": [], "belief": [], "model": []})
    
    for row in agent_rows:
        agent_id = row.get("agent")
        step = row.get("step")
        
        if agent_id is None or step is None:
            continue
        
        alignments_by_agent[agent_id]["steps"].append(step)
        alignments_by_agent[agent_id]["belief"].append(
            row.get("phi_alignment", np.nan)
        )
        alignments_by_agent[agent_id]["model"].append(
            row.get("phi_model_alignment", np.nan)
        )
    
    return dict(alignments_by_agent)


if __name__ == "__main__":
    # Run example
    print("Alignment metrics module loaded.")
    print("Use compute_belief_alignment() and compute_model_alignment() in your simulation.")
    print("MetricsViz will automatically generate bar charts of alignments!")