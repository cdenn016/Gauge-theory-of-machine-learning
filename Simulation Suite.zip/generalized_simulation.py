import config
import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
import sys
ROOT = os.path.dirname(os.path.abspath(__file__))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from pathlib import Path
import sys, shutil, numpy as np
from contextlib import contextmanager
from time import perf_counter

from core.induced_connection import initialize_A_from_attention
from core.runtime_context import cfg_set_override, ensure_shared_cache_attached
from core.get_generators import casimir_scalar
from core.runtime_context import ensure_runtime_defaults, cfg_get 
from core.shared_cache import SharedDiskCache
from core.utils import ( mean_norm, prepare_generators, initialize_or_resume,
    log_and_viz_after_step, wrap_epilogue, save_step )

from updates.update_rules import synchronous_step
from updates.update_terms_curvature_A import ensure_global_A

from diagnostics import ( compute_total_action, print_action_breakdown, save_all_series_npz,
                          compute_global_metrics, log_phi_vectors, log_mu_vectors           )
from metrics_viz import VizConfig, MetricsViz, plot_beta_map

from alignments import compute_belief_alignment, compute_self_alignment, compute_model_alignment
from MV_enhanced import setup_professional_metrics_viz
# ============================================================================
# NEW: PHASE 1&2 VALIDATION IMPORTS
# ============================================================================
from tests_and_stability.energy_budget import EnergyBudget
from tests_and_stability.stability_monitor import StabilityMonitor


@contextmanager
def section_timer(ctx, name, step=None):
    """
    Simple wall-clock timer. Prints and records duration into ctx.timings.
    step: optional step index (int) for per-step timings.
    """
    t0 = perf_counter()
    try:
        yield
    finally:
        dt = perf_counter() - t0
        # Record
        ts = getattr(ctx, "timings", None)
        if ts is None:
            ctx.timings = {}
            ts = ctx.timings
        bucket = "init" if step is None else f"step_{int(step)}"
        ts.setdefault(bucket, []).append((name, dt))
        # Print
        where = f"[t:{bucket}]"
        print(f"{where} {name}: {dt:.3f}s")

def _dt_ms(dt):
    return f"{dt*1000.0:.1f} ms"


def post_step_io(
    runtime_ctx,
    agents,
    metrics,           # precomputed from run_one_step
    action,            # precomputed from run_one_step
    step: int,
    outdir: str,
    mv,                # MetricsViz instance
    parent_metrics: list,
    metric_log: list,
):
    """
    All step side effects in one place:
      - print breakdown
      - run existing log/viz helper
      - log global & per-agent rows
      - flush/plot/snapshot
      - save checkpoint
      - NEW: energy budget tracking
      - NEW: stability monitoring

    Pure consumers: relies ONLY on inputs; no recomputation of metrics/action.
    """
    
    # 1) console output
    print_action_breakdown(runtime_ctx, action)

    # 2) reuse your consolidated logger/plotter (keeps previous behavior)
    log_and_viz_after_step(
        runtime_ctx, agents, step, outdir,
        parent_metrics, metric_log,
        getattr(runtime_ctx, "config", {}).get("n_jobs", 1),
        precomputed_metrics=metrics,
        precomputed_Q=action,
    )

    # 3) global row (reuse precomputed values)
    E_tot = action.get("Action_total", np.nan)
    gmetrics = {
        "E_total": float(E_tot) if np.isfinite(E_tot) else np.nan,
        "mean_total": float(metrics.get("mean_total", np.nan)),
        **action,  # includes Geom_total, A_curv, A_cov, align*, gamma*, etc.
    }
    mv.log_global(step, gmetrics)

    for a in agents:
        aid = int(a.id)
    
         
        # --- norms over full fields (averaged over mask / region) ---
        phi_norm_mean       = mean_norm(getattr(a, "phi", None))
        phi_model_norm_mean = mean_norm(getattr(a, "phi_model", None))
        mu_q_norm_mean      = mean_norm(getattr(a, "mu_q_field", None))
        mu_p_norm_mean      = mean_norm(getattr(a, "mu_p_field", None))
    
        # --- NEW: center μ_q diagnostics using full K-dim vector ---
        mu_logs = getattr(runtime_ctx, "_mu_logs", {})
        rec = mu_logs.get(aid, None)
    
        if rec is not None and len(rec.get("mu_q_full", [])) > 0:
            mu_q_center_vec = np.asarray(rec["mu_q_full"][-1], dtype=np.float32)
            muq_norm_center = float(np.linalg.norm(mu_q_center_vec, ord=2))
    
            # grab first few components just for plotting inspectability
            # (don't call them x/y/z anymore; they're just indices in rep space)
            dims_to_log = min(4, mu_q_center_vec.shape[0])
            comp_values = [float(mu_q_center_vec[i]) for i in range(dims_to_log)]
        else:
            mu_q_center_vec = None
            muq_norm_center = float("nan")
            comp_values = []
    
       
        mv.log_agent(step, aid, {
          
            # field norms (optional to plot later)
             "phi_norm_mean":       phi_norm_mean,
             "phi_model_norm_mean": phi_model_norm_mean,
             "mu_q_norm_mean":      mu_q_norm_mean,
             "mu_p_norm_mean":      mu_p_norm_mean,
    
            # center μ_q diagnostics
            "mu_q_center_norm":    muq_norm_center,  # <-- this is the one you care about scientifically
    
        
        })

    # 5) plots + snapshots (cadence inside MetricsViz)
    mv.maybe_flush(step)
    mv.maybe_plot(step)
    mv.maybe_snapshot(step, runtime_ctx, agents)

    # ========================================================================
    # NEW: PHASE 1&2 VALIDATION HOOKS
    # ========================================================================
    
    # 6a) Energy Budget Tracking
    if hasattr(runtime_ctx, 'energy_budget'):
        runtime_ctx.energy_budget.record(step, action_dict=action)  # ← LINE 169 - CORRECT!
        
        # Print summary every 10 steps
        if step % 10 == 0:
            runtime_ctx.energy_budget.print_summary()
    
    # 6b) Stability Monitoring
    if hasattr(runtime_ctx, 'stability_monitor'):
        all_healthy = runtime_ctx.stability_monitor.check_all_agents(agents, step)
        
        # Record energy for conservation checking
        E_total = action.get('Action_total', 0.0)
        runtime_ctx.stability_monitor.record_energy(step, E_total)
        
        # Check for critical issues
        if not all_healthy:
            critical_issues = [
                i for i in runtime_ctx.stability_monitor.issues
                if i.severity == 'critical' and i.step == step
            ]
            
            if critical_issues:
                print("\n" + "="*70)
                print(f"⚠️  {len(critical_issues)} CRITICAL STABILITY ISSUES DETECTED")
                print("="*70)
                for issue in critical_issues[:5]:  # Show first 5
                    print(f"  Agent {issue.agent_id}: {issue.message}")
                if len(critical_issues) > 5:
                    print(f"  ... and {len(critical_issues)-5} more")
                print("="*70)
                print("\nConsider:")
                print("  1. Reducing learning rates (α_phi, α_mu, etc.)")
                print("  2. Increasing regularization (sigma_eps)")
                print("  3. Enabling gradient clipping")
                print("  4. Checking for implementation bugs")
                print()
                
                # Optional: Uncomment to abort on critical issues
                # raise RuntimeError(f"Critical stability issues at step {step}")
    
    # ========================================================================
    # END PHASE 1&2 VALIDATION
    # ========================================================================

    # 7) checkpoint
    save_step(agents, outdir, step)


def run_one_step(runtime_ctx, agents, G_q, G_p, n_jobs=1):
    """
    Perform ONE pure simulation step:
      - refresh per-step settings from config + runtime overrides
      - ensure a shared, disk-backed cache (memmapped) usable by loky workers
      - run synchronous child update (parallel if n_jobs > 1)
      - compute per-step metrics and action
    """
    # Ensure cache is attached (idempotent; safe if already set)
    ensure_shared_cache_attached(runtime_ctx)
    from core.runtime_context import ensure_observation_model
    runtime_ctx, agents = ensure_observation_model(runtime_ctx, agents)

# =====================================================
    # NEW: ensure observation model + per-agent x_obs
    # =====================================================
    import numpy as np

    # latent dim of q-fiber
    Kq = int(np.asarray(agents[0].mu_q_field).shape[-1])

    # init W_obs, Lambda_obs on the ctx if missing
    if getattr(runtime_ctx, "W_obs", None) is None:
        runtime_ctx.W_obs = np.eye(Kq, dtype=np.float32)      # shape (Kq, Kq) but we treat as (Dx,Kq) with Dx=Kq
    if getattr(runtime_ctx, "Lambda_obs", None) is None:
        runtime_ctx.Lambda_obs = np.eye(Kq, dtype=np.float32) # (Dx, Dx)

    # now give each agent an x_obs if missing
    for ag in agents:
        if getattr(ag, "x_obs", None) is None:
            # predicted obs y_hat = W_obs @ mu_q
            # We want shape (*S, D_x). With W_obs = I, D_x = Kq, so just copy mu_q_field.
            mu_q = np.asarray(ag.mu_q_field, np.float32)           # (*S, Kq)
            y_hat = np.einsum("dk,...k->...d", runtime_ctx.W_obs, mu_q, optimize=True)
            # Dummy target for now: zeros, same shape
            ag.x_obs = np.zeros_like(y_hat, dtype=np.float32)
    # =====================================================

    # Per-step resets (pure, in-memory)
    runtime_ctx.timings = {}
    runtime_ctx.energy_acc = {}   # fresh per-step accumulator dict (master-only)

    # (A) pre-step snapshot = t_k
    log_phi_vectors(runtime_ctx, agents)
    log_mu_vectors(runtime_ctx, agents)

    # Run updates. Parallel section writes results; master reducer fills energy_acc.
    agents = synchronous_step(
        agents, G_q, G_p,
        n_jobs=int(n_jobs),
        runtime_ctx=runtime_ctx,
    )
    runtime_ctx.children_latest = agents

    # (B) post-step snapshot = t_{k+1}
    log_phi_vectors(runtime_ctx, agents)
    log_mu_vectors(runtime_ctx, agents)

    # Metrics & action (these read from runtime_ctx.energy_acc populated above)
    metrics = compute_global_metrics(runtime_ctx, agents)
    action  = compute_total_action(runtime_ctx, agents, precomputed_metrics=metrics)

    return agents, metrics, action


def run_simulation(
    outdir="_checkpoints",
    resume=False,
    log_metrics=True,
    log_fields=True,
    num_cores=None,
    fresh_outdir=False,
    clear_agent_logs=True,
    runtime_ctx=None,
    # NEW: Phase 1&2 flags
    enable_energy_budget=False,
    enable_stability_monitor=False,
    abort_on_critical=False,
):
    """
    Enhanced simulation runner with Phase 1&2 validation tools.
    
    New Parameters:
        enable_energy_budget: Track energy decomposition and conservation
        enable_stability_monitor: Monitor numerical stability in real-time
        abort_on_critical: Stop simulation on critical stability issues
    """
    t0_all = perf_counter()

    # ---------- core selection ----------
    # If num_cores not provided, default to cfg.compute.n_jobs; otherwise honor the parameter
    if num_cores is None:
        num_cores = int(getattr(config, "n_jobs", 1))
    else:
        num_cores = max(1, int(num_cores))

    # ---------- runtime ctx ----------
    runtime_ctx = ensure_runtime_defaults(runtime_ctx)
    runtime_ctx.timings = {}

    # Initialize shared disk cache (for caching expensive pushes)
    cache_dir = cfg_get(runtime_ctx, "shared_cache_dir", "./_shared_cache")
    runtime_ctx.cache = SharedDiskCache(cache_dir)
    print(f"[CACHE] Initialized SharedDiskCache at {cache_dir}")

    # Use ctx.overrides for explicit runtime changes only
    runtime_ctx.overrides = {}

    # Reflect chosen n_jobs into cfg so downstream uses it consistently
    cfg_set_override(runtime_ctx, "n_jobs", num_cores)
    print("[CONFIG] Using config.py as single source of truth")
    n_jobs_val = cfg_get(runtime_ctx, "n_jobs", 1)
    print(f"[CONFIG] n_jobs = {n_jobs_val}")
    if runtime_ctx.overrides:
        print(f"[CONFIG] Active overrides: {list(runtime_ctx.overrides.keys())}")

    # ========================================================================
    # NEW: PHASE 1&2 VALIDATION SETUP
    # ========================================================================
    
    if enable_energy_budget:
        print("\n[PHASE 1&2] Initializing Energy Budget Tracker...")
        runtime_ctx.energy_budget = EnergyBudget(output_dir=Path(outdir) / "energy_analysis")
        print("  ✓ Energy decomposition tracking enabled")
        print("  ✓ Conservation law verification enabled")
    
    if enable_stability_monitor:
        print("\n[PHASE 1&2] Initializing Stability Monitor...")
        runtime_ctx.stability_monitor = StabilityMonitor(
            cond_warn=1e8,
            cond_error=1e10,
            grad_warn=10.0,
            grad_error=100.0,
            energy_tol=1e-4,
            output_dir=Path(outdir) / "stability_reports"
        )
        print("  ✓ Condition number monitoring enabled")
        print("  ✓ NaN/Inf detection enabled")
        print("  ✓ Gradient explosion detection enabled")
        print("  ✓ SPD property validation enabled")
        
        if abort_on_critical:
            print("  ⚠️  ABORT ON CRITICAL MODE: Simulation will stop on critical issues")
    
    print()
    
    # ========================================================================
    # END PHASE 1&2 SETUP
    # ========================================================================

    # ---------- generators (ctx-driven) ----------
    G_q, G_p = prepare_generators(runtime_ctx)
    Kq, Kp = int(np.asarray(G_q).shape[1]), int(np.asarray(G_p).shape[1])

    # ---------- init or resume ----------
    if fresh_outdir and not resume and os.path.isdir(outdir):
        shutil.rmtree(outdir, ignore_errors=True)
    os.makedirs(outdir, exist_ok=True)

    with section_timer(runtime_ctx, "initialize_or_resume"):
        agents, step_start = initialize_or_resume(
            outdir, resume, runtime_ctx, clear_agent_logs=clear_agent_logs
        )

    # ---------- runtime ctx bootstrapping ----------
    runtime_ctx.global_step = step_start
    runtime_ctx.children_latest = agents

    vizcfg = VizConfig(
            outdir=Path(outdir),
            run_name="runs",
            legend_label=f"l_q={cfg_get(runtime_ctx, 'ell_q', 3)}",
            plot_every_steps=1,
            snapshot_every_steps=99,
        )
    mv = setup_professional_metrics_viz(vizcfg, plot_style='all')  #auto, all, summary, heatmap, etc
    meta_generators = {
            "Kq": Kq, "Kp": Kp,
            "casimir_total_q": casimir_scalar(G_q),
            "casimir_total_p": casimir_scalar(G_p),
        }
    mv.start_run(meta=meta_generators)
    runtime_ctx.viz = mv    
    
   # H, W = agents[0].spatial_shape
   # runtime_ctx.spatial_shape = (H, W)
  #  runtime_ctx.ndim = len(runtime_ctx.spatial_shape)
    
  #  if not hasattr(runtime_ctx, "fields"):
   #     runtime_ctx.fields = {}
    
   # if "A" not in runtime_ctx.fields or np.shape(runtime_ctx.fields["A"]) == ():
   #     runtime_ctx.fields["A"] = np.zeros((H, W, runtime_ctx.ndim, 3), dtype=np.float32)
        
    # ---------- global A (M-D) ----------
    S_agents = agents[0].spatial_shape
    A_init_scale = cfg_get(runtime_ctx, "A_init_scale", getattr(config, "A_init_scale", 0.0))
    ensure_global_A(runtime_ctx, spatial_shape=S_agents, init_scale=A_init_scale, smooth_sigma=1.5)

  #  A_init = initialize_A_from_attention(runtime_ctx, agents,which="q", use_spatial_directions=True,
   #     normalize_per_direction=True, verbose=True)
    
   # runtime_ctx.fields["A"] = A_init.astype(np.float32, copy=False)
   # print("Induced A shape:", A_init.shape)


    # ---------- step range ----------
    total_steps = int(cfg_get(runtime_ctx, "steps", getattr(config, "steps", 0)))
    if step_start >= total_steps:
        with section_timer(runtime_ctx, "epilogue_noop"):
            wrap_epilogue(runtime_ctx, agents, outdir, [], [])
            mv.end_run()
        print("[DONE] Nothing to do: resume step >= total steps.")
        print(f"[TOTAL] {_dt_ms(perf_counter() - t0_all)}")
        return agents, []

    # ---------- loop ----------
    parent_metrics, metric_log = [], []
    print(f"[RUN] Starting simulation at step {step_start} with {num_cores} cores")

    try:
        for step in range(step_start, total_steps):
            runtime_ctx.global_step = step
            print(f"\n[STEP {step}] -----------------------------\n")
            t_step0 = perf_counter()

            # One step (compute)
            with section_timer(runtime_ctx, "run_one_step", step=step):
                agents, metrics, action = run_one_step(
                    runtime_ctx, agents, G_q, G_p, n_jobs=n_jobs_val
                )

            # IO / logging (includes Phase 1&2 validation)
            with section_timer(runtime_ctx, "post_step_io", step=step):
                post_step_io(runtime_ctx, agents, metrics, action, step, outdir, mv, parent_metrics, metric_log)

            # ================================================================
            # NEW: Check for abort condition
            # ================================================================
            if abort_on_critical and hasattr(runtime_ctx, 'stability_monitor'):
                critical_now = [
                    i for i in runtime_ctx.stability_monitor.issues
                    if i.severity == 'critical' and i.step == step
                ]
                if critical_now:
                    print(f"\n[ABORT] Terminating at step {step} due to {len(critical_now)} critical issues")
                    break

            # Step summary
            dt_step = perf_counter() - t_step0
            print(f"[t:step_{step}] total: {dt_step:.3f}s")

    except KeyboardInterrupt:
        print("\n[INTERRUPTED] Simulation interrupted by user")
    except Exception as e:
        print(f"\n[ERROR] Simulation crashed: {e}")
        import traceback
        traceback.print_exc()
        
        # Still try to generate reports
        if hasattr(runtime_ctx, 'stability_monitor'):
            print("\n[CRASH ANALYSIS] Generating stability report...")
            runtime_ctx.stability_monitor.report()

    # ---------- epilogue ----------
    print("\n" + "="*70)
    print("FINALIZING SIMULATION")
    print("="*70)
    plot_beta_map(runtime_ctx, i_id=0, j_id=1, which="q")

    
    wrap_epilogue(runtime_ctx, agents, outdir, parent_metrics, metric_log)
    save_all_series_npz(runtime_ctx, os.path.join(outdir, "phi_series.npz"))
    mv.end_run()

    # ========================================================================
    # NEW: PHASE 1&2 FINAL REPORTS
    # ========================================================================
    
    print("\n" + "="*70)
    print("GENERATING VALIDATION REPORTS")
    print("="*70)
    
    if hasattr(runtime_ctx, 'energy_budget'):
        print("\n[Energy Budget] Generating reports...")
        try:
            runtime_ctx.energy_budget.plot_history()
            runtime_ctx.energy_budget.check_conservation()
            runtime_ctx.energy_budget.export_csv()
            # Optional: Sankey diagram (requires plotly)
            try:
                runtime_ctx.energy_budget.export_sankey()
            except Exception as e:
                print(f"  (Sankey diagram skipped: {e})")
        except Exception as e:
            print(f"  ⚠️  Energy budget reporting failed: {e}")
    
    if hasattr(runtime_ctx, 'stability_monitor'):
        print("\n[Stability Monitor] Generating reports...")
        try:
            runtime_ctx.stability_monitor.report()
            runtime_ctx.stability_monitor.plot_health_over_time()
        except Exception as e:
            print(f"  ⚠️  Stability monitoring reporting failed: {e}")
    
    print("\n" + "="*70)
    print("VALIDATION REPORTS COMPLETE")
    print("="*70)
    
    # ========================================================================
    # END PHASE 1&2 REPORTS
    # ========================================================================

    dt_all = perf_counter() - t0_all
    print("\n[DONE] Simulation completed.")
    print(f"[TOTAL] {dt_all:.3f}s")
    
    return agents, metric_log


if __name__ == "__main__":
    print("\n" + "="*70)
    print("PHASE 1&2 ENHANCED SIMULATION")
    print("="*70)
    print("\nFeatures enabled:")
    print("  ✓ Energy budget tracking")
    print("  ✓ Stability monitoring")
    print("  ✓ Conservation law validation")
    print("  ✓ Real-time numerical health checks")
    print("\nReports will be generated in:")
    print("  ./_checkpoints/energy_analysis/")
    print("  ./_checkpoints/stability_reports/")
    print("="*70 + "\n")
    
    run_simulation(
        enable_energy_budget=False,
        enable_stability_monitor=False,
        abort_on_critical=False,  # Set to True to stop on critical issues
    )