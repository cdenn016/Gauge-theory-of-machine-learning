# -*- coding: utf-8 -*-
"""
Created on Fri Oct 24 07:59:20 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
Numerical Stability Monitor

Real-time monitoring system for detecting numerical issues before they
cause crashes or corrupt results.

Monitors:
- Condition numbers (matrix ill-conditioning)
- NaN/Inf occurrences
- Gradient magnitudes
- Energy conservation violations
- SPD property violations

Integration:
    from stability_monitor import StabilityMonitor
    
    monitor = StabilityMonitor()
    runtime_ctx.stability_monitor = monitor
    
    # In simulation loop:
    monitor.check_all_agents(agents, step)
    
    # At end:
    monitor.report()

Author: Phase 1&2 Stability Team
"""

import numpy as np
import warnings
from typing import List, Dict, Tuple, Optional, Any
from dataclasses import dataclass
from collections import defaultdict
from pathlib import Path
import json


@dataclass
class StabilityIssue:
    """Record of a single stability issue"""
    step: int
    agent_id: int
    issue_type: str
    severity: str  # 'warning', 'error', 'critical'
    value: float
    threshold: float
    message: str


class StabilityMonitor:
    """
    Real-time numerical stability monitoring.
    
    Tracks:
    1. Condition numbers of covariance matrices
    2. NaN/Inf in fields
    3. Gradient explosion
    4. Energy conservation violations
    5. SPD property violations
    
    Severity levels:
    - INFO: Worth noting but not concerning
    - WARNING: Potential issue, monitor closely
    - ERROR: Serious issue, may affect results
    - CRITICAL: Fatal issue, simulation should stop
    """
    
    def __init__(
        self,
        cond_warn=1e8,
        cond_error=1e10,
        grad_warn=10.0,
        grad_error=100.0,
        energy_tol=1e-4,
        output_dir: Optional[Path] = None
    ):
        """
        Args:
            cond_warn: Condition number warning threshold
            cond_error: Condition number error threshold
            grad_warn: Gradient norm warning threshold
            grad_error: Gradient norm error threshold
            energy_tol: Energy conservation tolerance
            output_dir: Directory for reports
        """
        self.cond_warn = cond_warn
        self.cond_error = cond_error
        self.grad_warn = grad_warn
        self.grad_error = grad_error
        self.energy_tol = energy_tol
        
        self.output_dir = Path(output_dir) if output_dir else Path("./stability_reports")
        self.output_dir.mkdir(exist_ok=True, parents=True)
        
        # Issue tracking
        self.issues: List[StabilityIssue] = []
        self.issue_counts: Dict[str, int] = defaultdict(int)
        
        # Per-agent tracking
        self.agent_health: Dict[int, List[float]] = defaultdict(list)  # agent_id -> cond numbers
        
        # Energy tracking
        self.energy_history: List[float] = []
        self.energy_violations: List[Tuple[int, float]] = []  # (step, dE)
    
    def check_agent(self, agent: Any, step: int) -> bool:
        """
        Check single agent for numerical issues.
        
        Returns:
            True if agent is healthy, False if issues detected
        """
        agent_id = agent.id
        has_issues = False
        
        # 1. Check Sigma condition numbers
        try:
            cond_q = self._check_condition_number(
                agent.sigma_q_field, agent_id, step, 'sigma_q'
            )
            cond_p = self._check_condition_number(
                agent.sigma_p_field, agent_id, step, 'sigma_p'
            )
            
            # Track health
            max_cond = max(cond_q, cond_p)
            self.agent_health[agent_id].append(max_cond)
            
        except Exception as e:
            self._record_issue(
                step, agent_id, 'condition_check_failed',
                severity='error',
                value=0.0,
                threshold=0.0,
                message=f"Failed to compute condition number: {e}"
            )
            has_issues = True
        
        # 2. Check for NaN/Inf
        has_issues |= self._check_finite(agent.phi, agent_id, step, 'phi')
        has_issues |= self._check_finite(agent.phi_model, agent_id, step, 'phi_model')
        has_issues |= self._check_finite(agent.mu_q_field, agent_id, step, 'mu_q')
        has_issues |= self._check_finite(agent.mu_p_field, agent_id, step, 'mu_p')
        has_issues |= self._check_finite(agent.sigma_q_field, agent_id, step, 'sigma_q')
        has_issues |= self._check_finite(agent.sigma_p_field, agent_id, step, 'sigma_p')
        
        # 3. Check gradient magnitudes
        if hasattr(agent, 'grad_phi'):
            has_issues |= self._check_gradient(agent.grad_phi, agent_id, step, 'grad_phi')
        if hasattr(agent, 'grad_phi_tilde'):
            has_issues |= self._check_gradient(agent.grad_phi_tilde, agent_id, step, 'grad_phi_tilde')
        
        # 4. Check SPD property (spot check)
        if step % 10 == 0:  # Don't check every step (expensive)
            has_issues |= self._check_spd(agent.sigma_q_field, agent_id, step, 'sigma_q')
            has_issues |= self._check_spd(agent.sigma_p_field, agent_id, step, 'sigma_p')
        
        return not has_issues
    
    def check_all_agents(self, agents: List[Any], step: int) -> bool:
        """
        Check all agents and return overall health status.
        
        Returns:
            True if all agents healthy, False if any issues
        """
        all_healthy = True
        
        for agent in agents:
            if not self.check_agent(agent, step):
                all_healthy = False
              
        
        return all_healthy
    
    def record_energy(self, step: int, energy: float):
        """Record energy for conservation checking"""
        self.energy_history.append(energy)
        
        if len(self.energy_history) > 1:
            dE = energy - self.energy_history[-2]
            
            if dE > self.energy_tol:
                self.energy_violations.append((step, dE))
                self._record_issue(
                    step, -1, 'energy_increase',
                    severity='error',
                    value=dE,
                    threshold=self.energy_tol,
                    message=f"Energy increased by {dE:.3e}"
                )
    
    def _check_condition_number(
        self, sigma: np.ndarray, agent_id: int, step: int, field_name: str
    ) -> float:
        """Check condition number and record if problematic"""
        # Compute max condition number across spatial points
        *spatial, K, _ = sigma.shape
        conds = []
        
        for idx in np.ndindex(tuple(spatial)):
            cond = np.linalg.cond(sigma[idx])
            conds.append(cond)
        
        max_cond = max(conds)
        
        if max_cond > self.cond_error:
            self._record_issue(
                step, agent_id, 'condition_critical',
                severity='critical',
                value=max_cond,
                threshold=self.cond_error,
                message=f"{field_name} critically ill-conditioned: {max_cond:.2e}"
            )
        elif max_cond > self.cond_warn:
            self._record_issue(
                step, agent_id, 'condition_high',
                severity='warning',
                value=max_cond,
                threshold=self.cond_warn,
                message=f"{field_name} ill-conditioned: {max_cond:.2e}"
            )
        
        return max_cond
    
    def _check_finite(
        self, field: np.ndarray, agent_id: int, step: int, field_name: str
    ) -> bool:
        """Check for NaN/Inf"""
        if not np.all(np.isfinite(field)):
            num_nan = np.sum(np.isnan(field))
            num_inf = np.sum(np.isinf(field))
            
            self._record_issue(
                step, agent_id, 'nonfinite_values',
                severity='critical',
                value=num_nan + num_inf,
                threshold=0.0,
                message=f"{field_name} has {num_nan} NaN and {num_inf} Inf values"
            )
            return True
        return False
    
    def _check_gradient(
        self, grad: np.ndarray, agent_id: int, step: int, field_name: str
    ) -> bool:
        """Check gradient magnitude"""
        grad_norm = np.linalg.norm(grad)
        
        if grad_norm > self.grad_error:
            self._record_issue(
                step, agent_id, 'gradient_explosion',
                severity='error',
                value=grad_norm,
                threshold=self.grad_error,
                message=f"{field_name} norm critically large: {grad_norm:.2e}"
            )
            return True
        elif grad_norm > self.grad_warn:
            self._record_issue(
                step, agent_id, 'gradient_large',
                severity='warning',
                value=grad_norm,
                threshold=self.grad_warn,
                message=f"{field_name} norm large: {grad_norm:.2e}"
            )
            return True
        return False
    
    def _check_spd(
        self, sigma: np.ndarray, agent_id: int, step: int, field_name: str
    ) -> bool:
        """Check SPD property via eigenvalues"""
        *spatial, K, _ = sigma.shape
        
        for idx in np.ndindex(tuple(spatial)):
            evals = np.linalg.eigvalsh(sigma[idx])
            min_eval = np.min(evals)
            
            if min_eval <= 0:
                self._record_issue(
                    step, agent_id, 'not_spd',
                    severity='critical',
                    value=min_eval,
                    threshold=0.0,
                    message=f"{field_name} not SPD at {idx}: min_eval={min_eval:.3e}"
                )
                return True
        return False
    
    
    
    def _record_issue(
        self,
        step: int,
        agent_id: int,
        issue_type: str,
        severity: str,
        value: float,
        threshold: float,
        message: str
    ):
        """Record a stability issue"""
        issue = StabilityIssue(
            step=step,
            agent_id=agent_id,
            issue_type=issue_type,
            severity=severity,
            value=value,
            threshold=threshold,
            message=message
        )
        
        self.issues.append(issue)
        self.issue_counts[issue_type] += 1
        
        # Print critical issues immediately
        if severity == 'critical':
            warnings.warn(f"[CRITICAL] Step {step}: {message}", RuntimeWarning)
    
    def report(self, verbose: bool = True):
        """Generate comprehensive stability report"""
        print()
        print("=" * 70)
        print("NUMERICAL STABILITY REPORT")
        print("=" * 70)
        print()
        
        if not self.issues:
            print("✓ No stability issues detected")
            print()
            return
        
        # Summary by severity
        severity_counts = defaultdict(int)
        for issue in self.issues:
            severity_counts[issue.severity] += 1
        
        print("Summary by severity:")
        for severity in ['critical', 'error', 'warning', 'info']:
            count = severity_counts.get(severity, 0)
            if count > 0:
                symbol = "🔴" if severity == 'critical' else "🟠" if severity == 'error' else "🟡"
                print(f"  {symbol} {severity.upper()}: {count}")
        print()
        
        # Summary by issue type
        print("Summary by issue type:")
        for issue_type, count in sorted(self.issue_counts.items(), key=lambda x: -x[1]):
            print(f"  {issue_type}: {count}")
        print()
        
        # Worst offenders
        print("Agents with most issues:")
        agent_issue_counts = defaultdict(int)
        for issue in self.issues:
            if issue.agent_id >= 0:
                agent_issue_counts[issue.agent_id] += 1
        
        for agent_id, count in sorted(agent_issue_counts.items(), key=lambda x: -x[1])[:5]:
            print(f"  Agent {agent_id}: {count} issues")
        print()
        
        # Energy violations
        if self.energy_violations:
            print(f"Energy conservation violations: {len(self.energy_violations)}")
            print(f"  Max violation: {max(abs(dE) for _, dE in self.energy_violations):.3e}")
            print()
        
        # Detailed issues (if verbose)
        if verbose and len(self.issues) <= 50:
            print("Detailed issues:")
            for issue in self.issues[:50]:  # Limit to first 50
                print(f"  Step {issue.step}, Agent {issue.agent_id}: {issue.message}")
            if len(self.issues) > 50:
                print(f"  ... and {len(self.issues) - 50} more")
            print()
        
        print("=" * 70)
        print()
        
        # Save to file
        self._save_report()
    
    def _save_report(self):
        """Save detailed report to file"""
        report_path = self.output_dir / "stability_report.json"
        
        report = {
            'summary': {
                'total_issues': len(self.issues),
                'issue_counts': dict(self.issue_counts),
                'energy_violations': len(self.energy_violations),
            },
            'issues': [
                {
                    'step': issue.step,
                    'agent_id': issue.agent_id,
                    'type': issue.issue_type,
                    'severity': issue.severity,
                    'value': float(issue.value),
                    'threshold': float(issue.threshold),
                    'message': issue.message,
                }
                for issue in self.issues
            ],
            'agent_health': {
                agent_id: {
                    'max_cond': float(max(conds)) if conds else 0.0,
                    'mean_cond': float(np.mean(conds)) if conds else 0.0,
                }
                for agent_id, conds in self.agent_health.items()
            }
        }
        
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"Detailed report saved to {report_path}")
    
    def plot_health_over_time(self):
        """Generate plots of numerical health over time"""
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            print("matplotlib not available for plotting")
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        # Top left: Condition numbers over time
        ax = axes[0, 0]
        for agent_id, conds in list(self.agent_health.items())[:10]:  # Plot first 10 agents
            ax.plot(conds, alpha=0.7, label=f"Agent {agent_id}")
        ax.axhline(self.cond_warn, color='orange', linestyle='--', label='Warning')
        ax.axhline(self.cond_error, color='red', linestyle='--', label='Error')
        ax.set_yscale('log')
        ax.set_xlabel('Check iteration')
        ax.set_ylabel('Max condition number')
        ax.set_title('Condition Number Evolution')
        ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        ax.grid(True, alpha=0.3)
        
        # Top right: Issues over time
        ax = axes[0, 1]
        issue_times = [issue.step for issue in self.issues]
        if issue_times:
            ax.hist(issue_times, bins=50, alpha=0.7)
            ax.set_xlabel('Step')
            ax.set_ylabel('Number of issues')
            ax.set_title('Issue Distribution Over Time')
            ax.grid(True, alpha=0.3)
        
        # Bottom left: Energy conservation
        ax = axes[1, 0]
        if len(self.energy_history) > 1:
            dE = np.diff(self.energy_history)
            ax.plot(dE, alpha=0.7)
            ax.axhline(0, color='black', linestyle='-', linewidth=0.5)
            ax.axhline(self.energy_tol, color='orange', linestyle='--', label='Tolerance')
            ax.axhline(-self.energy_tol, color='orange', linestyle='--')
            ax.set_xlabel('Step')
            ax.set_ylabel('ΔE')
            ax.set_title('Energy Change per Step')
            ax.legend()
            ax.grid(True, alpha=0.3)
        
        # Bottom right: Issue type breakdown
        ax = axes[1, 1]
        if self.issue_counts:
            types = list(self.issue_counts.keys())
            counts = list(self.issue_counts.values())
            ax.barh(types, counts, alpha=0.7)
            ax.set_xlabel('Count')
            ax.set_title('Issue Type Breakdown')
            ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(self.output_dir / 'stability_health.png', dpi=150, bbox_inches='tight')
        plt.close()
        
        print(f"Health plots saved to {self.output_dir / 'stability_health.png'}")


# =============================================================================
# USAGE EXAMPLE
# =============================================================================

if __name__ == "__main__":
    print("Stability Monitor - Usage Example")
    print("=" * 70)
    print()
    
    # Example integration
    example = """
    from stability_monitor import StabilityMonitor
    
    # In run_simulation():
    monitor = StabilityMonitor(
        cond_warn=1e8,
        cond_error=1e10,
        grad_warn=10.0,
        grad_error=100.0,
        output_dir=outdir
    )
    runtime_ctx.stability_monitor = monitor
    
    # In simulation loop (post_step_io or similar):
    if hasattr(runtime_ctx, 'stability_monitor'):
        all_healthy = runtime_ctx.stability_monitor.check_all_agents(agents, step)
        
        # Record energy
        E_total = action.get('Action_total', 0.0)
        runtime_ctx.stability_monitor.record_energy(step, E_total)
        
        # Optional: Abort on critical issues
        if not all_healthy:
            critical_issues = [
                i for i in runtime_ctx.stability_monitor.issues
                if i.severity == 'critical' and i.step == step
            ]
            if critical_issues:
                print(f"[ABORT] {len(critical_issues)} critical issues at step {step}")
                # Optionally: break  # Stop simulation
    
    # At end of simulation:
    runtime_ctx.stability_monitor.report()
    runtime_ctx.stability_monitor.plot_health_over_time()
    """
    
    print(example)