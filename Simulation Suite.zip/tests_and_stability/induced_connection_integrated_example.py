#!/usr/bin/env python3
"""
Induced Connection Example - Integration with Project Codebase (FIXED)
========================================================================

This example shows how to use the induced_connection module with your
actual simulation code, properly handling the Agent schema.

Usage:
    python induced_connection_integrated_example_FIXED.py

Requirements:
    - Your project codebase must be in Python path
    - Run from project root directory
    
Author: c&c (FIXED VERSION)
Date: 2025
"""

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import sys

# Add project to path if needed
# sys.path.insert(0, '/path/to/your/project')


def create_test_simulation():
    """
    Create a minimal test simulation with proper structure.
    
    This properly constructs Agent objects with ALL required fields.
    """
    print("[Setup] Creating test simulation...")
    
    # Mock spatial configuration
    S = (16, 16)  # Spatial shape
    ndim = 2
    n_agents = 4
    
    # Import required modules
    try:
        from core.runtime_context import RuntimeCtx, EdgeMaps
        from agents.agent_schema import Agent
        from agents.agent_initialization import make_soft_mask
    except ImportError as e:
        print(f"Import error: {e}")
        print("\nPlease ensure you're running from the project directory")
        print("or adjust sys.path to include your project.")
        return None, None
    
    # Create runtime context
    ctx = RuntimeCtx()
    ctx.spatial_shape = S
    ctx.ndim = ndim
    ctx.edge = EdgeMaps()
    
    # Create mock agents
    agents = []
    centers = [(4, 4), (4, 12), (12, 4), (12, 12)]  # 2x2 grid
    
    # Initialize fields (Gaussian distributions)
    K = 3  # Use spin-1 representation
    lie_algebra_dim = 3  # so(3)
    
    print("   Initializing agent fields...")
    
    for i, center in enumerate(centers):
        # Create circular mask
        mask = make_soft_mask(center, radius=6, domain_size=S)
        
        # Mean vectors (spatial fields)
        mu_q = np.random.randn(*S, K).astype(np.float32) * 0.1
        mu_p = np.random.randn(*S, K).astype(np.float32) * 0.1
        
        # Covariance matrices (diagonal, float64 for numerical stability)
        sigma_q = np.tile(np.eye(K)[None, None, :, :], (*S, 1, 1)).astype(np.float64)
        sigma_p = np.tile(np.eye(K)[None, None, :, :], (*S, 1, 1)).astype(np.float64)
        
        # so(3) gauge fields
        phi = np.random.randn(*S, lie_algebra_dim).astype(np.float32) * 0.01
        phi_model = np.random.randn(*S, lie_algebra_dim).astype(np.float32) * 0.01
        
        # Construct Agent with ALL required arguments
        # Based on Agent schema: id, center, radius, mask, phi, phi_model,
        #                        mu_q_field, sigma_q_field, mu_p_field, sigma_p_field, neighbors
        agent = Agent(
            id=i,
            center=center,
            radius=6.0,
            mask=mask.astype(np.float32),
            phi=phi,
            phi_model=phi_model,
            mu_q_field=mu_q,
            sigma_q_field=sigma_q,
            mu_p_field=mu_p,
            sigma_p_field=sigma_p,
            neighbors=[]  # Initialize empty
        )
        
        # Add derived attributes
        agent.position = np.array(center, dtype=np.float32)  # For spatial direction inference
        agent.mask_bool = mask > 0.5  # For overlap computation
        
        # Add hierarchy info
        agent.level = 0
        agent.parent_ids = []
        agent.child_ids = []
        
        agents.append(agent)
    
    print(f"   Created {len(agents)} agents in {S} domain")
    
    return ctx, agents


def compute_mock_edge_maps(ctx, agents):
    """
    Create mock edge maps (attention weights) for demonstration.
    
    In real code, this would be done by edge_maps._build_edge_maps_single_pass
    """
    print("[Edge Maps] Computing attention weights...")
    
    from core.runtime_context import EdgeMaps
    
    if not hasattr(ctx, 'edge') or ctx.edge is None:
        ctx.edge = EdgeMaps()
    
    S = ctx.spatial_shape
    n_agents = len(agents)
    
    # Create smooth attention weights between agents
    from scipy.ndimage import gaussian_filter
    
    for i, agent_i in enumerate(agents):
        for j, agent_j in enumerate(agents):
            if i == j:
                continue
            
            # Distance-based attention
            pos_i = agent_i.position
            pos_j = agent_j.position
            
            # Create attention field favoring proximity to j
            X, Y = np.meshgrid(np.arange(S[0]), np.arange(S[1]), indexing='ij')
            dist_to_j = np.sqrt((X - pos_j[0])**2 + (Y - pos_j[1])**2)
            
            # Attention decreases with distance
            beta = np.exp(-dist_to_j / 5.0).astype(np.float32)
            
            # Smooth
            beta = gaussian_filter(beta, sigma=2.0)
            
            # Mask to overlap region
            overlap = agent_i.mask_bool & agent_j.mask_bool
            if overlap.sum() > 0:
                beta[~overlap] = 0
                beta /= (beta.sum() + 1e-8)
            else:
                beta = np.zeros_like(beta)
            
            # Store in edge maps
            # Note: EdgeMaps.set_align(ctx, which, i_id, j_id, KL_map, beta_map)
            KL_dummy = 0.1  # Mock KL divergence
            ctx.edge.set_align(ctx, "q", agent_i.id, agent_j.id, KL_dummy, beta)
    
    print(f"   Created attention weights for {n_agents*(n_agents-1)} agent pairs")


def compute_mock_transports(ctx, agents):
    """
    Create mock transport operators for demonstration.
    
    In real code, these would be computed from Omega(ctx, ...)
    """
    print("[Transports] Creating mock Ω operators...")
    
    from scipy.spatial.transform import Rotation
    
    S = ctx.spatial_shape
    
    # Store transports in a dict for later use
    transports = {}
    
    for i, agent_i in enumerate(agents):
        for j, agent_j in enumerate(agents):
            if i == j:
                continue
            
            # Create spatially-varying rotation
            Omega = np.zeros(S + (3, 3), dtype=np.float32)
            
            # Direction from i to j
            dir_ij = agent_j.position - agent_i.position
            dir_ij = dir_ij / (np.linalg.norm(dir_ij) + 1e-8)
            
            for x in range(S[0]):
                for y in range(S[1]):
                    # Rotation angle depends on spatial position
                    angle = 0.1 * np.sin(2*np.pi*x/S[0]) * np.cos(2*np.pi*y/S[1])
                    
                    # Rotation axis aligned with i→j direction
                    axis = np.array([dir_ij[0], dir_ij[1], 0.0])
                    axis_norm = np.linalg.norm(axis)
                    if axis_norm > 1e-8:
                        axis /= axis_norm
                    else:
                        axis = np.array([0, 0, 1])
                    
                    # Create rotation
                    R = Rotation.from_rotvec(angle * axis).as_matrix()
                    Omega[x, y] = R.astype(np.float32)
            
            transports[(i, j)] = Omega
    
    print(f"   Created {len(transports)} transport operators")
    
    return transports


import numpy as np

def sync_edge_maps_from_mock(ctx, agents, beta_cache):
    """
    Force-populate ctx.edge._edge_beta / _edge_kl1 so that
    initialize_A_from_attention can read them via ctx.edge.get_align.

    beta_cache is expected to map (i_id, j_id) -> beta_map[(H,W)].
    We'll store each under ('q', i_id, j_id) in ctx.edge.
    KL will just be zeros of the same shape.
    """
    if not hasattr(ctx.edge, "_edge_beta"):
        ctx.edge._edge_beta = {}
    if not hasattr(ctx.edge, "_edge_kl1"):
        ctx.edge._edge_kl1 = {}

    for a_i in agents:
        for a_j in agents:
            if a_i.id == a_j.id:
                continue
            key_ij = (a_i.id, a_j.id)
            beta_map = beta_cache.get(key_ij, None)
            if beta_map is None:
                # no overlap / no attention for this pair
                continue

            beta_arr = np.asarray(beta_map, dtype=np.float32)
            # ensure correct spatial shape and C order
            beta_arr = beta_arr.reshape(ctx.spatial_shape).copy(order="C")

            ctx.edge._edge_beta[("q", a_i.id, a_j.id)] = beta_arr

            # KL isn't used in A induction, but some code expects it to exist.
            ctx.edge._edge_kl1[("q", a_i.id, a_j.id)] = np.zeros_like(beta_arr, dtype=np.float32)


def build_and_sync_attention(ctx, agents):
    """
    Run the existing mock attention builder and then coerce whatever
    it wrote into a ('q', i, j)->beta map on ctx.edge.
    """
    # run your existing attention builder
    beta_cache = compute_mock_edge_maps(ctx, agents)  # may return None

    # If compute_mock_edge_maps didn't return anything,
    # try to synthesize beta_cache by inspecting ctx.edge.
    if beta_cache is None:
        beta_cache = {}
        if hasattr(ctx.edge, "_edge_beta"):
            for k, B in ctx.edge._edge_beta.items():
                # k might already be ('q', i, j). If so, grab ids.
                # If it's in some other format, adapt here.
                if isinstance(k, tuple) and len(k) == 3 and isinstance(k[0], str):
                    which, i_id, j_id = k
                    if which == "q":
                        beta_cache[(i_id, j_id)] = B
                elif isinstance(k, tuple) and len(k) == 2:
                    i_id, j_id = k
                    beta_cache[(i_id, j_id)] = B
                # else ignore weird keys

    # Now force-sync so ctx.edge._edge_beta[("q", i,j)] definitely exists
    sync_edge_maps_from_mock(ctx, agents, beta_cache)



def normalize_edge_beta_keys(ctx, agents):
    """
    Normalize attention maps in ctx.edge so that, for EVERY ordered pair
    (i_id,j_id) with i_id != j_id, we have:

        ctx.edge._edge_beta[('q', i_id, j_id)] -> (H,W) float32
        ctx.edge._edge_kl1[ ('q', i_id, j_id)] -> (H,W) float32 dummy

    Behavior:
    - Take whatever compute_mock_edge_maps wrote (any key format).
    - Coerce shapes to (H,W).
    - For missing pairs that *do* overlap spatially, synthesize a normalized
      overlap mask as β.
    - For pairs STILL missing after that (disjoint agents), synthesize an
      all-zero β map.  This makes the induced-connection code happy, and it
      contributes nothing to A because β=0.
    """
    import numpy as np

    # Ensure dicts exist
    if not hasattr(ctx.edge, "_edge_beta"):
        ctx.edge._edge_beta = {}
    if not hasattr(ctx.edge, "_edge_kl1"):
        ctx.edge._edge_kl1 = {}

    H, W = ctx.spatial_shape
    new_beta = {}
    new_kl1  = {}

    # --- 1. Normalize any keys already present from compute_mock_edge_maps ---
    for k, B in list(ctx.edge._edge_beta.items()):
        # Accepted formats:
        #   ('q', i_id, j_id)
        #   (i_id, j_id)
        if isinstance(k, tuple):
            if len(k) == 3 and isinstance(k[0], str):
                which, i_id, j_id = k
            elif len(k) == 2:
                which = "q"
                i_id, j_id = k
            else:
                continue
        else:
            continue

        try:
            i_id = int(i_id)
            j_id = int(j_id)
        except Exception:
            continue

        canon_key = ("q", i_id, j_id)

        B_arr = np.asarray(B, dtype=np.float32)
        # force to (H,W)
        if B_arr.shape != (H, W):
            if B_arr.size == H * W:
                B_arr = B_arr.reshape(H, W).astype(np.float32, copy=False)
            else:
                # Can't coerce shape => skip
                continue

        new_beta[canon_key] = B_arr.copy(order="C")
        new_kl1[canon_key]  = np.zeros_like(B_arr, dtype=np.float32)

    # --- 2. For any overlapping pairs still missing, create an overlap β ---
    for ai in agents:
        for aj in agents:
            if ai.id == aj.id:
                continue

            canon_key = ("q", int(ai.id), int(aj.id))
            if canon_key in new_beta:
                continue

            mb_i = getattr(ai, "mask_bool", None)
            mb_j = getattr(aj, "mask_bool", None)
            if mb_i is None or mb_j is None:
                continue

            overlap = (mb_i & mb_j).astype(np.float32)
            if not np.any(overlap):
                continue  # handle in step 3

            tmp = overlap / (np.sum(overlap) + 1e-8)

            new_beta[canon_key] = tmp.astype(np.float32, copy=False)
            new_kl1[canon_key]  = np.zeros_like(tmp, dtype=np.float32)

    # --- 3. For ALL remaining ordered pairs, even if disjoint, create β=0 ---
    zero_map = np.zeros((H, W), dtype=np.float32)
    for ai in agents:
        for aj in agents:
            if ai.id == aj.id:
                continue

            canon_key = ("q", int(ai.id), int(aj.id))
            if canon_key in new_beta:
                continue

            # no attention between ai and aj in mock world:
            # give an all-zero beta so downstream won't crash
            new_beta[canon_key] = zero_map.copy()
            new_kl1[canon_key]  = np.zeros_like(zero_map, dtype=np.float32)

    # --- 4. Commit canonical entries back into ctx.edge ---
    ctx.edge._edge_beta.update(new_beta)
    ctx.edge._edge_kl1.update(new_kl1)




def main():
    print("\n" + "="*70)
    print("INDUCED CONNECTION - PROJECT INTEGRATION EXAMPLE (FIXED)")
    print("="*70 + "\n")

    from core.runtime_context import RuntimeCtx, EdgeMaps
    from core.utils import prepare_generators
    from agents.agent_initialization import initialize_agents
    from induced_connection import (
        initialize_A_from_attention,
        construct_connection_from_attention,
    )
    import types
    import numpy as np
    from pathlib import Path
    import matplotlib.pyplot as plt

    # ------------------------------------------------------------------
    # 1. Context with config
    # ------------------------------------------------------------------
    ctx_cfg = RuntimeCtx()
    ctx_cfg.config = {
        "domain_size": (16, 16),
        "N": 4,
        "agent_seed": 0,
        "spec_q": [("so3", 1)],
        "spec_p": [("so3", 1)],
    }

    # ------------------------------------------------------------------
    # 2. Demo sim just to get spatial info (spatial grid + masks)
    #    We will NOT keep agents_demo for physics, only for spatial props.
    # ------------------------------------------------------------------
    ctx_raw, agents_demo = create_test_simulation()
    if ctx_raw is None:
        return

    # ------------------------------------------------------------------
    # 3. Merge spatial attrs from ctx_raw into ctx_cfg
    # ------------------------------------------------------------------
    ctx_cfg.spatial_shape = getattr(ctx_raw, "spatial_shape", (16, 16))
    ctx_cfg.ndim          = getattr(ctx_raw, "ndim", 2)
    ctx_cfg.edge          = getattr(ctx_raw, "edge", EdgeMaps())

    if not hasattr(ctx_cfg, "fields"):
        ctx_cfg.fields = {}

    ctx = ctx_cfg  # <- this is now the canonical runtime context

    # ------------------------------------------------------------------
    # 3.5 NEW: seed ctx.fields["A"] with a zero connection so Ω can be built
    #          (_expA_pure needs something shaped like (H,W,ndim,3))
    # ------------------------------------------------------------------
    H, W = ctx.spatial_shape
    ndim = ctx.ndim
    if "A" not in ctx.fields or np.shape(ctx.fields["A"]) == ():
        ctx.fields["A"] = np.zeros((H, W, ndim, 3), dtype=np.float32)

    # ------------------------------------------------------------------
    # 4. Prepare generators + FINAL agents
    #    These final agents are the ones we will hand to the induced A code.
    # ------------------------------------------------------------------
    G_q, G_p = prepare_generators(ctx)

    agents = initialize_agents(
        seed=ctx.config.get("agent_seed", 0),
        domain_size=ctx.config["domain_size"],
        N=ctx.config.get("N", 4),
        lie_algebra_dim=3,
        fixed_location=True,
        generators_q=G_q,
        generators_p=G_p,
    )

    print("[Setup] Using finalized agents from initialize_agents()")
    print(f"   Created {len(agents)} agents in {ctx.config['domain_size']} domain")

    # Copy spatial helpers (position, mask_bool, etc.) from agents_demo → agents
    demo_by_id = {a.id: a for a in agents_demo}
    for a in agents:
        d = demo_by_id.get(a.id, None)
        if d is not None:
            a.position   = getattr(d, "position", None)
            a.mask_bool  = getattr(d, "mask_bool", None)
            a.radius     = getattr(d, "radius", getattr(a, "radius", None))
            a.center     = getattr(d, "center", getattr(a, "center", None))
        else:
            a.position  = np.array([0.0, 0.0], dtype=np.float32)
            a.mask_bool = np.zeros(ctx.spatial_shape, dtype=bool)

    # ------------------------------------------------------------------
    # 5. Build β (attention weights) and Ω (transports) for THESE final agents
    # ------------------------------------------------------------------
    # compute_mock_edge_maps writes attention fields into ctx.edge
    compute_mock_edge_maps(ctx, agents)

    # compute_mock_transports returns Ω_ij fields, but also (critically)
    # exercises transport_cache.Omega(...) which uses ctx.fields["A"]
    # (we already primed A above as zeros with correct shape)
    transports = compute_mock_transports(ctx, agents)

    # Make sure ctx.edge dicts exist before normalizing keys
    if not hasattr(ctx.edge, "_edge_beta"):
        ctx.edge._edge_beta = {}
    if not hasattr(ctx.edge, "_edge_kl1"):
        ctx.edge._edge_kl1 = {}

    # Normalize keys in ctx.edge so they match what induced_connection expects:
    # ('q', i_id, j_id) -> beta_map[H,W], and a dummy KL map with same shape.
    normalize_edge_beta_keys(ctx, agents)

    # ------------------------------------------------------------------
    # 6. Monkey-patch a tolerant ctx.edge.get_align
    #    Supplies (KL_map, beta_map) to induced_connection, allowing
    #    KL to be None/zeros, while enforcing beta shape.
    # ------------------------------------------------------------------
    def _safe_get_align(self, ctx_local, which, i_id, j_id, shape):
        import numpy as np
        k = (str(which), int(i_id), int(j_id))

        beta_map = self._edge_beta.get(k, None)
        KL_map   = self._edge_kl1.get(k, None)

        if beta_map is None:
            raise RuntimeError(
                f"EdgeMaps.get_align missing beta for key={k}"
            )

        B_arr = np.asarray(beta_map)
        if tuple(B_arr.shape) != tuple(shape):
            raise RuntimeError(
                f"EdgeMaps.get_align beta shape mismatch for key={k}: "
                f"B{B_arr.shape} expected {shape}"
            )

        # KL is optional in this integration harness
        if KL_map is not None and not np.isscalar(KL_map):
            KL_arr = np.asarray(KL_map)
            return KL_arr, B_arr

        return None, B_arr

    ctx.edge.get_align = types.MethodType(_safe_get_align, ctx.edge)

    # ------------------------------------------------------------------
    # 7. Try production initializer (Method 1)
    # ------------------------------------------------------------------
    print("\n[Method 1] Using induced_connection module...\n")

    A_induced = None
    try:
        A_induced = initialize_A_from_attention(
            ctx, agents,
            which="q",
            use_spatial_directions=True,
            normalize_per_direction=True,
            verbose=True,
        )

        ctx.fields["A"] = A_induced.astype(np.float32, copy=False)
        print(f"   Constructed A with shape {A_induced.shape}")

    except Exception as e:
        print(f"   initialize_A_from_attention failed: {e}")
        A_induced = None

    # ------------------------------------------------------------------
    # 8. Fallback to direct construct_connection_from_attention (Method 2)
    #    This uses the same project code; we just call it explicitly.
    # ------------------------------------------------------------------
    if A_induced is None:
        print("\n[Method 2] Manual construction from attention + transports...")

        A_induced = construct_connection_from_attention(
            ctx, agents,
            which="q",
            bootstrap_A=False,
            use_spatial_directions=True,
            normalize_per_direction=True,
            verbose=True,
        )

        ctx.fields["A"] = A_induced.astype(np.float32, copy=False)
        print(f"   Constructed A with shape {A_induced.shape}")
        print(f"   Connection norm: ||A|| = {np.linalg.norm(A_induced):.6f}")

    # ------------------------------------------------------------------
    # 9. Visualization
    # ------------------------------------------------------------------
    print("\n[Visualization] Creating plots...")

    output_dir = Path("./induced_connection_integration_outputs")
    output_dir.mkdir(exist_ok=True)

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    for d in range(2):
        # A_induced[..., d, :] is the so(3) vector for direction d per lattice site
        A_dir_norm = np.linalg.norm(A_induced[..., d, :], axis=-1)

        im = axes[d].imshow(A_dir_norm, cmap="RdBu_r", interpolation="nearest")
        axes[d].set_title(f"Connection A ({'xy'[d]}-direction)")
        axes[d].set_xlabel("x")
        axes[d].set_ylabel("y")

        # mark agent positions
        for i, agent in enumerate(agents):
            pos = agent.position
            axes[d].plot(
                pos[1], pos[0],
                "ko",
                markersize=10,
                markerfacecolor="yellow",
                markeredgewidth=2,
            )
            axes[d].text(
                pos[1], pos[0],
                str(i),
                ha="center",
                va="center",
                fontsize=10,
                color="black",
                weight="bold",
            )

        plt.colorbar(im, ax=axes[d], label=f"||A_{d}||")

    plt.suptitle(
        "Attention-Induced Connection with Agent Positions",
        fontsize=14,
        y=1.02,
    )
    plt.tight_layout()
    plot_path = output_dir / "connection_with_agents.png"
    plt.savefig(plot_path, dpi=150, bbox_inches="tight")
    print(f"   Saved to {plot_path}")
    plt.close()

    # ------------------------------------------------------------------
    # 10. Summary
    # ------------------------------------------------------------------
    print("\n" + "="*70)
    print("INTEGRATION SUMMARY")
    print("="*70)

    print(f"""
Successfully demonstrated attention-induced connection with project structure:

1. Context Setup: RuntimeCtx with spatial grid and EdgeMaps
2. Agent Grid: Initialized {len(agents)} agents in {ctx.config['domain_size']} domain
3. Attention Weights βᵢⱼ(x): computed from spatial overlap / proximity
4. Transports Ωᵢⱼ(x): position-dependent SO(3) rotations
5. Connection Field A_μ(x): assembled as Σⱼ βᵢⱼ(x) · log Ωᵢⱼ(x) per direction μ

Connection Statistics
---------------------
- Shape: {A_induced.shape}
- Norm: ||A|| = {np.linalg.norm(A_induced):.6f}
- Range: [{np.min(A_induced):.6f}, {np.max(A_induced):.6f}]

Next Steps
----------
- Swap compute_mock_edge_maps → real edge_maps._build_edge_maps_single_pass
- Swap compute_mock_transports → real Omega(ctx, ...)
- Call initialize_A_from_attention() during sim startup instead of random A
- Optionally refine A with gradient updates (hybrid_connection_update)

Outputs saved under: {Path('./induced_connection_integration_outputs').absolute()}
    """)

    print("="*70 + "\n")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n[ERROR] {e}")
        import traceback
        traceback.print_exc()

        print("\n" + "="*70)
        print("TROUBLESHOOTING")
        print("="*70)
        print("""
If you see import errors:

1. Ensure you're running from the project root directory
2. Or adjust sys.path at the top of this script
3. Or copy this script into your project's examples/ directory

For minimal standalone version (no dependencies):
    python induced_connection_fixed_example.py

Common Issues:
--------------
- Agent construction errors: Check agents/agent_schema.py for required fields
- Import errors: Verify project is in Python path
- Missing functions: Ensure induced_connection_fixed_example.py is present
        """)
