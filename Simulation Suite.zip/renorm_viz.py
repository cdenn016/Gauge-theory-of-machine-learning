#!/usr/bin/env python3
"""
Block Renormalization Visualizations

Creates publication-quality figures showing:
1. Variance reduction across scales
2. Free energy decomposition
3. Determinant corrections
4. RG flow diagrams
5. Lattice visualizations

Author: Validation Suite
"""

import sys
sys.path.insert(0, '/home/claude')

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.gridspec import GridSpec
from mpl_toolkits.mplot3d import Axes3D
import warnings
warnings.filterwarnings('ignore')

from renorm import (
    BlockConfig, create_agent_lattice, perform_blocking,
    compute_microscopic_free_energy, compute_block_decomposition,
    compute_determinant_correction, so3_log, frechet_mean_so3
)


def plot_variance_reduction_scaling():
    """
    Figure 1: Variance reduction as a function of block size
    """
    plt.figure(figsize=(10, 6))
    
    # Test different block sizes
    block_sizes = [2, 4, 8, 16]
    lattice_size = 64
    
    theoretical_reductions = []
    empirical_reductions = []
    empirical_stds = []
    
    for block_size in block_sizes:
        if lattice_size % block_size != 0:
            continue
        
        n_alpha = block_size ** 2
        theoretical_reductions.append(np.sqrt(n_alpha))
        
        # Run multiple trials
        n_trials = 20
        reductions = []
        
        for trial in range(n_trials):
            config = BlockConfig(
                N=lattice_size ** 2,
                lattice_shape=(lattice_size, lattice_size),
                block_shape=(block_size, block_size),
                sigma=0.3,
                gamma=1.0,
                use_periodic=True
            )
            
            agents = create_agent_lattice(config, random_state=trial)
            blocks = perform_blocking(agents, config)
            
            # Compute empirical variances
            block_vars = []
            for block in blocks:
                log_M = so3_log(block.M[np.newaxis])[0]
                block_vars.append(np.linalg.norm(log_M) ** 2)
            
            agent_vars = []
            for agent in agents:
                log_m = so3_log(agent.m[np.newaxis])[0]
                agent_vars.append(np.linalg.norm(log_m) ** 2)
            
            reduction = np.sqrt(np.mean(agent_vars) / np.mean(block_vars))
            reductions.append(reduction)
        
        empirical_reductions.append(np.mean(reductions))
        empirical_stds.append(np.std(reductions))
    
    # Plot
    n_alphas = [b**2 for b in block_sizes[:len(empirical_reductions)]]
    
    plt.errorbar(n_alphas, empirical_reductions, yerr=empirical_stds,
                 marker='o', markersize=8, capsize=5, capthick=2,
                 label='Empirical', linewidth=2, color='#2E86AB')
    
    plt.plot(n_alphas, theoretical_reductions[:len(empirical_reductions)],
             '--', linewidth=2, color='#A23B72', label='Theory: $\\sqrt{n_\\alpha}$')
    
    plt.xlabel('Agents per block ($n_\\alpha$)', fontsize=12)
    plt.ylabel('Variance reduction factor', fontsize=12)
    plt.title('Variance Reduction in Block Priors', fontsize=14, fontweight='bold')
    plt.legend(fontsize=11)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    
    return plt.gcf()


def plot_free_energy_decomposition():
    """
    Figure 2: Free energy decomposition F = F_slow + F_fast
    """
    fig = plt.figure(figsize=(12, 5))
    gs = GridSpec(1, 2, figure=fig)
    
    config = BlockConfig(
        N=64,
        lattice_shape=(8, 8),
        block_shape=(2, 2),
        sigma=0.3,
        gamma=1.0,
        use_periodic=True
    )
    
    # Generate data for multiple coupling strengths
    gammas = np.logspace(-1, 1, 10)
    
    F_micros = []
    F_slows = []
    F_fasts = []
    
    for gamma in gammas:
        config.gamma = gamma
        agents = create_agent_lattice(config, random_state=42)
        blocks = perform_blocking(agents, config)
        
        micro_result = compute_microscopic_free_energy(agents, config)
        decomp_result = compute_block_decomposition(agents, blocks, config)
        
        F_micros.append(micro_result['F_total'])
        F_slows.append(decomp_result['F_slow'])
        F_fasts.append(decomp_result['F_fast'])
    
    # Panel A: Components
    ax1 = fig.add_subplot(gs[0, 0])
    ax1.plot(gammas, F_micros, 'o-', label='$F_{\\rm micro}$', linewidth=2, markersize=6, color='#2E86AB')
    ax1.plot(gammas, F_slows, 's-', label='$F_{\\rm slow}$', linewidth=2, markersize=6, color='#A23B72')
    ax1.plot(gammas, F_fasts, '^-', label='$F_{\\rm fast}$', linewidth=2, markersize=6, color='#F18F01')
    
    ax1.set_xlabel('Coupling strength $\\gamma$', fontsize=11)
    ax1.set_ylabel('Free energy', fontsize=11)
    ax1.set_xscale('log')
    ax1.set_title('(A) Free Energy Components', fontsize=12, fontweight='bold')
    ax1.legend(fontsize=10)
    ax1.grid(True, alpha=0.3)
    
    # Panel B: Reconstruction accuracy
    ax2 = fig.add_subplot(gs[0, 1])
    F_reconstructed = np.array(F_slows) + np.array(F_fasts)
    relative_errors = np.abs(np.array(F_micros) - F_reconstructed) / np.abs(F_micros)
    
    ax2.semilogy(gammas, relative_errors, 'o-', linewidth=2, markersize=6, color='#2E86AB')
    ax2.axhline(y=0.01, color='red', linestyle='--', linewidth=1.5, label='1% error')
    
    ax2.set_xlabel('Coupling strength $\\gamma$', fontsize=11)
    ax2.set_ylabel('Relative error', fontsize=11)
    ax2.set_xscale('log')
    ax2.set_title('(B) Decomposition Accuracy: $|F_{\\rm micro} - (F_{\\rm slow} + F_{\\rm fast})|$',
                  fontsize=11, fontweight='bold')
    ax2.legend(fontsize=10)
    ax2.grid(True, alpha=0.3, which='both')
    
    plt.tight_layout()
    return fig


def plot_entropic_corrections():
    """
    Figure 3: Entropic corrections vs block size
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
    
    # Vary block size
    block_sizes = [2, 3, 4]
    lattice_size = 48
    
    corrections_per_block = []
    theoretical_estimates = []
    n_alphas = []
    
    for block_size in block_sizes:
        if lattice_size % block_size != 0:
            continue
        
        config = BlockConfig(
            N=lattice_size ** 2,
            lattice_shape=(lattice_size, lattice_size),
            block_shape=(block_size, block_size),
            sigma=0.3,
            gamma=1.0,
            use_periodic=True
        )
        
        agents = create_agent_lattice(config, random_state=42)
        blocks = perform_blocking(agents, config)
        
        det_result = compute_determinant_correction(agents, blocks, config)
        corrections_per_block.append(det_result['mean_correction'])
        
        n_alpha = block_size ** 2
        n_alphas.append(n_alpha)
        
        # Theoretical estimate
        d = 3
        theoretical = 0.5 * d * (n_alpha - 1) * np.log(
            1.0 / config.sigma ** 2 + n_alpha * config.gamma
        )
        theoretical_estimates.append(theoretical)
    
    # Panel A: Corrections vs block size
    ax1.plot(n_alphas, corrections_per_block, 'o-', markersize=8, linewidth=2,
             label='Numerical', color='#2E86AB')
    ax1.plot(n_alphas, theoretical_estimates, 's--', markersize=8, linewidth=2,
             label='Theory: $\\frac{3}{2}(n_\\alpha-1)\\log(\\sigma^{-2}+n_\\alpha\\gamma)$',
             color='#A23B72')
    
    ax1.set_xlabel('Agents per block ($n_\\alpha$)', fontsize=11)
    ax1.set_ylabel('Entropic correction per block', fontsize=11)
    ax1.set_title('(A) Determinant Corrections', fontsize=12, fontweight='bold')
    ax1.legend(fontsize=9)
    ax1.grid(True, alpha=0.3)
    
    # Panel B: Scaling with coupling strength
    gammas = np.logspace(-1, 1, 10)
    corrections_vs_gamma = []
    
    config = BlockConfig(
        N=64,
        lattice_shape=(8, 8),
        block_shape=(2, 2),
        sigma=0.3,
        gamma=1.0,
        use_periodic=True
    )
    
    for gamma in gammas:
        config.gamma = gamma
        agents = create_agent_lattice(config, random_state=42)
        blocks = perform_blocking(agents, config)
        det_result = compute_determinant_correction(agents, blocks, config)
        corrections_vs_gamma.append(det_result['mean_correction'])
    
    ax2.plot(gammas, corrections_vs_gamma, 'o-', markersize=6, linewidth=2, color='#2E86AB')
    ax2.set_xlabel('Coupling strength $\\gamma$', fontsize=11)
    ax2.set_ylabel('Mean correction per block', fontsize=11)
    ax2.set_xscale('log')
    ax2.set_title('(B) Corrections vs Coupling Strength', fontsize=12, fontweight='bold')
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    return fig


def plot_rg_flow():
    """
    Figure 4: RG flow showing variance reduction across scales
    """
    fig, ax = plt.subplots(figsize=(10, 8))
    
    # Start with fine lattice
    lattice_size = 32
    block_size = 2
    
    config = BlockConfig(
        N=lattice_size ** 2,
        lattice_shape=(lattice_size, lattice_size),
        block_shape=(block_size, block_size),
        sigma=0.5,
        gamma=1.0,
        use_periodic=True
    )
    
    # Track scales
    scales = [0]
    sigmas = [config.sigma ** 2]
    n_agents_list = [lattice_size ** 2]
    
    current_agents = create_agent_lattice(config, random_state=42)
    current_config = config
    
    # Recursive blocking
    for scale in range(1, 5):
        if min(current_config.n_blocks) < 2:
            break
        
        blocks = perform_blocking(current_agents, current_config)
        
        # New variance
        new_sigma_sq = current_config.sigma ** 2 / (block_size ** 2)
        sigmas.append(new_sigma_sq)
        scales.append(scale)
        n_agents_list.append(len(blocks))
        
        # Prepare for next iteration
        current_config = BlockConfig(
            N=len(blocks),
            lattice_shape=current_config.n_blocks,
            block_shape=(min(2, current_config.n_blocks[0]), min(2, current_config.n_blocks[1])),
            sigma=np.sqrt(new_sigma_sq),
            gamma=current_config.gamma,
            use_periodic=True
        )
        
        # Treat blocks as new agents
        from renorm import AgentState
        current_agents = []
        for block in blocks:
            current_agents.append(AgentState(
                m=block.M,
                mu=np.eye(3),
                Sigma=block.Sigma_block,
                Sigma_inv=block.Sigma_block_inv,
                position=block.position
            ))
    
    # Plot RG flow
    ax.plot(scales, sigmas, 'o-', markersize=10, linewidth=3, color='#2E86AB',
            label='Variance $\\sigma^2$')
    
    # Add annotations
    for i, (scale, sigma, n_agents) in enumerate(zip(scales, sigmas, n_agents_list)):
        ax.annotate(f'$N={n_agents}$',
                   xy=(scale, sigma), xytext=(10, 10),
                   textcoords='offset points', fontsize=10,
                   bbox=dict(boxstyle='round,pad=0.3', facecolor='yellow', alpha=0.3))
    
    ax.set_xlabel('RG Scale (blocking iteration)', fontsize=12)
    ax.set_ylabel('Prior variance $\\sigma^2$', fontsize=12)
    ax.set_yscale('log')
    ax.set_title('Renormalization Group Flow: Variance Reduction', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, which='both')
    ax.legend(fontsize=11)
    
    # Add theoretical curve
    scale_fine = np.linspace(0, max(scales), 100)
    sigma_theory = sigmas[0] / (block_size ** 2) ** scale_fine
    ax.plot(scale_fine, sigma_theory, '--', linewidth=2, color='#A23B72',
            label=f'Theory: $\\sigma_0^2 / {block_size**2}^\\ell$', alpha=0.7)
    ax.legend(fontsize=11)
    
    plt.tight_layout()
    return fig


def plot_lattice_visualization():
    """
    Figure 5: Visual representation of blocking structure
    """
    fig = plt.figure(figsize=(14, 6))
    gs = GridSpec(1, 2, figure=fig)
    
    config = BlockConfig(
        N=64,
        lattice_shape=(8, 8),
        block_shape=(2, 2),
        sigma=0.3,
        gamma=1.0,
        use_periodic=True
    )
    
    agents = create_agent_lattice(config, random_state=42)
    blocks = perform_blocking(agents, config)
    
    # Panel A: Agent orientations
    ax1 = fig.add_subplot(gs[0, 0])
    
    # Visualize rotation angles
    orientations = np.zeros((8, 8))
    for agent in agents:
        i, j = agent.position
        log_m = so3_log(agent.m[np.newaxis])[0]
        angle = np.linalg.norm(log_m)
        orientations[i, j] = angle
    
    im1 = ax1.imshow(orientations, cmap='viridis', origin='lower')
    ax1.set_title('(A) Individual Agent Orientations', fontsize=12, fontweight='bold')
    ax1.set_xlabel('Lattice position $x$', fontsize=11)
    ax1.set_ylabel('Lattice position $y$', fontsize=11)
    plt.colorbar(im1, ax=ax1, label='Rotation angle (radians)')
    
    # Draw block boundaries
    for i in range(0, 8, 2):
        ax1.axhline(i-0.5, color='red', linewidth=2, alpha=0.7)
        ax1.axvline(i-0.5, color='red', linewidth=2, alpha=0.7)
    
    # Panel B: Block mean orientations
    ax2 = fig.add_subplot(gs[0, 1])
    
    block_orientations = np.zeros((4, 4))
    for block in blocks:
        bi, bj = block.position
        log_M = so3_log(block.M[np.newaxis])[0]
        angle = np.linalg.norm(log_M)
        block_orientations[bi, bj] = angle
    
    im2 = ax2.imshow(block_orientations, cmap='viridis', origin='lower', interpolation='nearest')
    ax2.set_title('(B) Block Mean Orientations', fontsize=12, fontweight='bold')
    ax2.set_xlabel('Block position $x$', fontsize=11)
    ax2.set_ylabel('Block position $y$', fontsize=11)
    plt.colorbar(im2, ax=ax2, label='Mean rotation angle (radians)')
    
    plt.tight_layout()
    return fig


def create_all_figures():
    """Generate all figures and save to outputs"""
    print("Generating visualization figures...")
    print()
    
    # Figure 1
    print("Creating Figure 1: Variance Reduction Scaling...")
    fig1 = plot_variance_reduction_scaling()
    fig1.savefig('./plots//fig1_variance_reduction.png', dpi=300, bbox_inches='tight')
    print("  ✓ Saved to fig1_variance_reduction.png")
    
    # Figure 2
    print("Creating Figure 2: Free Energy Decomposition...")
    fig2 = plot_free_energy_decomposition()
    fig2.savefig('./plots/fig2_free_energy.png', dpi=300, bbox_inches='tight')
    print("  ✓ Saved to fig2_free_energy.png")
    
    # Figure 3
    print("Creating Figure 3: Entropic Corrections...")
    fig3 = plot_entropic_corrections()
    fig3.savefig('./plots/fig3_entropic_corrections.png', dpi=300, bbox_inches='tight')
    print("  ✓ Saved to fig3_entropic_corrections.png")
    
    # Figure 4
    print("Creating Figure 4: RG Flow...")
    fig4 = plot_rg_flow()
    fig4.savefig('./plots/fig4_rg_flow.png', dpi=300, bbox_inches='tight')
    print("  ✓ Saved to fig4_rg_flow.png")
    
    # Figure 5
    print("Creating Figure 5: Lattice Visualization...")
    fig5 = plot_lattice_visualization()
    fig5.savefig('./plots/fig5_lattice_visualization.png', dpi=300, bbox_inches='tight')
    print("  ✓ Saved to fig5_lattice_visualization.png")
    
    print()
    print("All figures generated successfully!")
    
    plt.close('all')


if __name__ == "__main__":
    create_all_figures()