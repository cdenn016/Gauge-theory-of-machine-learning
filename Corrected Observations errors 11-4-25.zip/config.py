"""
config.py - Gauge-Theoretic Free Energy Configuration
======================================================

This configuration studies PURE BELIEF DYNAMICS with static gauge geometry:
    F[q] = KL(q_i || p_i) + β_ij KL(q_i || Ω_ij q_j) - E_q[log p(o|c)]
    
All model (p), gauge frames (φ, φ̃), and curvature (A) fields are FROZEN.
"""

# ==============================================================================
# SPATIAL DOMAIN
# ==============================================================================

D                              = 2                               # Spatial dimension
L                              = 4                               # Grid size (L^D total sites)
domain_size = (L,) * D              # Derived

# ==============================================================================
# AGENT CONFIGURATION
# ==============================================================================
N                               = 20                               # Number of agents
max_neighbors                   = 20                   # Max neighbors per agent

# ==============================================================================
# SIMULATION
# ==============================================================================
steps                           = 250                        # Total optimization steps

# Fiber - SO(3) representations
ell_q                           = 9                           # Highest ℓ (angular momentum)
ell_p                           = 9

# Agent geometry
agent_radius_range              = (1, 1)         # (min, max) agent radii

fixed_location                  = True               # Fixed vs. mobile agents
point_agents                    = False                # True = point masses, False = extended agents

# Agent initialization
agent_seed                      = 241                    # Random seed for reproducibility

# ==============================================================================
# FIBER SPECIFICATIONS (Representation Theory)
# ==============================================================================

spec_q                         = [(ell_q, 1)]               # [(ℓ, multiplicity)] - single irrep
spec_p                         = [(ell_p, 1)]

mix_generators_q               = False            # Use canonical SO(3) generators
mix_generators_p               = False

# ==============================================================================
# NUMERICAL STABILITY
# ==============================================================================

eps                            = 1e-8                          # General-purpose regularization floor
support_tau                    = 0.2                   # Mask threshold for agent support
overlap_eps                    = 1e-3                  # Threshold for inter-agent overlap

# Covariance manifold retraction
sigma_retraction_mode          = "exp"       # "exp" (exact SPD) or "linear" (first-order)
sigma_rel_step_max             = 1e-1           # Trust region radius (geodesic step limit)

# ==============================================================================
# ENERGY WEIGHTS
# ==============================================================================

# Self-consistency and feedback
alpha                          = 1                 # Self-energy: KL(q || p') weight
feedback_weight                = 0.0                  # Feedback: KL(p || q') weight (DISABLED)

# Alignment (β-coupling)
beta_kappa_q                   = 1.0                  # Softmax temperature for belief alignment
beta_kappa_p                   = 1.0                  # (Unused when use_alignment_p = False)


# Curvature (A-field)
lambda_A_curv                  = 0.0                 # Intrinsic curvature weight (DISABLED)
lambda_A_cov                   = 0.0                  # Covariant φ-A coupling weight (DISABLED)
A_init_scale                   = 0.0                  # Initialize A to zero (flat connection)


# ==============================================================================
# OBSERVATION MODEL (Currently disabled via obs_scale = 0)
# ==============================================================================
obs_scale                      = 1                     # Observation log p(o|c) weight (DISABLED for now)

D_x                            = 8                             # Observation space dimension
obs_W_scale                    = 0.5                   # Observation matrix W initialization scale
obs_Lambda_scale               = 0.3              # Precision matrix Λ initialization scale
obs_noise_scale                = 0.2               # Per-agent observation noise
obs_bias_scale                 = 0.3                # Per-agent observation bias



# ==============================================================================
# LEARNING RATES
# ==============================================================================

# Belief parameters (ACTIVE)
tau_mu_belief                  = 1e-1                # Belief mean learning rate
tau_sigma_belief               = 1e-1             # Belief covariance learning rate

# Model parameters (FROZEN)
tau_mu_model                   = 0.0                  # Model mean (frozen via freeze flag)
tau_sigma_model                = 0.0               # Model covariance (frozen via freeze flag)

# Gauge frames (FROZEN)
tau_phi                        = 0.0                       # Belief frame (frozen via freeze flag)
tau_phi_model                  = 0.0                 # Model frame (frozen via freeze flag)

# Global gauge field (FROZEN)
A_lr                           = 0.0                          # Connection field (frozen via freeze flag)

# ==============================================================================
# FREEZE FLAGS (Master Switches)
# ==============================================================================

# Belief/Model Parameters
freeze_mu_sigma_q              = False           # ✅ Belief updates ACTIVE
freeze_mu_sigma_p              = True            # ❌ Model updates FROZEN

# Gauge Frames
freeze_phi_q                   = True                 # ❌ Belief frames FROZEN (static geometry)
freeze_phi_p                   = True                 # ❌ Model frames FROZEN (static geometry)

# Global Gauge Field
freeze_A                       = True                     # ❌ Connection field FROZEN (no curvature)

# ==============================================================================
# ALIGNMENT & COUPLING TOGGLES
# ==============================================================================

# β-Alignment (pairwise KL minimization)
use_alignment_q               = True              # ✅ Belief alignment ACTIVE
use_alignment_p               = False             # ❌ Model alignment DISABLED

# γ-Coupling (cross-fiber terms) - ALL DISABLED
use_gamma_block_q             = False           # Gamma block for belief
use_gamma_block_p             = False           # Gamma block for model
use_gamma_A                   = False                 # Gamma case A (j→i transport)
use_gamma_B                   = False                 # Gamma case B (i→j transport)

# Cross-fiber coupling (γ-terms)
kappa_gamma_q                  = 1.0                 # Temperature for belief γ-coupling (if enabled)
kappa_gamma_p                  = 1.0                 # Temperature for model γ-coupling (if enabled)



# Gradient accumulation
accumulate_sender_grads       = True      # Accumulate sender terms during pairwise pass

# ==============================================================================
# INITIALIZATION RANGES
# ==============================================================================

# Belief bundle (q)
q_mu_range                    = (-3.0, 3.0)            # Initial belief mean range
q_sigma_range                 = (0.2, 3.0)          # Initial belief covariance diagonal range

# Model bundle (p)
p_mu_range                    = (-3.0, 3.0)            # Initial model mean range
p_sigma_range                 = (0.2, 3.0)          # Initial model covariance diagonal range

# Gauge frames
phi_init                      = 0.25                     # Initial φ (belief frame) magnitude
phi_model_offset              = 0.15             # Offset for φ̃ (model frame)
phi_init_smooth_sigma         = 2.0         # Spatial smoothing for initial frames

# Model diversity
diagonal_sigma                = False              # Use full covariance matrices
identical_models              = True             # All agents share same initial model frame



# ==============================================================================
# GRADIENT CLIPPING
# ==============================================================================

gradient_clip_phi             = -1              # Max ||∇φ|| per voxel (-1 = no clip)
gradient_clip_phi_model       = -1        # Max ||∇φ̃|| per voxel (-1 = no clip)
A_grad_clip                   = -1                    # Max ||∇A|| global (-1 = no clip)

# ==============================================================================
# TRANSPORT & CACHING
# ==============================================================================

transport_backend             = "pure"          # "pure" = functional/loky-safe, "ctx" = stateful
freeze_omega_mode             = "none"          # "none" | "identity" (for ablation studies)

# Shared cache (optional - speeds up repeated runs)
shared_cache_dir              = "F:/_shared_cache"  # Path to persistent cache (or None)

# ==============================================================================
# PARALLEL EXECUTION
# ==============================================================================

n_jobs                        = 20                         # Number of parallel workers
joblib_prefer                 = "processes"         # "processes" or "threads"
joblib_memmap_threshold       = "10G"     # Memmap threshold for large arrays
blas_threads_per_worker       = 1         # BLAS threads per worker (avoid oversubscription)



# ==============================================================================
# DIAGNOSTICS & DEBUGGING
# ==============================================================================

debug_phase_timing = False          # Print detailed phase timings
debug_grad_timing  = False           # Print gradient computation timings

# ==============================================================================
# CONFIGURATION SUMMARY
# ==============================================================================
"""
ACTIVE TERMS:
  ✅ KL(q_i || p_i)                    [Self-energy, weight α=1.0]
  ✅ Σ_j β_ij KL(q_i || Ω_ij q_j)      [Alignment, temperature κ=1.0]
  ❌ -E_q[log p(o|c)]                  [Observation, weight=0.0 - DISABLED]

FROZEN FIELDS:
  ❌ All model parameters (μ_p, Σ_p)
  ❌ All gauge frames (φ_q, φ_p)  
  ❌ Global gauge field (A)
  ❌ Feedback term KL(p || q')
  ❌ All γ cross-fiber couplings
  ❌ All curvature energies

RESULT: Pure belief dynamics on a STATIC gauge geometry.
"""

# ==============================================================================
# VALIDATION (Optional - uncomment to run at import)
# ==============================================================================

# def _validate_config():
#     """Sanity checks for config consistency."""
#     assert D >= 1, "Spatial dimension must be positive"
#     assert L >= 2, "Grid must have at least 2 points per dimension"
#     assert N >= 1, "Must have at least one agent"
#     assert alpha >= 0, "Energy weights must be non-negative"
#     assert sigma_rel_step_max > 0, "Trust region must be positive"
#     assert tau_mu_belief >= 0 and tau_sigma_belief >= 0, "Learning rates must be non-negative"
#     
#     if freeze_mu_sigma_q and freeze_mu_sigma_p:
#         print("⚠️  WARNING: Both belief and model are frozen - no learning will occur!")
#     
#     if not use_alignment_q and not use_gamma_block_q and alpha == 0 and obs_scale == 0:
#         print("⚠️  WARNING: No active energy terms for belief - gradients will be zero!")
#     
#     print("✅ Configuration validation passed")
#
# _validate_config()