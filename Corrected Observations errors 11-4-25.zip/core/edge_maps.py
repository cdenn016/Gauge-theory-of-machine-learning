# -*- coding: utf-8 -*-
"""
Created on Sat Sep 27 15:19:10 2025

@author: chris and christine

gamma_q: Case A:  KL( q_j ||Ω^q_ji Φ̃_i p_i )
gamma_p: Case B:  KL( p_i || Φ_i Ω^q_ij q_j )  

beta_q:  KL( q_i || Ω^q_ij q_j )
beta_p:  KL( p_i || Ω^p_ij p_j ) 

"""
from typing import Tuple, Optional
import numpy as np
from core.numerical_utils import kl_gaussian, push_gaussian
from core.transport_cache import Omega,  Phi
from core.utils import joint_masks
from core.runtime_context import cfg_get, EdgeMaps
from agents.agent_accessor import AA


# -*- coding: utf-8 -*-
"""
Single-pass edge map construction.

Consolidates alignment (β_q, β_p) and cross-fiber (γ_A, γ_B) metrics into
one iteration over agent pairs, eliminating redundant transport lookups and
field accesses.

Key functions:
  - compute_all_edge_maps: Main entry point (replaces compute_edge_phase)
  - _build_edge_maps_single_pass: Core single-pass loop
  
All functions maintain identical behavior to the original 3-pass implementation
in beta.py (compute_edge_betas + compute_edge_gammas).
"""




# ──────────────────────────────────────────────────────────────────────────────
# Main Entry Point
# ──────────────────────────────────────────────────────────────────────────────

from updates.gradient_utils import get_mu_sigma_config  # <-- you may need to fix this import


def _edge_build_flags_from_cfg(ctx):
    """
    Decide which edge maps to build this step, based on config.

    Returns:
        build_q:      build β_q / KL_q maps?
        build_p:      build β_p / KL_p maps?
        build_gamma:  build γ_A / γ_B maps?
    """
    cfg = get_mu_sigma_config(ctx)

    # Alignment toggles (β):
    use_align_q = cfg.get("use_alignment_q", True)
    use_align_p = cfg.get("use_alignment_p", False)

    # Gamma toggles:
    use_gamma_q = cfg.get("use_gamma_block_q", False)
    use_gamma_p = cfg.get("use_gamma_block_p", False)

    # We should build gamma edge maps ONLY if *any* gamma branch will actually
    # be consumed downstream. In practice γ_A couples q→p and γ_B couples p→q,
    # and both ultimately feed the gamma gradients. If both are off, skip.
    build_gamma = (use_gamma_q or use_gamma_p)

    # If p-alignment is off, we don't need β_p at all.
    build_q = bool(use_align_q)
    build_p = bool(use_align_p)

    return build_q, build_p, build_gamma


def compute_all_edge_maps(ctx, agents):
    """
    Public entry point for edge map construction.

    Uses config toggles to decide which maps to actually build.
    This prevents wasting work on γ edge maps when γ gradients are disabled,
    and similarly lets us skip p-fiber alignment if p-align is off.

    Side effects:
      - ctx.edge is populated (or cleared) for the requested fibers
      - No γ transports / Φ fetches happen if gamma is disabled
    """
    if ctx is None:
        raise RuntimeError("compute_all_edge_maps: ctx required.")

    build_q, build_p, build_gamma = _edge_build_flags_from_cfg(ctx)

    # numerical eps for push_gaussian / KL safety
    eps = float(cfg_get(ctx, "eps", 1e-6))

    return _build_edge_maps_single_pass(
        ctx,
        agents,
        build_q=build_q,
        build_p=build_p,
        build_gamma=build_gamma,
        eps=eps,
    )


def _build_edge_maps_single_pass(
    ctx,
    agents,
    *,
    build_q: bool,
    build_p: bool,
    build_gamma: bool,
    eps: float
):
    """
    Core loop: one iteration over (i,j) pairs with no redundant work.
    Populates all edge structures in a single traversal.
    
    Algorithm:
      1. Pre-flight: validate agents, initialize edge storage
      2. Resolve config (kappa, tolerances)
      3. For each receiver i:
           a. Extract agent fields once
           b. Initialize alignment accumulators (if needed)
           c. For each sender j != i:
                - Compute overlap mask once
                - Fetch all required transports once
                - Compute alignment KLs (if enabled)
                - Accumulate alignment logits
                - Compute gamma maps (if enabled) and write immediately
           d. Finalize alignment softmax and write β maps
      4. Return updated ctx
    """
    # ---- Pre-flight ----
    if not agents:
        _clear_edge_storage(ctx, build_q, build_p, build_gamma)
        return ctx
    
    if not (build_q or build_p or build_gamma):
        # Ensure ctx.edge has empty containers so downstream code doesn't explode.
        if not hasattr(ctx, "edge") or ctx.edge is None:
            ctx.edge = EdgeMaps()
        # normalize the subdicts we usually rely on:
        ctx.edge.beta   = {}
        ctx.edge.kl     = {}
        ctx.edge.mask   = {}
        ctx.edge.gamma  = {}
        ctx.edge.align  = {}
        return ctx.edge  # <-- EARLY RETURN

    
    
    # ---- Config resolution ----
    kappa_q = float(cfg_get(ctx, "kappa_q", 1))
    kappa_p = float(cfg_get(ctx, "kappa_p", 1))
    tol = float(cfg_get(ctx, "beta_norm_tolerance", 1e-4))
    
    # Gamma config
    if build_gamma:
        cfg = getattr(ctx, "gamma_cfg", {}) or {}
        kappa_gamma_q = float(cfg.get("kappa_q", 1.0))
        kappa_gamma_p = float(cfg.get("kappa_p", 1.0))
        gamma_tol = float(cfg.get("tol", 1e-6))
    
    # ---- Initialize EdgeMaps if needed ----
    if not hasattr(ctx, "edge") or ctx.edge is None:
        ctx.edge = EdgeMaps()
    
    # Clear relevant storage
    if build_q:
        ctx.edge.clear_fiber("q")
    if build_p:
        ctx.edge.clear_fiber("p")
    if build_gamma:
        ctx.edge.gamma.clear()
        ctx.edge.klX.clear()
    
    # ---- ID mapping ----
    ids = [AA.get_id(a) for a in agents]
    
    # ---- Main loop: iterate once over receivers ----
    for i_idx, ai in enumerate(agents):
        i_id = ids[i_idx]
        
        # Pre-fetch receiver fields ONCE
        fields_i = _extract_agent_fields(ai, need_q=build_q, need_p=build_p)
        Sshape = fields_i["shape"]
        
        # Accumulators for softmax (if alignment enabled)
        align_state = None
        if build_q or build_p:
            align_state = _init_alignment_accumulators(Sshape, build_q, build_p)
        
        # ---- Inner loop: iterate over senders ----
        for j_idx, aj in enumerate(agents):
            if j_idx == i_idx:
                continue
            
            j_id = ids[j_idx]
            
            # Compute overlap mask ONCE per edge
            mbool, mvec = joint_masks(ctx, ai, aj)
            if not np.any(mbool):
                # Write explicit zeros for non-overlapping pairs
                _write_zero_edges(ctx, i_id, j_id, Sshape,
                                 build_q, build_p, build_gamma)
                continue
            
            # Pre-fetch sender fields ONCE
            fields_j = _extract_agent_fields(aj, need_q=build_q, need_p=build_p)
            
            # Fetch transports ONCE per edge (leverages cache)
            transports = _fetch_edge_transports(
                ctx, ai, aj,
                need_Om_q=(build_q or build_gamma),
                need_Om_p=build_p,
                need_Om_q_inv=build_gamma,  # Ω_ji for Case A
                need_Phi=(build_gamma and fields_i["has_p"]),
                need_Phi_tilde=(build_gamma and fields_i["has_p"])
            )
            
            # ---- Alignment branch (β, KL_align) ----
            if build_q or build_p:
                kl_q, kl_p = _compute_alignment_kls(
                    fields_i, fields_j, transports,
                    build_q, build_p, eps
                )
                _accumulate_alignment_logits(
                    align_state, j_idx, j_id, kl_q, kl_p,
                    kappa_q, kappa_p, mbool, eps
                )
            
            # ---- Cross-fiber branch (γ_A, γ_B) ----
            if build_gamma and fields_i["has_p"] and fields_j["has_q"]:
                gamma_A, gamma_B, kl_A, kl_B = _compute_gamma_maps(
                    fields_i, fields_j, transports,
                    kappa_gamma_q, kappa_gamma_p, mbool, eps
                )
                # Write immediately (no softmax aggregation)
                ctx.edge.set_gamma(ctx, "A", j_id, i_id,
                                  gamma_map=gamma_A, kl_map=kl_A)
                ctx.edge.set_gamma(ctx, "B", i_id, j_id,
                                  gamma_map=gamma_B, kl_map=kl_B)
                
                # Check invariants
                _check_gamma_invariants(ctx, gamma_A[mbool], kl_A[mbool],
                                       which="A", i_id=i_id, j_id=j_id, tol=gamma_tol)
                _check_gamma_invariants(ctx, gamma_B[mbool], kl_B[mbool],
                                       which="B", i_id=i_id, j_id=j_id, tol=gamma_tol)
        
        # ---- End of senders loop: finalize alignment softmax ----
        if align_state is not None:
            _finalize_alignment_softmax(
                ctx, align_state, i_id, Sshape,
                build_q, build_p, tol
            )
    
    return ctx


# ──────────────────────────────────────────────────────────────────────────────
# Helper: Field Extraction
# ──────────────────────────────────────────────────────────────────────────────

def _extract_agent_fields(agent, *, need_q: bool, need_p: bool) -> dict:
    """Extract and sanitize agent fields once per agent in the loop."""
    # Use AgentAccessor's bulk extraction (does everything above)
    return AA.extract_fields(agent, need_q=need_q, need_p=need_p)

# ──────────────────────────────────────────────────────────────────────────────
# Helper: Transport Fetching
# ──────────────────────────────────────────────────────────────────────────────

def _fetch_edge_transports(
    ctx,
    agent_i,
    agent_j,
    *,
    need_Om_q: bool = False,
    need_Om_p: bool = False,
    need_Om_q_inv: bool = False,
    need_Phi: bool = False,
    need_Phi_tilde: bool = False
) -> dict:
    """
    Fetch all required transport maps for edge (i→j) in one call.
    Leverages transport_cache.py memoization.
    
    Args:
        ctx: Runtime context
        agent_i: Receiver agent
        agent_j: Sender agent
        need_Om_q: If True, fetch Ω^q_ij (j→i in q-fiber)
        need_Om_p: If True, fetch Ω^p_ij (j→i in p-fiber)
        need_Om_q_inv: If True, fetch Ω^q_ji (i→j, for gamma Case A)
        need_Phi: If True, fetch Φ_i (q→p morphism)
        need_Phi_tilde: If True, fetch Φ̃_i (p→q morphism)
    
    Returns:
        dict with requested transports as keys (all float64):
          - Om_q: Ω^q_ij
          - Om_p: Ω^p_ij
          - Om_q_inv: Ω^q_ji (reverse direction)
          - Phi: Φ_i
          - Phi_tilde: Φ̃_i
    
    Notes:
        - All arrays cast to float64 for precision in KL computations
        - Omega/Phi calls leverage SharedDiskCache automatically
        - Missing transports are omitted from returned dict
    """
    out = {}
    
    if need_Om_q:
        out["Om_q"] = np.asarray(
            Omega(ctx, agent_i, agent_j, which="q"),
            np.float64
        )
    
    if need_Om_p:
        out["Om_p"] = np.asarray(
            Omega(ctx, agent_i, agent_j, which="p"),
            np.float64
        )
    
    if need_Om_q_inv:
        # For Case A: need reverse transport Ω_ji (from i to j)
        out["Om_q_inv"] = np.asarray(
            Omega(ctx, agent_j, agent_i, which="q"),
            np.float64
        )
    
    if need_Phi:
        out["Phi"] = np.asarray(
            Phi(ctx, agent_i, kind="q_to_p"),
            np.float64
        )
    
    if need_Phi_tilde:
        out["Phi_tilde"] = np.asarray(
            Phi(ctx, agent_i, kind="p_to_q"),
            np.float64
        )
    
    return out


# ──────────────────────────────────────────────────────────────────────────────
# Helper: Alignment KL Computation
# ──────────────────────────────────────────────────────────────────────────────

def _compute_alignment_kls(
    fields_i: dict,
    fields_j: dict,
    transports: dict,
    build_q: bool,
    build_p: bool,
    eps: float
) -> Tuple[Optional[np.ndarray], Optional[np.ndarray]]:
    """
    Compute alignment KL divergences for q and/or p fibers.
    
    Alignment KL measures how well receiver i's belief aligns with
    the transported sender j's belief:
      - KL_q: KL(q_i || Ω^q_ij q_j)
      - KL_p: KL(p_i || Ω^p_ij p_j)
    
    Args:
        fields_i: Receiver fields from _extract_agent_fields
        fields_j: Sender fields from _extract_agent_fields
        transports: Transport maps from _fetch_edge_transports
        build_q: If True, compute q-fiber KL
        build_p: If True, compute p-fiber KL
        eps: Numerical stability epsilon
    
    Returns:
        (kl_q, kl_p) tuple where each is:
          - np.ndarray shape (*S,) float32 if computed
          - None if not requested
    
    Notes:
        - Uses push_gaussian to transport sender's distribution
        - Returns float32 for memory efficiency
    """
    kl_q, kl_p = None, None
        
    if build_q and "Om_q" in transports:
        # Transport j's q-distribution into i's frame
        mu_j_t, S_j_t = push_gaussian(
            fields_j["mu_q"],
            fields_j["sigma_q"],
            transports["Om_q"],
            eps=eps
        )[:2]
        
        # Compute KL divergence
        kl_q = kl_gaussian(
            fields_i["mu_q"],
            fields_i["sigma_q"],
            mu_j_t,
            S_j_t,
            eps=eps
        )
        
             
        kl_q = kl_q.astype(np.float32, copy=False)
    
    if build_p and "Om_p" in transports:
        # Transport j's p-distribution into i's frame
        mu_j_t, S_j_t = push_gaussian(
            fields_j["mu_p"],
            fields_j["sigma_p"],
            transports["Om_p"],
            eps=eps
        )[:2]
        
        # Compute KL divergence
        kl_p = kl_gaussian(
            fields_i["mu_p"],
            fields_i["sigma_p"],
            mu_j_t,
            S_j_t,
            eps=eps
        )
        
           
        kl_p = kl_p.astype(np.float32, copy=False)
    
    return kl_q, kl_p


# ──────────────────────────────────────────────────────────────────────────────
# Helper: Gamma Map Computation
# ──────────────────────────────────────────────────────────────────────────────

def _compute_gamma_maps(
    fields_i: dict,
    fields_j: dict,
    transports: dict,
    kappa_q: float,
    kappa_p: float,
    mbool: np.ndarray,
    eps: float
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Compute cross-fiber γ maps and their KL diagnostics.
    
    Cross-fiber coupling measures how well beliefs align across the
    q/p fiber boundary via morphisms:
    
    Case A: γ_A(j→i, x) = exp(-KL(q_j || Ω^q_ji[Φ̃_i p_i]) / κ_q)
      Interpretation: How well j's sensory belief matches i's motor plan
                      transported to j's frame
    
    Case B: γ_B(i→j, x) = exp(-KL(p_i || Φ_i[Ω^q_ij q_j]) / κ_p)
      Interpretation: How well i's motor plan matches j's sensory input
                      transported to i's frame and lifted to motor space
    
    Args:
        fields_i: Receiver fields (must have p-fiber)
        fields_j: Sender fields (must have q-fiber)
        transports: Must contain Om_q, Om_q_inv, Phi, Phi_tilde
        kappa_q: Temperature for Case A (q-fiber)
        kappa_p: Temperature for Case B (p-fiber)
        mbool: Overlap mask (*S,) boolean
        eps: Numerical stability epsilon
    
    Returns:
        (gamma_A, gamma_B, kl_A, kl_B) all shape (*S,) float32
        where gamma and KL are zero off the overlap mask
    
    Notes:
        - Computes on full lattice but only populates overlap region
        - Uses float64 internally for precision, casts to float32 for storage
        - Clips negative KL to zero (numerical artifacts)
    """
    Sshape = fields_i["shape"]
    
    # Pre-allocate (full lattice, float64 for precision during exp)
    gA = np.zeros(Sshape, np.float64)
    gB = np.zeros(Sshape, np.float64)
    kA = np.zeros(Sshape, np.float64)
    kB = np.zeros(Sshape, np.float64)
    
    # ---- Case A: KL(q_j || Ω_ji[Φ̃_i p_i]) ----
    # Path: p_i → Φ̃_i → q-space → Ω_ji → neighbor j's q-space
    
    # Step 1: Lift i's motor plan to sensory space via inverse morphism
    mu_pi_q, S_pi_q = push_gaussian(
        fields_i["mu_p"],
        fields_i["sigma_p"],
        transports["Phi_tilde"],
        eps=eps
    )[:2]
    
    # Step 2: Transport to j's q-frame via reverse connection
    mu_pi_q_j, S_pi_q_j = push_gaussian(
        mu_pi_q,
        S_pi_q,
        transports["Om_q_inv"],  # Ω_ji
        eps=eps
    )[:2]
    
    # Step 3: Measure misalignment with j's actual sensory belief
    KL_A = kl_gaussian(
        fields_j["mu_q"],
        fields_j["sigma_q"],
        mu_pi_q_j,
        S_pi_q_j,
        eps=eps
    )
    
    # ---- Case B: KL(p_i || Φ_i[Ω_ij q_j]) ----
    # Path: q_j → Ω_ij → receiver i's q-space → Φ_i → p-space
    
    # Step 1: Transport j's sensory input to i's q-frame
    mu_qj_i, S_qj_i = push_gaussian(
        fields_j["mu_q"],
        fields_j["sigma_q"],
        transports["Om_q"],
        eps=eps
    )[:2]
    
    # Step 2: Lift to motor space via forward morphism
    mu_qj_i_p, S_qj_i_p = push_gaussian(
        mu_qj_i,
        S_qj_i,
        transports["Phi"],
        eps=eps
    )[:2]
    
    # Step 3: Measure misalignment with i's actual motor plan
    KL_B = kl_gaussian(
        fields_i["mu_p"],
        fields_i["sigma_p"],
        mu_qj_i_p,
        S_qj_i_p,
        eps=eps
    )
    
    # ---- Compute γ = exp(-KL/κ) on overlap only ----
    # Clip negative KL (numerical artifacts) and compute γ on overlap only
    kA[mbool] = np.clip(KL_A[mbool], 0.0, np.inf)
    kB[mbool] = np.clip(KL_B[mbool], 0.0, np.inf)
    gA[mbool] = np.exp(-kA[mbool] / max(kappa_q, eps))
    gB[mbool] = np.exp(-kB[mbool] / max(kappa_p, eps))
    
    # Cast to float32 for storage
    return (
        gA.astype(np.float32, copy=False),
        gB.astype(np.float32, copy=False),
        kA.astype(np.float32, copy=False),
        kB.astype(np.float32, copy=False)
    )


# ──────────────────────────────────────────────────────────────────────────────
# Helper: Alignment Accumulators
# ──────────────────────────────────────────────────────────────────────────────

def _init_alignment_accumulators(Sshape: tuple, build_q: bool, build_p: bool) -> dict:
    """
    Initialize per-receiver accumulators for alignment softmax.
    
    Args:
        Sshape: Spatial shape tuple (without channel dim)
        build_q: If True, initialize q-fiber accumulators
        build_p: If True, initialize p-fiber accumulators
    
    Returns:
        dict with keys:
          - Sshape: spatial shape
          - send_ids: list of sender IDs
          - logits_q, masks_q, kls_q: q-fiber accumulators (if build_q)
          - logits_p, masks_p, kls_p: p-fiber accumulators (if build_p)
    
    Notes:
        - Lists grow with each sender via _accumulate_alignment_logits
        - Finalized via _finalize_alignment_softmax
    """
    state = {"Sshape": Sshape, "send_ids": []}
    
    if build_q:
        state["logits_q"] = []  # List of (*S,) arrays
        state["masks_q"] = []   # List of (*S,) bool arrays
        state["kls_q"] = {}     # {j_id: KL_map}
    
    if build_p:
        state["logits_p"] = []
        state["masks_p"] = []
        state["kls_p"] = {}
    
    return state


def _accumulate_alignment_logits(
    state: dict,
    j_idx: int,
    j_id: int,
    kl_q: Optional[np.ndarray],
    kl_p: Optional[np.ndarray],
    kappa_q: float,
    kappa_p: float,
    mbool: np.ndarray,
    eps: float
):
    """
    Accumulate logits and masks for one sender j.
    
    Alignment logits are computed as -KL/κ and will be aggregated
    via softmax over all senders in _finalize_alignment_softmax.
    
    Args:
        state: Accumulator state from _init_alignment_accumulators
        j_idx: Sender index (unused, for compatibility)
        j_id: Sender agent ID
        kl_q: Q-fiber KL array (*S,) or None
        kl_p: P-fiber KL array (*S,) or None
        kappa_q: Temperature for q-fiber softmax
        kappa_p: Temperature for p-fiber softmax
        mbool: Overlap mask (*S,) boolean
        eps: Numerical stability epsilon
    
    Notes:
        - KL masked to zero off-overlap for diagnostics
        - Logits masked to -inf off-overlap for softmax
        - Appends to state lists in-place
    """
    state["send_ids"].append(j_id)
    
    if kl_q is not None:
        # Mask KL for diagnostics (zeros off-overlap)
        kl_masked = np.where(mbool, kl_q, 0.0).astype(np.float32, copy=False)
        state["kls_q"][j_id] = kl_masked
        
        # Logits: -KL/κ, mask via -inf for softmax stability
        logits = (-kl_q / max(kappa_q, eps)).astype(np.float32, copy=False)
        state["logits_q"].append(np.where(mbool, logits, -np.inf))
        state["masks_q"].append(mbool)
    
    if kl_p is not None:
        kl_masked = np.where(mbool, kl_p, 0.0).astype(np.float32, copy=False)
        state["kls_p"][j_id] = kl_masked
        
        logits = (-kl_p / max(kappa_p, eps)).astype(np.float32, copy=False)
        state["logits_p"].append(np.where(mbool, logits, -np.inf))
        state["masks_p"].append(mbool)


def _finalize_alignment_softmax(
    ctx,
    state: dict,
    i_id: int,
    Sshape: tuple,
    build_q: bool,
    build_p: bool,
    tol: float
):
    """
    Perform softmax over senders, check invariants, write edge maps.
    
    This function:
      1. Stacks logits/masks over sender dimension
      2. Computes softmax weights β via _softmax_over_senders
      3. Checks β normalization invariant (sum to 1 on overlap)
      4. Writes (β, KL) pairs via ctx.edge.set_align(...)
    
    Args:
        ctx: Runtime context
        state: Accumulator state with logits/masks/kls
        i_id: Receiver agent ID
        Sshape: Spatial shape tuple
        build_q: If True, finalize q-fiber
        build_p: If True, finalize p-fiber
        tol: Tolerance for β normalization check
    
    Notes:
        - Writes through ctx.edge.set_align which handles disk caching
        - Empty sender list is handled gracefully (early return)
    """
    send_ids = state["send_ids"]
    if not send_ids:
        return
    
    # ---- Q-fiber softmax ----
    if build_q and "logits_q" in state and state["logits_q"]:
        L = np.stack(state["logits_q"], axis=0)  # (Ns, *S)
        M = np.stack(state["masks_q"], axis=0)   # (Ns, *S)
        W = _softmax_over_senders(L, M, tiny=1e-12)
        
        # Check/fix normalization
        W = _enforce_beta_normalization(ctx, W, M, tol, fiber="q")
        
        # Write β and KL maps
        for s, j_id in enumerate(send_ids):
            beta_ij = np.where(M[s], W[s], 0.0).astype(np.float32, order="C")
            kl_ij = state["kls_q"][j_id]
            ctx.edge.set_align(ctx, "q", i_id, j_id,
                              KL_map=kl_ij, beta_map=beta_ij)
    
    # ---- P-fiber softmax ----
    if build_p and "logits_p" in state and state["logits_p"]:
        L = np.stack(state["logits_p"], axis=0)
        M = np.stack(state["masks_p"], axis=0)
        W = _softmax_over_senders(L, M, tiny=1e-12)
        
        W = _enforce_beta_normalization(ctx, W, M, tol, fiber="p")
        
        for s, j_id in enumerate(send_ids):
            beta_ij = np.where(M[s], W[s], 0.0).astype(np.float32, order="C")
            kl_ij = state["kls_p"][j_id]
            ctx.edge.set_align(ctx, "p", i_id, j_id,
                              KL_map=kl_ij, beta_map=beta_ij)


# ──────────────────────────────────────────────────────────────────────────────
# Helper: Softmax Implementation
# ──────────────────────────────────────────────────────────────────────────────

def _softmax_over_senders(logits: np.ndarray, mask: np.ndarray, tiny: float = 1e-12):
    """
    Masked softmax over axis 0 (senders). Shapes (J, *S).
    
    Algorithm:
      1. Identify valid entries (on-mask AND finite)
      2. Subtract max for numerical stability
      3. Compute exp and sum over senders
      4. Normalize with underflow protection
    
    Args:
        logits: (Ns, *S) logit array (may contain -inf for off-mask)
        mask: (Ns, *S) boolean mask (which senders valid)
        tiny: Minimum denominator for division
    
    Returns:
        (Ns, *S) float32 weights where:
          - sum(W, axis=0) == 1.0 on overlap (within float32 precision)
          - W == 0 off-overlap
    
    Notes:
        - NaN/±inf-safe under strict np.seterr
        - Underflow-safe: clamps subnormals to 0 then renormalizes
        - Identical to beta.py::_softmax_over_senders
    """
    L = np.asarray(logits, np.float64)
    M = np.asarray(mask, dtype=bool)
    
    # valid := on-mask AND finite
    valid = M & np.isfinite(L)
    any_valid = np.any(valid, axis=0, keepdims=True)  # (1, *S)
    
    # Max over valid entries; -inf where none are valid
    L_masked = np.where(valid, L, -np.inf)
    Lmax = np.max(L_masked, axis=0, keepdims=True)
    Lmax_safe = np.where(np.isfinite(Lmax), Lmax, 0.0)  # avoid (-inf)-(-inf)
    
    with np.errstate(invalid='ignore', over='ignore', under='ignore'):
        shifted = L - Lmax_safe
        shifted = np.where(valid, shifted, -np.inf)
        expL = np.exp(shifted)
        expL = np.where(valid, expL, 0.0)
    
    Z = np.sum(expL, axis=0, keepdims=True)
    Z = np.where(any_valid, np.maximum(Z, tiny), 1.0)
    
    W = expL / Z
    W = np.where(any_valid, W, 0.0)
    
    # ---- Underflow-safe cast to float32 ----
    # Clamp subnormals to zero, then renormalize across senders
    tiny32 = np.finfo(np.float32).tiny  # ~1.175e-38
    W = np.where(W < tiny32, 0.0, W)
    
    sumW = np.sum(W, axis=0, keepdims=True)
    # If we zeroed some tiny entries, re-normalize to keep sum=1 where valid
    sumW_safe = np.where(any_valid, np.maximum(sumW, tiny), 1.0)
    W = np.where(any_valid, W / sumW_safe, 0.0)
    
    # Now casting cannot underflow (we only have zeros or >= tiny32)
    return W.astype(np.float32, copy=False)


# ──────────────────────────────────────────────────────────────────────────────
# Helper: Utilities
# ──────────────────────────────────────────────────────────────────────────────


    


def _write_zero_edges(
    ctx,
    i_id: int,
    j_id: int,
    Sshape: tuple,
    build_q: bool,
    build_p: bool,
    build_gamma: bool
):
    """
    Write explicit zero maps for non-overlapping agent pairs.
    Ensures consistent shapes in downstream consumers.
    
    Args:
        ctx: Runtime context
        i_id: Receiver agent ID
        j_id: Sender agent ID
        Sshape: Spatial shape tuple
        build_q: If True, write q-fiber zeros
        build_p: If True, write p-fiber zeros
        build_gamma: If True, write gamma zeros
    
    Notes:
        - Writes through ctx.edge API which handles disk caching
        - Critical for shape consistency when consumers expect all edges
    """
    Z = np.zeros(Sshape, np.float32)
    
    if build_q:
        ctx.edge.set_align(ctx, "q", i_id, j_id, KL_map=Z, beta_map=Z)
    
    if build_p:
        ctx.edge.set_align(ctx, "p", i_id, j_id, KL_map=Z, beta_map=Z)
    
    if build_gamma:
        ctx.edge.set_gamma(ctx, "A", j_id, i_id, gamma_map=Z, kl_map=Z)
        ctx.edge.set_gamma(ctx, "B", i_id, j_id, gamma_map=Z, kl_map=Z)


def _clear_edge_storage(ctx, build_q: bool, build_p: bool, build_gamma: bool):
    """
    Clear relevant portions of edge storage when no agents present.
    
    Args:
        ctx: Runtime context
        build_q: If True, clear q-fiber storage
        build_p: If True, clear p-fiber storage
        build_gamma: If True, clear gamma storage
    """
    if not hasattr(ctx, "edge") or ctx.edge is None:
        ctx.edge = EdgeMaps()
    
    if build_q:
        ctx.edge.clear_fiber("q")
    if build_p:
        ctx.edge.clear_fiber("p")
    if build_gamma:
        ctx.edge.gamma.clear()
        ctx.edge.klX.clear()




def _enforce_beta_normalization(
    ctx,
    W: np.ndarray,
    M: np.ndarray,
    tol: float,
    fiber: str
) -> np.ndarray:
    """
    Check β softmax invariant (sum to 1 on overlap) and renormalize if needed.
    
    Invariant: For each pixel with at least one valid sender,
               sum(β_ij over j) should equal 1.0 within tolerance.
    
    Args:
        ctx: Runtime context
        W: (Ns, *S) beta weights
        M: (Ns, *S) mask (which senders are valid)
        tol: Tolerance for deviation from sum=1
        fiber: "q" or "p" (for logging)
    
    Returns:
        W (possibly renormalized)
    
    Notes:
        - If strict_beta_norm config is True, raises on violation
        - Otherwise renormalizes and logs warning
        - Handles both regular spatial grids and point agents (S=(1,1))
    """
    from core.runtime_context import cfg_get
    import numpy as np
    
    # Sum over senders (axis 0)
    any_sender = np.any(M, axis=0)  # (*S,) - boolean mask of pixels with ≥1 sender
    sum_beta = np.sum(W, axis=0, dtype=np.float32)  # (*S,) - sum of β over senders
    
    # Compute deviation from sum=1 - FLATTEN for consistent indexing
    any_sender_flat = any_sender.ravel()
    sum_beta_flat = sum_beta.ravel()
    
    dev_flat = np.zeros_like(sum_beta_flat, dtype=np.float32)
    dev_flat[any_sender_flat] = np.abs(sum_beta_flat[any_sender_flat] - 1.0)
    
    max_dev = float(np.nanmax(dev_flat)) if np.any(any_sender_flat) else 0.0
    
    if max_dev > tol:
        msg = f"[β-{fiber}] max deviation={max_dev:.3e} (tol={tol:.1e})"
        
        if bool(cfg_get(ctx, "strict_beta_norm", False)):
            raise AssertionError(msg)
        else:
            # Renormalize: broadcast-safe division
            tiny = 1e-12
            denom = np.where(sum_beta > tiny, sum_beta, 1.0).astype(np.float32)
            
            # Reshape denom for broadcasting: (1, *S) to divide (Ns, *S)
            denom_bc = denom[None, ...]  # Add sender dimension
            W = W / denom_bc
            
            # Report post-fix deviation
            sum_beta_fix = np.sum(W, axis=0, dtype=np.float32)
            sum_beta_fix_flat = sum_beta_fix.ravel()
            dev_fix_flat = np.zeros_like(sum_beta_fix_flat)
            dev_fix_flat[any_sender_flat] = np.abs(sum_beta_fix_flat[any_sender_flat] - 1.0)
            max_dev_fix = float(np.nanmax(dev_fix_flat)) if np.any(any_sender_flat) else 0.0
            print(msg + f" → renorm → {max_dev_fix:.3e}")
    
    return W


def _check_gamma_invariants(
    ctx,
    gamma_vals: np.ndarray,
    kl_vals: np.ndarray,
    *,
    which: str,
    i_id: int,
    j_id: int,
    tol: float
):
    """
    Check invariants for γ/KL on the overlap set:
      • KL ≥ -tol
      • 0 - tol ≤ γ ≤ 1 + tol
      • finite (no NaNs/Inf)
    
    Logs warnings (does not raise) to avoid killing long runs.
    
    Args:
        ctx: Runtime context
        gamma_vals: γ values on overlap (1D or flattened)
        kl_vals: KL values on overlap (1D or flattened)
        which: "A" or "B" (for logging)
        i_id: Agent i ID
        j_id: Agent j ID
        tol: Numerical tolerance
    
    Notes:
        - Only checks values on the overlap (caller must pre-filter)
        - Identical to beta.py::_check_gamma_invariants
    """
    if gamma_vals.size == 0:
        return
    
    issues = []
    if not np.all(np.isfinite(gamma_vals)):
        issues.append("γ non-finite")
    if not np.all(np.isfinite(kl_vals)):
        issues.append("KL non-finite")
    if np.nanmin(kl_vals) < -tol:
        issues.append(f"KL < 0 (min={float(np.nanmin(kl_vals)):.3e})")
    
    gmin = float(np.nanmin(gamma_vals)) if gamma_vals.size else 0.0
    gmax = float(np.nanmax(gamma_vals)) if gamma_vals.size else 0.0
    if gmin < -tol or gmax > 1.0 + tol:
        issues.append(f"γ bounds (min={gmin:.3e}, max={gmax:.3e})")
    
    if issues:
        msg = f"[γ/{which}] invariants warn (i={i_id}, j={j_id}): " + "; ".join(issues)
        logger = getattr(ctx, "logger", None)
        try:
            (logger.warning if logger else print)(msg)
        except Exception:
            print(msg)








# ──────────────────────────────────────────────────────────────────────────────
# KL builders
# ──────────────────────────────────────────────────────────────────────────────









def beta_align_maps(ctx, agent_i, agent_j, *, which: str):
    """Read-only accessor for ALIGN maps produced earlier."""
    if not hasattr(ctx, "edge") or ctx.edge is None:
        ctx.edge = EdgeMaps()
   
    # Determine receiver spatial shape via canonical mask helper
    mbool, _mvec = joint_masks(ctx, agent_i, agent_j)
    Sshape = mbool.shape
    i_id = AA.get_id(agent_i)
    j_id = AA.get_id(agent_j)
    

    # get_align returns (beta, kl); legacy callers expect (KL, beta)
    kl_map, beta_map = ctx.edge.get_align(ctx, str(which), i_id, j_id, shape=Sshape) or (None, None)

    if beta_map is None:
        Z = np.zeros(Sshape, np.float32)
        return Z, Z

    beta_map = np.asarray(beta_map, np.float32, order="C")
    kl_map   = np.asarray(kl_map,   np.float32, order="C") if kl_map is not None else np.zeros_like(beta_map)

    return kl_map, beta_map





def gamma_maps(ctx, agent_i, agent_j, *, include_kl: bool = True):
    """Fetch γ and (optionally) KL maps for ordered edge (i <- j)."""
    
    # Shape via canonical joint mask on q-grid (no channel dim)
    mbool, _ = joint_masks(ctx, agent_i, agent_j)
    Sshape = mbool.shape
    i_id = AA.get_id(agent_i)
    j_id = AA.get_id(agent_j)
    
    out = {}

    # Case A: j -> i
    gA, kA = ctx.edge.get_gamma(ctx, "A", j_id, i_id, shape=Sshape)
    if gA is not None:
        gA = np.asarray(gA, np.float32, order="C")
        if include_kl:
            kA = np.zeros(Sshape, np.float32) if kA is None else np.asarray(kA, np.float32, order="C")
            out["A"] = (kA, gA)
        else:
            out["A"] = gA

    # Case B: i -> j
    gB, kB = ctx.edge.get_gamma(ctx, "B", i_id, j_id, shape=Sshape)
    if gB is not None:
        gB = np.asarray(gB, np.float32, order="C")
        if include_kl:
            kB = np.zeros(Sshape, np.float32) if kB is None else np.asarray(kB, np.float32, order="C")
            out["B"] = (kB, gB)
        else:
            out["B"] = gB

    return out






