# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Literal
import numpy as np
from agents.agent_accessor import AA
import hashlib
from updates.update_helpers import dirty_manager
import threading
from dataclasses import is_dataclass
from types import SimpleNamespace
from dataclasses import dataclass
from typing import Tuple, Sequence



# Add this import at the TOP of runtime_context.py (with other imports)
import config as CONFIG_MODULE

# Add this sentinel near the top (after imports, before functions)
_SENTINEL = object()



Fiber = Literal["q", "p"]

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _shape_sig(a):
    return tuple(int(x) for x in np.asarray(a).shape)

def _arr_digest(a: np.ndarray, *, tol: float | None = None) -> str:
    a = np.asarray(a, np.float32)
    if tol and tol > 0:
        b = (np.round(a / tol) * tol).tobytes()
    else:
        b = a.tobytes()
    return hashlib.sha256(b).hexdigest()




def ensure_runtime_defaults(ctx: Optional[RuntimeCtx]) -> RuntimeCtx:
    if ctx is None:
        ctx = RuntimeCtx()
    if ctx.global_step is None:
        ctx.global_step = 0

    # existing
    _ = dirty_manager(ctx)
    if not hasattr(ctx, "edge") or ctx.edge is None:
        ctx.edge = EdgeMaps()

    # --- NEW: observation model defaults ---
    # We define these lazily when we see our first agent in run_one_step
    if not hasattr(ctx, "W_obs"):
        ctx.W_obs = None
    if not hasattr(ctx, "Lambda_obs"):
        ctx.Lambda_obs = None


    return ctx



def ensure_observation_model(runtime_ctx, agents):
    """
    SINGLE SOURCE OF TRUTH for observation model initialization.
    
    Creates W_obs, Lambda_obs on runtime_ctx if missing.
    Creates x_obs on each agent if missing.
    
    Configuration (from config.py):
        D_x: Observation space dimension (default: 3)
        obs_W_scale: Scale for W_obs initialization (default: 0.5)
        obs_Lambda_scale: Scale for Lambda_obs initialization (default: 0.3)
        obs_noise_scale: Per-agent noise scale (default: 0.1)
        obs_bias_scale: Per-agent bias scale (default: 0.3)
    
    MUST be called:
    - After initialize_agents() in run_simulation()
    - At start of run_one_step() for safety
    
    Idempotent: safe to call multiple times, only initializes what's missing.
    """
    import numpy as np
    
    # Get first agent to determine dimensions
    if not agents:
        raise ValueError("Cannot initialize observation model: no agents provided")
    
    mu0 = np.asarray(agents[0].mu_q_field, np.float32)
    K_q = mu0.shape[-1]
    
    # ================================================================
    # STEP 1: Initialize global observation model (W_obs, Lambda_obs)
    # ================================================================
    if not hasattr(runtime_ctx, "W_obs") or runtime_ctx.W_obs is None:
        # Read configuration from config.py
        D_x = int(cfg_get(runtime_ctx, "D_x", 3))
        W_scale = float(cfg_get(runtime_ctx, "obs_W_scale", 0.5))
        Lambda_scale = float(cfg_get(runtime_ctx, "obs_Lambda_scale", 0.3))
        
        seed = cfg_get(runtime_ctx, "agent_seed", 0)
        rng_obs = np.random.default_rng(seed + 10)  # offset for reproducibility
        
        # Observation matrix: maps latent K_q -> observed D_x
        runtime_ctx.W_obs = rng_obs.normal(scale=W_scale, size=(D_x, K_q)).astype(np.float32)
        
        # Precision matrix (SPD): Lambda = A^T A
        A = rng_obs.normal(scale=Lambda_scale, size=(D_x, D_x)).astype(np.float32)
        Lambda_obs = (A.T @ A).astype(np.float32)
        Lambda_obs /= np.linalg.norm(Lambda_obs)  # normalize for stability
        runtime_ctx.Lambda_obs = Lambda_obs
        
        print(f"[OBS_MODEL] Initialized W_obs: {runtime_ctx.W_obs.shape}, Lambda_obs: {runtime_ctx.Lambda_obs.shape}")
        print(f"[OBS_MODEL] Config: D_x={D_x}, W_scale={W_scale}, Lambda_scale={Lambda_scale}")
    
    if not hasattr(runtime_ctx, "Lambda_obs") or runtime_ctx.Lambda_obs is None:
        # Fallback: create identity if somehow W_obs exists but Lambda doesn't
        D_x = runtime_ctx.W_obs.shape[0]
        runtime_ctx.Lambda_obs = np.eye(D_x, dtype=np.float32)
        print("[OBS_MODEL] Warning: Lambda_obs was missing, using identity")
    
    # ================================================================
    # STEP 2: Initialize per-agent observations (x_obs)
    # ================================================================
    W_obs = runtime_ctx.W_obs
    D_x = W_obs.shape[0]
    
    # Read per-agent noise/bias configuration
    noise_scale = float(cfg_get(runtime_ctx, "obs_noise_scale", 0.1))
    bias_scale = float(cfg_get(runtime_ctx, "obs_bias_scale", 0.3))
    
    seed = cfg_get(runtime_ctx, "agent_seed", 0)
    rng = np.random.default_rng(seed + 20)  # different offset for agent obs
    
    n_initialized = 0
    for idx, agent in enumerate(agents):
        if hasattr(agent, "x_obs") and agent.x_obs is not None:
            continue  # Already initialized, skip
        
        mu_q = np.asarray(agent.mu_q_field, np.float32)  # (*S, K_q)
        
        # Predict observation from current belief
        y_pred = np.einsum("dk,...k->...d", W_obs, mu_q, optimize=True)  # (*S, D_x)
        
        # Add per-agent noise and bias for unique observations
        noise = rng.normal(scale=noise_scale, size=y_pred.shape).astype(np.float32)
        agent_bias = rng.normal(scale=bias_scale, size=(1, 1, D_x)).astype(np.float32)
        
        agent.x_obs = (y_pred + noise + agent_bias).astype(np.float32)
        n_initialized += 1
    
    if n_initialized > 0:
        print(f"[OBS_MODEL] Initialized x_obs for {n_initialized} agents (noise_scale={noise_scale}, bias_scale={bias_scale})")
    
    return runtime_ctx, agents





def ensure_shared_cache_attached(ctx):
    """
    Ensure ctx.cache is a SharedDiskCache instance (process-safe).
    Back-compat: also alias ctx.shared = ctx.cache if not set.
    """
    if getattr(ctx, "cache", None) is None:
        from core.shared_cache import SharedDiskCache
        cache_dir = cfg_get(ctx, "shared_cache_dir", "./_shared_cache")
        ctx.cache = SharedDiskCache(cache_dir)
    if getattr(ctx, "shared", None) is None:
        # Optional alias so any legacy code using ctx.shared keeps working
        try:
            ctx.shared = ctx.cache
        except Exception:
            pass
    return ctx


# ─────────────────────────────────────────────────────────────────────────────
# Edge maps (unified API for β / KL / γ)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class EdgeMaps:
    """
    Unified, fiber-aware per-edge storage:
      - beta[(which,i,j)]  : β_ij(*S,) float32
      - kl1[(which,i,j)]   : ALIGN KL(*S,) float32
      - kl_basis[(basis,i,j)] : KL for A/B/C/D/align_{q,p} (optional)
      - gamma[(case,i,j)]  : γ maps where case ∈ {"A","B"}
      - klX[(case,i,j)]    : KL behind γ (diagnostics)

    Back-compat mirrors are kept on the ctx (ctx._edge_beta, ctx._edge_kl1, ctx._edge_gamma, ctx._edge_klX).
    CONTRACTS:
      get_align(...) -> (KL_map, beta_map)     # KL FIRST, β SECOND
      get_gamma(...) -> (gamma_map, kl_map)    # γ FIRST,  KL SECOND (zeros if missing)
    """
    beta: Dict[tuple, np.ndarray] = field(default_factory=dict)
    kl1: Dict[tuple, np.ndarray] = field(default_factory=dict)
    kl_basis: Dict[tuple, np.ndarray] = field(default_factory=dict)
    gamma: Dict[tuple, np.ndarray] = field(default_factory=dict)
    klX: Dict[tuple, np.ndarray] = field(default_factory=dict)

    # ---- clears ----
    def clear_all(self):
        self.beta.clear(); self.kl1.clear(); self.kl_basis.clear(); self.gamma.clear(); self.klX.clear()

    def clear_fiber(self, which: str):
        which = str(which)
        self.beta  = {k:v for k,v in self.beta.items()  if k and k[0] != which}
        self.kl1   = {k:v for k,v in self.kl1.items()   if k and k[0] != which}
        # leave kl_basis as-is (keyed by textual basis)

    # ---- writes ----
    def set_align(self, ctx, which: str, i_id: int, j_id: int, KL_map, beta_map):
        k = (str(which), int(i_id), int(j_id))
        self.kl1[k]  = np.asarray(KL_map,   np.float32, order="C")
        self.beta[k] = np.asarray(beta_map, np.float32, order="C")

        # Persist to disk cache if available
        C = getattr(ctx, "cache", None)
        if C is not None:
            step = int(getattr(ctx, "global_step", 0))
            C.put("edge", ("kl1",  step, which, i_id, j_id), self.kl1[k])
            C.put("edge", ("beta", step, which, i_id, j_id), self.beta[k])

    def set_gamma(self, ctx, case: str, a_id: int, b_id: int, gamma_map, kl_map=None):
        k = (str(case), int(a_id), int(b_id))
        self.gamma[k] = np.asarray(gamma_map, np.float32, order="C")
        if kl_map is not None:
            self.klX[k] = np.asarray(kl_map, np.float32, order="C")

        C = getattr(ctx, "cache", None)
        if C is not None:
            step = int(getattr(ctx, "global_step", 0))
            C.put("edge", ("gamma", step, case, a_id, b_id), self.gamma[k])
            if kl_map is not None:
                C.put("edge", ("klX",   step, case, a_id, b_id), self.klX[k])

    # ---- reads ----
    def get_align(self, ctx, which: str, i_id: int, j_id: int, *, shape):
        """
        Returns: (KL_map, beta_map)   # KL FIRST, β SECOND
        """
        k = (str(which), int(i_id), int(j_id))
        K = self.kl1.get(k,  None)
        B = self.beta.get(k, None)

        if (K is None or B is None):
            # Prefer ctx.cache; fallback to ctx.shared only if cache missing
            C = getattr(ctx, "cache", None) or getattr(ctx, "shared", None)
            if C is not None:
                step = int(getattr(ctx, "global_step", 0))
                if K is None:
                    K = C.get("edge", ("kl1",  step, which, i_id, j_id))
                if B is None:
                    B = C.get("edge", ("beta", step, which, i_id, j_id))

        if K is None or B is None:
            z = np.zeros(tuple(shape), np.float32)
            return z, z

        K = np.asarray(K, np.float32, order="C")
        B = np.asarray(B, np.float32, order="C")
        if K.shape != tuple(shape) or B.shape != tuple(shape):
            raise RuntimeError(f"EdgeMaps.get_align shape mismatch for key={(which,i_id,j_id)}: "
                               f"K{K.shape} B{B.shape} expected {tuple(shape)}")
        return K, B

    def get_gamma(self, ctx, case: str, a_id: int, b_id: int, *, shape):
        """
        Returns: (gamma_map, kl_map)  # γ FIRST, KL SECOND (zeros if missing)
        """
        k = (str(case), int(a_id), int(b_id))
        G = self.gamma.get(k, None)
        K = self.klX.get(k,   None)

        if G is None:
            C = getattr(ctx, "cache", None) or getattr(ctx, "shared", None)
            if C is not None:
                step = int(getattr(ctx, "global_step", 0))
                G = C.get("edge", ("gamma", step, case, a_id, b_id))
                if K is None:
                    K = C.get("edge", ("klX",   step, case, a_id, b_id))

        if G is None:
            z = np.zeros(tuple(shape), np.float32)
            return z, (np.zeros_like(z) if K is None else K)

        G = np.asarray(G, np.float32, order="C")
        if K is None:
            return G, np.zeros(tuple(shape), np.float32)

        K = np.asarray(K, np.float32, order="C")
        if G.shape != tuple(shape) or K.shape != tuple(shape):
            raise RuntimeError(f"EdgeMaps.get_gamma shape mismatch for key={(case,a_id,b_id)}: "
                               f"G{G.shape} K{K.shape} expected {tuple(shape)}")
        return G, K



# ─────────────────────────────────────────────────────────────────────────────
# Cache hub
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class CacheHub:
    step_tag: int = -1
    spaces: Dict[str, Dict[Any, Any]] = field(default_factory=lambda: {
        "exp": {}, "omega": {}, "morphism": {}, "fisher": {}, "misc": {}, "jinv": {}
    })
    persist: Dict[str, Dict[Any, Any]] = field(default_factory=lambda: {
        "morph_base": {}
    })
    hits: int = 0
    misses: int = 0
    invalidations: int = 0

    def ns(self, name: str) -> Dict[Any, Any]:
        return self.spaces.setdefault(name, {})

    def nsp(self, name: str) -> Dict[Any, Any]:
        return self.persist.setdefault(name, {})

    def clear_on_step(self, step: int) -> None:
        if step != self.step_tag:
            for d in self.spaces.values():
                d.clear()
            self.step_tag = step

    def stats(self) -> Dict[str, int]:
        return {k: len(v) for k, v in self.spaces.items()}

    def key_E(self, *, agent_id: int, step: int, phi: np.ndarray,
          cfg: dict, wrap_flag: bool, tol: float | None = None,
          gensig: tuple | None = None):
        """
        E-cache key; includes optional generator signature to disambiguate reps.
        gensig should be a small tuple like (K, 'sha256hex') or None.
        """
        return ("E", int(agent_id), int(step),
                _shape_sig(phi), bool(wrap_flag),
                gensig, _arr_digest(phi, tol=tol))
    
    def key_Jinv(self, **kw):
        k = self.key_E(**kw)
        return ("Jinv",) + k[1:]
    
    def key_Omega(self, *, agent_i: int, agent_j: int, step: int,
                  phi_i: np.ndarray, phi_j: np.ndarray, cfg: dict,
                  wrap_flag: bool, tol: float | None = None,
                  gensig_i: tuple | None = None, gensig_j: tuple | None = None):
        """
        Omega-cache key; includes optional generator signatures for each endpoint.
        """
        di = _arr_digest(phi_i, tol=tol)
        dj = _arr_digest(phi_j, tol=tol)
        pair_sha = hashlib.sha256((di + "|" + dj).encode()).hexdigest()
        return ("Omega", int(agent_i), int(agent_j), int(step),
                _shape_sig(phi_i), bool(wrap_flag),
                gensig_i, gensig_j, pair_sha)


    def key_Fisher(self, *, agent_id: int, step: int,
                   mu: np.ndarray, Sigma: np.ndarray,
                   cfg: dict, which: str = "q", tol: float | None = None):
        mu  = np.asarray(mu,    np.float32)
        Sig = np.asarray(Sigma, np.float32)
        mu_sha  = _arr_digest(mu,  tol=tol)
        Sig_sha = _arr_digest(Sig, tol=tol)
        shape   = _shape_sig(Sig)
        return ("Fisher", which, int(agent_id), int(step),
                shape, mu_sha, Sig_sha)

    # ---- typed get/put with counters ----
    def get(self, ns_name: str, key):
        ns = self.ns(ns_name)
        val = ns.get(key)
        if val is None: self.misses += 1
        else:           self.hits += 1
        return val

    def put(self, ns_name: str, key, value):
        self.ns(ns_name)[key] = value

    def invalidate_like(self, ns_name: str, predicate):
        ns = self.ns(ns_name)
        todel = [k for k in list(ns.keys()) if predicate(k)]
        for k in todel:
            ns.pop(k, None)
        self.invalidations += len(todel)

    def full_stats(self) -> Dict[str, int]:
        out = self.stats()
        out.update({"hits": self.hits, "misses": self.misses, "invalidations": self.invalidations})
        return out

# ─────────────────────────────────────────────────────────────────────────────
# Neighbor graph (single level)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class LevelGraph:
    level: int
    agent_ids: List[int]
    neighbors: Dict[int, List[int]] = field(default_factory=dict)  # id -> [neighbor ids]

# ─────────────────────────────────────────────────────────────────────────────
# Runtime context (single-scale)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RuntimeCtx:
    global_step: int = 0
    agents_by_level: Dict[int, Dict[int, Any]] = field(default_factory=dict)
    graphs: Dict[int, LevelGraph] = field(default_factory=dict)
    cache: CacheHub = field(default_factory=CacheHub)
    fields: Dict[str, Any] = field(default_factory=dict)
   
    edge: EdgeMaps = field(default_factory=EdgeMaps)     # <— unified per-edge state
    
    def register_agents(self, level: int, agents: List[Any]) -> None:
        lvl = self.agents_by_level.setdefault(level, {})
        lvl.clear()
        for a in agents:
            lvl[AA.get_id(a)] = a

    def build_neighbors(self, level: int, neighbor_map: Dict[int, List[int]]) -> None:
        ids = list(self.agents_by_level.get(level, {}).keys())
        nm: Dict[int, List[int]] = {i: [j for j in neighbor_map.get(i, []) if j in ids] for i in ids}
        self.graphs[level] = LevelGraph(level=level, agent_ids=ids, neighbors=nm)

    def neighbors_of(self, level: int, agent_id: int) -> List[int]:
        g = self.graphs.get(level)
        return [] if not g else g.neighbors.get(int(agent_id), [])

    def agent(self, level: int, agent_id: int) -> Any:
        return self.agents_by_level[level][int(agent_id)]

    def agents(self, level: int) -> List[Any]:
        if level not in self.graphs:
            return list(self.agents_by_level.get(level, {}).values())
        g = self.graphs[level]
        return [self.agents_by_level[level][aid] for aid in g.agent_ids]

    def cache_stats(self) -> dict:
        return {} if not getattr(self, "cache", None) else self.cache.stats()






#===================================================
#
#         CONFIG
#
#==================================================




# REPLACE the existing cfg_get function with this:
def cfg_get(ctx, name: str, default=_SENTINEL):
    """
    Read configuration from config.py module (single source of truth).
    
    Resolution order:
      1. ctx.overrides[name] - explicit runtime overrides (e.g., CLI args)
      2. config.py module - the source of truth for all parameters
      3. default - provided fallback value
    
    Args:
        ctx: Runtime context (may have .overrides dict for explicit overrides)
        name: Parameter name (must exist in config.py unless default provided)
        default: Fallback value if not in config.py or overrides (optional)
        
    Returns:
        Parameter value from config.py (or override, or default)
        
    Raises:
        AttributeError: If parameter not found in config.py and no default provided
        
    Examples:
        >>> cfg_get(ctx, "tau_phi")  # Returns config.tau_phi
        0.01
        >>> ctx.overrides = {"tau_phi": 0.001}
        >>> cfg_get(ctx, "tau_phi")  # Returns override
        0.001
        >>> cfg_get(ctx, "missing_param", 999)  # Returns default
        999
    """
    # 1. Check explicit runtime overrides (highest priority)
    overrides = getattr(ctx, "overrides", None)
    if overrides and isinstance(overrides, dict) and name in overrides:
        return overrides[name]
    
    # 2. Read from config.py module (source of truth)
    try:
        return getattr(CONFIG_MODULE, name)
    except AttributeError:
        # 3. Use default if provided
        if default is not _SENTINEL:
            return default
        
        # No default provided - raise informative error
        available = [k for k in dir(CONFIG_MODULE) if not k.startswith('_')]
        raise AttributeError(
            f"Parameter '{name}' not found in config.py and no default provided.\n"
            f"Available parameters: {', '.join(sorted(available)[:10])}...\n"
            f"Either add '{name}' to config.py or provide a default value."
        )


# ADD these helper functions RIGHT AFTER cfg_get:

def cfg_set_override(ctx, name: str, value):
    """
    Set an explicit runtime override for a config parameter.
    
    Use this for CLI arguments or experiment-specific overrides.
    These take precedence over config.py values in cfg_get().
    
    Args:
        ctx: Runtime context
        name: Parameter name
        value: Override value
        
    Example:
        >>> cfg_set_override(ctx, "n_jobs", 23)  # Use 23 cores instead of config.py
        >>> cfg_get(ctx, "n_jobs")  # Returns 23
    """
    if not hasattr(ctx, "overrides") or ctx.overrides is None:
        ctx.overrides = {}
    ctx.overrides[name] = value


def cfg_clear_overrides(ctx):
    """
    Clear all runtime overrides (back to config.py values).
    
    Args:
        ctx: Runtime context
        
    Example:
        >>> cfg_set_override(ctx, "tau_phi", 1e-3)
        >>> cfg_get(ctx, "tau_phi")  # 1e-3
        >>> cfg_clear_overrides(ctx)
        >>> cfg_get(ctx, "tau_phi")  # Back to config.tau_phi
    """
    if hasattr(ctx, "overrides"):
        ctx.overrides = {}


def cfg_list_overrides(ctx) -> dict:
    """
    Return current runtime overrides.
    
    Args:
        ctx: Runtime context
        
    Returns:
        Dictionary of current overrides, or empty dict if none
        
    Example:
        >>> cfg_set_override(ctx, "n_jobs", 23)
        >>> cfg_list_overrides(ctx)
        {'n_jobs': 23}
    """
    return getattr(ctx, "overrides", {}) or {}










# ─────────────────────────────────────────────────────────────────────────────
# Convenience
# ─────────────────────────────────────────────────────────────────────────────
# --- in runtime_context.py (top-level dataclass or simple attrs init) ---
def ensure_clock_defaults(ctx):
    if not hasattr(ctx, "clock_t"):             ctx.clock_t = 0.0       # intrinsic time
    if not hasattr(ctx, "clock_last"):          ctx.clock_last = {}     # last speeds per field
    if not hasattr(ctx, "clock_cfg"):           ctx.clock_cfg = {
        "aggregate": "max_agent_mean",          # or: "mean_agent_mean"
        "w_mu": 1.0, "w_S": 1.0,                # Gaussian fibre weights
        "w_phi": 1.0, "w_tphi": 1.0,            # Lie algebra weights
        "w_A": 0.5,                             # global A (optional)
        "eps": 1e-8,
    }
    return ctx







def _to_plain_dict(obj):
    """Return a JSON/pickle-friendly dict for config-like objects."""
    if obj is None:
        return {}
    if isinstance(obj, dict):
        return dict(obj)
    if is_dataclass(obj):
        return asdict(obj)               # handles nested dataclasses too
    if hasattr(obj, "__dict__"):
        # best-effort for simple objects
        return dict(obj.__dict__)
    # last resort: empty (don’t blow up on unknown types)
    return {}



def ctx_view_for_workers(ctx):
    """
    Workers import config.py themselves.
    Only pass runtime state + overrides + grad_cfg + obs model params.
    """
    fields = _to_plain_dict(getattr(ctx, "fields", {}) or {})
    overrides = getattr(ctx, "overrides", {}) or {}
    grad_cfg = getattr(ctx, "grad_cfg", None)

    # NEW: safely expose observation model pieces
    W_obs = getattr(ctx, "W_obs", None)
    Lambda_obs = getattr(ctx, "Lambda_obs", None)

    return SimpleNamespace(
        fields=fields,
        overrides=overrides,
        global_step=int(getattr(ctx, "global_step", 0)),
        grad_cfg=grad_cfg,

        # NEW: include observation model so _obs_grads_for_agent can run in workers
        W_obs=W_obs,
        Lambda_obs=Lambda_obs,
    )




__all__ = [
     "CacheHub",
     "LevelGraph",
     "RuntimeCtx",
     "EdgeMaps",
     "cfg_get",
     "cfg_set_override",          # <- ADD
     "cfg_clear_overrides",       # <- ADD
     "cfg_list_overrides",        # <- ADD
     "ensure_runtime_defaults",
]