# -*- coding: utf-8 -*-
"""
omega.py — Lie-group exponentials, transports, BCH helpers, and curvature ops.
CacheHub-ready: uses ctx.cache namespaces 'exp' and 'omega' when provided.

Author: c&c
"""
from __future__ import annotations
from typing import Optional
import numpy as np
from joblib import Parallel, delayed, parallel_backend
from core.utils import _to32_no_underflow


# -----------------------------------------------------------------------------
# Principal-ball retraction (axis–angle)
# -----------------------------------------------------------------------------



def _safe_matmul32(A, B):
    A64 = np.asarray(A, dtype=np.float64)
    B64 = np.asarray(B, dtype=np.float64)
    with np.errstate(under='ignore', over='ignore', invalid='raise'):
        C64 = A64 @ B64
    return _to32_no_underflow(C64)







def _so3_log_matrix(R: np.ndarray, eps: float = 1e-12) -> np.ndarray:
    """
    Log map for SO(3) rotation matrices.
    Input:
      R: (..., 3, 3)
    Output:
      phi: (..., 3)  such that exp([phi]_×) ≈ R
    Handles small angles and π-neighborhood robustly.
    """
 
    R = np.asarray(R, np.float64)
    if R.shape[-2:] != (3, 3):
        raise ValueError(f"_so3_log_matrix expects (...,3,3), got {R.shape}")

    # Symmetrize numerically and clamp trace to [-1,3]
    tr = np.trace(R, axis1=-2, axis2=-1)
    tr = np.clip(tr, -1.0, 3.0)
    # angle
    cos_theta = (tr - 1.0) * 0.5
    cos_theta = np.clip(cos_theta, -1.0, +1.0)
    theta = np.arccos(cos_theta)  # in [0,pi]

    # Skew part S = (R - R^T)/2
    S = 0.5 * (R - np.swapaxes(R, -1, -2))
    # For generic case (not tiny/singular): axis = vee(S) / sinθ
    v = np.stack([S[..., 2, 1], S[..., 0, 2], S[..., 1, 0]], axis=-1)  # (...,3)

    # Small angle: use series θ ≈ ||v|| (since sinθ ≈ θ), fall back to S
    small = (theta < 1e-6)
    phi = np.empty_like(v)

    # Regular branch
    s = np.sin(theta)
    denom = s + eps
    phi_reg = v * (theta / denom)[..., None]

    # Small-angle branch: use first-order approx phi ≈ vee(S)
    phi_small = v  # already ~ θ u when θ→0

    # Near π: numerical issues—recover axis from R+I
    near_pi = (np.abs(theta - np.pi) < 1e-5)
    if np.any(near_pi):
        # From Hartley/Zisserman trick: use principal eigenvector of (R + I)
        RpI = R + np.eye(3)[None, None, ...]
        # pick the column with largest norm
        # But that’s messy for batch; instead, compute axis component-wise:
        ux = np.sqrt(np.maximum(RpI[..., 0, 0] / 2.0, 0.0))
        uy = np.sqrt(np.maximum(RpI[..., 1, 1] / 2.0, 0.0))
        uz = np.sqrt(np.maximum(RpI[..., 2, 2] / 2.0, 0.0))
        # fix signs using off-diagonals
        ux = np.copysign(ux, S[..., 2, 1])
        uy = np.copysign(uy, S[..., 0, 2])
        uz = np.copysign(uz, S[..., 1, 0])
        u = np.stack([ux, uy, uz], axis=-1)
        # normalize axis and set phi = θ u
        n = np.linalg.norm(u, axis=-1, keepdims=True) + eps
        u = u / n
        phi_pi = u * theta[..., None]
    else:
        phi_pi = phi_reg  # unused where not near π

    # Blend
    phi = np.where(small[..., None], phi_small, phi_reg)
    phi = np.where(near_pi[..., None], phi_pi, phi)

    return phi.astype(np.float32, copy=False)





def retract_phi_principal(
    phi,
    *,
    margin: float | None = 1e-2,
    use_float64: bool = True,
):
    """
    Project axis–angle φ onto the SO(3) principal ball: ||φ|| <= π - margin,
    using mod 2π + antipodal flip. Avoids the θ=π branch-cut "lock".
    Shapes: (..., 3) -> (..., 3)
    """

    # --- dtype & input ---
    work_dtype = np.float64 if use_float64 else np.float32
    v = np.asarray(phi, dtype=work_dtype, order="C")
    if v.ndim == 0 or v.shape[-1] != 3:
        raise ValueError(f"retract_phi_principal expects (...,3), got {v.shape}")

    if not np.all(np.isfinite(v)):
        raise FloatingPointError("retract_phi_principal: nonfinite input detected.")

    # --- constants in working dtype ---
    pi     = np.asarray(np.pi, dtype=work_dtype)
    two_pi = np.asarray(2.0*np.pi, dtype=work_dtype)
    eps    = np.finfo(work_dtype).eps

    # --- margin sanitize ---
    if margin is None or not np.isfinite(margin):
        margin = 1e-3
    margin = float(margin)
    # keep strictly inside; cap silly values
    margin = max(1e-12, min(margin, float(pi)*0.5))
    r_max  = pi - np.asarray(margin, dtype=work_dtype)

    # --- norms and 2π reduction ---
    t = np.linalg.norm(v, axis=-1, keepdims=True)            # (...,1)
    t_flat = t[..., 0]                                       # (...,)
    t_mod  = np.remainder(t_flat, two_pi)                    # [0, 2π)

    over = (t_mod > pi)                                      # reflection region
    t_ref = np.where(over, two_pi - t_mod, t_mod)            # (...,) in [0, π]
    t_target = np.minimum(t_ref, r_max)                      # clamp to π - margin

    # --- scale & flip ---
    denom = np.maximum(t_flat, eps)                          # avoid /0
    scale = (t_target / denom)[..., None]                    # (...,1)
    out = v * scale                                          # scale original vector
    out = np.where(over[..., None], -out, out)               # antipodal flip if needed


    # Optional: nudge away from boundary (robustness on exact representable edges)
    # out = np.nextafter(out, np.zeros_like(out))

    return out.astype(phi.dtype, copy=False)




# =============================================================================
#                          Exponentials / Transports
# =============================================================================



def exp_lie_algebra_irrep(
    v_batch: np.ndarray,
    generators: np.ndarray,
    *,
    threshold: float = 1e-3,
    max_norm: Optional[float] = None,
    parallelize_expm: bool = False,
    n_jobs: int = -1,
    reproject_ortho: bool = False,          # NEW: optional SVD projection to nearest orthogonal (costly)
    use_float64: bool = True,               # NEW: do math in float64, return float32
    **_legacy,                              
) -> np.ndarray:
    """
    Compute exp(Σ v^a G_a) in an arbitrary K×K irrep for a batch of v.

    v_batch:    (..., 3) axis–angle coefficients in the chosen basis
    generators: (3, K, K) irrep generators (typically skew for SO(3))
    Returns:    (..., K, K) float32

    Notes:
      - 'threshold' controls small-angle Taylor cutoff.
      - 'max_norm' clips ||v|| radially for stability.
      - No in-kernel masking;
    """
    # --- shape & dtype checks
    v = np.asarray(v_batch, dtype=(np.float64 if use_float64 else np.float32))
    G = np.asarray(generators, dtype=v.dtype)

    if v.ndim == 0 or v.shape[-1] != 3:
        raise ValueError(f"exp_lie_algebra_irrep: expected (...,3) v_batch, got {v.shape}")
    if G.ndim != 3 or G.shape[0] != 3 or G.shape[-1] != G.shape[-2]:
        raise ValueError(f"exp_lie_algebra_irrep: generators must be (3,K,K), got {G.shape}")

    
    if not (np.all(np.isfinite(v)) and np.all(np.isfinite(G))):
        raise FloatingPointError("exp_lie_algebra_irrep: nonfinite v/generators.")

    batch_shape = v.shape[:-1]
    d = 3
    K = int(G.shape[-1])

    # Optional global norm clip (safe at 0)
    if max_norm is not None:
        vv = v.reshape(-1, d)
        n = np.linalg.norm(vv, axis=1)
        scale = np.minimum(1.0, float(max_norm) / np.maximum(n, 1e-16)).astype(v.dtype)
        v = (vv * scale[:, None]).reshape(batch_shape + (d,))

    # Algebra element: Xi = v·G, then enforce skew numerically
    Xi = np.einsum("...a,aij->...ij", v, G, optimize=True)          # (...,K,K)
    X = 0.5 * (Xi - np.swapaxes(Xi, -1, -2))                        # (...,K,K)

    # Flatten for batch processing
    flat = X.reshape(-1, K, K)
    out  = np.empty_like(flat)

    # Small-angle mask
    norms = np.linalg.norm(v.reshape(-1, d), axis=1)                # (N,)
    mask_small = norms < float(threshold)
    mask_big   = ~mask_small

    # Taylor (order 4) near identity
    if np.any(mask_small):
        Xs = flat[mask_small]
        I = np.eye(K, dtype=flat.dtype)[None, ...]
        X2 = Xs @ Xs
        X3 = X2 @ Xs
        X4 = X2 @ X2
        out[mask_small] = I + Xs + 0.5*X2 + (1.0/6.0)*X3 + (1.0/24.0)*X4

    # Exact expm elsewhere
    if np.any(mask_big):
        Xh = flat[mask_big]

        # Local expm with SciPy if available; minimal fallback otherwise
        def _expm(A):
            try:
                from scipy.linalg import expm as _scipy_expm   # prefer SciPy
                return _scipy_expm(A)
            except Exception:
                # Minimal Pade(13) + scaling & squaring (batched via loop)
                return _expm_pade13(A)

        if parallelize_expm and Xh.shape[0] >= 64:
            try:
               
                with parallel_backend("threading"):
                    res = Parallel(n_jobs=n_jobs, batch_size=8)(
                        delayed(_expm)(X_i) for X_i in Xh
                    )
            except Exception:
                res = [_expm(X_i) for X_i in Xh]
        else:
            res = [_expm(X_i) for X_i in Xh]
        out[mask_big] = np.stack(res, axis=0)

    # Optional SVD reprojection to nearest orthogonal (use for fundamental or if drift bothers you)
    if reproject_ortho:
        U, _, Vt = np.linalg.svd(out, full_matrices=False)
        out = U @ Vt

    # Final finite check — no in-kernel masking
    if not np.all(np.isfinite(out)):
        raise FloatingPointError("exp_lie_algebra_irrep: nonfinite exp result.")
   

    return out.reshape(batch_shape + (K, K)).astype(np.float32, copy=False)




# ------- Minimal fallback: Pade(13) + scaling & squaring for a single matrix -------
def _expm_pade13(A: np.ndarray) -> np.ndarray:
    """
    Minimal, dependency-free expm fallback for a single (K,K) matrix.
    Good enough for skew-symmetric inputs typically seen here.
    """
    # Scaling
    A = np.asarray(A, dtype=np.float64)
    n_squarings = max(0, int(np.ceil(max(0.0, np.log2(np.linalg.norm(A, ord=np.inf))) - 1)))
    As = A / (2 ** n_squarings)

    # Pade(13) coefficients
    b = [64764752532480000., 32382376266240000., 7771770303897600., 1187353796428800.,
         129060195264000., 10559470521600., 670442572800., 33522128640., 1323241920.,
         40840800., 960960., 16380., 182., 1.]

    I = np.eye(A.shape[0], dtype=As.dtype)
    A2 = As @ As
    A4 = A2 @ A2
    A6 = A2 @ A4

    U = As @ (A6@(b[13]*A6 + b[11]*A4 + b[9]*A2) + b[7]*A6 + b[5]*A4 + b[3]*A2 + b[1]*I)
    V =      (A6@(b[12]*A6 + b[10]*A4 + b[8]*A2) + b[6]*A6 + b[4]*A4 + b[2]*A2 + b[0]*I)

    # (V - U)^{-1} (V + U)
    X = np.linalg.solve(V - U, V + U)

    # Squaring
    for _ in range(n_squarings):
        X = X @ X
    return X




# =============================================================================
#                       Exact dexp derivatives for SO(3)
# =============================================================================


def build_dexpinv_matrix(
    phi: np.ndarray,
    eps: float = 1e-12,
    *,
    margin: float = 1e-1,     # principal-ball margin (π - margin)
    use_float64: bool = False,
) -> np.ndarray:
    """
    Stable SO(3) right-Jacobian inverse J^{-1}(φ).
    Returns array of shape (..., 3, 3).

    Formula (kept from your convention):
      J^{-1}(φ) = I - (θ/2) ad(u) + (1 - h) ad(u)^2,
      h(θ) = (θ/2) cot(θ/2),  φ = θ u,  ad(u) = [u]_×.
    """
    
    dtype = np.float64 if use_float64 else np.float32

    # ---- validate & retract ----
    phi = np.asarray(phi, dtype=dtype)
    if phi.shape[-1] != 3:
        raise ValueError(f"build_dexpinv_matrix: last dim must be 3, got {phi.shape}")
    phi_r = retract_phi_principal(phi, margin=margin, use_float64=use_float64).astype(dtype, copy=False)

    # ---- axis/angle pieces ----
    th   = np.linalg.norm(phi_r, axis=-1)               # (...,)
    u    = np.divide(phi_r, th[..., None] + eps, dtype=dtype)  # (...,3)

    ux, uy, uz = u[..., 0], u[..., 1], u[..., 2]
    z = np.zeros_like(ux, dtype=dtype)
    adu = np.stack([
        np.stack([ z,  -uz,  uy], axis=-1),
        np.stack([ uz,   z, -ux], axis=-1),
        np.stack([-uy,  ux,   z], axis=-1),
    ], axis=-2).astype(dtype, copy=False)               # (...,3,3)

    # ---- h(θ) = (θ/2) cot(θ/2) with small-θ series ----
    half = 0.5 * th
    small = th < 1e-3
    # series in θ (not half): 1 - θ^2/12 - θ^4/720 + O(θ^6)
    t2 = th * th
    h_series = 1.0 - (t2 / 12.0) - ((t2 * t2) / 720.0)

    # safe half-angle for non-small branch
    half_ns = np.clip(half, 1e-6, np.pi/2 - 1e-6)
    h_closed = half_ns / np.tan(half_ns)

    # piecewise combine without extra passes
    h = np.where(small, h_series, h_closed)

    # ---- build J^{-1} ----
    I = np.eye(3, dtype=dtype)
    uuT  = u[..., :, None] * u[..., None, :]           # (...,3,3)
    adu2 = (uuT - I)                                   # (...,3,3)

    Jinv = I - half[..., None, None] * adu + (1.0 - h)[..., None, None] * adu2
    if not np.all(np.isfinite(Jinv)):
        raise FloatingPointError("build_dexpinv_matrix produced non-finite values")

    return Jinv.astype(np.float32, copy=False)




def d_exp_exact(
    phi_vec: np.ndarray,
    generators: np.ndarray,
    *,
    exp_phi_all: Optional[np.ndarray] = None,
    eps: float = 1e-12,
) -> list[np.ndarray]:
    """
    For Φ = Σ_a φ^a G_a (SO(3) left-trivialized), compute
      dE/dφ^a = E · Q_a,
    where Q_a = G_a - c1 ad_Φ(G_a) + c2 ad_Φ^2(G_a),
    c1 = (1 - cos θ)/θ^2, c2 = (θ - sin θ)/θ^3, θ = ||φ||.
    Returns a list [dE/dφ^0, dE/dφ^1, dE/dφ^2], each (...,K,K).
    """

    φ = np.asarray(phi_vec, dtype=np.float32)
    G = np.asarray(generators, dtype=np.float32)

    # Validate generators as (3,K,K)
    if not (G.ndim == 3 and G.shape[0] == 3 and G.shape[1] == G.shape[2]):
        raise ValueError(f"d_exp_exact: generators must be (3,K,K), got {G.shape}")
    K = int(G.shape[-1])

    *lead, d = φ.shape
    if d != 3:
        raise ValueError(f"d_exp_exact: expected d=3 (SO(3)), got d={d}")
    N = int(np.prod(lead)) if lead else 1

    # Flatten sites
    φN = φ.reshape(N, 3)                                  # (N,3)
    Φ  = np.einsum("na,aij->nij", φN, G, optimize=True)   # (N,K,K)

    # Coefficients c1, c2
    θ  = np.linalg.norm(φN, axis=1).astype(np.float32)    # (N,)
    c1 = np.empty_like(θ)
    c2 = np.empty_like(θ)
    
    small = θ < 1e-4
    
    if np.any(small):
        t  = θ[small]; t2 = t*t; t4 = t2*t2
        c1[small] = 0.5 - t2/24.0 + t4/720.0
        c2[small] = 1.0/6.0 - t2/120.0 + t4/5040.0
    
    big = ~small
    
    if np.any(big):
        tb = θ[big]
        tb2 = np.maximum(tb*tb, eps)
        tb3 = np.maximum(tb2*tb, eps)
        c1[big] = (1.0 - np.cos(tb)) / tb2
        c2[big] = (tb - np.sin(tb)) / tb3

    # E(φ)
    if exp_phi_all is None:
        E = exp_lie_algebra_irrep(φN, G)                  # (N,K,K)
    else:
        E = np.asarray(exp_phi_all, dtype=np.float32).reshape(N, K, K)

    # Commutators: ad_Φ(G_a) and its square
    ΦB = Φ[None, ...]            # (1,N,K,K)
    GA = G[:, None, :, :]        # (3,1,K,K)
    ad1 = (ΦB @ GA) - (GA @ ΦB)  # (3,N,K,K)
    ad2 = (ΦB @ ad1) - (ad1 @ ΦB)# (3,N,K,K)

    # Q_a and dE/dφ^a
    Q  = GA - c1[None, :, None, None]*ad1 + c2[None, :, None, None]*ad2  # (3,N,K,K)
    dE = np.einsum("nij,anjk->anik", E, Q, optimize=True)                # (3,N,K,K)

    dE = dE.reshape(3, *lead, K, K).astype(np.float32, copy=False)
    return [dE[a] for a in range(3)]





# 1) keep this utility as-is (optional: add finite checks inside)
def project_phi_covector_to_step(param_cograd, Jinv, Finv):
    """
    param-covector (∂L/∂φ)_param → param-step via:
        g_body = Jinv^T @ param_cograd
        v_body = Finv   @ g_body
        v_param= Jinv   @ v_body
    Shapes: grad: (*S,3), Jinv/Finv: (*S,3,3) → step: (*S,3)
    """
    g_body = np.einsum("...ji,...j->...i", Jinv, param_cograd, optimize=True)
    v_body = np.einsum("...ab,...b->...a", Finv, g_body,      optimize=True)
    return np.einsum("...ab,...b->...a",   Jinv, v_body,      optimize=True)




def matrix_cograd_to_param_covector_irrep(E, G_E, generators_irrep=None):
    """
    Map a matrix co-gradient G_E (same rep as E) to a parameter-space covector (*S,3).

    If generators_irrep is provided (shape (3,K,K)), use the general irrep path:
        α_a = tr( E^T G_E  · G_a^T )
    Otherwise, if K==3, use the adjoint fast-path (no generators required).

    Args:
      E:    (*S, K, K)  frame in some SO(3) rep
      G_E:  (*S, K, K)  matrix co-gradient w.r.t. E
      generators_irrep: optional (3,K,K)

    Returns:
      covector: (*S, 3)  in parameter coordinates (right-trivialized)
    """
    Rt = np.swapaxes
   
    # General irrep path when generators are given
    if generators_irrep is not None:
        H = np.einsum("...ij,...jk->...ik", Rt(E, -1, -2), G_E, optimize=True)  # H = E^T G_E
        # α_a = tr(H G_a^T)
        cov = np.stack(
            [np.einsum("...ij,ij->...", H, generators_irrep[a], optimize=True) for a in range(3)],
            axis=-1
        )
        return cov.astype(np.float32, copy=False)

    raise ValueError(
        "matrix_cograd_to_param_covector_irrep: either provide generators_irrep "
        "or ensure K==3 for the adjoint fast-path."
    )






# =============================================================================
#                       Holonomy / transport helpers
# =============================================================================





