# holonomy.py
"""
Holonomy and parallel transport helpers for multi-agent systems.

Provides:
  - Spatial holonomy (Wilson loops on agent grids)
  - Inter-agent holonomy (transport between overlapping agents)
  - Curvature estimation from holonomy defects
  - Path-ordered exponentials for gauge connections

All functions are loky-compatible (pure, stateless).
"""
from __future__ import annotations
import numpy as np
from typing import Optional, Literal, Tuple, List
from dataclasses import dataclass


# ============================================================================
# Data Structures
# ============================================================================

@dataclass(frozen=True)
class HolonomyPath:
    """
    Represents a discrete path for holonomy computation.
    
    Attributes
    ----------
    vertices : list[tuple[int, ...]]
        List of grid coordinates (i, j, ...) along the path
    closed : bool
        Whether path is a closed loop
    agent_id : int or None
        Which agent this path belongs to (None for inter-agent paths)
    """
    vertices: tuple[tuple[int, ...], ...]  # immutable for hashing
    closed: bool
    agent_id: Optional[int] = None
    
    def __post_init__(self):
        if len(self.vertices) < 2:
            raise ValueError("Path must have at least 2 vertices")
        if self.closed and self.vertices[0] != self.vertices[-1]:
            raise ValueError("Closed path must start and end at same vertex")


@dataclass(frozen=True)
class HolonomyResult:
    """
    Result of holonomy computation.
    
    Attributes
    ----------
    holonomy : ndarray (K, K)
        Parallel transport matrix
    curvature : float
        Estimated curvature from holonomy defect (for closed paths)
    path : HolonomyPath
        The path that was integrated
    """
    holonomy: np.ndarray
    curvature: float
    path: HolonomyPath


# ============================================================================
# Core: Path-Ordered Exponential
# ============================================================================

def compute_path_ordered_exp(
    connection_field: np.ndarray,
    path: HolonomyPath,
    *,
    generators: Optional[np.ndarray] = None,
    method: Literal["discrete", "midpoint", "trapezoidal"] = "discrete",
    eps: float = 1e-8,
) -> np.ndarray:
    """
    Compute path-ordered exponential of a connection along a discrete path.
    
    For connection A(x) valued in a Lie algebra, computes:
        P exp(∫_γ A(x) dx) ≈ ∏_edges exp(A_edge · Δx)
    
    Parameters
    ----------
    connection_field : ndarray (*spatial_dims, ndim, d)
        Connection 1-form at each grid point.
        Shape: (*S, ndim, d) where:
          - *S are spatial dimensions (e.g., H, W for 2D)
          - ndim is the number of spatial directions (2 for 2D, 3 for 3D)
          - d is the dimension of the Lie algebra (3 for SO(3))
    path : HolonomyPath
        Discrete path through the grid
    generators : ndarray (d, K, K), optional
        Lie algebra generators for the representation.
        If None, assumes SO(3) fundamental (3×3).
    method : str
        Integration scheme:
        - "discrete": Use connection at start of each edge
        - "midpoint": Average connection at edge endpoints
        - "trapezoidal": Trapezoidal rule
    eps : float
        Small value for numerical stability
    
    Returns
    -------
    holonomy : ndarray (K, K)
        Parallel transport matrix (element of the group)
    
    Examples
    --------
    >>> # 2D grid with SO(3) connection
    >>> A = np.random.randn(10, 10, 2, 3) * 0.1  # small connection
    >>> path = HolonomyPath(
    ...     vertices=((5, 5), (5, 6), (6, 6), (6, 5), (5, 5)),
    ...     closed=True
    ... )
    >>> U = compute_path_ordered_exp(A, path)
    >>> # U is now the holonomy around a plaquette
    """
    from omega import exp_lie_algebra_irrep
    
    A = np.asarray(connection_field, np.float32)
    
    # Infer dimensions
    spatial_shape = A.shape[:-2]
    ndim = int(A.shape[-2])
    d = int(A.shape[-1])
    
    # Default generators (SO(3) fundamental)
    if generators is None:
        if d != 3:
            raise ValueError(
                f"Default generators only available for d=3 (SO(3)), got d={d}"
            )
        generators = _get_so3_generators()
    
    K = int(generators.shape[-1])
    
    # Initialize holonomy as identity
    U = np.eye(K, dtype=np.float32)
    
    # Integrate along edges
    vertices = path.vertices
    for i in range(len(vertices) - 1):
        v0 = vertices[i]
        v1 = vertices[i + 1]
        
        # Validate coordinates
        if len(v0) != len(spatial_shape) or len(v1) != len(spatial_shape):
            raise ValueError(
                f"Path vertex dimension {len(v0)} doesn't match "
                f"connection spatial dims {len(spatial_shape)}"
            )
        
        # Edge displacement
        delta = tuple(v1[k] - v0[k] for k in range(len(v0)))
        edge_length = float(np.linalg.norm(delta))
        
        if edge_length < eps:
            continue  # Skip degenerate edges
        
        # Get connection values
        try:
            A0 = A[v0]  # (ndim, d)
            A1 = A[v1]  # (ndim, d)
        except IndexError:
            raise IndexError(
                f"Path vertex {v0} or {v1} out of bounds for connection "
                f"with spatial shape {spatial_shape}"
            )
        
        # Project connection onto edge direction
        # A_edge^a = A^μ_a * Δx^μ
        if method == "discrete":
            A_edge = np.einsum("md,m->d", A0, delta, optimize=True)  # (d,)
        elif method == "midpoint":
            A_mid = 0.5 * (A0 + A1)
            A_edge = np.einsum("md,m->d", A_mid, delta, optimize=True)
        elif method == "trapezoidal":
            A_avg = 0.5 * (A0 + A1)
            A_edge = np.einsum("md,m->d", A_avg, delta, optimize=True)
        else:
            raise ValueError(f"Unknown integration method: {method}")
        
        # Exponential map: exp(A_edge · G)
        U_edge = exp_lie_algebra_irrep(
            A_edge[None, :],  # (1, d)
            generators,
            threshold=1e-3,
            use_float64=False,
            allow_parallel=False,
        )[0]  # (K, K)
        
        # Path-ordered product: U_new = U_edge @ U_old
        U = U_edge @ U
    
    return U.astype(np.float32, copy=False)


# ============================================================================
# Spatial Holonomy: Wilson Loops on Agent Grids
# ============================================================================

def compute_plaquette_holonomy(
    connection_field: np.ndarray,
    base_point: tuple[int, ...],
    plane: tuple[int, int],
    *,
    generators: Optional[np.ndarray] = None,
    size: int = 1,
) -> HolonomyResult:
    """
    Compute holonomy around a single plaquette (elementary loop).
    
    Parameters
    ----------
    connection_field : ndarray (*S, ndim, d)
        Connection 1-form
    base_point : tuple[int, ...]
        Starting corner of the plaquette
    plane : tuple[int, int]
        Which two coordinate directions define the plaquette.
        E.g., (0, 1) for x-y plane in a 2D/3D grid.
    generators : ndarray (d, K, K), optional
        Lie algebra generators
    size : int
        Side length of the plaquette in grid units
    
    Returns
    -------
    result : HolonomyResult
        Holonomy matrix and estimated curvature
    
    Examples
    --------
    >>> # Holonomy around (x, y) plaquette starting at (5, 5)
    >>> A = np.random.randn(10, 10, 2, 3) * 0.1
    >>> result = compute_plaquette_holonomy(A, (5, 5), (0, 1))
    >>> print(f"Curvature: {result.curvature:.4f}")
    """
    spatial_shape = connection_field.shape[:-2]
    ndim = len(spatial_shape)
    
    i_dir, j_dir = plane
    if not (0 <= i_dir < ndim and 0 <= j_dir < ndim):
        raise ValueError(f"Plane directions {plane} invalid for {ndim}D grid")
    
    # Construct square path in the specified plane
    # Path: base → base+i → base+i+j → base+j → base
    v0 = list(base_point)
    
    v1 = v0.copy()
    v1[i_dir] += size
    
    v2 = v1.copy()
    v2[j_dir] += size
    
    v3 = v0.copy()
    v3[j_dir] += size
    
    path = HolonomyPath(
        vertices=(tuple(v0), tuple(v1), tuple(v2), tuple(v3), tuple(v0)),
        closed=True,
    )
    
    # Compute holonomy
    U = compute_path_ordered_exp(
        connection_field, path, generators=generators, method="midpoint"
    )
    
    # Estimate curvature from holonomy defect
    # For small curvature: U ≈ exp(F_ij * area)
    # Curvature ≈ ||log(U)|| / area
    area = float(size * size)
    curv = _estimate_curvature_from_holonomy(U, area)
    
    return HolonomyResult(holonomy=U, curvature=curv, path=path)


def compute_all_plaquettes(
    connection_field: np.ndarray,
    *,
    generators: Optional[np.ndarray] = None,
    stride: int = 1,
) -> dict[tuple[tuple[int, ...], tuple[int, int]], HolonomyResult]:
    """
    Compute holonomy for all plaquettes on a grid.
    
    Parameters
    ----------
    connection_field : ndarray (*S, ndim, d)
        Connection 1-form
    generators : ndarray (d, K, K), optional
        Lie algebra generators
    stride : int
        Spacing between plaquettes (1 = every plaquette, 2 = every other, etc.)
    
    Returns
    -------
    results : dict
        Maps (base_point, plane) → HolonomyResult
    
    Examples
    --------
    >>> A = np.random.randn(10, 10, 2, 3) * 0.1
    >>> results = compute_all_plaquettes(A, stride=2)
    >>> curvatures = [r.curvature for r in results.values()]
    >>> print(f"Mean curvature: {np.mean(curvatures):.4f}")
    """
    spatial_shape = connection_field.shape[:-2]
    ndim = len(spatial_shape)
    
    results = {}
    
    # All possible 2D planes
    from itertools import combinations
    planes = list(combinations(range(ndim), 2))
    
    # Iterate over grid points and planes
    for plane in planes:
        i_dir, j_dir = plane
        
        # Range to keep plaquette inside grid
        ranges = []
        for dim_idx in range(ndim):
            if dim_idx in plane:
                ranges.append(range(0, spatial_shape[dim_idx] - 1, stride))
            else:
                ranges.append(range(0, spatial_shape[dim_idx], stride))
        
        from itertools import product
        for base_point in product(*ranges):
            try:
                result = compute_plaquette_holonomy(
                    connection_field, base_point, plane,
                    generators=generators, size=1
                )
                results[(base_point, plane)] = result
            except (IndexError, ValueError):
                # Skip plaquettes at boundary
                continue
    
    return results


def compute_wilson_loop(
    connection_field: np.ndarray,
    path_vertices: list[tuple[int, ...]],
    *,
    generators: Optional[np.ndarray] = None,
    closed: bool = True,
) -> HolonomyResult:
    """
    Compute Wilson loop for an arbitrary closed path.
    
    Parameters
    ----------
    connection_field : ndarray (*S, ndim, d)
        Connection 1-form
    path_vertices : list[tuple[int, ...]]
        Ordered list of grid coordinates defining the path
    generators : ndarray (d, K, K), optional
        Lie algebra generators
    closed : bool
        Whether to close the path (append first vertex to end)
    
    Returns
    -------
    result : HolonomyResult
    
    Examples
    --------
    >>> # Rectangular Wilson loop
    >>> A = np.random.randn(20, 20, 2, 3) * 0.1
    >>> vertices = [(5, 5), (5, 15), (10, 15), (10, 5)]
    >>> result = compute_wilson_loop(A, vertices, closed=True)
    """
    if closed and path_vertices[0] != path_vertices[-1]:
        path_vertices = list(path_vertices) + [path_vertices[0]]
    
    path = HolonomyPath(
        vertices=tuple(path_vertices),
        closed=closed,
    )
    
    U = compute_path_ordered_exp(
        connection_field, path, generators=generators, method="trapezoidal"
    )
    
    if closed:
        # Compute enclosed area (crude estimate for irregular loops)
        area = _estimate_loop_area(path_vertices)
        curv = _estimate_curvature_from_holonomy(U, area)
    else:
        curv = 0.0
    
    return HolonomyResult(holonomy=U, curvature=curv, path=path)


# ============================================================================
# Inter-Agent Holonomy: Transport Between Agents
# ============================================================================

def compute_inter_agent_holonomy(
    agent_i,
    agent_j,
    ctx,
    *,
    method: Literal["overlap_centroid", "boundary_path", "direct"] = "overlap_centroid",
    generators_q: Optional[np.ndarray] = None,
) -> HolonomyResult:
    """
    Compute holonomy transporting from agent i to agent j.
    
    Uses the gauge connection (φ fields) to define parallel transport
    between overlapping regions.
    
    Parameters
    ----------
    agent_i, agent_j : Agent
        Source and target agents
    ctx : RuntimeCtx
        Runtime context with connection information
    method : str
        How to define the transport path:
        - "overlap_centroid": Straight line between overlap centroids
        - "boundary_path": Follow boundary of overlap region
        - "direct": Use Ω_ij directly (assumes it's a holonomy)
    generators_q : ndarray (3, K, K), optional
        Generators for q fiber (SO(3))
    
    Returns
    -------
    result : HolonomyResult
        Holonomy matrix for i → j transport
    
    Examples
    --------
    >>> # Transport belief from agent 0 to agent 1
    >>> result = compute_inter_agent_holonomy(
    ...     agents[0], agents[1], ctx, method="overlap_centroid"
    ... )
    >>> # Apply to a vector in agent_i's frame:
    >>> v_i = agents[0].mu_q_field[overlap_region]
    >>> v_j = result.holonomy @ v_i
    """
    from core.transport_cache import Omega
    from utils import joint_masks
    
    # Get overlap region
    m_bool, m_vec = joint_masks(ctx, agent_i, agent_j)
    if not np.any(m_bool):
        raise ValueError(f"Agents {agent_i.id} and {agent_j.id} don't overlap")
    
    if method == "direct":
        # Use Ω_ij as holonomy directly
        Om = Omega(ctx, agent_i, agent_j, which="q")
        # Take representative value (e.g., at overlap centroid)
        centroid = _get_overlap_centroid(m_bool)
        U = Om[tuple(centroid)]
        
        return HolonomyResult(
            holonomy=U,
            curvature=0.0,  # Not computed for direct method
            path=HolonomyPath(vertices=(centroid, centroid), closed=False),
        )
    
    elif method == "overlap_centroid":
        # Build connection field from φ_i on agent_i's grid
        A_i = _phi_to_connection_field(agent_i.phi, generators_q)
        
        # Find centroids in agent coordinates
        centroid_i = _get_overlap_centroid(m_bool)
        
        # Map to agent_j coordinates (assuming aligned grids for now)
        # TODO: Handle misaligned grids with proper coordinate transform
        centroid_j = centroid_i  # Simplified
        
        # Straight-line path
        path_vertices = _discretize_line(centroid_i, centroid_j, n_points=10)
        
        path = HolonomyPath(
            vertices=tuple(path_vertices),
            closed=False,
            agent_id=int(getattr(agent_i, "id", -1)),
        )
        
        U = compute_path_ordered_exp(
            A_i, path, generators=generators_q, method="trapezoidal"
        )
        
        return HolonomyResult(holonomy=U, curvature=0.0, path=path)
    
    elif method == "boundary_path":
        # Follow the boundary of the overlap region
        A_i = _phi_to_connection_field(agent_i.phi, generators_q)
        boundary = _extract_boundary_path(m_bool)
        
        path = HolonomyPath(
            vertices=tuple(boundary),
            closed=True,
            agent_id=int(getattr(agent_i, "id", -1)),
        )
        
        U = compute_path_ordered_exp(
            A_i, path, generators=generators_q, method="trapezoidal"
        )
        
        # Estimate curvature from boundary loop
        area = float(np.sum(m_bool))
        curv = _estimate_curvature_from_holonomy(U, area)
        
        return HolonomyResult(holonomy=U, curvature=curv, path=path)
    
    else:
        raise ValueError(f"Unknown method: {method}")


def compute_multi_agent_holonomy(
    agents: list,
    agent_path: list[int],
    ctx,
    *,
    generators_q: Optional[np.ndarray] = None,
) -> HolonomyResult:
    """
    Compute holonomy along a path through multiple agents.
    
    Composes inter-agent holonomies: agent_path[0] → ... → agent_path[-1]
    
    Parameters
    ----------
    agents : list[Agent]
        All agents
    agent_path : list[int]
        Sequence of agent IDs defining the path
    ctx : RuntimeCtx
        Runtime context
    generators_q : ndarray (3, K, K), optional
        Generators
    
    Returns
    -------
    result : HolonomyResult
        Composed holonomy for the full path
    
    Examples
    --------
    >>> # Transport through agents 0 → 1 → 2 → 0 (closed loop)
    >>> result = compute_multi_agent_holonomy(
    ...     agents, [0, 1, 2, 0], ctx
    ... )
    >>> print(f"Multi-agent curvature: {result.curvature:.4f}")
    """
    if len(agent_path) < 2:
        raise ValueError("Need at least 2 agents in path")
    
    # Map IDs to agents
    id_to_agent = {int(getattr(a, "id", i)): a for i, a in enumerate(agents)}
    
    if generators_q is None:
        generators_q = _get_so3_generators()
    
    K = int(generators_q.shape[-1])
    U_total = np.eye(K, dtype=np.float32)
    
    # Compose holonomies
    for i in range(len(agent_path) - 1):
        id_i = agent_path[i]
        id_j = agent_path[i + 1]
        
        agent_i = id_to_agent[id_i]
        agent_j = id_to_agent[id_j]
        
        result_ij = compute_inter_agent_holonomy(
            agent_i, agent_j, ctx,
            method="overlap_centroid",
            generators_q=generators_q,
        )
        
        U_total = result_ij.holonomy @ U_total
    
    # Check if path is closed
    closed = (agent_path[0] == agent_path[-1])
    
    if closed:
        # Estimate curvature (crude: just use holonomy defect)
        curv = _estimate_curvature_from_holonomy(U_total, area=1.0)
    else:
        curv = 0.0
    
    # Dummy path for return value
    path = HolonomyPath(
        vertices=((0, 0), (0, 0)),  # Placeholder
        closed=closed,
        agent_id=None,
    )
    
    return HolonomyResult(holonomy=U_total, curvature=curv, path=path)


# ============================================================================
# Curvature Estimation
# ============================================================================

def estimate_curvature_field(
    connection_field: np.ndarray,
    *,
    generators: Optional[np.ndarray] = None,
    method: Literal["plaquette", "lattice"] = "plaquette",
) -> np.ndarray:
    """
    Estimate curvature 2-form from holonomy defects.
    
    Parameters
    ----------
    connection_field : ndarray (*S, ndim, d)
        Connection 1-form
    generators : ndarray (d, K, K), optional
        Lie algebra generators
    method : str
        - "plaquette": Use elementary plaquettes
        - "lattice": Lattice field strength (discrete curl)
    
    Returns
    -------
    curvature_field : ndarray (*S,)
        Scalar curvature at each point (trace of F^μν F_μν)
    
    Examples
    --------
    >>> A = np.random.randn(20, 20, 2, 3) * 0.1
    >>> F = estimate_curvature_field(A)
    >>> print(f"Max curvature: {np.max(F):.4f}")
    """
    spatial_shape = connection_field.shape[:-2]
    curvature = np.zeros(spatial_shape, dtype=np.float32)
    
    if method == "plaquette":
        # Compute all plaquettes
        results = compute_all_plaquettes(
            connection_field, generators=generators, stride=1
        )
        
        # Accumulate curvature at base points
        for (base_point, plane), result in results.items():
            curvature[base_point] += abs(result.curvature)
    
    elif method == "lattice":
        # Discrete field strength: F_ij = ∂_i A_j - ∂_j A_i + [A_i, A_j]
        ndim = len(spatial_shape)
        d = connection_field.shape[-1]
        
        if generators is None:
            generators = _get_so3_generators()
        
        from itertools import combinations
        for i, j in combinations(range(ndim), 2):
            # Finite differences
            A_i = connection_field  # (*S, ndim, d)
            
            # ∂_i A_j
            dA_ij = _finite_diff(A_i[..., j, :], axis=i)  # (*S, d)
            # ∂_j A_i
            dA_ji = _finite_diff(A_i[..., i, :], axis=j)  # (*S, d)
            
            # Commutator [A_i, A_j] (approximate at each point)
            # TODO: Proper Lie bracket computation
            
            # Field strength component (simplified)
            F_ij = dA_ij - dA_ji
            
            # Add squared norm to curvature
            curvature += np.sum(F_ij**2, axis=-1)
    
    else:
        raise ValueError(f"Unknown method: {method}")
    
    return curvature


# ============================================================================
# Diagnostics
# ============================================================================

def compute_holonomy_diagnostics(
    agents: list,
    ctx,
    *,
    generators_q: Optional[np.ndarray] = None,
) -> dict:
    """
    Compute holonomy-based diagnostics for multi-agent system.
    
    Returns
    -------
    diagnostics : dict
        Contains:
        - "spatial_curvature_per_agent": list of mean curvatures
        - "inter_agent_holonomies": dict mapping (i, j) → holonomy matrix
        - "global_curvature": scalar estimate of total curvature
        - "holonomy_norms": distribution of ||U - I||
    """
    from core.transport_cache import Omega
    
    diagnostics = {}
    
    # 1. Spatial curvature per agent
    spatial_curvatures = []
    for agent in agents:
        # Build connection from φ
        A = _phi_to_connection_field(agent.phi, generators_q)
        F = estimate_curvature_field(A, generators=generators_q)
        spatial_curvatures.append(float(np.mean(F)))
    
    diagnostics["spatial_curvature_per_agent"] = spatial_curvatures
    diagnostics["mean_spatial_curvature"] = float(np.mean(spatial_curvatures))
    
    # 2. Inter-agent holonomies
    inter_agent_holonomies = {}
    holonomy_norms = []
    
    for i, agent_i in enumerate(agents):
        for j, agent_j in enumerate(agents):
            if i >= j:
                continue
            
            try:
                result = compute_inter_agent_holonomy(
                    agent_i, agent_j, ctx,
                    method="direct",
                    generators_q=generators_q,
                )
                
                key = (int(getattr(agent_i, "id", i)), 
                       int(getattr(agent_j, "id", j)))
                inter_agent_holonomies[key] = result.holonomy
                
                # Measure deviation from identity
                K = result.holonomy.shape[0]
                norm = float(np.linalg.norm(
                    result.holonomy - np.eye(K), ord='fro'
                ))
                holonomy_norms.append(norm)
                
            except (ValueError, IndexError):
                # Agents don't overlap
                continue
    
    diagnostics["inter_agent_holonomies"] = inter_agent_holonomies
    diagnostics["holonomy_norms"] = holonomy_norms
    diagnostics["mean_holonomy_deviation"] = float(np.mean(holonomy_norms)) if holonomy_norms else 0.0
    
    # 3. Global curvature (sum over all plaquettes)
    total_curvature = sum(spatial_curvatures)
    diagnostics["global_curvature"] = total_curvature
    
    return diagnostics


# ============================================================================
# Helper Functions
# ============================================================================

def _get_so3_generators() -> np.ndarray:
    """Return standard SO(3) generators in fundamental rep."""
    return np.array([
        [[0, 0, 0], [0, 0, -1], [0, 1, 0]],     # J_x
        [[0, 0, 1], [0, 0, 0], [-1, 0, 0]],     # J_y
        [[0, -1, 0], [1, 0, 0], [0, 0, 0]],     # J_z
    ], dtype=np.float32)


def _phi_to_connection_field(
    phi: np.ndarray,
    generators: Optional[np.ndarray] = None,
) -> np.ndarray:
    """
    Convert φ field to connection 1-form.
    
    Parameters
    ----------
    phi : ndarray (*S, 3)
        Axisangle field
    generators : ndarray (3, K, K), optional
        Generators
    
    Returns
    -------
    A : ndarray (*S, ndim, 3)
        Connection 1-form (gradient of φ in each direction)
    """
    spatial_shape = phi.shape[:-1]
    ndim = len(spatial_shape)
    d = phi.shape[-1]
    
    # Connection = gradient of φ
    A = np.zeros(spatial_shape + (ndim, d), dtype=np.float32)
    
    for direction in range(ndim):
        # Finite difference in this direction
        grad = _finite_diff(phi, axis=direction)
        A[..., direction, :] = grad
    
    return A


