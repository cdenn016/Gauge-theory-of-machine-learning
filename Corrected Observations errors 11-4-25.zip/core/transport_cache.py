from __future__ import annotations
from typing import Any
import numpy as np
from agents.agent_accessor import AA

# Your existing utilities
from core.omega import exp_lie_algebra_irrep, retract_phi_principal
from core.numerical_utils import safe_omega_inv
from joblib import Parallel, delayed
import hashlib
from core.get_generators import get_generators
# --- Shared helpers (top of file or above functions) ---
from functools import lru_cache
from core.utils import _aid, _broadcast_mask_to_S, _roll_spatial_axis, _get_phi
from core.omega import _so3_log_matrix, _safe_matmul32
  # already defined in runtime_context
# _shape_sig/_arr_digest exist here: they produce stable shape+hash signatures. :contentReference[oaicite:0]{index=0}
def _pure_key(*parts):
    return tuple(parts)

"""
Cache Policy — Rule of One
1) One cache hub: runtime_ctx.cache (cleared once per step).
2) One facade to read/write: this file (E_grid, Omega, Jinv_grid, Phi, Phi_tilde, Lambda_*).
3) One warm point per step: ensure_dirty(...) — nowhere else.
Consumers must never pre-warm; they just call the facade.
"""




def _compose_geom_if_split(U_geom: np.ndarray, order=None) -> np.ndarray:
    """
    Normalize geometry shapes and compose per-axis links if provided.

    Accepts:
      - (K, K)              → uniform (returns (K,K))
      - (*S, K, K)          → already composed (returns (*S,K,K))
      - (*S, M, K, K)       → split per spatial axis; composed by `order` → (*S,K,K)
    """
    import numpy as np
    U = np.asarray(U_geom, np.float32)

    # Split per axis: (*S, M, K, K)  -- HANDLE THIS FIRST
    if U.ndim >= 4 and U.shape[-1] == U.shape[-2]:
        M = int(U.shape[-3])
        K = int(U.shape[-1])

        # If there are exactly 4 dims and the penultimate is square K, it might
        # still be (*S,K,K) (already composed). Distinguish by comparing sizes:
        # For split, U.shape[-3] (M) is the number of spatial directions; that is
        # usually != K. Even if M==K by coincidence, we still treat as split when
        # there is a distinct "direction" axis of length M.
        if U.ndim > 3 and (U.shape[-3] != K or U.ndim > 4):
            # resolve order
            if order is None:
                ord_idx = list(range(M))
            elif isinstance(order, str):
                o = order.lower()
                if o in ("yx", "zyx"):
                    ord_idx = list(range(M - 1, -1, -1))
                else:
                    ord_idx = list(range(M))
            else:
                ord_idx = list(int(x) for x in order)
                if len(set(ord_idx)) != len(ord_idx) or not all(0 <= x < M for x in ord_idx):
                    raise ValueError(f"_compose_geom_if_split: bad order {order} for M={M}")

            S = U.shape[:-3]
            I = np.broadcast_to(np.eye(K, dtype=np.float32), S + (K, K)).copy()
            Acc = I
            for m in ord_idx:
                Um = U[..., m, :, :]
                Acc = np.einsum("...ik,...kj->...ij", Um, Acc, optimize=True)
            return Acc.astype(np.float32, copy=False)

    # Already composed: (*S, K, K)
    if U.ndim >= 3 and U.shape[-1] == U.shape[-2]:
        return U

    # Uniform: (K, K)
    if U.ndim == 2 and U.shape[0] == U.shape[1]:
        return U

    raise ValueError(f"_compose_geom_if_split: unrecognized geometry shape {U.shape}")




def _compose_or_lift_geom_pure(U_geom, G32, K, *, max_norm: float, order):
    """
    Ensure geometry is a single (*S, K, K) matrix:
      - If U_geom is split per-axis (*S, M, ...), lift per-axis (if needed) and compose -> (*S, K, K)
      - If U_geom is already (*S, K, K), return as-is
      - If U_geom is SO(3) blocks, lift to KxK with irrep
    """
    U = np.asarray(U_geom)

    # Case A: split field (*S, M, ?, ?)  -> compose to (*S, K, K)
    if U.ndim >= 4 and U.shape[-1] == U.shape[-2]:
        # U has a split axis -3 (M)
        # Lift each per-axis matrix to KxK if needed
        if U.shape[-1] != K:
            # Log in Lie algebra and lift with irrep per axis
            phi_A = _so3_log_matrix(U)  # (*S, M, 3)
            M = U.shape[-3]
            mats = []
            for m in range(M):
                Um = exp_lie_algebra_irrep(phi_A[..., m, :].astype(np.float32), G32, max_norm=max_norm)
                mats.append(Um)
            U = np.stack(mats, axis=-3).astype(np.float32, copy=False)  # (*S, M, K, K)

        # Now compose per-axis links into a single (*S, K, K)
        U = _compose_geom_if_split(U, order=order).astype(np.float32, copy=False)
        return U  # (*S, K, K)

    # Case B: per-site matrix field (*S, K?, K?)  -> lift (if needed) to (*S, K, K)
    if U.ndim >= 3 and U.shape[-1] == U.shape[-2]:
        if U.shape[-1] == K:
            return U.astype(np.float32, copy=False)  # (*S, K, K)
        # Otherwise treat as SO(3) blocks and lift to KxK
        phi_A = _so3_log_matrix(U)  # (*S, 3)
        U = exp_lie_algebra_irrep(phi_A.astype(np.float32), G32, max_norm=max_norm)
        return U.astype(np.float32, copy=False)  # (*S, K, K)

    # Case C: single matrix (K,K)
    if U.ndim == 2 and U.shape[0] == U.shape[1] == K:
        return U.astype(np.float32, copy=False)

    # Case D: SO(3) single (3,3) -> lift to (K,K)
    if U.ndim == 2 and U.shape == (3, 3):
        phi_A = _so3_log_matrix(U)    # (3,) or (1,3) — function already handles broadcasting
        U = exp_lie_algebra_irrep(np.asarray(phi_A, np.float32), G32, max_norm=max_norm)
        return U.astype(np.float32, copy=False)

    raise ValueError(f"_compose_or_lift_geom_pure: unexpected geometry shape {U.shape}")











#==============================================================================
#
#                GLOBAL GAUGE FIELD
#
#==============================================================================




def _expA_generic(ctx, agent, which: str):
    # Dispatcher for cached vs pure
    
    from core.runtime_context import cfg_get
    
    backend  = str(cfg_get(ctx, "transport_backend", "ctx")).lower()   # "ctx" | "pure"
    validate = bool(cfg_get(ctx, "transport_validation", False))
    rtol     = float(cfg_get(ctx, "transport_valid_rtol", 1e-6))
    atol     = float(cfg_get(ctx, "transport_valid_atol", 1e-6))

    primary = _expA_generic_pure if backend == "pure" else _expA_generic_cached
    shadow  = _expA_generic_cached if backend == "pure" else _expA_generic_pure

    out = primary(ctx, agent, which)

    if validate:
        try:
            ref = shadow(ctx, agent, which)
            np.testing.assert_allclose(out, ref, rtol=rtol, atol=atol)
        except AssertionError as e:
            aid = _aid(agent)
            print(f"[transport-check] expA({which}) mismatch for agent {aid}: "
                  f"{str(e).splitlines()[0]} (rtol={rtol}, atol={atol})")
    return out


def expA_q(ctx, agent): return _expA_generic(ctx, agent, "q")
def expA_p(ctx, agent): return _expA_generic(ctx, agent, "p")




def _expA_generic_cached(ctx, agent, which: str):
    
    
    from core.omega import exp_lie_algebra_irrep, retract_phi_principal
    from core.runtime_context import cfg_get

    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))
    G        = get_generators(agent, which).astype(np.float32, copy=False)
    gsig     = stable_sig(G)
    max_norm = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))

    A = np.asarray(getattr(ctx, "fields", {}).get("A", None), np.float32)
    if A is None: raise RuntimeError("Global A not initialized. Call ensure_global_A(...) first.")
    if A.ndim == 1 and A.shape == (3,):
        key = (f"expA_{which}_scalar", step_tag, gsig)
        U = C.get("exp", key)
        if U is None:
            a = retract_phi_principal(A, use_float64=False)
            U = exp_lie_algebra_irrep(a, G, max_norm=max_norm).astype(np.float32, copy=False)
            C.put("exp", key, U)
        return U  # (K,K)

    # A is (*S, M, 3)
    if not (A.ndim >= 2 and A.shape[-1] == 3):
        raise ValueError(f"expA: expected (*S,M,3) or (3,), got {A.shape}")
    M = int(A.shape[-2])
    S = A.shape[:-2]

    key = (f"expA_{which}_split", step_tag, gsig, S, M)
    U = C.get("exp", key)
    if U is not None:
        return U

    Aproj = retract_phi_principal(A, use_float64=False).astype(np.float32, copy=False)
    # Exponentiate per spatial direction:
    mats = []
    for m in range(M):
        Am = Aproj[..., m, :]                              # (*S, 3)
        Um = exp_lie_algebra_irrep(Am, G, max_norm=max_norm)  # (*S, K, K)
        mats.append(Um)
    U = np.stack(mats, axis=-3).astype(np.float32, copy=False)   # (*S, M, K, K)
    C.put("exp", key, U)
    return U

# ---------- Pure (loky-safe) implementation with shared-disk cache ----------
def _expA_pure(ctx, agent, which: str, G32: np.ndarray, *, max_norm: float):
    """
    Loky-safe PURE path for expA_{q,p}. Uses shared-disk cache when enabled.

    Returns:
      - (K,K)           if A is a scalar 3-vector
      - (*S, M, K, K)   if A is a split field (*S,M,3)

    Cache:
      ns="exp"
      key (scalar): ("expA_pure_scalar", which, step, G_sig, A_dtype, A_shape, A_digest, max_norm)
      key (split) : ("expA_pure_split",  which, step, G_sig, A_dtype, A_shape, A_digest, max_norm)
    """
    import numpy as np
    from core.runtime_context import cfg_get, _shape_sig, _arr_digest
    from core.omega import exp_lie_algebra_irrep, retract_phi_principal

    use_cache = bool(cfg_get(ctx, "pure_write_cache", True))
    step      = int(getattr(ctx, "global_step", 0))

    A = np.asarray(getattr(ctx, "fields", {}).get("A", None), np.float32)
    if A is None:
        raise RuntimeError("Global A not initialized. Call ensure_global_A(...) first.")

    # ---- scalar A (3,) → (K,K) ----
    if A.ndim == 1 and A.shape == (3,):
        if use_cache:
            key = (
                "expA_pure_scalar", str(which), step,
                ("G", G32.dtype.str, _shape_sig(G32), _arr_digest(G32)),
                A.dtype.str, _shape_sig(A), _arr_digest(A),
                float(max_norm),
            )
            hit = ctx.cache.get("exp", key)
            if hit is not None:
                return np.asarray(hit, np.float32, order="C")

        a = retract_phi_principal(A, use_float64=False).astype(np.float32, copy=False)
        U = exp_lie_algebra_irrep(a, G32, max_norm=max_norm).astype(np.float32, copy=False)

        if use_cache:
            ctx.cache.put("exp", key, U)
        return U  # (K,K)

    # ---- split field (*S,M,3) → (*S,M,K,K) ----
    if not (A.ndim >= 2 and A.shape[-1] == 3):
        raise ValueError(f"_expA_pure: expected (*S,M,3) or (3,), got {A.shape}")

    if use_cache:
        key = (
            "expA_pure_split", str(which), step,
            ("G", G32.dtype.str, _shape_sig(G32), _arr_digest(G32)),
            A.dtype.str, _shape_sig(A), _arr_digest(A),
            float(max_norm),
        )
        hit = ctx.cache.get("exp", key)
        if hit is not None:
            return np.asarray(hit, np.float32, order="C")

    Aproj = retract_phi_principal(A, use_float64=False).astype(np.float32, copy=False)
    M = int(Aproj.shape[-2])
    mats = []
    for m in range(M):
        Am = Aproj[..., m, :]                               # (*S,3)
        Um = exp_lie_algebra_irrep(Am, G32, max_norm=max_norm)  # (*S,K,K)
        mats.append(Um.astype(np.float32, copy=False))
    U = np.stack(mats, axis=-3).astype(np.float32, copy=False)  # (*S,M,K,K)

    if use_cache:
        ctx.cache.put("exp", key, U)
    return U


def _expA_generic_pure(ctx, agent, which: str):
    """
    Loky-safe PURE path that reads/rebuilds A, computes expA with shared-disk caching.

    Returns:
      - (K,K)           if A is a scalar 3-vector
      - (*S, M, K, K)   if A is a split field (*S,M,3)

    Cache:
      ns="exp"
      key (scalar): ("expA_pure_scalar", which, step, G_sig, A_dtype, A_shape, A_digest, max_norm)
      key (split) : ("expA_pure_split",  which, step, G_sig, A_dtype, A_shape, A_digest, max_norm)
    """
    import numpy as np
    from core.runtime_context import cfg_get, _shape_sig, _arr_digest
    from core.omega import exp_lie_algebra_irrep, retract_phi_principal

    max_norm = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))
    use_cache = bool(cfg_get(ctx, "pure_write_cache", True))
    step      = int(getattr(ctx, "global_step", 0))

    G = get_generators(agent, which).astype(np.float32, copy=False)

    # Read A; if not present, rebuild from spec without mutating ctx
    try:
        A = np.asarray(getattr(ctx, "fields", {}).get("A", None), np.float32)
        if A is None:
            from core.transport_cache import get_global_A  # local pure accessor
            A = np.asarray(get_global_A(ctx), np.float32)
    except Exception:
        raise RuntimeError("Global A not available to pure path; call ensure_global_A(...) on master first.")

    # ---- scalar A (3,) → (K,K) ----
    if A.ndim == 1 and A.shape == (3,):
        if use_cache:
            key = (
                "expA_pure_scalar", str(which), step,
                ("G", G.dtype.str, _shape_sig(G), _arr_digest(G)),
                A.dtype.str, _shape_sig(A), _arr_digest(A),
                float(max_norm),
            )
            hit = ctx.cache.get("exp", key)
            if hit is not None:
                return np.asarray(hit, np.float32, order="C")

        a = retract_phi_principal(A, use_float64=False)
        U = exp_lie_algebra_irrep(a, G, max_norm=max_norm).astype(np.float32, copy=False)

        if use_cache:
            ctx.cache.put("exp", key, U)
        return U  # (K,K)

    # ---- split field (*S,M,3) → (*S,M,K,K) ----
    if not (A.ndim >= 2 and A.shape[-1] == 3):
        raise ValueError(f"expA(pure): expected (*S,M,3) or (3,), got {A.shape}")

    if use_cache:
        key = (
            "expA_pure_split", str(which), step,
            ("G", G.dtype.str, _shape_sig(G), _arr_digest(G)),
            A.dtype.str, _shape_sig(A), _arr_digest(A),
            float(max_norm),
        )
        hit = ctx.cache.get("exp", key)
        if hit is not None:
            return np.asarray(hit, np.float32, order="C")

    Aproj = retract_phi_principal(A, use_float64=False).astype(np.float32, copy=False)
    M = int(Aproj.shape[-2])
    mats = []
    for m in range(M):
        Am = Aproj[..., m, :]                                # (*S, 3)
        Um = exp_lie_algebra_irrep(Am, G, max_norm=max_norm) # (*S, K, K)
        mats.append(Um.astype(np.float32, copy=False))
    U = np.stack(mats, axis=-3).astype(np.float32, copy=False)  # (*S, M, K, K)

    if use_cache:
        ctx.cache.put("exp", key, U)
    return U



#==============================================================================
#
#                  GAUGE FRAMES
#
#==============================================================================




def E_grid(ctx, agent, which: str = "q") -> np.ndarray:
    """
    Dispatcher:
      transport_backend = "ctx"  -> cached impl (legacy behavior)
      transport_backend = "pure" -> pure, no-cache impl
    If transport_validation=True, runs both and logs a warning if mismatched (uses primary output).
    """
    from core.runtime_context import cfg_get
    
    backend = str(cfg_get(ctx, "transport_backend", "ctx")).lower()
    validate = bool(cfg_get(ctx, "transport_validation", False))
    rtol = float(cfg_get(ctx, "transport_valid_rtol", 1e-6))
    atol = float(cfg_get(ctx, "transport_valid_atol", 1e-6))

    if backend == "pure":
        primary = _E_grid_pure_impl
        shadow  = _E_grid_cached_impl
    else:
        primary = _E_grid_cached_impl
        shadow  = _E_grid_pure_impl

    out = primary(ctx, agent, which=which)

    if validate:
        try:
            ref = shadow(ctx, agent, which=which)
            np.testing.assert_allclose(out, ref, rtol=rtol, atol=atol)
        except AssertionError as e:
            aid = _aid(agent)
            print(f"[transport-check] E_grid({which}) mismatch for agent {aid}: "
                  f"{str(e).splitlines()[0]}  (rtol={rtol}, atol={atol})")
    return out



def _E_grid_pure_impl(ctx, agent, which: str = "q") -> np.ndarray:
    
    from core.runtime_context import cfg_get,  _shape_sig, _arr_digest
    use_A       = bool(cfg_get(ctx, "use_global_A", True))
    compose_ord = cfg_get(ctx, "A_compose_order", None)
    th_small    = float(cfg_get(ctx, "phi_small_threshold", 1e-3))
    max_norm    = float(cfg_get(ctx, "exp_clip_max_norm",   1e4))

    # ----- NEW: shared-disk cache probe -----
    if bool(cfg_get(ctx, "pure_write_cache", True)):
        aid  = AA.get_id(agent)
        step = int(getattr(ctx, "global_step", 0))
        phi  = _get_phi(agent, which)
        G    = get_generators(agent, which)
        key  = _pure_key("E_pure", which, aid, step, _shape_sig(phi), _arr_digest(phi),
                         _shape_sig(G), use_A, compose_ord, max_norm)
        hit = ctx.cache.get("exp", key)   # SharedDiskCache.get returns a memmap/ndarray :contentReference[oaicite:1]{index=1}
        if hit is not None:
            return np.asarray(hit, np.float32, order="C")

    phi = _get_phi(agent, which)                     # (*S,3)
    G   = get_generators(agent, which)               # (3,K,K)
    G32 = np.asarray(G, np.float32, order="C")
    if not (G32.ndim == 3 and G32.shape[0] == 3 and G32.shape[1] == G32.shape[2]):
        raise ValueError(f"E_grid[{which}]: generators must be (3,K,K); got {G32.shape}")
    K = int(G32.shape[1])

    # sanitize φ
    phi32 = retract_phi_principal(np.asarray(phi, np.float32, order="C"),
                                  use_float64=False)

    # Small-angle fast path
    if phi32.shape[-1] == 3:
        th = np.linalg.norm(phi32, axis=-1)
        if float(np.max(th)) < th_small:
            E64 = np.broadcast_to(np.eye(K, dtype=np.float64),
                                  phi32.shape[:-1] + (K, K)).copy()
            if use_A:
                U_geom_raw = _expA_pure(ctx, agent, which, G32, max_norm=max_norm)
                U_geom64 = _compose_or_lift_geom_pure(U_geom_raw, G32, K, max_norm=max_norm, order=compose_ord)
                
                E64 = np.einsum("...ik,...kj->...ij", U_geom64, E64, optimize=True)
            
            return np.asarray(E64, np.float32, order="C")

    # Main path
    E_local64 = exp_lie_algebra_irrep(phi32, G32, max_norm=max_norm)  # (*S,K,K)
    

    if not use_A:
        return np.asarray(E_local64, np.float32, order="C")

    U_geom_raw = _expA_pure(ctx, agent, which, G32, max_norm=max_norm)
    U_geom64 = _compose_or_lift_geom_pure(U_geom_raw, G32, K, max_norm=max_norm, order=compose_ord)
    

    E64 = np.einsum("...ik,...kj->...ij", U_geom64, E_local64, optimize=True)
    out = np.asarray(E64 if use_A else E_local64, np.float32, order="C")  # your existing returns

    # ----- NEW: persist -----
    if bool(cfg_get(ctx, "pure_write_cache", True)):
        ctx.cache.put("exp", key, out)  # atomic, process-safe write (.npy). :contentReference[oaicite:2]{index=2}
    return out



def _E_grid_cached_impl(ctx, agent, which: str = "q") -> np.ndarray:
    """
    Frame map E = exp(phi · G) optionally composed with global geometry A.
    Returns: (*S, K, K)
    """
    import numpy as np
    from core.runtime_context import cfg_get


    if getattr(ctx, "cache", None) is None:
        raise RuntimeError("E_grid: ctx.cache missing")

    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))

    use_A       = bool(cfg_get(ctx, "use_global_A", True))
    compose_ord = cfg_get(ctx, "A_compose_order", None)
    th_small    = float(cfg_get(ctx, "phi_small_threshold", 1e-3))
    max_norm    = float(cfg_get(ctx, "exp_clip_max_norm",   1e4))

    phi = _get_phi(agent, which)                     # (*S,3)
    G   = get_generators(agent, which)               # (3,K, K)
    G32 = np.asarray(G, np.float32, order="C")
    if not (G32.ndim == 3 and G32.shape[0] == 3 and G32.shape[1] == G32.shape[2]):
        raise ValueError(f"E_grid[{which}]: generators must be (3,K,K); got {G32.shape}")
    K = int(G32.shape[1])

    gsig   = stable_sig(("G", G32))
    phisig = stable_sig(("phi", np.asarray(phi, np.float32, order="C")))
    cfgsig = stable_sig(("useA", use_A), ("ord", compose_ord),
                        ("thr", th_small), ("clip", max_norm))
    key = ("E_grid", step_tag, _aid(agent), which, gsig, phisig, cfgsig)
    E_cached = C.get("exp", key)
    if E_cached is not None:
        return E_cached

    # sanitize φ
    phi32 = retract_phi_principal(np.asarray(phi, np.float32, order="C"),
                                   use_float64=False)

    # ---------------- small-angle fast path: E ≈ I ----------------
    if phi32.shape[-1] == 3:
        th = np.linalg.norm(phi32, axis=-1)
        if float(np.max(th)) < th_small:
            # start from identity in KxK
            E64 = np.broadcast_to(np.eye(K, dtype=np.float64),
                                  phi32.shape[:-1] + (K, K)).copy()
            if use_A:
                U_geom_raw = expA_q(ctx, agent) if which == "q" else expA_p(ctx, agent)
                U_geom64 = _compose_geom_if_split(U_geom_raw, order=compose_ord)  # (*S,?,?)
                # LIFT to K×K if needed
                if U_geom64.ndim >= 2 and U_geom64.shape[-1] != K:
                    phi_A = _so3_log_matrix(U_geom64)  # (*S,3)
                    U_geom64 = exp_lie_algebra_irrep(phi_A.astype(np.float32), G32, max_norm=max_norm)
                
                E64 = np.einsum("...ik,...kj->...ij", U_geom64, E64, optimize=True)
            
            E = np.asarray(E64, np.float32, order="C")
            C.put("exp", key, E)
            return E

    # ---------------- main path: local site exponential ----------------
    # build local exponential in float64 via lift
    E_local = exp_lie_algebra_irrep(phi32, G32, max_norm=max_norm)  # (*S, K, K)
    

    E_local64 = E_local

    if not use_A:
        E = np.asarray(E_local64, np.float32, order="C")
        C.put("exp", key, E)
        return E

    # compose geometry
    U_geom_raw = expA_q(ctx, agent) if which == "q" else expA_p(ctx, agent)
    U_geom64 = _compose_geom_if_split(U_geom_raw, order=compose_ord)  # (*S,?,?)

    # LIFT to K×K if needed
    if U_geom64.ndim >= 2 and U_geom64.shape[-1] != K:
        phi_A = _so3_log_matrix(U_geom64)  # (*S,3)
        U_geom64 = exp_lie_algebra_irrep(phi_A.astype(np.float32), G32, max_norm=max_norm)


    # final composition (float64), polar-retract, cast
    
    E64 = np.einsum("...ik,...kj->...ij", U_geom64, E_local64, optimize=True)
  
    E = np.asarray(E64, np.float32, order="C")
    C.put("exp", key, E)
    return E



def E_grid_field(ctx, phi_field, generators, *, sign=+1):
    """
    Pure exponential from a *field* (no agent/cache): E = exp(sign * φ · G).
    φ: (..., 3), G: (3, K, K). Returns (..., K, K).
    """
    import numpy as np
    from core.runtime_context import cfg_get

    if sign not in (+1, -1):
        raise ValueError(f"E_grid_field: sign must be +1 or -1, got {sign!r}")

    phi = np.asarray(phi_field, np.float32, order="C")
    if sign == -1:
        phi = -phi

    # sanitize φ to principal ball
    phi = retract_phi_principal(phi, use_float64=False).astype(np.float32, copy=False)

    G = np.asarray(generators, np.float32, order="C")
    if not (G.ndim == 3 and G.shape[0] == 3 and G.shape[1] == G.shape[2]):
        raise ValueError(f"E_grid_field: generators must be (3,K,K); got {G.shape}")

    max_norm = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))
    return exp_lie_algebra_irrep(phi, G, max_norm=max_norm)

#==============================================================================
#
#                  OMEGA
#
#==============================================================================


def _Omega_cached_impl(ctx: Any, ai: Any, aj: Any, which: str = "q") -> np.ndarray:
    import numpy as np
    from core.runtime_context import cfg_get

    if getattr(ctx, "cache", None) is None:
        raise RuntimeError("Omega: ctx.cache missing")
    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))
    mode     = str(cfg_get(ctx, "freeze_omega_mode", "none")).lower()

    # ---------- IDENTITY mode (N-D safe) ----------
    if mode == "identity":
        Gi = get_generators(ai, which); Gj = get_generators(aj, which)
        Gi32 = np.asarray(Gi, np.float32, order="C"); Gj32 = np.asarray(Gj, np.float32, order="C")
        if not (Gi32.ndim == 3 and Gi32.shape[0] == 3 and Gi32.shape[1] == Gi32.shape[2]):
            raise ValueError(f"Omega[{which}]: generators_i must be (3,K,K); got {Gi32.shape}")
        if not (Gj32.ndim == 3 and Gj32.shape[0] == 3 and Gj32.shape[1] == Gj32.shape[2]):
            raise ValueError(f"Omega[{which}]: generators_j must be (3,K,K); got {Gj32.shape}")
        Ki, Kj = int(Gi32.shape[1]), int(Gj32.shape[1])
        if Ki != Kj:
            raise ValueError(f"Omega[{which}]-identity: Ki ({Ki}) != Kj ({Kj}); no identity transport defined")
        try:
            S = np.asarray(_get_phi(ai, which)).shape[:-1]
        except Exception:
            m = np.asarray(getattr(ai, "mask"))
            if m.ndim >= 1 and m.shape[-1] == 1: m = m[..., 0]
            S = m.shape
        keyI = ("Omega_identity", step_tag, _aid(ai), _aid(aj), which, S, Ki)
        OmI = C.get("omega", keyI)
        if OmI is None:
            OmI = np.broadcast_to(np.eye(Ki, dtype=np.float32), tuple(S) + (Ki, Ki)).copy()
            C.put("omega", keyI, OmI)
        return OmI

    # ---------- Default mode ----------
    phi_i = _get_phi(ai, which); phi_j = _get_phi(aj, which)
    Gi = get_generators(ai, which); Gj = get_generators(aj, which)
    Gi32 = np.asarray(Gi, np.float32, order="C"); Gj32 = np.asarray(Gj, np.float32, order="C")
    if not (Gi32.ndim == 3 and Gi32.shape[0] == 3 and Gi32.shape[1] == Gi32.shape[2]):
        raise ValueError(f"Omega[{which}]: generators_i must be (3,K,K); got {Gi32.shape}")
    if not (Gj32.ndim == 3 and Gj32.shape[0] == 3 and Gj32.shape[1] == Gj32.shape[2]):
        raise ValueError(f"Omega[{which}]: generators_j must be (3,K,K); got {Gj32.shape}")

    gensig_i = getattr(ai, f"_gensig_{which}", None)
    if gensig_i is None:
        gensig_i = stable_sig(("G", Gi32)); setattr(ai, f"_gensig_{which}", gensig_i)
    gensig_j = getattr(aj, f"_gensig_{which}", None)
    if gensig_j is None:
        gensig_j = stable_sig(("G", Gj32)); setattr(aj, f"_gensig_{which}", gensig_j)
    phisig_i = stable_sig(("phi", np.asarray(phi_i, np.float32, order="C")))
    phisig_j = stable_sig(("phi", np.asarray(phi_j, np.float32, order="C")))

    key = ("Omega", step_tag, _aid(ai), _aid(aj), which, gensig_i, gensig_j, phisig_i, phisig_j)
    Om = C.get("omega", key)
    if Om is not None:
        return Om

    Ei64 = E_grid(ctx, ai, which)   # (*S, K, K)
    Ej64 = E_grid(ctx, aj, which)   # (*S, K, K)
    if not (np.isfinite(Ei64).all() and np.isfinite(Ej64).all()):
        raise FloatingPointError("Omega: non-finite frame exponentials")

    Om64 = np.einsum("...ik,...jk->...ij", Ei64, Ej64, optimize=True)  # Ei @ Ej^T
    if not np.isfinite(Om64).all():
        raise FloatingPointError("Omega: non-finite Ω after polar")

    Om = np.asarray(Om64, np.float32, order="C")
    C.put("omega", key, Om)
    return Om



def _Omega_pure_impl(ctx: Any, ai: Any, aj: Any, which: str = "q") -> np.ndarray:
    
    from core.runtime_context import cfg_get,  _shape_sig, _arr_digest

    mode = str(cfg_get(ctx, "freeze_omega_mode", "none")).lower()

    # ---------- IDENTITY mode (no cache) ----------
    if mode == "identity":
        Gi = get_generators(ai, which); Gj = get_generators(aj, which)
        Gi32 = np.asarray(Gi, np.float32, order="C"); Gj32 = np.asarray(Gj, np.float32, order="C")
        if not (Gi32.ndim == 3 and Gi32.shape[0] == 3 and Gi32.shape[1] == Gi32.shape[2]):
            raise ValueError(f"Omega[{which}]: generators_i must be (3,K,K); got {Gi32.shape}")
        if not (Gj32.ndim == 3 and Gj32.shape[0] == 3 and Gj32.shape[1] == Gj32.shape[2]):
            raise ValueError(f"Omega[{which}]: generators_j must be (3,K,K); got {Gj32.shape}")
        Ki, Kj = int(Gi32.shape[1]), int(Gj32.shape[1])
        if Ki != Kj:
            raise ValueError(f"Omega[{which}]-identity: Ki ({Ki}) != Kj ({Kj}); no identity transport defined")

        try:
            S = np.asarray(_get_phi(ai, which)).shape[:-1]
        except Exception:
            m = np.asarray(getattr(ai, "mask"))
            if m.ndim >= 1 and m.shape[-1] == 1: m = m[..., 0]
            S = m.shape
        return np.broadcast_to(np.eye(Ki, dtype=np.float32), tuple(S) + (Ki, Ki)).copy()

    # ----- NEW: cache probe before computing -----
    if bool(cfg_get(ctx, "pure_write_cache", True)):
        step = int(getattr(ctx, "global_step", 0))
        phi_i = _get_phi(ai, which); phi_j = _get_phi(aj, which)
        Gi = get_generators(ai, which); Gj = get_generators(aj, which)
        key = _pure_key("Omega_pure", which, int(getattr(ai,"id",-1)), int(getattr(aj,"id",-1)),
                        step, _shape_sig(phi_i), _arr_digest(phi_i), _shape_sig(phi_j), _arr_digest(phi_j),
                        _shape_sig(Gi), _shape_sig(Gj))
        hit = ctx.cache.get("omega", key)
        if hit is not None:
            return np.asarray(hit, np.float32, order="C")

    # ---------- Default mode (pure) ----------
    Ei64 = E_grid(ctx, ai, which)   # already dual-path, pure if backend="pure"
    Ej64 = E_grid(ctx, aj, which)
    
    if not (np.isfinite(Ei64).all() and np.isfinite(Ej64).all()):
        raise FloatingPointError("Omega(pure): non-finite frame exponentials")

    Om64 = np.einsum("...ik,...jk->...ij", Ei64, Ej64, optimize=True)  # Ei @ Ej^T
    
    if not np.isfinite(Om64).all():
        raise FloatingPointError("Omega(pure): non-finite Ω after polar")
    
    out = np.asarray(Om64, np.float32, order="C")
    
    if bool(cfg_get(ctx, "pure_write_cache", True)):
            ctx.cache.put("omega", key, out)   # matches cached branch behavior. :contentReference[oaicite:6]{index=6}
    return out



def Omega(ctx: Any, ai: Any, aj: Any, which: str = "q") -> np.ndarray:
    """
    Neighbor transport Ω_{ij}. Builds Ω = E_i E_j^T with strict orthonormalization.

    config.freeze_omega_mode:
      - "none"     : default behavior
      - "identity" : per-site identity (*S, K, K) (shape taken from ai)

    Backends:
      config.transport_backend = "ctx" (default) | "pure"
      If config.transport_validation = True, runs both and logs diffs; returns primary.
    """
    import numpy as np
    from core.runtime_context import cfg_get

    backend  = str(cfg_get(ctx, "transport_backend", "ctx")).lower()   # "ctx" | "pure"
    validate = bool(cfg_get(ctx, "transport_validation", False))
    rtol     = float(cfg_get(ctx, "transport_valid_rtol", 1e-6))
    atol     = float(cfg_get(ctx, "transport_valid_atol", 1e-6))

    primary = _Omega_pure_impl if backend == "pure" else _Omega_cached_impl
    shadow  = _Omega_cached_impl if backend == "pure" else _Omega_pure_impl

    Om = primary(ctx, ai, aj, which)

    if validate:
        try:
            ref = shadow(ctx, ai, aj, which)
            np.testing.assert_allclose(Om, ref, rtol=rtol, atol=atol)
        except AssertionError as e:
            print(f"[transport-check] Omega({which}) mismatch for pair ({_aid(ai)},{_aid(aj)}): "
                  f"{str(e).splitlines()[0]} (rtol={rtol}, atol={atol})")
    return Om


#==============================================================================
#
#                  J INVERSE
#
#==============================================================================


def _Jinv_crop_nd(J, bbox):
    """
    N-D crop helper for J with shape (*S, 3, 3).
    Supports legacy 2-D bbox (y0,y1,x0,x1) by center-slicing extra leading axes.
    """
    import numpy as np

    if bbox is None:
        return J
    J = np.asarray(J)
    if J.ndim < 3 or J.shape[-2:] != (3, 3):
        return J  # not a spatial field; ignore

    S = J.shape[:-2]
    M = len(S)
    if M == 0:
        return J

    if not (isinstance(bbox, (tuple, list)) and len(bbox) == 4):
        return J

    y0, y1, x0, x1 = map(int, bbox)
    H, W = S[-2], S[-1]
    if not (0 <= y0 < y1 <= H and 0 <= x0 < x1 <= W):
        raise ValueError(f"Jinv_grid: bbox {bbox} out of bounds for ({H},{W})")

    idx = []
    if M > 2:
        for ax in range(M - 2):
            mid = S[ax] // 2
            idx.append(slice(mid, mid + 1))
    idx.extend([slice(y0, y1), slice(x0, x1), slice(None), slice(None)])
    Jc = J[tuple(idx)]
    if M > 2:
        # squeeze the center-sliced singleton spatial axes
        Jc = np.squeeze(Jc, axis=tuple(range(M - 2)))
    return Jc



def _Jinv_grid_cached(ctx, agent, which="q", bbox=None):
    import numpy as np
    from core.omega import build_dexpinv_matrix

    if getattr(ctx, "cache", None) is None:
        raise RuntimeError("Jinv_grid: ctx.cache missing")
    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))

    # pull phi (keep dtype as-is)
    phi = np.asarray(_get_phi(agent, which), order="C")
    key = ("Jinv_grid", step_tag, _aid(agent), which,
           stable_sig(("phi", np.asarray(phi, np.float32, order="C"))))

    J = C.get("jinv", key)
    if J is None:
        J = build_dexpinv_matrix(phi, use_float64=(phi.dtype == np.float64))
        if not np.all(np.isfinite(J)):
            raise FloatingPointError("Jinv_grid: non-finite J")
        C.put("jinv", key, J)

    return _Jinv_crop_nd(J, bbox)


# ---------- Pure (loky-safe) implementation with shared-disk cache ----------
def _Jinv_grid_pure(ctx, agent, which="q", bbox=None):
    import numpy as np
    from core.runtime_context import cfg_get, _shape_sig, _arr_digest
    from core.omega import build_dexpinv_matrix

    use_cache = bool(cfg_get(ctx, "pure_write_cache", True))

    # Build a stable key for the *full* Jinv grid (crop applied after load)
    phi = np.asarray(_get_phi(agent, which))          # keep dtype
    aid  = AA.get_id(agent)
    step = int(getattr(ctx, "global_step", 0))
    key  = ("Jinv_pure", which, aid, step, phi.dtype.str, _shape_sig(phi), _arr_digest(phi))

    if use_cache:
        hit = ctx.cache.get("jinv", key)              # returns ndarray/memmap or None
        if hit is not None:
            J = np.asarray(hit, dtype=phi.dtype, order="C")
            return _Jinv_crop_nd(J, bbox)

    # Miss: compute, then persist
    J = build_dexpinv_matrix(phi, use_float64=(phi.dtype == np.float64))
    if not np.all(np.isfinite(J)):
        raise FloatingPointError("Jinv_grid(pure): non-finite J")

    # Store as float32 on disk to keep files small, but preserve compute dtype in RAM
    if use_cache:
        ctx.cache.put("jinv", key, np.asarray(J, np.float32, order="C"))

    return _Jinv_crop_nd(J, bbox)



# ---------- Dispatcher with optional validation ----------
def Jinv_grid(ctx, agent, which="q", bbox=None):
    """
    Grid of dexp^{-1}(phi) matrices: shape (*S, 3, 3).

    Backend:
      config.transport_backend = "ctx" (default) | "pure"
    Validation:
      config.transport_validation = True -> run both, compare, return primary.
    """
    import numpy as np
    from core.runtime_context import cfg_get

    backend  = str(cfg_get(ctx, "transport_backend", "ctx")).lower()
    validate = bool(cfg_get(ctx, "transport_validation", False))
    rtol     = float(cfg_get(ctx, "transport_valid_rtol", 1e-6))
    atol     = float(cfg_get(ctx, "transport_valid_atol", 1e-6))

    primary = _Jinv_grid_pure if backend == "pure" else _Jinv_grid_cached
    shadow  = _Jinv_grid_cached if backend == "pure" else _Jinv_grid_pure

    out = primary(ctx, agent, which=which, bbox=bbox)

    if validate:
        try:
            ref = shadow(ctx, agent, which=which, bbox=bbox)
            np.testing.assert_allclose(out, ref, rtol=rtol, atol=atol)
        except AssertionError as e:
            print(f"[transport-check] Jinv_grid({which}) mismatch for agent {_aid(agent)}: "
                  f"{str(e).splitlines()[0]} (rtol={rtol}, atol={atol})")
    return out




def exp_and_jinv_single(ctx, agent, field: str, *args):
    """
    Resolve exp(field) and Jinv for one agent/fiber using backend-aware E_grid/Jinv_grid.
    Back-compat:
      Old signature: (ctx, agent, field, base_field, generators_q, generators_p)
      New signature: (ctx, agent, field, [generators_q=None], [generators_p=None])

    Returns:
      exp_this, exp_other, Jinv, which, G_q, G_p
    """
    # ---- parse args for both signatures ----
    generators_q = None
    generators_p = None
    
    if len(args) == 0:
        pass
    elif len(args) == 1:
        # new-style: (generators_q,)
        generators_q = args[0]
    elif len(args) == 2:
        # new-style: (generators_q, generators_p)
        generators_q, generators_p = args
    elif len(args) == 3:
        # old-style: (base_field, generators_q, generators_p)  -> ignore base_field
        _, generators_q, generators_p = args
    else:
        raise TypeError(
            "exp_and_jinv_single() unexpected arguments. "
            "Use (ctx, agent, field [, generators_q [, generators_p]]) "
            "or legacy (ctx, agent, field, base_field, generators_q, generators_p)."
        )

    which = "q" if str(field) == "phi" else "p"

    # frames (pure if transport_backend='pure')
    exp_q = E_grid(ctx, agent, which="q")
    exp_p = E_grid(ctx, agent, which="p")
    Jinv  = Jinv_grid(ctx, agent, which=which)

    exp_this  = exp_q if which == "q" else exp_p
    exp_other = exp_p if which == "q" else exp_q

    # generators (fetch if not provided)
    G_q = generators_q if generators_q is not None else get_generators(agent, "q")
    G_p = generators_p if generators_p is not None else get_generators(agent, "p")

    return exp_this, exp_other, Jinv, which, G_q, G_p








#==============================================================================
#
#                  BUNDLE MORPHISMS
#
#==============================================================================



def _Phi_cached_impl(ctx, agent, kind: str = "q_to_p"):
    """
    Bundle morphisms:
      q_to_p: Φ  = E_p  Φ₀   (E_q)^{-1}
      p_to_q: Φ̃ = E_q  Φ̃₀  (E_p)^{-1}
    Cached per agent/rep/fields/geometry knobs.
    """
    import numpy as np
    from core.runtime_context import cfg_get

    if getattr(ctx, "cache", None) is None:
        raise RuntimeError("Phi: ctx.cache required")
    if kind not in ("q_to_p", "p_to_q"):
        raise ValueError(f"Phi: unknown kind={kind!r}")

    C        = ctx.cache
    step_tag = int(getattr(ctx, "global_step", -1))
    aid      = _aid(agent)

    # Generators (validate early)
    Gq = np.asarray(get_generators(agent, "q"), np.float32, order="C")
    Gp = np.asarray(get_generators(agent, "p"), np.float32, order="C")
    if not (Gq.ndim == 3 and Gq.shape[0] == 3 and Gq.shape[1] == Gq.shape[2]):
        raise ValueError(f"Phi[q]: generators must be (3,Kq,Kq); got {Gq.shape}")
    if not (Gp.ndim == 3 and Gp.shape[0] == 3 and Gp.shape[1] == Gp.shape[2]):
        raise ValueError(f"Phi[p]: generators must be (3,Kp,Kp); got {Gp.shape}")
    Kq, Kp  = int(Gq.shape[1]), int(Gp.shape[1])
    sigGq   = stable_sig(("Gq", Gq))
    sigGp   = stable_sig(("Gp", Gp))

    # Bases (Φ0, Φ̃0)
    Phi0, Phit0 = get_morphism_bases(ctx, agent)  # shapes (Kp,Kq) and (Kq,Kp)
    sigB        = stable_sig(("Phi0", Phi0), ("Phit0", Phit0))

    # Geometry knobs that affect E_grid -> Φ
    use_A    = bool(cfg_get(ctx, "use_global_A", True))
    ord_raw  = cfg_get(ctx, "A_compose_order", "yx")
    axis_ord = str(ord_raw).lower()
    th_small = float(cfg_get(ctx, "phi_small_threshold", 0.0))
    max_norm = float(cfg_get(ctx, "exp_clip_max_norm", 1e4))
    geom_sig = stable_sig(("useA", use_A), ("ord", axis_ord),
                          ("thr", th_small), ("clip", max_norm))

    # Sign sanitized fields (same values E_grid uses)
    phi_q = np.asarray(_get_phi(agent, "q"), np.float32, order="C")
    phi_p = np.asarray(_get_phi(agent, "p"), np.float32, order="C")
    sigPh = stable_sig(("phi_q", phi_q), ("phi_p", phi_p))

    # Keys (cache both directions)
    key_qp = ("morphism_full", aid, (Kq, Kp), "q_to_p", sigGq, sigGp, sigB, geom_sig, sigPh, step_tag)
    key_pq = ("morphism_full", aid, (Kq, Kp), "p_to_q", sigGq, sigGp, sigB, geom_sig, sigPh, step_tag)

    M_qp = C.get("morphism", key_qp)
    M_pq = C.get("morphism", key_pq)
    if M_qp is not None and M_pq is not None:
        return M_qp if kind == "q_to_p" else M_pq

    # Build frames (E_grid caches internally in cached backend)
    Eq = E_grid(ctx, agent, "q")    # (...,Kq,Kq) or (Kq,Kq)
    Ep = E_grid(ctx, agent, "p")    # (...,Kp,Kp) or (Kp,Kp)
    inv_Eq = safe_omega_inv(Eq)
    inv_Ep = safe_omega_inv(Ep)

    # Underflow-safe chains (float64 inside _safe_matmul32), then clamp to f32
    Phi_full  = _safe_matmul32(_safe_matmul32(Ep,  Phi0),  inv_Eq)
    Phit_full = _safe_matmul32(_safe_matmul32(Eq, Phit0),  inv_Ep)

    if not (np.isfinite(Phi_full).all() and np.isfinite(Phit_full).all()):
        raise FloatingPointError("Phi: non-finite result")

    Phi_full  = np.asarray(Phi_full,  np.float32, order="C")
    Phit_full = np.asarray(Phit_full, np.float32, order="C")
    C.put("morphism", key_qp, Phi_full)
    C.put("morphism", key_pq, Phit_full)
    return Phi_full if kind == "q_to_p" else Phit_full


def _Phi_pure_impl(ctx, agent, kind: str = "q_to_p"):
    
    from core.runtime_context import cfg_get,  _shape_sig, _arr_digest

    if kind not in ("q_to_p","p_to_q"): raise ValueError(...)

    # ----- NEW: cache probe -----
    if bool(cfg_get(ctx, "pure_write_cache", True)):
        aid  = AA.get_id(agent)
        step = int(getattr(ctx, "global_step", 0))
        Eq_shape = _shape_sig(_get_phi(agent, "q"))
        Ep_shape = _shape_sig(_get_phi(agent, "p"))
        Phi0, Phit0 = get_morphism_bases(ctx, agent)   # pure read already
        key = _pure_key("Phi_pure", kind, aid, step, Eq_shape, Ep_shape,
                        _shape_sig(Phi0), _arr_digest(Phi0), _shape_sig(Phit0), _arr_digest(Phit0))
        hit = ctx.cache.get("morphism", key)
        if hit is not None:
            return np.asarray(hit, np.float32, order="C")

    Eq = E_grid(ctx, agent, "q"); Ep = E_grid(ctx, agent, "p")
    inv_Eq = safe_omega_inv(Eq);   inv_Ep = safe_omega_inv(Ep)
    Phi0, Phit0 = get_morphism_bases(ctx, agent)

    out = _safe_matmul32(_safe_matmul32(Ep, Phi0), inv_Eq) if kind == "q_to_p" \
          else _safe_matmul32(_safe_matmul32(Eq, Phit0), inv_Ep)
    out = np.asarray(out, np.float32, order="C")

    if bool(cfg_get(ctx, "pure_write_cache", True)):
        ctx.cache.put("morphism", key, out)  # same ns used in cached impl. :contentReference[oaicite:7]{index=7}
    return out



# ---------- DISPATCHER + OPTIONAL VALIDATION ----------
def Phi(ctx, agent, kind: str = "q_to_p"):
    """
    Bundle morphisms:
      q_to_p: Φ  = E_p  Φ₀   (E_q)^{-1}
      p_to_q: Φ̃ = E_q  Φ̃₀  (E_p)^{-1}

    Backends:
      config.transport_backend = "ctx" (default) | "pure"
    Validation:
      config.transport_validation = True -> run both and compare (non-fatal).
    """
    import numpy as np
    from core.runtime_context import cfg_get

    backend  = str(cfg_get(ctx, "transport_backend", "ctx")).lower()
    validate = bool(cfg_get(ctx, "transport_validation", False))
    rtol     = float(cfg_get(ctx, "transport_valid_rtol", 1e-6))
    atol     = float(cfg_get(ctx, "transport_valid_atol", 1e-6))

    primary = _Phi_pure_impl if backend == "pure" else _Phi_cached_impl
    shadow  = _Phi_cached_impl if backend == "pure" else _Phi_pure_impl

    out = primary(ctx, agent, kind)

    if validate:
        try:
            ref = shadow(ctx, agent, kind)
            np.testing.assert_allclose(out, ref, rtol=rtol, atol=atol)
        except AssertionError as e:
            print(f"[transport-check] Phi({kind}) mismatch for agent {_aid(agent)}: "
                  f"{str(e).splitlines()[0]} (rtol={rtol}, atol={atol})")
    return out









# --- Cached (legacy master) implementation ---
def _get_morphism_bases_cached(ctx, agent):
    """
    Uses ctx.cache.nsp('morph_base'); rebuilds on generator digest changes.
    Master-only (not loky-safe).
    """
    import numpy as np
    from core.runtime_context import cfg_get
    from core.bundle_morphism_utils import build_intertwiner_bases, _morph_finalize_and_check

    ns = ctx.cache.nsp("morph_base")

    # Generators & sizes
    Gq = np.asarray(get_generators(agent, "q"), np.float32, order="C")  # (3,Kq,Kq)
    Gp = np.asarray(get_generators(agent, "p"), np.float32, order="C")  # (3,Kp,Kp)
    if not (Gq.ndim == 3 and Gq.shape[0] == 3 and Gq.shape[1] == Gq.shape[2]):
        raise ValueError(f"[morph] Gq must be (3,Kq,Kq); got {Gq.shape}")
    if not (Gp.ndim == 3 and Gp.shape[0] == 3 and Gp.shape[1] == Gp.shape[2]):
        raise ValueError(f"[morph] Gp must be (3,Kp,Kp); got {Gp.shape}")

    Kq, Kp = int(Gq.shape[1]), int(Gp.shape[1])
    aid    = _aid(agent)
    key    = (aid, Kq, Kp)

    # Digest to guard rebuilds
    dig_now = stable_sig(
        ("Gq", Gq), ("Gp", Gp),
        ("Kq", Kq), ("Kp", Kp),
        ("impl", "build_intertwiner_bases@v1"),
        ("method", "auto"),
        ("orth_if_square", bool(cfg_get(ctx, "morphism_orthogonalize_if_square", True))),
    )

    # Cache hit
    entry = ns.get(key)
    if entry is not None and entry.get("digest") == dig_now:
        return entry["Phi0"], entry["Phit0"]

    # Prefer agent-provided bases
    Phi0_agent  = getattr(agent, "Phi0_base",  None) or getattr(agent, "Phi_0", None)
    Phit0_agent = getattr(agent, "Phit0_base", None) or getattr(agent, "Phi_tilde_0", None)
    if isinstance(Phi0_agent, np.ndarray) and isinstance(Phit0_agent, np.ndarray):
        Phi0, Phit0 = _morph_finalize_and_check(ctx, Gq, Gp, Phi0_agent, Phit0_agent, Kq=Kq, Kp=Kp)
        ns[key] = {"Phi0": Phi0, "Phit0": Phit0, "digest": dig_now}
        return Phi0, Phit0

    # Build once
    Phi0_new, Phit0_new, _ = build_intertwiner_bases(Gq, Gp, method="auto", return_meta=True)
    Phi0, Phit0 = _morph_finalize_and_check(ctx, Gq, Gp, Phi0_new, Phit0_new, Kq=Kq, Kp=Kp)
    ns[key] = {"Phi0": Phi0, "Phit0": Phit0, "digest": dig_now}
    return Phi0, Phit0


# --- Pure (loky-safe) implementation ---
@lru_cache(maxsize=512)
def _get_morphism_bases_pure_digest(digest_bytes):
    """
    Tiny per-process LRU keyed by a digest; returns (Phi0, Phit0) arrays.
    This is loky-safe (process-local) and avoids recomputing bases repeatedly in workers.
    """
    # This function body is filled by the caller via a closure-like pattern; we only
    # use it as an LRU shell keyed by bytes. We’ll never actually call it directly.


def _get_morphism_bases_pure(ctx, agent):
    """
    No ctx.cache; reads agent-provided bases if present, else builds.
    Uses a per-process LRU keyed by a stable digest to avoid repeated builds in workers.
    """
    import numpy as np
    from core.runtime_context import cfg_get
    from core.bundle_morphism_utils import build_intertwiner_bases, _morph_finalize_and_check

    # Generators & sizes
    Gq = np.asarray(get_generators(agent, "q"), np.float32, order="C")
    Gp = np.asarray(get_generators(agent, "p"), np.float32, order="C")
    if not (Gq.ndim == 3 and Gq.shape[0] == 3 and Gq.shape[1] == Gq.shape[2]):
        raise ValueError(f"[morph] Gq must be (3,Kq,Kq); got {Gq.shape}")
    if not (Gp.ndim == 3 and Gp.shape[0] == 3 and Gp.shape[1] == Gp.shape[2]):
        raise ValueError(f"[morph] Gp must be (3,Kp,Kp); got {Gp.shape}")

    Kq, Kp = int(Gq.shape[1]), int(Gp.shape[1])

    # Build a digest identical to cached path (so behavior aligns)
    dig_now = stable_sig(
        ("Gq", Gq), ("Gp", Gp),
        ("Kq", Kq), ("Kp", Kp),
        ("impl", "build_intertwiner_bases@v1"),
        ("method", "auto"),
        ("orth_if_square", bool(cfg_get(ctx, "morphism_orthogonalize_if_square", True))),
    )

    # Try per-process LRU
    # We encode the digest tuple into bytes via its string representation; if you have a
    # canonical byte encoder for stable_sig, use that instead.
    digest_bytes = str(dig_now).encode("utf-8")

    # Agent-provided bases short-circuit (no caching)
    Phi0_agent  = getattr(agent, "Phi0_base",  None) or getattr(agent, "Phi_0", None)
    Phit0_agent = getattr(agent, "Phit0_base", None) or getattr(agent, "Phi_tilde_0", None)
    if isinstance(Phi0_agent, np.ndarray) and isinstance(Phit0_agent, np.ndarray):
        return _morph_finalize_and_check(ctx, Gq, Gp, Phi0_agent, Phit0_agent, Kq=Kq, Kp=Kp)

    # LRU lookup/compute pattern
    @lru_cache(maxsize=512)
    def _compute_from_digest(db):
        # db is digest_bytes; close over Gq,Gp,Kq,Kp,ctx
        Phi0_new, Phit0_new, _ = build_intertwiner_bases(Gq, Gp, method="auto", return_meta=True)
        return _morph_finalize_and_check(ctx, Gq, Gp, Phi0_new, Phit0_new, Kq=Kq, Kp=Kp)

    Phi0, Phit0 = _compute_from_digest(digest_bytes)
    return Phi0, Phit0


# --- Dispatcher with optional validation ---
def get_morphism_bases(ctx, agent):
    """
    Returns (Phi0, Phit0) intertwiner bases.

    Backends:
      config.transport_backend = "ctx" (default) | "pure"
    Validation:
      config.transport_validation = True -> build both and compare (non-fatal).
    """
    import numpy as np
    from core.runtime_context import cfg_get

    backend  = str(cfg_get(ctx, "transport_backend", "ctx")).lower()
    validate = bool(cfg_get(ctx, "transport_validation", False))
    rtol     = float(cfg_get(ctx, "transport_valid_rtol", 1e-6))
    atol     = float(cfg_get(ctx, "transport_valid_atol", 1e-6))

    primary = _get_morphism_bases_pure if backend == "pure" else _get_morphism_bases_cached
    shadow  = _get_morphism_bases_cached if backend == "pure" else _get_morphism_bases_pure

    Phi0, Phit0 = primary(ctx, agent)

    if validate:
        try:
            r0, rt = shadow(ctx, agent)
            np.testing.assert_allclose(Phi0, r0, rtol=rtol, atol=atol)
            np.testing.assert_allclose(Phit0, rt, rtol=rtol, atol=atol)
        except AssertionError as e:
            print(f"[transport-check] get_morphism_bases mismatch for agent {_aid(agent)}: "
                  f"{str(e).splitlines()[0]} (rtol={rtol}, atol={atol})")
    return Phi0, Phit0







def Phi_cached(ctx, agent, *, kind: str):
    """
    Backend-aware cached accessor:
      - If transport_backend == "pure" or no cache hub: compute directly (no writes).
      - Else: cache per (agent,id,kind,step) in ctx.cache["Phi"].
    """
    from core.runtime_context import cfg_get

    backend = str(cfg_get(ctx, "transport_backend", "ctx")).lower()
    C = getattr(ctx, "cache", None)
    if backend == "pure" or C is None:
        return Phi(ctx, agent, kind=kind)  # pure, loky-safe path

    step_tag = int(getattr(ctx, "global_step", -1))
    ns = "Phi"
    key = (id(agent), kind, step_tag)

    val = C.get(ns, key)
    if val is not None:
        return val

    M = Phi(ctx, agent, kind=kind)  # cached backend; Phi itself may use cache
    C.put(ns, key, M)
    return M




#==============================================================================
#
#                  FISHER
#
#==============================================================================


def _invert_fisher_blocks_per_pixel(Fflat, mflat, *, d, abs_floor, rel_floor,
                                    do_norm, cap_fro, tiny=1e-12):
    """Vectorized-ish per-pixel inversion with Cholesky backoff and optional norm/cap."""
    import numpy as np
    I_d    = np.eye(d, dtype=np.float64)
    Finv_f = np.zeros_like(Fflat)
    if not np.any(mflat):
        return Finv_f

    M      = Fflat[mflat]                                     # (M,d,d)
    trF    = np.trace(M, axis1=-2, axis2=-1)                  # (M,)
    lam    = np.maximum(abs_floor, rel_floor * (np.abs(trF) / float(d)))
    M_reg  = M + lam[:, None, None] * I_d

    Minv   = np.empty_like(M_reg)
    ok     = np.ones(M.shape[0], dtype=bool)
    tries  = 4
    for _ in range(tries):
        idxs = np.where(ok)[0]
        if idxs.size == 0:
            break
        for idx in idxs:
            Mi = M_reg[idx]
            try:
                L = np.linalg.cholesky(Mi)
                X = np.linalg.solve(L, I_d)
                Minv[idx] = X.T @ X
                ok[idx] = False
            except np.linalg.LinAlgError:
                lam[idx] *= 10.0
                M_reg[idx] = M[idx] + lam[idx] * I_d

    # last-resort pseudo-inverse
    if np.any(ok):
        for idx in np.where(ok)[0]:
            Minv[idx] = np.linalg.pinv(M[idx], rcond=1e-12)

    if do_norm:
        # bring avg eigenvalue of Minv to ~1 by multiplying with avg eig of M_reg
        avg_eig_Mreg = np.maximum(np.trace(M_reg, axis1=-2, axis2=-1) / float(d), tiny)
        Minv = Minv * avg_eig_Mreg[:, None, None]

    if cap_fro and cap_fro > 0.0:
        fn = np.linalg.norm(Minv.reshape(Minv.shape[0], -1), axis=1)
        s  = np.minimum(1.0, cap_fro / (fn + tiny))
        Minv = Minv * s[:, None, None]

    # symmetrize after scaling
    Minv = 0.5 * (Minv + np.swapaxes(Minv, -1, -2))
    Finv_f[mflat] = Minv
    return Finv_f





# --- cached (master) implementation ------------------------------------------
def _inverse_fisher_metric_field_cached(ctx, agent, generators, *, which="q", eps=1e-6, tol=None):
    import numpy as np
    from core.runtime_context import cfg_get
    # config / floors
    tau        = float(cfg_get(ctx, "support_tau", 1e-6))
    abs_floor  = float(cfg_get(ctx, "fisher_abs_floor", 1e-6))
    rel_floor  = float(cfg_get(ctx, "fisher_rel_floor", 1e-3))
    do_norm    = bool(cfg_get(ctx, "fisher_normalize", False))
    cap_fro    = float(cfg_get(ctx, "fisher_cap_fro", 0.0))

    Sig = np.asarray(AA.get_sigma_q(agent, sanitize=False) if which == "q" else AA.get_sigma_p(agent, sanitize=False), np.float64)
    if not np.isfinite(Sig).all():
        raise FloatingPointError("inverse_fisher_metric_field: non-finite Σ")

    Gens = np.asarray(generators, np.float64)  # (d,K,K)
    if Gens.ndim != 3 or Gens.shape[1] != Gens.shape[2]:
        raise ValueError(f"generators must be (d,K,K); got {Gens.shape}")
    if not np.isfinite(Gens).all():
        raise FloatingPointError("inverse_fisher_metric_field: non-finite generators")
    # enforce skew
    Gens = 0.5 * (Gens - np.swapaxes(Gens, -1, -2))

    S = Sig.shape[:-2]; K = Sig.shape[-2]; d = int(Gens.shape[0])
    mask = _broadcast_mask_to_S(S, getattr(agent, "mask", None), tau)

    # cache key
    C    = getattr(ctx, "cache", None)
    step = int(getattr(ctx, "global_step", -1))
    aid  = _aid(agent)
    key  = ("FisherMetricInv_v2", which, aid, step, (S, K, d))
    if C is not None:
        cached = C.get("fisher", key)
        if cached is not None:
            return cached

    # precision Σ^{-1}
    Fb   = Fisher_blocks(ctx, agent, which=which, tol=tol)
    Prec = np.asarray(Fb["precision"], np.float64)  # (*S,K,K)
    if Prec.shape[:-2] != S or Prec.shape[-2:] != (K, K):
        raise ValueError(f"precision shape {Prec.shape} incompatible with Σ {Sig.shape}")
    if not np.isfinite(Prec).all():
        raise FloatingPointError("inverse_fisher_metric_field: non-finite precision from Fisher_blocks")

    # F_ab = -tr(Σ^{-1} G_a Σ^{-1} G_b)
    T = np.einsum("...ij,ajk->...aik", Prec, Gens, optimize=True)    # (*S,d,K,K)
    T = np.einsum("...aik,...kl->...ail", T,   Prec, optimize=True)  # (*S,d,K,K)
    F = -np.einsum("...aij,bji->...ab", T, Gens, optimize=True)      # (*S,d,d)
    F = 0.5 * (F + np.swapaxes(F, -1, -2))
    if not np.isfinite(F).all():
        raise FloatingPointError("inverse_fisher_metric_field: non-finite Fisher matrix")

    # invert per pixel
    N = int(np.prod(S, dtype=int))
    Finv_f = _invert_fisher_blocks_per_pixel(
        F.reshape(N, d, d), mask.reshape(N),
        d=d, abs_floor=abs_floor, rel_floor=rel_floor,
        do_norm=do_norm, cap_fro=cap_fro
    )
    Finv = Finv_f.reshape(S + (d, d)).astype(np.float32, copy=False)

    if C is not None:
        C.put("fisher", key, Finv)
    return Finv



# --- pure (loky-safe) implementation -----------------------------------------
def _inverse_fisher_metric_field_pure(ctx, agent, generators, *, which="q", eps=1e-6, tol=None):
    import numpy as np
    from core.runtime_context import cfg_get, _shape_sig, _arr_digest
    # Note: ctx.cache is a SharedDiskCache in loky workers (ensure_shared_cache_attached)

    tau        = float(cfg_get(ctx, "support_tau", 1e-6))
    abs_floor  = float(cfg_get(ctx, "fisher_abs_floor", 1e-6))
    rel_floor  = float(cfg_get(ctx, "fisher_rel_floor", 1e-3))
    do_norm    = bool(cfg_get(ctx, "fisher_normalize", False))
    cap_fro    = float(cfg_get(ctx, "fisher_cap_fro", 0.0))
    use_cache  = bool(cfg_get(ctx, "pure_write_cache", True))

    Sig = np.asarray(AA.get_sigma_q(agent, sanitize=False) if which == "q" else AA.get_sigma_p(agent, sanitize=False), np.float64)
    if not np.isfinite(Sig).all():
        raise FloatingPointError("inverse_fisher_metric_field: non-finite Σ")

    Gens = np.asarray(generators, np.float64)
    if Gens.ndim != 3 or Gens.shape[1] != Gens.shape[2]:
        raise ValueError(f"generators must be (d,K,K); got {Gens.shape}")
    if not np.isfinite(Gens).all():
        raise FloatingPointError("inverse_fisher_metric_field: non-finite generators")
    Gens = 0.5 * (Gens - np.swapaxes(Gens, -1, -2))  # antisymmetrize

    S = Sig.shape[:-2]; K = Sig.shape[-2]; d = int(Gens.shape[0])
    mask = _broadcast_mask_to_S(S, getattr(agent, "mask", None), tau)

    # 1) precision Σ^{-1} (Fisher_blocks itself can be pure/dual-pathed)
    Fb   = Fisher_blocks(ctx, agent, which=which, tol=tol)
    Prec = np.asarray(Fb["precision"], np.float64)
    if Prec.shape[:-2] != S or Prec.shape[-2:] != (K, K):
        raise ValueError(f"precision shape {Prec.shape} incompatible with Σ {Sig.shape}")
    if not np.isfinite(Prec).all():
        raise FloatingPointError("inverse_fisher_metric_field: non-finite precision from Fisher_blocks")

    # 2) OPTIONAL: shared-disk cache probe (keyed on precision + gens + knobs + mask)
    if use_cache:
        aid  = AA.get_id(agent)
        step = int(getattr(ctx, "global_step", 0))
        key = (
            "Finv_pure", which, aid, step,
            _shape_sig(Prec), _arr_digest(Prec),
            _shape_sig(Gens), _arr_digest(Gens),
            bool(do_norm), float(abs_floor), float(rel_floor), float(cap_fro), float(tau),
            None if tol is None else float(tol),
            _shape_sig(mask), _arr_digest(mask.astype(np.uint8, copy=False)),
        )
        hit = ctx.cache.get("fisher_inv", key)
        if hit is not None:
            return np.asarray(hit, np.float32, order="C")

    # 3) build Fisher matrix field F_ab = -Tr[ Prec G_a Prec G_b ]
    T = np.einsum("...ij,ajk->...aik", Prec, Gens, optimize=True)
    T = np.einsum("...aik,...kl->...ail", T,   Prec, optimize=True)
    F = -np.einsum("...aij,bji->...ab", T, Gens, optimize=True)
    F = 0.5 * (F + np.swapaxes(F, -1, -2))
    if not np.isfinite(F).all():
        raise FloatingPointError("inverse_fisher_metric_field: non-finite Fisher matrix")

    # 4) invert per pixel with floors/normalization
    N = int(np.prod(S, dtype=int))
    Finv_f = _invert_fisher_blocks_per_pixel(
        F.reshape(N, d, d), mask.reshape(N),
        d=d, abs_floor=abs_floor, rel_floor=rel_floor,
        do_norm=do_norm, cap_fro=cap_fro
    )
    out = Finv_f.reshape(S + (d, d)).astype(np.float32, copy=False)

    # 5) persist to shared-disk for other loky workers
    if use_cache:
        ctx.cache.put("fisher_inv", key, out)

    return out




# --- dispatcher with optional validation --------------------------------------
def inverse_fisher_metric_field(ctx, agent, generators, *, which="q", eps=1e-6, tol=None):
    """
    Per-pixel inverse Fisher metric for algebra coords (φ or φ̃).
    F_ab = -tr(Σ^{-1} G_a Σ^{-1} G_b); return (F + λ I)^-1 per pixel.
    Dual-path:
      - transport_backend = "ctx" → cached (master)
      - transport_backend = "pure" → pure (loky-safe)
    If transport_validation=True, runs both and logs mismatch (returns primary).
    """
    import numpy as np
    from core.runtime_context import cfg_get

    backend  = str(cfg_get(ctx, "transport_backend", "ctx")).lower()
    validate = bool(cfg_get(ctx, "transport_validation", False))
    rtol     = float(cfg_get(ctx, "transport_valid_rtol", 1e-6))
    atol     = float(cfg_get(ctx, "transport_valid_atol", 1e-6))

    primary = _inverse_fisher_metric_field_pure if backend == "pure" else _inverse_fisher_metric_field_cached
    shadow  = _inverse_fisher_metric_field_cached if backend == "pure" else _inverse_fisher_metric_field_pure

    out = primary(ctx, agent, generators, which=which, eps=eps, tol=tol)

    if validate:
        try:
            ref = shadow(ctx, agent, generators, which=which, eps=eps, tol=tol)
            np.testing.assert_allclose(out, ref, rtol=rtol, atol=atol)
        except AssertionError as e:
            print(f"[transport-check] inverse_fisher_metric_field({which}) mismatch for agent {_aid(agent)}: "
                  f"{str(e).splitlines()[0]} (rtol={rtol}, atol={atol})")
    return out













# ---- shared compute core (no cache; float64 inside) --------------------------
def _compute_fisher_blocks_core(Sig_f32: np.ndarray, tol=None):
    """
    Sig_f32: (..., K, K) float32/float64
    Returns dict: {"precision": (*S,K,K) float32, "logdet": (*S,) float32}
    """
    Sig = np.asarray(Sig_f32, np.float64, order="C")
    if Sig.shape[-1] != Sig.shape[-2]:
        raise ValueError(f"Sigma must be (...,K,K); got {Sig.shape}")

    # Symmetrize, then Cholesky w/ optional jitter backoff
    Sig = 0.5 * (Sig + np.swapaxes(Sig, -1, -2))

    def _chol_with_jitter(A, base=1e-12, tol_val=None, max_tries=6):
        try:
            return np.linalg.cholesky(A), 0.0
        except np.linalg.LinAlgError:
            pass
        # if tol provided, escalate jitter; else raise like original
        if tol_val is None:
            raise np.linalg.LinAlgError("Σ not SPD even after symmetrization")
        jitter = float(tol_val)
        I = np.eye(A.shape[-1], dtype=A.dtype)
        for _ in range(max_tries):
            try:
                return np.linalg.cholesky(A + jitter * I), jitter
            except np.linalg.LinAlgError:
                jitter *= 10.0
        raise np.linalg.LinAlgError("Σ not SPD after jitter backoff")

    L, used_jitter = _chol_with_jitter(Sig, tol_val=tol)

    # Solve for precision via triangular solves (X = L^{-1} I)
    I = np.eye(Sig.shape[-1], dtype=np.float64)
    I_b = np.broadcast_to(I, Sig.shape[:-2] + I.shape).copy()
    X = np.linalg.solve(L, I_b)             # X = L^{-1}
    Prec = np.swapaxes(X, -1, -2) @ X       # (L^{-T})(L^{-1})
    Prec = 0.5 * (Prec + np.swapaxes(Prec, -1, -2))

    # logdet Σ = 2 * sum(log(diag(L)))
    diagL = np.diagonal(L, axis1=-2, axis2=-1)
    logdet = (2.0 * np.log(np.clip(diagL, 1e-30, None)).sum(axis=-1)).astype(np.float32)

    out = {"precision": Prec.astype(np.float32, copy=False), "logdet": logdet}
    return out



# ---- cached (master) path ----------------------------------------------------
def _Fisher_blocks_cached(ctx, agent, which="q", *, tol=None):
    C = getattr(ctx, "cache", None)
    step_tag = int(getattr(ctx, "global_step", -1))

    Sig = np.asarray(
        getattr(agent, "sigma_q_field" if which == "q" else "sigma_p_field"),
        np.float32, order="C"
    )
    if Sig.shape[-1] != Sig.shape[-2]:
        raise ValueError(f"Sigma must be (...,K,K); got {Sig.shape}")

    key = None
    if C is not None:
        # fast digest on bytes view
        sigsig = hashlib.sha1(Sig.view(np.uint8)).hexdigest()
        key = ("Fisher_blocks", step_tag, _aid(agent), which, Sig.shape[-1], sigsig, tol)
        cached = C.get("fisher", key)
        if cached is not None:
            return cached

    out = _compute_fisher_blocks_core(Sig, tol=tol)

    if C is not None:
        C.put("fisher", key, out)
    return out



# ---- pure (loky-safe) path ---------------------------------------------------
def _Fisher_blocks_pure(ctx, agent, which="q", *, tol=None):
    Sig = np.asarray(
        getattr(agent, "sigma_q_field" if which == "q" else "sigma_p_field"),
        np.float32, order="C"
    )
    if Sig.shape[-1] != Sig.shape[-2]:
        raise ValueError(f"Sigma must be (...,K,K); got {Sig.shape}")

    return _compute_fisher_blocks_core(Sig, tol=tol)



# ---- dispatcher + optional validation ---------------------------------------
def Fisher_blocks(ctx, agent, which="q", *, tol=None):
    """
    Returns {"precision": (*S,K,K) f32, "logdet": (*S,) f32}.
    Backend:
      config.transport_backend = "ctx" (default) | "pure"
    Validation (optional):
      config.transport_validation = True -> compare pure vs cached (non-fatal log).
    """
    from core.runtime_context import cfg_get


    backend  = str(cfg_get(ctx, "transport_backend", "ctx")).lower()
    validate = bool(cfg_get(ctx, "transport_validation", False))
    rtol     = float(cfg_get(ctx, "transport_valid_rtol", 1e-6))
    atol     = float(cfg_get(ctx, "transport_valid_atol", 1e-6))

    primary = _Fisher_blocks_pure if backend == "pure" else _Fisher_blocks_cached
    shadow  = _Fisher_blocks_cached if backend == "pure" else _Fisher_blocks_pure

    out = primary(ctx, agent, which=which, tol=tol)

    if validate:
        try:
            ref = shadow(ctx, agent, which=which, tol=tol)
            # compare both precision and logdet
            np.testing.assert_allclose(out["precision"], ref["precision"], rtol=rtol, atol=atol)
            np.testing.assert_allclose(out["logdet"], ref["logdet"], rtol=rtol, atol=atol)
        except AssertionError as e:
            print(f"[transport-check] Fisher_blocks({which}) mismatch for agent {_aid(agent)}: "
                  f"{str(e).splitlines()[0]} (rtol={rtol}, atol={atol})")
    return out





#==============================================================================
#
#                  Gauge Curvature
#
#==============================================================================





def plaquette_from_A(ctx, agent, which: str = "q", pair: tuple[int, int] | None = None):
    """
    P_ab(i) = U_a(i) · U_b(i+ê_a) · U_a(i+ê_b)^{-1} · U_b(i)^{-1}
    using per-axis links from expA_q/expA_p.

    Pure / loky-safe: no cache writes. expA_* will be pure if transport_backend="pure".
    """
    import numpy as np

    Ugeom = expA_q(ctx, agent) if which == "q" else expA_p(ctx, agent)  # (*S,M,K,K) or (K,K) or (*S,K,K)
    Ugeom = np.asarray(Ugeom, np.float32, order="C")

    # Normalize to shape (*S, M, K, K)
    if Ugeom.ndim == 2 and Ugeom.shape[0] == Ugeom.shape[1]:
        # Scalar/uniform A → broadcast to grid size S
        # Prefer AA.get_mask_float(agent); fallback to phi field; last resort: rebuild from A spec
        S = None
        m = getattr(agent, "mask", None)
        if m is not None:
            S = tuple(np.asarray(m).shape)
        if S is None:
            try:
                S = tuple(np.asarray(_get_phi(agent, which)).shape[:-1])
            except Exception:
                S = None
        if S is None:
            # Final fallback: infer S from stored A if available
            A = getattr(ctx, "fields", {}).get("A", None)
            if A is not None and np.asarray(A).ndim >= 3:
                S = tuple(np.asarray(A).shape[:-2])
        if S is None:
            raise ValueError("plaquette_from_A: cannot infer spatial shape S for uniform A")
        Ugeom = np.broadcast_to(Ugeom, S + Ugeom.shape)         # (*S,K,K)
        Ugeom = Ugeom[..., None, :, :]                           # (*S,1,K,K)

    elif Ugeom.ndim == 3 and Ugeom.shape[-1] == Ugeom.shape[-2]:
        # Already per-site matrix but no axis split → treat as M=1
        Ugeom = Ugeom[..., None, :, :]                           # (*S,1,K,K)

    if not (Ugeom.ndim >= 4 and Ugeom.shape[-2] == Ugeom.shape[-1]):
        raise ValueError(f"expA_* must return (*S,M,K,K) or (K,K); got {Ugeom.shape}")

    S = Ugeom.shape[:-3]
    M = int(Ugeom.shape[-3])
    if pair is None:
        pair = (0, 1)
    a, b = map(int, pair)

    if not (0 <= a < M and 0 <= b < M and a != b):
        raise ValueError(f"plaquette_from_A: bad plaquette pair {pair} for M={M}")
    if M < 2:
        raise ValueError("plaquette_from_A: need at least two spatial axes (M>=2) to form a plaquette")

    # Extract links
    Ua = Ugeom[..., a, :, :]  # (*S,K,K)
    Ub = Ugeom[..., b, :, :]

    # Shift neighbors along spatial axes a/b
    Ub_a1 = _roll_spatial_axis(Ub, a, +1, trailing=2)  # U_b(i+ê_a)
    Ua_b1 = _roll_spatial_axis(Ua, b, +1, trailing=2)  # U_a(i+ê_b)

    # Compose: use inverse via transpose-safe helper in case of slight non-orthogonality
    P = Ua @ Ub_a1 @ safe_omega_inv(Ua_b1) @ safe_omega_inv(Ub)

    if not np.isfinite(P).all():
        raise FloatingPointError("plaquette_from_A: non-finite entries in P")
    return np.asarray(P, np.float32, order="C")







def plaquette_product(ctx, phi_field, generators, *,
                      split_edge: bool = False, sign: int = +1,
                      pair: tuple[int, int] | None = None):
    """
    Compute local plaquette product:
      P_ab(i) = U_a(i) · U_b(i+ê_a) · U_a(i+ê_b)^T · U_b(i)^T

    Inputs
      phi_field : (*S, 3)
      generators: (3,K,K) or (K,K,3)
      pair      : (a, b) spatial axes (default (0,1))
      split_edge: if True, uses half-steps (E^{1/2}) to form links

    Returns
      (*S, K, K)  float32

    Notes
      - Pure / loky-safe (no cache).
      - Uses safe_omega_inv() for inverses to be robust to small non-orthogonality.
    """
    import numpy as np

    # --- normalize inputs ---
    phi = np.asarray(phi_field, np.float32, order="C")
    if phi.ndim < 1 or phi.shape[-1] != 3:
        raise ValueError(f"plaquette_product: phi_field must be (...,3); got {phi.shape}")

    G = np.asarray(generators, np.float32, order="C")
    if G.ndim != 3:
        raise ValueError(f"plaquette_product: generators must be rank-3; got {G.shape}")
    G3 = G if G.shape[0] == 3 else np.moveaxis(G, -1, 0)
    if not (G3.shape[0] == 3 and G3.shape[1] == G3.shape[2]):
        raise ValueError(f"plaquette_product: generators must be (3,K,K) or (K,K,3); got {G.shape}")
    K = int(G3.shape[1])

    # --- spatial rank / pair ---
    S = phi.shape[:-1]
    M = len(S)
    if M < 2:
        raise ValueError(f"plaquette_product: need at least two spatial axes (M>=2), got M={M} from phi {phi.shape}")
    if pair is None:
        pair = (0, 1)
    a, b = map(int, pair)
    if not (0 <= a < M and 0 <= b < M and a != b):
        raise ValueError(f"plaquette_product: bad plaquette pair {pair} for spatial rank {M}")

    # --- per-site exponentials ---
    E = E_grid_field(ctx, phi, G3, sign=sign)     # (*S,K,K)
    if E.shape[:-2] != S or E.shape[-2:] != (K, K):
        raise ValueError(f"E_grid_field produced shape {E.shape} incompatible with phi {phi.shape} and K={K}")
    Et = np.swapaxes(E, -1, -2)

    # --- links U_a(i), U_b(i) ---
    if not split_edge:
        E_a1 = _roll_spatial_axis(E, a, +1, trailing=2)  # E(i+ê_a)
        E_b1 = _roll_spatial_axis(E, b, +1, trailing=2)  # E(i+ê_b)

        Ua_ij = E_a1 @ Et
        Ub_ij = E_b1 @ Et

        # neighbor-shifted links
        Ua_b1 = _roll_spatial_axis(Ua_ij, b, +1, trailing=2)
        Ub_a1 = _roll_spatial_axis(Ub_ij, a, +1, trailing=2)
    else:
        half = 0.5
        Ehalf_here = E_grid_field(ctx, half * phi, G3, sign=sign)  # (*S,K,K)
        Eh_t       = np.swapaxes(Ehalf_here, -1, -2)
        Ehalf_a1   = _roll_spatial_axis(Ehalf_here, a, +1, trailing=2)
        Ehalf_b1   = _roll_spatial_axis(Ehalf_here, b, +1, trailing=2)

        Ua_ij = Ehalf_a1 @ Eh_t
        Ub_ij = Ehalf_b1 @ Eh_t
        Ua_b1 = _roll_spatial_axis(Ua_ij, b, +1, trailing=2)
        Ub_a1 = _roll_spatial_axis(Ub_ij, a, +1, trailing=2)

    # --- plaquette product with numerically safe inverses ---
    # Use safe_omega_inv instead of simple transpose to guard drift from perfect orthogonality.
    P = Ua_ij @ Ub_a1 @ safe_omega_inv(Ua_b1) @ safe_omega_inv(Ub_ij)

    if not np.isfinite(P).all():
        raise FloatingPointError("plaquette_product: non-finite entries in P")
    return np.asarray(P, np.float32, order="C")



# ---------------------------------------------------------------------------
# Warming & invalidation
# ---------------------------------------------------------------------------





def warm_E(ctx, agents, whiches=("q","p"), n_jobs=None, backend=None, strict=False):
    """
    Prefetch E_grid into ctx.cache (master-only usefulness).
    - If transport_backend=='ctx': thread-parallel prefill.
    - If 'pure': no shared cache to fill; we still compute (optional) to surface errors.
    Args:
      backend: 'threading' (default), or None to auto-choose
      strict : if True, re-raises first error after logging
    """
    from core.runtime_context import cfg_get
    
    n  = max(1, int(n_jobs or cfg_get(ctx, "n_jobs", 1)))
    be = backend or "threading"  # never use loky here—warming is master-local

    errors = []

    def _one(a):
        for w in whiches:
            try:
                _ = E_grid(ctx, a, which=w)  # dual-pathed; pure if tb=='pure'
            except Exception as e:
                msg = f"warm-E fail (agent={getattr(a,'id',None)} {w}): {type(e).__name__}: {e}"
                print(msg)
                errors.append((a, w, e))

    if n <= 1:
        for a in agents: _one(a)
    else:
        Parallel(n_jobs=n, backend=be, batch_size="auto")(delayed(_one)(a) for a in agents)

    # In pure mode, this is mostly a sanity pass; in cached mode it pre-fills ctx.cache.
    if strict and errors:
        # raise the first one to fail fast in CI/debug runs
        raise errors[0][2]


def warm_Jinv(ctx, agents, whiches=("q","p"), n_jobs=None, backend=None, strict=False):
    """
    Prefetch Jinv_grid into ctx.cache (master-only usefulness).
    Behaves like warm_E; in pure mode, just computes to check for issues.
    """
    from core.runtime_context import cfg_get
    
    n  = max(1, int(n_jobs or cfg_get(ctx, "n_jobs", 1)))
    be = backend or "threading"

    errors = []

    def _one(a):
        for w in whiches:
            try:
                _ = Jinv_grid(ctx, a, which=w)  # dual-pathed; pure if tb=='pure'
            except Exception as e:
                msg = f"warm-Jinv fail (agent={getattr(a,'id',None)} {w}): {type(e).__name__}: {e}"
                print(msg)
                errors.append((a, w, e))

    if n <= 1:
        for a in agents: _one(a)
    else:
        Parallel(n_jobs=n, backend=be, batch_size="auto")(delayed(_one)(a) for a in agents)

    if strict and errors:
        raise errors[0][2]






def stable_sig(*parts, float_dtype=np.float32, order="C") -> str:
    """
    Deterministic SHA256 over heterogeneous inputs.
    - Arrays: cast to float_dtype, force C-order, include shape bytes
    - Numbers/strings/bytes: tagged
    - dicts: sorted by key; lists/tuples: include length and order
    - None: tagged
    Falls back to repr(...) for unknown types.
    """
    h = hashlib.sha256()

    def _upd(x):
        if isinstance(x, np.ndarray):
            a = np.asarray(x, dtype=float_dtype, order=order)
            h.update(b"A"); h.update(str(a.shape).encode()); h.update(a.tobytes())
        elif isinstance(x, (float, np.floating)):
            h.update(b"f"); h.update(np.asarray(x, float_dtype).tobytes())
        elif isinstance(x, (int, np.integer, bool, np.bool_)):
            # 8-byte little-endian signed for stability
            h.update(b"i"); h.update(int(x).to_bytes(8, "little", signed=True))
        elif isinstance(x, (bytes, bytearray, memoryview)):
            h.update(b"B"); h.update(bytes(x))
        elif isinstance(x, str):
            h.update(b"S"); h.update(x.encode("utf-8"))
        elif isinstance(x, dict):
            h.update(b"D")
            for k in sorted(x.keys()):
                _upd(k); _upd(x[k])
        elif isinstance(x, (list, tuple)):
            h.update(b"L"); h.update(len(x).to_bytes(8, "little"))
            for y in x: _upd(y)
        elif x is None:
            h.update(b"N")
        else:
            h.update(b"R"); h.update(repr(x).encode("utf-8"))

    for p in parts: _upd(p)
    return h.hexdigest()