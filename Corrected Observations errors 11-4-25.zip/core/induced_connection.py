from __future__ import annotations

# -*- coding: utf-8 -*-
"""
Created on Sat Oct 25 10:51:47 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
induced_connection.py - Explicit construction of gauge connection A from attention weights

This module implements the attention → geometry correspondence:
    A_μ(x) = Σ_{j ∈ neighbors along μ} β_ij(x) · log(Ω_ij(x))

Author: c&c
Created: 2025
"""

from typing import Optional, Tuple, List
import numpy as np
from pathlib import Path

from core.omega import _so3_log_matrix, exp_lie_algebra_irrep
from core.transport_cache import Omega, E_grid
from core.numerical_utils import safe_omega_inv
from agents.agent_accessor import AA
from core.runtime_context import cfg_get
from core.get_generators import get_generators


# ============================================================================
#                    MATRIX LOG FOR HIGHER IRREPS
# ============================================================================


def matrix_log_to_so3(
    Omega_matrix: np.ndarray,
    generators: np.ndarray,
    *,
    max_iter: int = 50,
    tol: float = 1e-6,
    init_phi: Optional[np.ndarray] = None
) -> np.ndarray:
    """
    Extract so(3) Lie algebra coordinates from K×K rotation matrix.
    
    Given Omega = exp(φ · G) where G are generators in irrep,
    recover φ ∈ ℝ³.
    
    Algorithm:
      - K=3 (fundamental rep): Use direct SO(3) logarithm
      - K>3 (higher irreps): Numerical optimization
    
    Args:
        Omega_matrix: (..., K, K) rotation matrices
        generators: (3, K, K) SO(3) generators in irrep
        max_iter: Maximum optimization iterations
        tol: Convergence tolerance
        init_phi: Optional initial guess (..., 3)
    
    Returns:
        phi: (..., 3) Lie algebra coordinates
    
    Notes:
        - For K=3, this is the exact SO(3) logarithm
        - For K>3, uses Gauss-Newton to minimize ||exp(φ·G) - Omega||_F
        - Batch-friendly: processes all spatial points simultaneously
    """
    Omega_matrix = np.asarray(Omega_matrix, dtype=np.float32)
    generators = np.asarray(generators, dtype=np.float32)
    
    *batch_shape, K, K2 = Omega_matrix.shape
    assert K == K2, f"Omega must be square, got shape {Omega_matrix.shape}"
    assert generators.shape == (3, K, K), f"Generators must be (3,K,K), got {generators.shape}"
    
    # Case 1: Fundamental representation (3×3 matrices)
    if K == 3:
        # Direct logarithm for SO(3)
        phi = _so3_log_matrix(Omega_matrix)  # (..., 3)
        return phi.astype(np.float32, copy=False)
    
    # Case 2: Higher irreps - numerical optimization
    n_batch = int(np.prod(batch_shape)) if batch_shape else 1
    Omega_flat = Omega_matrix.reshape(n_batch, K, K)
    
    # Initialize phi
    if init_phi is None:
        phi_flat = np.zeros((n_batch, 3), dtype=np.float32)
    else:
        phi_flat = np.asarray(init_phi, dtype=np.float32).reshape(n_batch, 3)
    
    # Optimization: minimize ||exp(φ·G) - Ω||_F² via Gauss-Newton
    for iteration in range(max_iter):
        # Current reconstruction
        Omega_recon = exp_lie_algebra_irrep(phi_flat, generators)  # (n_batch, K, K)
        
        # Residual in matrix space
        residual = Omega_recon - Omega_flat  # (n_batch, K, K)
        error = np.linalg.norm(residual.reshape(n_batch, -1), axis=1)  # (n_batch,)
        
        # Check convergence
        max_error = float(np.max(error))
        if max_error < tol:
            break
        
        # Compute Jacobian: ∂(exp(φ·G))/∂φ at current φ
        # Use finite differences for robustness
        eps_fd = 1e-5
        J = np.zeros((n_batch, K*K, 3), dtype=np.float32)
        
        for d in range(3):
            phi_plus = phi_flat.copy()
            phi_plus[:, d] += eps_fd
            Omega_plus = exp_lie_algebra_irrep(phi_plus, generators)
            
            dOmega_dphid = (Omega_plus - Omega_recon) / eps_fd
            J[:, :, d] = dOmega_dphid.reshape(n_batch, K*K)
        
        # Gauss-Newton step: solve J^T J Δφ = -J^T r
        residual_vec = residual.reshape(n_batch, K*K)  # (n_batch, K²)
        
        for b in range(n_batch):
            JtJ = J[b].T @ J[b]  # (3, 3)
            Jtr = J[b].T @ residual_vec[b]  # (3,)
            
            # Solve with regularization
            try:
                delta_phi = np.linalg.solve(JtJ + 1e-6 * np.eye(3), -Jtr)
            except np.linalg.LinAlgError:
                delta_phi = -0.01 * Jtr  # Gradient descent fallback
            
            # Line search with backtracking
            alpha = 1.0
            for _ in range(5):
                phi_new = phi_flat[b] + alpha * delta_phi
                Omega_new = exp_lie_algebra_irrep(phi_new.reshape(1, 3), generators)[0]
                error_new = np.linalg.norm(Omega_new - Omega_flat[b], 'fro')
                
                if error_new < error[b]:
                    phi_flat[b] = phi_new
                    break
                alpha *= 0.5
    
    # Reshape back
    phi = phi_flat.reshape(*batch_shape, 3).astype(np.float32, copy=False)
    return phi


# ============================================================================
#              SPATIAL DIRECTION INFERENCE (FOR LATTICES)
# ============================================================================


def infer_spatial_direction(
    pos_i: np.ndarray,
    pos_j: np.ndarray,
    ndim: int,
    *,
    tol: float = 0.1
) -> Optional[int]:
    """
    Infer which spatial direction agent j is from agent i.
    
    For structured lattices, j should differ from i in exactly one dimension.
    
    Args:
        pos_i: Position of agent i (ndim,)
        pos_j: Position of agent j (ndim,)
        ndim: Number of spatial dimensions
        tol: Tolerance for "same" coordinate (accounts for numerical noise)
    
    Returns:
        dimension index (0 to ndim-1) if j is a direct neighbor
        None if j is not a direct neighbor (diagonal, far, etc.)
    
    Example:
        For 2D lattice:
            pos_i = [5, 3], pos_j = [6, 3] → direction = 0 (x-axis)
            pos_i = [5, 3], pos_j = [5, 4] → direction = 1 (y-axis)
            pos_i = [5, 3], pos_j = [6, 4] → None (diagonal)
    """
    pos_i = np.asarray(pos_i, dtype=np.float32).ravel()
    pos_j = np.asarray(pos_j, dtype=np.float32).ravel()
    
    if pos_i.shape != (ndim,) or pos_j.shape != (ndim,):
        return None
    
    diff = np.abs(pos_j - pos_i)
    
    # Find dimensions with non-negligible difference
    active_dims = np.where(diff > tol)[0]
    
    # Should differ in exactly one dimension for direct neighbor
    if len(active_dims) == 1:
        return int(active_dims[0])
    
    return None


def get_agent_position(agent, ndim: int) -> np.ndarray:
    """
    Extract agent's spatial position.
    
    Priority:
        1. agent.position (if exists)
        2. Center of agent.mask
        3. Zero vector (fallback)
    """
    # Try explicit position attribute
    pos = getattr(agent, "position", None)
    if pos is not None:
        pos = np.asarray(pos, dtype=np.float32).ravel()
        if pos.shape == (ndim,):
            return pos
    
    # Try mask center of mass
    mask = getattr(agent, "mask", None)
    if mask is not None:
        mask = np.asarray(mask, dtype=np.float32)
        if mask.ndim >= ndim:
            # Compute center of mass
            coords = np.indices(mask.shape[:ndim])  # (ndim, *S)
            total_mass = np.sum(mask)
            if total_mass > 0:
                pos = np.array([
                    np.sum(coords[d] * mask) / total_mass
                    for d in range(ndim)
                ], dtype=np.float32)
                return pos
    
    # Fallback: origin
    return np.zeros(ndim, dtype=np.float32)


# ============================================================================
#           MAIN FUNCTION: CONSTRUCT CONNECTION FROM ATTENTION
# ============================================================================


def construct_connection_from_attention(
    ctx,
    agents: List,
    which: str = "q",
    *,
    use_spatial_directions: bool = True,
    normalize_per_direction: bool = True,
    bootstrap_A: bool = False,
    cache_transports: bool = True,
    verbose: bool = False
) -> np.ndarray:
    """
    Explicitly construct gauge connection A from attention weights.
    
    Implements: A_μ(x) = Σ_{j ∈ neighbors along μ} β_ij(x) · log(Ω_ij(x))
    
    Args:
        ctx: Runtime context (must have edge maps computed)
        agents: List of agents
        which: Fiber identifier ("q" or "p")
        use_spatial_directions: If True, separate A by spatial direction
                               If False, average over all neighbors
        normalize_per_direction: If True, renormalize β weights per direction
        bootstrap_A: If True, use current A in Omega computation
                     If False, set A=0 temporarily (breaks circularity)
        cache_transports: If True, cache Omega computations
        verbose: Print progress information
    
    Returns:
        A: (*S, ndim, 3) if use_spatial_directions else (*S, 3)
        
    Algorithm:
        1. Get spatial shape from agents
        2. Temporarily set A=0 if bootstrap_A=False (avoid circular dependency)
        3. For each receiver agent i:
            a. Get all sender agents j with β_ij > 0
            b. For each sender:
                - Compute Ω_ij using current frames
                - Extract ω_ij = log(Ω_ij) ∈ so(3)
                - Determine spatial direction (if using directions)
                - Accumulate β_ij * ω_ij
        4. Normalize by total attention weight per direction
        5. Restore original A
    
    Notes:
        - This makes the attention → geometry correspondence explicit
        - For bootstrap_A=False, breaks circularity: Ω doesn't depend on A
        - Can use as initialization for gradient-based A optimization
        - Attention weights β_ij must be pre-computed via compute_all_edge_maps
    """
    if not agents:
        raise ValueError("construct_connection_from_attention: empty agent list")
    
    # ---- Infer spatial shape ----
    S = AA.get_mask_float(agents[0]).shape
    ndim = len(S)
    
    if verbose:
        print(f"[Induced A] Spatial shape: {S}, ndim: {ndim}")
        print(f"[Induced A] Fiber: {which}, directions: {use_spatial_directions}")
    
    # ---- Get generators for log extraction ----
    generators = get_generators(agents[0], which)
    K = generators.shape[-1]
    
    if verbose:
        print(f"[Induced A] Generator shape: {generators.shape}, K={K}")
    
    # ---- Initialize connection field ----
    if use_spatial_directions:
        A = np.zeros(S + (ndim, 3), dtype=np.float32)
        beta_sum = np.zeros(S + (ndim,), dtype=np.float32)
    else:
        A = np.zeros(S + (3,), dtype=np.float32)
        beta_sum = np.zeros(S, dtype=np.float32)
    
    # ---- Bootstrap control: temporarily disable A in transport ----
    original_A = None
    if not bootstrap_A:
        if hasattr(ctx, "fields") and "A" in ctx.fields:
            original_A = ctx.fields["A"].copy()
            ctx.fields["A"] = np.zeros_like(original_A)
            if verbose:
                print("[Induced A] Temporarily disabled global A (bootstrap_A=False)")
    
    # ---- Build agent ID mapping ----
    id_to_agent = {AA.get_id(a): a for a in agents}
    id_to_idx = {AA.get_id(a): i for i, a in enumerate(agents)}
    
    # ---- Cache for transport operators (optional) ----
    omega_cache = {} if cache_transports else None
    
    # ---- Main loop: iterate over receivers ----
    n_pairs = 0
    n_contributions = 0
    
    for i_idx, agent_i in enumerate(agents):
        i_id = AA.get_id(agent_i)
        i_pos = get_agent_position(agent_i, ndim)
        
        # For each potential sender
        for j_idx, agent_j in enumerate(agents):
            if i_idx == j_idx:
                continue
            
            j_id = AA.get_id(agent_j)
            j_pos = get_agent_position(agent_j, ndim)
            
            # ---- Get attention weight (spatial field) ----
            KL_map, beta_map = ctx.edge.get_align(ctx, which, i_id, j_id, shape=S)
            
            if beta_map is None:
                continue
            
            beta_ij = np.asarray(beta_map, dtype=np.float32)
            
            # Skip if no attention
            if not np.any(beta_ij > 1e-8):
                continue
            
            n_pairs += 1
            
            # ---- Get or compute transport operator ----
            cache_key = (i_id, j_id, which)
            
            if cache_transports and cache_key in omega_cache:
                Omega_ij = omega_cache[cache_key]
            else:
                Omega_ij = Omega(ctx, agent_i, agent_j, which)
                if cache_transports:
                    omega_cache[cache_key] = Omega_ij
            
            # ---- Extract Lie algebra coordinates ----
            # Omega_ij has shape (*S, K, K)
            omega_ij = matrix_log_to_so3(Omega_ij, generators)  # (*S, 3)
            
            # ---- Determine spatial direction (if using) ----
            if use_spatial_directions:
                direction = infer_spatial_direction(i_pos, j_pos, ndim)
                
                if direction is not None:
                    # Accumulate weighted contribution for this direction
                    A[..., direction, :] += beta_ij[..., None] * omega_ij
                    beta_sum[..., direction] += beta_ij
                    n_contributions += 1
            else:
                # Average over all neighbors regardless of direction
                A += beta_ij[..., None] * omega_ij
                beta_sum += beta_ij
                n_contributions += 1
    
    # ---- Normalize by total attention weight ----
    if normalize_per_direction and use_spatial_directions:
        for d in range(ndim):
            mask = beta_sum[..., d] > 1e-8
            if np.any(mask):
                A[mask, d, :] /= beta_sum[mask, d, None]
    elif not use_spatial_directions:
        mask = beta_sum > 1e-8
        if np.any(mask):
            A[mask] /= beta_sum[mask, None]
    
    # ---- Restore original A ----
    if original_A is not None:
        ctx.fields["A"] = original_A
        if verbose:
            print("[Induced A] Restored original global A")
    
    # ---- Statistics ----
    if verbose:
        A_norm = np.linalg.norm(A)
        A_mean = float(np.mean(np.linalg.norm(A, axis=-1)))
        A_max = float(np.max(np.linalg.norm(A, axis=-1)))
        print(f"[Induced A] Processed {n_pairs} agent pairs")
        print(f"[Induced A] Total contributions: {n_contributions}")
        print(f"[Induced A] Connection stats: ||A||={A_norm:.4f}, mean={A_mean:.4f}, max={A_max:.4f}")
    
    return A


# ============================================================================
#                      HYBRID: EXPLICIT + GRADIENT
# ============================================================================


def hybrid_connection_update(
    ctx,
    agents: List,
    which: str = "q",
    *,
    alpha: float = 0.1,
    **kwargs
) -> np.ndarray:
    """
    Hybrid connection update: blend explicit construction with gradient-based A.
    
    A_new = (1-α) * A_explicit + α * A_gradient
    
    Args:
        ctx: Runtime context
        agents: List of agents
        which: Fiber identifier
        alpha: Interpolation weight
               α=0 → pure explicit (attention-induced)
               α=1 → pure gradient (current A)
        **kwargs: Passed to construct_connection_from_attention
    
    Returns:
        A_new: Blended connection field
    
    Usage:
        # Initialize from attention, then fine-tune
        A_init = hybrid_connection_update(ctx, agents, alpha=0.0)
        ctx.fields['A'] = A_init
        
        # During training, blend:
        A_hybrid = hybrid_connection_update(ctx, agents, alpha=0.1)
        ctx.fields['A'] = A_hybrid
    """
    # Explicit construction
    A_explicit = construct_connection_from_attention(
        ctx, agents, which, **kwargs
    )
    
    # Current A (from gradients)
    A_current = getattr(ctx, "fields", {}).get('A', A_explicit)
    A_current = np.asarray(A_current, dtype=np.float32)
    
    # Ensure shapes match
    if A_current.shape != A_explicit.shape:
        print(f"[Hybrid A] Shape mismatch: explicit {A_explicit.shape} vs current {A_current.shape}")
        return A_explicit
    
    # Blend
    alpha = float(np.clip(alpha, 0.0, 1.0))
    A_new = (1.0 - alpha) * A_explicit + alpha * A_current
    
    return A_new.astype(np.float32, copy=False)


# ============================================================================
#                       DIAGNOSTICS & VISUALIZATION
# ============================================================================


def compare_connections(
    ctx,
    agents: List,
    which: str = "q",
    *,
    verbose: bool = True
) -> dict:
    """
    Compare explicitly constructed A with gradient-based A.
    
    Returns dictionary with:
        - A_explicit: Attention-induced connection
        - A_gradient: Current gradient-based connection
        - diff_norm: Frobenius norm of difference
        - correlation: Correlation coefficient
        - stats: Per-direction statistics
    """
    # Construct explicit
    A_explicit = construct_connection_from_attention(ctx, agents, which, verbose=False)
    
    # Get gradient-based
    A_gradient = getattr(ctx, "fields", {}).get('A', None)
    
    if A_gradient is None:
        if verbose:
            print("[Compare A] No gradient-based A available")
        return {"A_explicit": A_explicit, "A_gradient": None}
    
    A_gradient = np.asarray(A_gradient, dtype=np.float32)
    
    # Ensure shapes match
    if A_explicit.shape != A_gradient.shape:
        if verbose:
            print(f"[Compare A] Shape mismatch: {A_explicit.shape} vs {A_gradient.shape}")
        return {"A_explicit": A_explicit, "A_gradient": A_gradient}
    
    # Compute difference
    diff = A_explicit - A_gradient
    diff_norm = float(np.linalg.norm(diff))
    
    # Correlation
    A_ex_flat = A_explicit.ravel()
    A_gr_flat = A_gradient.ravel()
    correlation = float(np.corrcoef(A_ex_flat, A_gr_flat)[0, 1])
    
    # Per-direction statistics
    ndim = A_explicit.shape[-2]
    dir_stats = {}
    for d in range(ndim):
        A_ex_d = A_explicit[..., d, :].ravel()
        A_gr_d = A_gradient[..., d, :].ravel()
        
        dir_stats[d] = {
            "explicit_norm": float(np.linalg.norm(A_ex_d)),
            "gradient_norm": float(np.linalg.norm(A_gr_d)),
            "diff_norm": float(np.linalg.norm(A_ex_d - A_gr_d)),
            "correlation": float(np.corrcoef(A_ex_d, A_gr_d)[0, 1])
        }
    
    result = {
        "A_explicit": A_explicit,
        "A_gradient": A_gradient,
        "diff_norm": diff_norm,
        "correlation": correlation,
        "stats_per_direction": dir_stats,
        "explicit_total_norm": float(np.linalg.norm(A_explicit)),
        "gradient_total_norm": float(np.linalg.norm(A_gradient))
    }
    
    if verbose:
        print(f"\n[Compare A] Comparison Results:")
        print(f"  Total diff norm: {diff_norm:.6f}")
        print(f"  Correlation: {correlation:.6f}")
        print(f"  Explicit ||A||: {result['explicit_total_norm']:.6f}")
        print(f"  Gradient ||A||: {result['gradient_total_norm']:.6f}")
        print(f"\n  Per-direction:")
        for d, stats in dir_stats.items():
            print(f"    Direction {d}: corr={stats['correlation']:.4f}, "
                  f"diff={stats['diff_norm']:.4f}")
    
    return result


def save_connection_comparison(
    comparison: dict,
    output_path: str | Path,
    step: int = 0
):
    """
    Save connection comparison to disk for later analysis.
    
    Saves:
        - NPZ file with A_explicit and A_gradient arrays
        - JSON file with statistics
    """
    output_path = Path(output_path)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # Save arrays
    npz_path = output_path / f"connection_comparison_step{step:04d}.npz"
    np.savez_compressed(
        npz_path,
        A_explicit=comparison["A_explicit"],
        A_gradient=comparison["A_gradient"] if comparison["A_gradient"] is not None else np.array([])
    )
    
    # Save statistics
    import json
    stats_path = output_path / f"connection_stats_step{step:04d}.json"
    
    # Remove arrays from stats (can't serialize)
    stats = {k: v for k, v in comparison.items() 
             if k not in ["A_explicit", "A_gradient"]}
    
    with open(stats_path, "w") as f:
        json.dump(stats, f, indent=2)
    
    print(f"[Save A Comparison] Saved to {output_path}")


# ============================================================================
#                            INITIALIZATION
# ============================================================================


def initialize_A_from_attention(
    ctx,
    agents: List,
    which: str = "q",
    *,
    verbose: bool = True,
    **kwargs
) -> np.ndarray:
    """
    Initialize global connection A from attention weights.
    
    This is the main entry point for replacing random A initialization
    with geometric initialization from attention structure.
    
    Usage:
        # In your simulation setup:
        from induced_connection import initialize_A_from_attention
        
        # After computing initial edge maps:
        A_init = initialize_A_from_attention(ctx, agents, which="q")
        ctx.fields['A'] = A_init
        
        # Then run gradient-based updates as normal
    """
    if verbose:
        print("\n" + "="*70)
        print("INITIALIZING CONNECTION FROM ATTENTION")
        print("="*70)
    
    A = construct_connection_from_attention(
        ctx, agents, which,
        bootstrap_A=False,  # Don't use A in Omega computation
        verbose=verbose,
        **kwargs
    )
    
    if verbose:
        print("="*70)
        print("INITIALIZATION COMPLETE")
        print("="*70 + "\n")
    
    return A