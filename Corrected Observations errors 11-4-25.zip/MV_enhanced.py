"""
MV_enhanced.py - FIXED VERSION
-------------------------------
Professional plotting integration for MetricsViz.

BUGFIX: Corrected method wrapper signature to properly bind as instance method.
"""

from pathlib import Path
from typing import List, Dict, Any
import numpy as np

# Import professional plotting functions
from metrics_viz_pro import (
    plot_timeseries_faceted,
    plot_timeseries_summary,
    plot_timeseries_ranked,
    plot_timeseries_heatmap,
    plot_multifield_comparison,
    plot_global_metrics,
    setup_publication_style,
    _get_color_cycle,
    _format_field_name,
    FONT_SIZE_TITLE,
    FONT_SIZE_LABEL,
    DPI_SCREEN
)

# Initialize publication styling
setup_publication_style()


def _get_numeric_fields_from_rows(rows: List[Dict], preferred: List[str] = None) -> List[str]:
    """Extract numeric field names from rows."""
    if not rows:
        return []
    
    exclude = {'step', 'agent', 'run_id', 'ts', '__kind__'}
    numeric_fields = []
    
    sample_row = rows[0]
    for key, val in sample_row.items():
        if key in exclude:
            continue
        try:
            float(val)
            numeric_fields.append(key)
        except (ValueError, TypeError, AttributeError):
            continue
    
    # Prioritize preferred fields
    if preferred:
        ordered = []
        for f in preferred:
            if f in numeric_fields:
                ordered.append(f)
        # Add remaining fields
        for f in numeric_fields:
            if f not in ordered:
                ordered.append(f)
        return ordered
    
    return numeric_fields


def _create_professional_agent_plots(mv, style='auto'):
    """
    Generate professional plots for agent metrics.
    
    Args:
        mv: MetricsViz instance
        style: 'auto', 'faceted', 'summary', 'ranked', 'heatmap', or 'all'
    """
    # Combine history and current rows
    all_rows = list(mv._agent_history) + list(mv.agent_rows)
    if not all_rows:
        return
    
    # Get numeric fields
    preferred = [
        'model_alignment_kl',
        'belief_alignment_kl', 
        'self_alignment_kl',
        'mu_q_center_norm',
        'phi_norm_mean',
        'phi_model_norm_mean',
        'mu_q_norm_mean',
        'mu_p_norm_mean',
    ]
    fields = _get_numeric_fields_from_rows(all_rows, preferred)
    
    # Determine which agents we have
    agent_ids = sorted(set(r['agent'] for r in all_rows if 'agent' in r))
    n_agents = len(agent_ids)
    
    # Auto-select style based on agent count
    if style == 'auto':
        if n_agents <= 8:
            style = 'faceted'
        elif n_agents <= 16:
            style = 'summary'
        else:
            style = 'heatmap'
    
    # Create professional plots directory
    prof_dir = mv.dir_plots / 'professional'
    prof_dir.mkdir(exist_ok=True)
    
    print(f"[Professional Plots] Generating {style} plots for {n_agents} agents, {len(fields)} metrics...")
    
    # Generate based on style
    if style == 'all':
        styles_to_gen = ['faceted', 'summary', 'ranked', 'heatmap']
    else:
        styles_to_gen = [style]
    
    for field in fields:
        for gen_style in styles_to_gen:
            try:
                if gen_style == 'faceted' and n_agents <= 20:
                    plot_timeseries_faceted(
                        field=field,
                        rows=all_rows,
                        output_path=prof_dir / f'{field}_faceted.png',
                        dpi=DPI_SCREEN
                    )
                
                elif gen_style == 'summary':
                    plot_timeseries_summary(
                        field=field,
                        rows=all_rows,
                        output_path=prof_dir / f'{field}_summary.png',
                        show_individual=(n_agents <= 12),
                        dpi=DPI_SCREEN
                    )
                
                elif gen_style == 'ranked' and n_agents >= 5:
                    plot_timeseries_ranked(
                        field=field,
                        rows=all_rows,
                        output_path=prof_dir / f'{field}_ranked.png',
                        top_n=min(5, n_agents // 2),
                        bottom_n=min(3, n_agents // 3),
                        dpi=DPI_SCREEN
                    )
                
                elif gen_style == 'heatmap':
                    plot_timeseries_heatmap(
                        field=field,
                        rows=all_rows,
                        output_path=prof_dir / f'{field}_heatmap.png',
                        dpi=DPI_SCREEN
                    )
            
            except Exception as e:
                print(f"  ⚠️  Failed to generate {gen_style} plot for {field}: {e}")
    
    # Multi-field comparison
    if len(fields) >= 2:
        try:
            plot_multifield_comparison(
                fields=fields[:6],  # Top 6 fields
                rows=all_rows,
                output_path=prof_dir / 'multifield_comparison.png',
                mode='summary',
                dpi=DPI_SCREEN
            )
        except Exception as e:
            print(f"  ⚠️  Failed to generate multi-field comparison: {e}")
    
    print(f"[Professional Plots] ✓ Generated in {prof_dir}/")


def _create_professional_global_plots(mv):
    """Generate professional plots for global metrics."""
    all_rows = list(mv._global_history) + list(mv.global_rows)
    if not all_rows:
        return
    
    # Get numeric fields
    preferred = [
        'E_total',
        'Action_total',
        'Geom_total',
        'A_curv',
        'align_q_mean',
        'align_p_mean',
    ]
    fields = _get_numeric_fields_from_rows(all_rows, preferred)
    
    if not fields:
        return
    
    prof_dir = mv.dir_plots / 'professional'
    prof_dir.mkdir(exist_ok=True)
    
    try:
        plot_global_metrics(
            fields=fields,
            rows=all_rows,
            output_path=prof_dir / 'global_metrics_professional.png',
            title='System-Wide Metrics',
            dpi=DPI_SCREEN
        )
        print(f"[Professional Plots] ✓ Generated global metrics")
    except Exception as e:
        print(f"[Professional Plots] ⚠️  Global plot failed: {e}")


def _maybe_plot_professional(self, step: int, style='auto'):
    """
    Enhanced plotting method using professional visualizations.
    
    This replaces the standard maybe_plot() method.
    
    Args:
        step: Current simulation step
        style: 'auto', 'faceted', 'summary', 'ranked', 'heatmap', or 'all'
    """
    if not self.cfg.enable_plots:
        return
    
    if step % self.cfg.plot_every_steps != 0:
        return
    
    try:
        # Generate professional plots
        _create_professional_agent_plots(self, style=style)
        _create_professional_global_plots(self)
        
        # Keep legacy plots if desired (comment out to disable)
        # Original plotting for backward compatibility
        try:
            self._plot_agent_alignments()  # Keep alignment bars (already good)
        except:
            pass
        
    except Exception as e:
        print(f"[MetricsViz] Professional plotting failed: {e}")
        import traceback
        traceback.print_exc()


def _end_run_with_final_plots(self, generate_all_variants=False):
    """
    Enhanced end_run that generates comprehensive final visualizations.
    
    Call this instead of or after the standard end_run().
    
    Args:
        generate_all_variants: If True, generate faceted, summary, ranked, and heatmap
    """
    # Standard flush
    self.maybe_flush(force=True)
    
    # Final comprehensive plots
    print("\n" + "="*70)
    print("GENERATING FINAL PROFESSIONAL VISUALIZATIONS")
    print("="*70)
    
    if generate_all_variants:
        _create_professional_agent_plots(self, style='all')
    else:
        _create_professional_agent_plots(self, style='auto')
    
    _create_professional_global_plots(self)
    
    # Summary statistics (original)
    if self.cfg.enable_summary_stats:
        try:
            self._save_summary_stats()
        except:
            pass
    
    prof_dir = self.dir_plots / 'professional'
    print(f"\n✓ Professional plots saved to: {prof_dir}/")
    print("="*70 + "\n")
    
    print(f"[MetricsViz] Ended run {self.run_id}")


def enhance_metrics_viz(mv, replace_plot_method=True, plot_style='auto'):
    """
    Enhance a MetricsViz instance with professional plotting.
    
    This patches the instance to use professional plotting methods.
    
    Args:
        mv: MetricsViz instance to enhance
        replace_plot_method: If True, replace maybe_plot() with professional version
        plot_style: Default plotting style ('auto', 'faceted', 'summary', 'ranked', 'heatmap', 'all')
    
    Returns:
        Enhanced MetricsViz instance (same object, modified in-place)
    
    Example:
        vizcfg = VizConfig(outdir=Path("output"))
        mv = MetricsViz(vizcfg)
        enhance_metrics_viz(mv)  # Now uses professional plots!
        
        # Use normally:
        mv.log_agent(step, agent_id, metrics)
        mv.maybe_plot(step)  # <- Professional plots!
    """
    # Store original methods for fallback
    mv._original_maybe_plot = mv.maybe_plot
    mv._original_end_run = mv.end_run
    
    # Store style preference
    mv._professional_plot_style = plot_style
    
    if replace_plot_method:
        # BUGFIX: Properly define wrapper that accepts step argument
        def maybe_plot_wrapper(step: int):
            """Wrapper that properly forwards step argument."""
            _maybe_plot_professional(mv, step, style=mv._professional_plot_style)
        
        # Replace the method directly (don't use MethodType - it causes signature issues)
        mv.maybe_plot = maybe_plot_wrapper
        
        print("[MetricsViz Enhanced] ✓ Replaced plotting with professional visualizations")
        print(f"[MetricsViz Enhanced] ✓ Using '{plot_style}' style")
    
    # Add method for generating final comprehensive plots
    def generate_final_plots(generate_all_variants=False):
        """Generate comprehensive final plots."""
        _end_run_with_final_plots(mv, generate_all_variants)
    
    mv.generate_final_plots = generate_final_plots
    
    # Add method to manually trigger professional plots
    def plot_professional(style='auto'):
        """Manually generate professional plots with specified style."""
        _create_professional_agent_plots(mv, style=style)
        _create_professional_global_plots(mv)
    
    mv.plot_professional = plot_professional
    
    # Add method to revert to original plotting
    def revert_to_original_plotting():
        """Revert to original plotting methods."""
        mv.maybe_plot = mv._original_maybe_plot
        print("[MetricsViz] Reverted to original plotting")
    
    mv.revert_to_original_plotting = revert_to_original_plotting
    
    return mv


# ═══════════════════════════════════════════════════════════════════════════
# Convenience function for generalized_simulation.py integration
# ═══════════════════════════════════════════════════════════════════════════

def setup_professional_metrics_viz(vizcfg, plot_style='auto'):
    """
    Create and configure a MetricsViz instance with professional plotting.
    
    Drop-in replacement for:
        mv = MetricsViz(vizcfg)
    
    Use instead:
        mv = setup_professional_metrics_viz(vizcfg)
    
    Args:
        vizcfg: VizConfig instance
        plot_style: 'auto' (smart selection based on agent count),
                   'faceted' (grid of subplots),
                   'summary' (mean ± std),
                   'ranked' (top/bottom agents),
                   'heatmap' (dense 2D view),
                   'all' (generate all variants)
    
    Returns:
        Enhanced MetricsViz instance
    """
    from metrics_viz import MetricsViz
    
    mv = MetricsViz(vizcfg)
    enhance_metrics_viz(mv, replace_plot_method=True, plot_style=plot_style)
    
    return mv


if __name__ == '__main__':
    print(__doc__)
    print("\nQuick Integration Guide:")
    print("="*70)
    print("\n1. MINIMAL CHANGE (replace one line):")
    print("   Old: mv = MetricsViz(vizcfg)")
    print("   New: mv = setup_professional_metrics_viz(vizcfg)")
    print("\n2. MANUAL CONTROL:")
    print("   mv = MetricsViz(vizcfg)")
    print("   enhance_metrics_viz(mv, plot_style='summary')  # or 'faceted', 'all'")
    print("\n3. GENERATE FINAL COMPREHENSIVE PLOTS:")
    print("   mv.generate_final_plots(generate_all_variants=True)")
    print("\n4. REVERT TO ORIGINAL (if needed):")
    print("   mv.revert_to_original_plotting()")
    print("\n" + "="*70)