"""
Energy Budget Tracking and Flow Analysis - REAL FIX

CRITICAL FIX v2: The issue is that energy_budget was reading from ctx.energy_acc,
but the actual energy components are in the 'action' dictionary returned by
compute_total_action(). 

Solution: Pass the 'action' dict directly to record(), not rely on ctx.energy_acc
"""

import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from collections import defaultdict
import matplotlib.pyplot as plt
from pathlib import Path


@dataclass
class EnergySnapshot:
    """Single timestep energy measurement"""
    step: int
    
    # Core energy components
    E_self: float          # Self-energy Σ_i E_self[φ_i, μ_i, Σ_i]
    E_align_q: float       # Belief alignment Σ_{i,j} KL(q_i || Ω_ij q_j)
    E_align_p: float       # Model alignment Σ_{i,j} KL(p_i || Ω_ij p_j)
    E_gamma_A: float       # Cross-fiber A: KL(q_j || Ω_ji Φ_i p_i)
    E_gamma_B: float       # Cross-fiber B: KL(p_i || Φ_i Ω_ij q_j)
    E_curvature: float     # Global curvature ∫ F_μν F^μν
    
    E_total: float         # Sum of all components
    
    # Dissipation (if computable)
    dissipation: Optional[float] = None
    
    # Numerical error estimate
    numerical_error: Optional[float] = None
    
    def __post_init__(self):
        """Validate energy decomposition"""
        computed_total = (
            self.E_self + self.E_align_q + self.E_align_p +
            self.E_gamma_A + self.E_gamma_B + self.E_curvature
        )
        
        # Only warn if both totals are non-zero
        if self.E_total > 1e-10 and abs(computed_total - self.E_total) > 1e-6 * abs(self.E_total):
            import warnings
            warnings.warn(
                f"Step {self.step}: Energy decomposition mismatch. "
                f"Sum={computed_total:.6e}, Total={self.E_total:.6e}"
            )


class EnergyBudget:
    """
    Energy budget tracker with flow analysis and conservation checks.
    
    UPDATED: Now accepts action dict directly for accurate tracking.
    
    Usage:
        budget = EnergyBudget()
        
        for step in range(steps):
            # ... run simulation step ...
            agents, metrics, action = run_one_step(...)
            
            # Pass action dict directly:
            budget.record(step, action)
            
            if step % 10 == 0:
                budget.print_summary()
        
        budget.plot_history()
        budget.check_conservation()
    """
    
    def __init__(self, output_dir: Optional[Path] = None):
        self.history: List[EnergySnapshot] = []
        self.output_dir = Path(output_dir) if output_dir else Path("./energy_analysis")
        self.output_dir.mkdir(exist_ok=True, parents=True)
        
        # Statistics
        self.max_violation: float = 0.0
        self.mean_violation: float = 0.0
    
    def record(self, step: int, action_dict: Optional[Dict[str, float]] = None, 
               agents: Optional[List[Any]] = None, ctx: Optional[Any] = None):
        """
        Record energy components for current state.
        
        Args:
            step: Current timestep
            action_dict: Dictionary from compute_total_action() [PREFERRED]
            agents: List of agents (for fallback computation)
            ctx: Runtime context (for fallback computation)
        
        The action_dict should contain:
            - Action_total: Total action
            - self_sum: Self-energy
            - align_q_sum: Belief alignment
            - align_p_sum: Model alignment  
            - gamma_A_sum: Gamma A cross-fiber
            - gamma_B_sum: Gamma B cross-fiber
            - A_curv: Curvature energy
            - A_cov: Covariance energy
        """
        if action_dict is not None:
            # PREFERRED: Extract from action dict
            snapshot = self._from_action_dict(step, action_dict)
        elif ctx is not None and hasattr(ctx, 'energy_acc'):
            # FALLBACK: Try to extract from ctx.energy_acc (old method)
            snapshot = self._from_context(step, ctx.energy_acc)
        elif agents is not None and ctx is not None:
            # LAST RESORT: Compute from scratch
            snapshot = self._compute_energies(step, agents, ctx)
        else:
            raise ValueError("Must provide either action_dict, or agents+ctx")
        
        self.history.append(snapshot)
        
        # Update statistics
        if len(self.history) > 1:
            self._update_conservation_stats()
    
    def _from_action_dict(self, step: int, action: Dict[str, float]) -> EnergySnapshot:
        """
        Extract energy snapshot from action dictionary (PREFERRED method).
        
        This is the correct way to get energy components from your simulation.
        """
        return EnergySnapshot(
            step=step,
            E_self=float(action.get('self_sum', 0.0)),
            E_align_q=float(action.get('align_q_sum', 0.0)),
            E_align_p=float(action.get('align_p_sum', 0.0)),
            E_gamma_A=float(action.get('gamma_A_sum', 0.0)),
            E_gamma_B=float(action.get('gamma_B_sum', 0.0)),
            E_curvature=float(action.get('A_curv', 0.0) + action.get('A_cov', 0.0)),
            E_total=float(action.get('Action_total', 0.0)),
        )
    
    def _from_context(self, step: int, energy_acc: Dict[str, float]) -> EnergySnapshot:
        """
        Extract energy snapshot from runtime context (FALLBACK method).
        
        NOTE: This doesn't work well because energy_acc only has per-agent keys.
        Use _from_action_dict() instead.
        """
        # This is the old method that doesn't work
        return EnergySnapshot(
            step=step,
            E_self=energy_acc.get('self_sum_w', energy_acc.get('self_sum', 0.0)),
            E_align_q=energy_acc.get('align_q_sum_w', energy_acc.get('align_q', 0.0)),
            E_align_p=energy_acc.get('align_p_sum_w', energy_acc.get('align_p', 0.0)),
            E_gamma_A=energy_acc.get('gamma_A_sum_w', energy_acc.get('gamma_A', 0.0)),
            E_gamma_B=energy_acc.get('gamma_B_sum_w', energy_acc.get('gamma_B', 0.0)),
            E_curvature=energy_acc.get('A_curv', 0.0) + energy_acc.get('A_cov', 0.0),
            E_total=energy_acc.get('Action_total', 0.0),
        )
    
    def _compute_energies(self, step: int, agents: List[Any], ctx: Any) -> EnergySnapshot:
        """
        Compute all energy components from scratch (LAST RESORT).
        
        This provides independent validation but is expensive.
        """
        
        from agents.agent_accessor import AA
        from core.numerical_utils import kl_gaussian
        
        
        E_self = 0.0
        E_align_q = 0.0
        E_align_p = 0.0
        E_gamma_A = 0.0
        E_gamma_B = 0.0
        
        # Self-energy: Σ_i KL(q_i || p_i)
        for agent in agents:
            try:
                mu_q = AA.get_mu_q(agent)
                sigma_q = AA.get_sigma_q(agent)
                mu_p = AA.get_mu_p(agent)
                sigma_p = AA.get_sigma_p(agent)
                
                kl = kl_gaussian(mu_q, sigma_q, mu_p, sigma_p)
                E_self += float(np.sum(kl))
            except Exception:
                pass
        
        # Curvature energy from global A field
        E_curvature = self._compute_curvature_energy(ctx)
        
        E_total = E_self + E_align_q + E_align_p + E_gamma_A + E_gamma_B + E_curvature
        
        return EnergySnapshot(
            step=step,
            E_self=E_self,
            E_align_q=E_align_q,
            E_align_p=E_align_p,
            E_gamma_A=E_gamma_A,
            E_gamma_B=E_gamma_B,
            E_curvature=E_curvature,
            E_total=E_total,
        )
    
    def _compute_curvature_energy(self, ctx) -> float:
        """Compute global curvature field energy"""
        if not hasattr(ctx, 'global_A'):
            return 0.0
        
        try:
            A = ctx.global_A
            # F_μν = ∂_μ A_ν - ∂_ν A_μ
            if A.ndim >= 3 and A.shape[-1] >= 2:
                Ax = A[..., 0]
                Ay = A[..., 1]
                
                dAy_dx = np.gradient(Ay, axis=0)
                dAx_dy = np.gradient(Ax, axis=1)
                
                F = dAy_dx - dAx_dy
                return float(np.sum(F**2))
        except Exception:
            pass
        
        return 0.0
    
    def _update_conservation_stats(self):
        """Update conservation violation statistics"""
        if len(self.history) < 2:
            return
        
        E_prev = self.history[-2].E_total
        E_curr = self.history[-1].E_total
        
        violation = E_curr - E_prev
        if violation > 0:  # Energy increased
            self.max_violation = max(self.max_violation, violation)
            
            # Running mean of violations
            violations = [
                self.history[i+1].E_total - self.history[i].E_total
                for i in range(len(self.history) - 1)
                if self.history[i+1].E_total > self.history[i].E_total
            ]
            if violations:
                self.mean_violation = np.mean(violations)
    
    def print_summary(self):
        """Print current energy budget summary"""
        if not self.history:
            print("No energy history recorded yet")
            return
        
        snap = self.history[-1]
        
        print("\n" + "="*60)
        print(f"Energy Budget at Step {snap.step}")
        print("="*60)
        print(f"  Self-energy:        {snap.E_self:.6e}")
        print(f"  Alignment (q):      {snap.E_align_q:.6e}")
        print(f"  Alignment (p):      {snap.E_align_p:.6e}")
        print(f"  Gamma (A):          {snap.E_gamma_A:.6e}")
        print(f"  Gamma (B):          {snap.E_gamma_B:.6e}")
        print(f"  Curvature:          {snap.E_curvature:.6e}")
        print("  " + "-"*58)
        print(f"  TOTAL:              {snap.E_total:.6e}")
        print("="*60)
        
        if len(self.history) > 1:
            dE = snap.E_total - self.history[-2].E_total
            status = "✓ Dissipative" if dE <= 0 else "✗ INCREASING (BUG!)"
            print(f"  ΔE = {dE:.6e} ({status})")
        print()
    
    def plot_history(self, filename: Optional[str] = None):
        """Generate comprehensive energy history plots (4-panel figure)"""
        if len(self.history) < 2:
            print("Not enough history to plot (need at least 2 steps)")
            return
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        steps = [s.step for s in self.history]
        
        # Panel 1: Total energy
        ax = axes[0, 0]
        E_total = [s.E_total for s in self.history]
        ax.plot(steps, E_total, 'b-', linewidth=2, label='Total Energy')
        ax.set_xlabel('Step')
        ax.set_ylabel('Total Energy')
        ax.set_title('Total Energy Evolution')
        ax.grid(True, alpha=0.3)
        ax.legend()
        
        # Panel 2: Component breakdown
        ax = axes[0, 1]
        E_self = [s.E_self for s in self.history]
        E_align_q = [s.E_align_q for s in self.history]
        E_align_p = [s.E_align_p for s in self.history]
        E_gamma_A = [s.E_gamma_A for s in self.history]
        E_gamma_B = [s.E_gamma_B for s in self.history]
        E_curv = [s.E_curvature for s in self.history]
        
        ax.plot(steps, E_self, label='Self', linewidth=2)
        ax.plot(steps, E_align_q, label='Align (q)', linewidth=2)
        ax.plot(steps, E_align_p, label='Align (p)', linewidth=2)
        ax.plot(steps, E_gamma_A, label='Gamma (A)', linewidth=2)
        ax.plot(steps, E_gamma_B, label='Gamma (B)', linewidth=2)
        ax.plot(steps, E_curv, label='Curvature', linewidth=2)
        
        ax.set_xlabel('Step')
        ax.set_ylabel('Energy')
        ax.set_title('Energy Components')
        ax.legend(loc='upper right')
        ax.grid(True, alpha=0.3)
        
        # Panel 3: Energy changes (ΔE)
        ax = axes[1, 0]
        if len(steps) > 1:
            dE = np.diff(E_total)
            ax.plot(steps[1:], dE, 'r-', linewidth=2)
            ax.axhline(0, color='black', linestyle='--', linewidth=1)
            ax.fill_between(steps[1:], 0, dE, where=(np.array(dE) < 0), 
                           color='green', alpha=0.3, label='Dissipative')
            ax.fill_between(steps[1:], 0, dE, where=(np.array(dE) >= 0), 
                           color='red', alpha=0.3, label='Increasing (BUG!)')
        ax.set_xlabel('Step')
        ax.set_ylabel('ΔE')
        ax.set_title('Energy Change per Step')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        # Panel 4: Relative contributions
        ax = axes[1, 1]
        E_components = np.array([
            [s.E_self, s.E_align_q, s.E_align_p, s.E_gamma_A, s.E_gamma_B, s.E_curvature]
            for s in self.history
        ]).T
        
        # Normalize to fractions
        E_totals = np.array([s.E_total for s in self.history])
        E_totals[E_totals == 0] = 1.0
        E_fractions = E_components / E_totals[None, :]
        
        ax.stackplot(steps, E_fractions,
                    labels=['Self', 'Align(q)', 'Align(p)', 'Gamma(A)', 'Gamma(B)', 'Curv'],
                    alpha=0.8)
        ax.set_xlabel('Step')
        ax.set_ylabel('Fraction of Total')
        ax.set_title('Energy Component Fractions')
        ax.legend(loc='upper left', bbox_to_anchor=(1, 1))
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        fname = filename or 'energy_history.png'
        plt.savefig(self.output_dir / fname, dpi=150, bbox_inches='tight')
        plt.close()
        print(f"Energy history plot saved to {self.output_dir / fname}")
    
    def check_conservation(self, tolerance: float = 1e-6) -> bool:
        """Check energy conservation or controlled dissipation"""
        if len(self.history) < 2:
            print("Insufficient history for conservation check")
            return True
        
        print("\n" + "="*60)
        print("Energy Conservation Analysis")
        print("="*60)
        
        E_initial = self.history[0].E_total
        E_final = self.history[-1].E_total
        
        total_change = E_final - E_initial
        relative_change = abs(total_change / E_initial) if E_initial != 0 else float('inf')
        
        print(f"Initial energy:  {E_initial:.6e}")
        print(f"Final energy:    {E_final:.6e}")
        print(f"Total change:    {total_change:.6e}")
        print(f"Relative change: {relative_change:.6e}")
        print(f"Max violation:   {self.max_violation:.6e}")
        print(f"Mean violation:  {self.mean_violation:.6e}")
        
        is_dissipative = total_change <= tolerance
        print(f"\nSystem is {'dissipative' if is_dissipative else 'GAINING energy (check for bugs!)'}")
        
        conserved = relative_change < tolerance
        
        if conserved:
            print(f"✓ Energy conserved within tolerance ({tolerance:.2e})")
        else:
            print(f"✗ Energy NOT conserved! Violation: {relative_change:.2e}")
        
        print("="*60 + "\n")
        
        return conserved
    
    def export_csv(self, filename: Optional[str] = None):
        """Export energy history to CSV"""
        import csv
        
        if not self.history:
            return
        
        fname = filename or 'energy_history.csv'
        path = self.output_dir / fname
        
        with open(path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                'step', 'E_self', 'E_align_q', 'E_align_p',
                'E_gamma_A', 'E_gamma_B', 'E_curvature', 'E_total'
            ])
            
            for snap in self.history:
                writer.writerow([
                    snap.step, snap.E_self, snap.E_align_q, snap.E_align_p,
                    snap.E_gamma_A, snap.E_gamma_B, snap.E_curvature, snap.E_total
                ])
        
        print(f"Energy history exported to {path}")
    
    def export_sankey(self, filename: Optional[str] = None):
        """Export Sankey diagram of energy flows (requires plotly)"""
        try:
            import plotly.graph_objects as go
        except ImportError:
            print("plotly not installed - cannot create Sankey diagram")
            return
        
        if not self.history:
            return
        
        snap = self.history[-1]
        
        nodes = [
            "Self Energy", "Alignment (q)", "Alignment (p)",
            "Gamma (A)", "Gamma (B)", "Curvature", "Total Action"
        ]
        
        flows = [
            (0, 6, snap.E_self), (1, 6, snap.E_align_q), (2, 6, snap.E_align_p),
            (3, 6, snap.E_gamma_A), (4, 6, snap.E_gamma_B), (5, 6, snap.E_curvature),
        ]
        
        flows = [(s, t, v) for s, t, v in flows if abs(v) > 1e-10]
        sources, targets, values = zip(*flows) if flows else ([], [], [])
        
        fig = go.Figure(data=[go.Sankey(
            node=dict(pad=15, thickness=20, line=dict(color="black", width=0.5), label=nodes),
            link=dict(source=sources, target=targets, value=values)
        )])
        
        fig.update_layout(title_text=f"Energy Flow (Step {snap.step})", font_size=12)
        
        fname = filename or 'energy_sankey.html'
        path = self.output_dir / fname
        fig.write_html(str(path))
        print(f"Sankey diagram saved to {path}")


if __name__ == "__main__":
    print("Energy Budget Tracking Module - REAL FIX v2")
    print("="*60)
    print("\nCRITICAL FIX: Now reads from action dict (compute_total_action)")
    print("  instead of ctx.energy_acc\n")
    print("Usage:")
    print("  budget.record(step, action_dict=action)")
    print("\nwhere action comes from compute_total_action()")