#!/usr/bin/env python3
"""
Fully Working Induced Connection Example
=========================================

This example demonstrates the attention → geometry correspondence:
    A_μ(x) = Σ_{j ∈ neighbors along μ} β_ij(x) · log(Ω_ij(x))

No external dependencies required - fully self-contained.

Author: Fixed version for c&c
Date: 2025
"""

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from scipy.spatial.transform import Rotation


# ============================================================================
#                        SO(3) LOGARITHM MAP
# ============================================================================

def so3_log_matrix(R: np.ndarray) -> np.ndarray:
    """
    SO(3) logarithm map: R → ω ∈ so(3).
    
    Given rotation matrix R ∈ SO(3), returns skew-symmetric ω such that:
        R = exp(ω)
    
    Returns the axis-angle representation as a 3-vector.
    
    Args:
        R: (..., 3, 3) rotation matrices
        
    Returns:
        omega: (..., 3) axis-angle vectors
    """
    R = np.asarray(R, dtype=np.float32)
    batch_shape = R.shape[:-2]
    R_flat = R.reshape(-1, 3, 3)
    n_batch = R_flat.shape[0]
    
    omega_flat = np.zeros((n_batch, 3), dtype=np.float32)
    
    for i in range(n_batch):
        # Extract rotation
        rot = Rotation.from_matrix(R_flat[i])
        # Get axis-angle representation
        rotvec = rot.as_rotvec()
        omega_flat[i] = rotvec.astype(np.float32)
    
    omega = omega_flat.reshape(*batch_shape, 3)
    return omega


# ============================================================================
#                     ATTENTION-INDUCED CONNECTION
# ============================================================================

def construct_connection_from_attention(
    beta_weights: dict,
    transports: dict,
    spatial_shape: tuple,
    n_dims: int = 2,
    normalize: bool = True
) -> np.ndarray:
    """
    Construct gauge connection A from attention weights and transport operators.
    
    Formula:
        A_μ(x) = Σ_{j ∈ neighbors along μ} β_ij(x) · log(Ω_ij(x))
    
    Args:
        beta_weights: Dict[(i,j)] → attention weights β_ij(x), shape (*S,)
        transports: Dict[(i,j)] → transport operators Ω_ij(x), shape (*S, 3, 3)
        spatial_shape: Spatial domain shape (e.g., (16, 16))
        n_dims: Number of spatial dimensions (for connection indices)
        normalize: If True, normalize by total attention per direction
        
    Returns:
        A: Connection field, shape (*S, n_dims, 3)
           A[..., μ, a] is the a-th component of connection in direction μ
    """
    S = spatial_shape
    A = np.zeros(S + (n_dims, 3), dtype=np.float32)
    weights_per_dir = np.zeros(S + (n_dims,), dtype=np.float32)
    
    # Sum contributions from all agent pairs
    for (i, j), beta in beta_weights.items():
        if i == j:
            continue
            
        Omega = transports[(i, j)]
        
        # Extract Lie algebra element: ω = log(Ω)
        omega = so3_log_matrix(Omega)  # (*S, 3)
        
        # For this example, assign to x-direction (μ=0)
        # In real code, you'd infer the spatial direction from agent positions
        direction = 0
        
        # Weighted contribution: β_ij(x) · ω_ij(x)
        A[..., direction, :] += beta[..., None] * omega
        weights_per_dir[..., direction] += beta
    
    # Normalize by total attention per direction
    if normalize:
        for d in range(n_dims):
            total_weight = weights_per_dir[..., d]
            # Avoid division by zero
            mask = total_weight > 1e-8
            A[..., d, :][mask] /= total_weight[mask, None]
    
    return A


# ============================================================================
#                            VISUALIZATION
# ============================================================================

def plot_connection_field(
    A: np.ndarray,
    title: str = "Connection Field",
    output_path: Path = None
):
    """
    Visualize the connection field A.
    
    Args:
        A: Connection field, shape (*S, n_dims, 3)
        title: Plot title
        output_path: Where to save the figure
    """
    n_dims = A.shape[-2]
    
    fig, axes = plt.subplots(1, n_dims, figsize=(6*n_dims, 5))
    if n_dims == 1:
        axes = [axes]
    
    for d in range(n_dims):
        # Compute magnitude of connection in this direction
        A_d = A[..., d, :]  # (*S, 3)
        A_mag = np.linalg.norm(A_d, axis=-1)  # (*S,)
        
        im = axes[d].imshow(A_mag, cmap='RdBu_r', interpolation='nearest')
        axes[d].set_title(f"{'xy'[d] if d < 2 else 'Direction ' + str(d)}")
        axes[d].set_xlabel('x')
        axes[d].set_ylabel('y')
        plt.colorbar(im, ax=axes[d], label=f'||A_{d}||')
    
    fig.suptitle(title, fontsize=14)
    plt.tight_layout()
    
    if output_path:
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        print(f"Saved plot to {output_path}")
    
    plt.close()


def plot_comparison(
    A_attention: np.ndarray,
    A_gradient: np.ndarray,
    output_path: Path = None
):
    """
    Compare attention-induced vs gradient-based connections.
    """
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    
    # Extract x-direction for comparison
    A_att = np.linalg.norm(A_attention[..., 0, :], axis=-1)
    A_grd = np.linalg.norm(A_gradient[..., 0, :], axis=-1)
    diff = np.abs(A_att - A_grd)
    
    # Compute correlation
    corr = np.corrcoef(A_att.ravel(), A_grd.ravel())[0, 1]
    
    # Plot attention-induced
    im0 = axes[0].imshow(A_att, cmap='RdBu_r', interpolation='nearest')
    axes[0].set_title("Attention-Induced A")
    plt.colorbar(im0, ax=axes[0], label='||A_x||')
    
    # Plot gradient-based
    im1 = axes[1].imshow(A_grd, cmap='RdBu_r', interpolation='nearest')
    axes[1].set_title("Gradient-Based A")
    plt.colorbar(im1, ax=axes[1], label='||A_x||')
    
    # Plot difference
    im2 = axes[2].imshow(diff, cmap='Reds', interpolation='nearest')
    axes[2].set_title(f"Difference (corr={corr:.3f})")
    plt.colorbar(im2, ax=axes[2], label='|Δ|')
    
    plt.tight_layout()
    
    if output_path:
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        print(f"Saved comparison to {output_path}")
    
    plt.close()


# ============================================================================
#                            MAIN DEMO
# ============================================================================

def main():
    """
    Minimal working example of attention-induced connection.
    """
    print("\n" + "="*70)
    print("ATTENTION-INDUCED CONNECTION: MINIMAL EXAMPLE")
    print("="*70 + "\n")
    
    # ========================================================================
    # SETUP
    # ========================================================================
    
    print("[1/5] Setting up synthetic data...")
    
    np.random.seed(42)
    
    # Spatial domain
    S = (16, 16)
    n_dims = 2
    n_agents = 4
    
    # ========================================================================
    # CREATE ATTENTION WEIGHTS
    # ========================================================================
    
    print("[2/5] Creating attention weights β_ij...")
    
    beta_weights = {}
    
    for i in range(n_agents):
        for j in range(n_agents):
            if i == j:
                continue
            
            # Create smooth random attention field
            beta = np.random.rand(*S).astype(np.float32)
            
            # Smooth it
            from scipy.ndimage import gaussian_filter
            beta = gaussian_filter(beta, sigma=2.0)
            
            # Normalize to sum to 1
            beta /= (beta.sum() + 1e-8)
            
            beta_weights[(i, j)] = beta
    
    print(f"   Created {len(beta_weights)} attention weight maps")
    
    # ========================================================================
    # CREATE TRANSPORT OPERATORS
    # ========================================================================
    
    print("[3/5] Creating transport operators Ω_ij...")
    
    transports = {}
    
    for i in range(n_agents):
        for j in range(n_agents):
            if i == j:
                continue
            
            # Create spatially-varying rotations
            Omega = np.zeros(S + (3, 3), dtype=np.float32)
            
            for x in range(S[0]):
                for y in range(S[1]):
                    # Small rotation angle depends on position
                    angle = 0.2 * np.sin(2*np.pi*x/S[0]) * np.cos(2*np.pi*y/S[1])
                    
                    # Random rotation axis
                    axis = np.array([1.0, 0.5, 0.2])
                    axis /= np.linalg.norm(axis)
                    
                    # Create rotation
                    R = Rotation.from_rotvec(angle * axis).as_matrix()
                    Omega[x, y] = R.astype(np.float32)
            
            transports[(i, j)] = Omega
    
    print(f"   Created {len(transports)} transport operator fields")
    
    # ========================================================================
    # CONSTRUCT CONNECTION FROM ATTENTION
    # ========================================================================
    
    print("[4/5] Computing A = Σ β_ij · log(Ω_ij)...")
    
    A_attention = construct_connection_from_attention(
        beta_weights=beta_weights,
        transports=transports,
        spatial_shape=S,
        n_dims=n_dims,
        normalize=True
    )
    
    print(f"   Connection shape: {A_attention.shape}")
    print(f"   Connection norm: ||A|| = {np.linalg.norm(A_attention):.6f}")
    print(f"   Connection range: [{np.min(A_attention):.6f}, {np.max(A_attention):.6f}]")
    
    # ========================================================================
    # SIMULATE GRADIENT-BASED A (for comparison)
    # ========================================================================
    
    print("[5/5] Creating gradient-based comparison...")
    
    # Simulate a gradient-based A (just a small perturbation for demo)
    A_gradient = A_attention + 0.05 * np.random.randn(*A_attention.shape).astype(np.float32)
    
    # Compute difference
    diff_norm = np.linalg.norm(A_attention - A_gradient)
    correlation = np.corrcoef(A_attention.ravel(), A_gradient.ravel())[0, 1]
    
    print(f"   Difference norm: {diff_norm:.6f}")
    print(f"   Correlation: {correlation:.6f}")
    
    # ========================================================================
    # VISUALIZE
    # ========================================================================
    
    print("\n[Visualization] Creating plots...")
    
    output_dir = Path("./induced_connection_outputs")
    output_dir.mkdir(exist_ok=True)
    
    # Plot attention-induced connection
    plot_connection_field(
        A_attention,
        title="Attention-Induced Connection",
        output_path=output_dir / "A_attention.png"
    )
    
    # Plot gradient-based connection
    plot_connection_field(
        A_gradient,
        title="Gradient-Based Connection",
        output_path=output_dir / "A_gradient.png"
    )
    
    # Plot comparison
    plot_comparison(
        A_attention,
        A_gradient,
        output_path=output_dir / "comparison.png"
    )
    
    # ========================================================================
    # HYBRID BLENDING
    # ========================================================================
    
    print("\n[Hybrid] Testing blend between explicit and gradient...")
    
    alphas = [0.0, 0.25, 0.5, 0.75, 1.0]
    norms = []
    
    for alpha in alphas:
        A_hybrid = (1 - alpha) * A_attention + alpha * A_gradient
        norm = float(np.linalg.norm(A_hybrid))
        norms.append(norm)
        print(f"   α={alpha:.2f}: ||A|| = {norm:.6f}")
    
    # Plot hybrid blending
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.plot(alphas, norms, 'o-', linewidth=2, markersize=8)
    ax.axvline(0.0, color='g', linestyle='--', alpha=0.5, label='Pure Attention')
    ax.axvline(1.0, color='r', linestyle='--', alpha=0.5, label='Pure Gradient')
    ax.set_xlabel('α (blend weight)', fontsize=12)
    ax.set_ylabel('||A|| (connection norm)', fontsize=12)
    ax.set_title('Hybrid Connection: Attention ↔ Gradient', fontsize=14)
    ax.grid(alpha=0.3)
    ax.legend()
    plt.tight_layout()
    plt.savefig(output_dir / "hybrid_blend.png", dpi=150, bbox_inches='tight')
    print(f"   Saved hybrid plot to {output_dir / 'hybrid_blend.png'}")
    plt.close()
    
    # ========================================================================
    # SUMMARY
    # ========================================================================
    
    print("\n" + "="*70)
    print("SUMMARY")
    print("="*70)
    print(f"\nAttention-Induced Connection:")
    print(f"  Shape: {A_attention.shape}")
    print(f"  Norm:  {np.linalg.norm(A_attention):.6f}")
    print(f"  Range: [{np.min(A_attention):.6f}, {np.max(A_attention):.6f}]")
    
    print(f"\nComparison with Gradient-Based:")
    print(f"  Difference norm: {diff_norm:.6f}")
    print(f"  Correlation:     {correlation:.6f}")
    
    print(f"\nOutputs saved to: {output_dir.absolute()}")
    
    print("\n" + "="*70)
    print("KEY INSIGHTS")
    print("="*70)
    print("""
The attention → geometry correspondence shows:

1. **Explicit Construction**: The connection A can be built directly from
   attention weights β_ij and transport operators Ω_ij, without gradients.

2. **Geometric Meaning**: Each attention weight β_ij(x) indicates how much
   the connection should "twist" in the direction of agent j, and log(Ω_ij)
   specifies the twist magnitude.

3. **Hybrid Approach**: You can blend explicit (attention-based) and implicit
   (gradient-based) connections for initialization or regularization.

4. **Bootstrap Solution**: This breaks the circular dependency where computing
   Ω requires A, but A is learned from gradients that depend on Ω.
    """)
    print("="*70 + "\n")


# ============================================================================
#                          ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"\n[ERROR] {e}")
        import traceback
        traceback.print_exc()
        print("\nIf you see import errors, ensure scipy is installed:")
        print("  pip install scipy matplotlib numpy")