# -*- coding: utf-8 -*-
"""
Created on Thu Oct 30 18:23:45 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
PUBLICATION-QUALITY FIGURE GENERATOR FOR TRANSFORMER VALIDATION

Creates journal-ready figures with:
- Nature/Science compatible styling
- High-resolution vector graphics (PDF + SVG)
- Professional color schemes
- Clear typography
- Proper axis labels and legends
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import patches
from pathlib import Path
from typing import Dict, List
import seaborn as sns

# ========================================
# PUBLICATION STYLING
# ========================================

# Nature/Science style parameters
NATURE_STYLE = {
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
    'font.size': 7,  # Nature uses 7pt for main text
    'axes.labelsize': 7,
    'axes.titlesize': 8,
    'xtick.labelsize': 6,
    'ytick.labelsize': 6,
    'legend.fontsize': 6,
    'figure.titlesize': 8,
    'figure.dpi': 300,
    'savefig.dpi': 600,  # High-res for publication
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
    'axes.linewidth': 0.5,
    'axes.labelpad': 3,
    'xtick.major.width': 0.5,
    'ytick.major.width': 0.5,
    'xtick.major.size': 2,
    'ytick.major.size': 2,
    'lines.linewidth': 1.0,
    'lines.markersize': 3,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.grid': False,
}

# Professional color palettes
COLORS = {
    'primary': '#2E86AB',      # Blue
    'secondary': '#A23B72',    # Purple
    'accent': '#F18F01',       # Orange
    'success': '#06A77D',      # Green
    'warning': '#D9534F',      # Red
    'neutral': '#6C757D',      # Gray
    'light': '#E9ECEF',        # Light gray
}

# Colorblind-friendly palette (from ColorBrewer)
CB_COLORS = ['#377eb8', '#ff7f00', '#4daf4a', '#f781bf', '#a65628', '#984ea3', '#999999', '#e41a1c']

def apply_publication_style():
    """Apply Nature/Science compatible style."""
    plt.style.use('default')  # Reset first
    plt.rcParams.update(NATURE_STYLE)


# ========================================
# FIGURE 1: TEMPERATURE SWEEP (Main Result)
# ========================================

def plot_temperature_sweep_publication(sweep_results: Dict, save_path: Path):
    """
    Publication-quality temperature sweep figure.
    Shows the main empirical result: optimal τ = 20.
    
    This is typically Figure 1 or 2 in the main text.
    """
    apply_publication_style()
    
    # Set up figure - Nature prefers width ~180mm (7 inches)
    fig = plt.figure(figsize=(7, 5))
    
    # Create grid for subplots
    gs = fig.add_gridspec(2, 3, hspace=0.4, wspace=0.4)
    
    temps = sorted(sweep_results.keys())
    
    # Extract metrics
    mean_rs = [sweep_results[t]['mean_r'] for t in temps]
    median_rs = [sweep_results[t]['median_r'] for t in temps]
    std_rs = [sweep_results[t]['std_r'] for t in temps]
    frac_08 = [100*sweep_results[t]['frac_r_gt_08'] for t in temps]
    frac_09 = [100*sweep_results[t]['frac_r_gt_09'] for t in temps]
    key_bias = [sweep_results[t]['key_norm_bias'] for t in temps]
    
    # Find optimal temperature
    opt_idx = np.argmax(mean_rs)
    opt_temp = temps[opt_idx]
    
    # Panel A: Mean correlation vs temperature (MAIN RESULT)
    ax1 = fig.add_subplot(gs[0, :2])
    
    # Plot with error bars
    ax1.errorbar(temps, mean_rs, yerr=std_rs, marker='o', markersize=5,
                 linewidth=1.5, capsize=3, capthick=1.5,
                 color=COLORS['primary'], label='Mean $r$')
    ax1.plot(temps, median_rs, marker='s', markersize=4,
             linewidth=1.5, color=COLORS['secondary'], alpha=0.7, label='Median $r$')
    
    # Highlight optimal temperature
    ax1.axvline(opt_temp, color=COLORS['warning'], linestyle='--', 
                linewidth=1.5, alpha=0.7, label=f'Optimal $\\tau$ = {opt_temp}')
    ax1.axhline(0.8, color=COLORS['neutral'], linestyle=':', 
                linewidth=1, alpha=0.5, label='$r$ = 0.8')
    
    # Theoretical prediction
    d = 64
    tau_theory = 2 * np.sqrt(d)
    ax1.axvline(tau_theory, color=COLORS['success'], linestyle=':', 
                linewidth=1.5, alpha=0.7, label=f'Theory: $\\tau \\approx {tau_theory:.0f}$')
    
    ax1.set_xlabel('Temperature $\\tau$', fontweight='bold')
    ax1.set_ylabel('Correlation $r$', fontweight='bold')
    ax1.set_xscale('log')
    ax1.set_ylim([0.65, 0.9])
    ax1.legend(frameon=False, loc='lower right')
    ax1.text(-0.15, 1.05, 'a', transform=ax1.transAxes, 
             fontsize=10, fontweight='bold', va='top')
    
    # Add annotation for optimal value
    ax1.annotate(f'{mean_rs[opt_idx]:.3f}',
                xy=(opt_temp, mean_rs[opt_idx]),
                xytext=(opt_temp*1.5, mean_rs[opt_idx]+0.02),
                fontsize=6, ha='left',
                arrowprops=dict(arrowstyle='->', lw=0.5, color=COLORS['warning']))
    
    # Panel B: Fraction of high-correlation heads
    ax2 = fig.add_subplot(gs[0, 2])
    
    width = 0.35
    x_pos = np.arange(len(temps))
    
    ax2.bar(x_pos - width/2, frac_08, width, 
            color=COLORS['accent'], alpha=0.8, label='$r > 0.8$')
    ax2.bar(x_pos + width/2, frac_09, width,
            color=COLORS['success'], alpha=0.8, label='$r > 0.9$')
    
    ax2.set_xlabel('$\\tau$', fontweight='bold')
    ax2.set_ylabel('Heads (%)', fontweight='bold')
    ax2.set_xticks(x_pos)
    ax2.set_xticklabels([f'{t:.1f}' if t < 1 else f'{int(t)}' for t in temps], rotation=45)
    ax2.legend(frameon=False, loc='upper left')
    ax2.text(-0.35, 1.05, 'b', transform=ax2.transAxes,
             fontsize=10, fontweight='bold', va='top')
    
    # Panel C: Key-norm bias vs temperature
    ax3 = fig.add_subplot(gs[1, :2])
    
    ax3.plot(temps, key_bias, marker='D', markersize=4,
             linewidth=1.5, color=COLORS['secondary'])
    ax3.fill_between(temps, key_bias, alpha=0.2, color=COLORS['secondary'])
    
    ax3.set_xlabel('Temperature $\\tau$', fontweight='bold')
    ax3.set_ylabel('Key-norm bias $|\\rho|$', fontweight='bold')
    ax3.set_xscale('log')
    ax3.text(-0.15, 1.05, 'c', transform=ax3.transAxes,
             fontsize=10, fontweight='bold', va='top')
    
    # Panel D: Summary statistics table
    ax4 = fig.add_subplot(gs[1, 2])
    ax4.axis('off')
    
    # Create summary text
    summary_text = (
        f"Optimal: $\\tau$ = {opt_temp}\n"
        f"Mean $r$ = {mean_rs[opt_idx]:.3f}\n"
        f"Median $r$ = {median_rs[opt_idx]:.3f}\n"
        f"Std $r$ = {std_rs[opt_idx]:.3f}\n"
        f"\n"
        f"$r > 0.8$: {frac_08[opt_idx]:.1f}%\n"
        f"$r > 0.9$: {frac_09[opt_idx]:.1f}%\n"
        f"\n"
        f"vs. $\\tau$=1:\n"
        f"$\\Delta r$ = +{(mean_rs[opt_idx]-mean_rs[0])*100:.1f}%\n"
        f"\n"
        f"Theory: $\\tau \\approx {tau_theory:.0f}$\n"
        f"Error: {abs(opt_temp-tau_theory)/tau_theory*100:.0f}%"
    )
    
    ax4.text(0.1, 0.9, summary_text, transform=ax4.transAxes,
             fontsize=6, verticalalignment='top', family='monospace',
             bbox=dict(boxstyle='round', facecolor=COLORS['light'], 
                      edgecolor=COLORS['neutral'], linewidth=0.5))
    ax4.text(-0.35, 1.05, 'd', transform=ax4.transAxes,
             fontsize=10, fontweight='bold', va='top')
    
    # Save in multiple formats
    for fmt in ['pdf', 'svg', 'png']:
        plt.savefig(save_path / f"fig1_temperature_sweep.{fmt}", 
                   dpi=600 if fmt == 'png' else None, bbox_inches='tight')
    
    plt.close()
    print(f"  Saved: fig1_temperature_sweep (pdf, svg, png)")


# ========================================
# FIGURE 2: CORRELATION DISTRIBUTION
# ========================================

def plot_correlation_distribution_publication(all_head_results: List[Dict], 
                                              save_path: Path,
                                              tau: float = 20):
    """
    Publication-quality correlation distribution.
    Shows that results are not cherry-picked.
    """
    apply_publication_style()
    
    fig, axes = plt.subplots(1, 2, figsize=(7, 2.5))
    
    corrs = [r['metrics_forward']['global_r'] for r in all_head_results]
    
    # Panel A: Histogram
    ax = axes[0]
    
    n, bins, patches = ax.hist(corrs, bins=25, edgecolor='white', linewidth=0.5,
                               color=COLORS['primary'], alpha=0.8)
    
    # Color bars by value
    cm = plt.cm.RdYlGn
    for i, patch in enumerate(patches):
        patch.set_facecolor(cm(bins[i]))
    
    # Add statistics
    mean_r = np.mean(corrs)
    median_r = np.median(corrs)
    
    ax.axvline(mean_r, color='red', linestyle='--', linewidth=1.5,
               label=f'Mean: {mean_r:.3f}')
    ax.axvline(median_r, color='blue', linestyle='--', linewidth=1.5,
               label=f'Median: {median_r:.3f}')
    ax.axvline(0.8, color=COLORS['neutral'], linestyle=':', linewidth=1,
               alpha=0.7, label='$r$ = 0.8')
    
    ax.set_xlabel('Correlation $r$ ($\\alpha$ vs $\\beta$)', fontweight='bold')
    ax.set_ylabel('Number of heads', fontweight='bold')
    ax.legend(frameon=False, loc='upper left')
    ax.text(-0.15, 1.05, 'a', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top')
    
    # Panel B: Cumulative distribution
    ax = axes[1]
    
    sorted_corrs = np.sort(corrs)
    cumulative = np.arange(1, len(sorted_corrs) + 1) / len(sorted_corrs) * 100
    
    ax.plot(sorted_corrs, cumulative, linewidth=2, color=COLORS['primary'])
    ax.fill_between(sorted_corrs, cumulative, alpha=0.2, color=COLORS['primary'])
    
    # Mark key percentiles
    ax.axhline(50, color=COLORS['neutral'], linestyle=':', linewidth=1, alpha=0.5)
    ax.axvline(0.8, color=COLORS['success'], linestyle='--', linewidth=1.5,
               label='$r$ = 0.8')
    
    frac_above_08 = np.sum(np.array(corrs) > 0.8) / len(corrs) * 100
    ax.text(0.85, 30, f'{frac_above_08:.1f}% of heads\n$r > 0.8$',
            fontsize=6, bbox=dict(boxstyle='round', facecolor='white',
                                 edgecolor=COLORS['success'], linewidth=0.5))
    
    ax.set_xlabel('Correlation $r$', fontweight='bold')
    ax.set_ylabel('Cumulative percentage', fontweight='bold')
    ax.set_xlim([0.5, 1.0])
    ax.legend(frameon=False, loc='upper left')
    ax.text(-0.15, 1.05, 'b', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top')
    
    plt.suptitle(f'Correlation distribution ($\\tau$ = {tau}, $N$ = 144 heads)',
                fontsize=8, y=1.02)
    
    for fmt in ['pdf', 'svg', 'png']:
        plt.savefig(save_path / f"fig2_correlation_distribution.{fmt}",
                   dpi=600 if fmt == 'png' else None, bbox_inches='tight')
    
    plt.close()
    print(f"  Saved: fig2_correlation_distribution (pdf, svg, png)")


# ========================================
# FIGURE 3: PER-HEAD HEATMAP
# ========================================

def plot_per_head_heatmap_publication(all_head_results: List[Dict], 
                                     save_path: Path,
                                     tau: float = 20):
    """
    Publication-quality heatmap showing all heads.
    Demonstrates transparency (no cherry-picking).
    """
    apply_publication_style()
    
    num_layers = max(r['layer'] for r in all_head_results) + 1
    num_heads = max(r['head'] for r in all_head_results) + 1
    
    # Create correlation matrix
    corr_matrix = np.zeros((num_layers, num_heads))
    for result in all_head_results:
        corr_matrix[result['layer'], result['head']] = result['metrics_forward']['global_r']
    
    fig, ax = plt.subplots(figsize=(5, 4))
    
    # Use professional colormap
    cmap = plt.cm.RdYlGn
    im = ax.imshow(corr_matrix, cmap=cmap, aspect='auto', 
                   vmin=0.4, vmax=1.0, interpolation='nearest')
    
    # Add colorbar
    cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label('Correlation $r$', rotation=270, labelpad=12, fontweight='bold')
    cbar.ax.tick_params(labelsize=6)
    
    # Set labels
    ax.set_xlabel('Head index', fontweight='bold')
    ax.set_ylabel('Layer index', fontweight='bold')
    ax.set_title(f'Per-head correlation ($\\tau$ = {tau})', 
                fontsize=8, fontweight='bold', pad=10)
    
    # Set ticks
    ax.set_xticks(np.arange(num_heads))
    ax.set_yticks(np.arange(num_layers))
    ax.set_xticklabels(np.arange(num_heads))
    ax.set_yticklabels(np.arange(num_layers))
    
    # Add grid
    ax.set_xticks(np.arange(num_heads) - 0.5, minor=True)
    ax.set_yticks(np.arange(num_layers) - 0.5, minor=True)
    ax.grid(which='minor', color='gray', linestyle='-', linewidth=0.2, alpha=0.3)
    
    # Add summary statistics
    mean_r = np.mean(corr_matrix)
    text_str = (f'Mean $r$ = {mean_r:.3f}\n'
               f'Min $r$ = {np.min(corr_matrix):.3f}\n'
               f'Max $r$ = {np.max(corr_matrix):.3f}')
    
    ax.text(0.02, 0.98, text_str, transform=ax.transAxes,
           fontsize=6, verticalalignment='top',
           bbox=dict(boxstyle='round', facecolor='white', 
                    edgecolor='black', linewidth=0.5, alpha=0.9))
    
    for fmt in ['pdf', 'svg', 'png']:
        plt.savefig(save_path / f"fig3_per_head_heatmap.{fmt}",
                   dpi=600 if fmt == 'png' else None, bbox_inches='tight')
    
    plt.close()
    print(f"  Saved: fig3_per_head_heatmap (pdf, svg, png)")


# ========================================
# FIGURE 4: KEY-NORM BIAS ANALYSIS
# ========================================

def plot_key_norm_bias_publication(all_head_results: List[Dict], 
                                   save_path: Path,
                                   tau: float = 20):
    """
    Publication-quality key-norm bias figure.
    Validates theoretical prediction.
    """
    apply_publication_style()
    
    fig = plt.figure(figsize=(7, 3))
    gs = fig.add_gridspec(1, 3, wspace=0.4)
    
    # Panel A: Example scatter plot
    ax1 = fig.add_subplot(gs[0, 0])
    
    example = all_head_results[0]
    metrics = example['metrics_forward']
    
    ax1.scatter(metrics['key_norms_sq'], metrics['avg_attn_to_key_beta'],
               s=20, alpha=0.6, color=COLORS['primary'], edgecolors='white', linewidth=0.3)
    
    # Add regression line
    z = np.polyfit(metrics['key_norms_sq'], metrics['avg_attn_to_key_beta'], 1)
    p = np.poly1d(z)
    x_line = np.linspace(metrics['key_norms_sq'].min(), metrics['key_norms_sq'].max(), 100)
    ax1.plot(x_line, p(x_line), color=COLORS['warning'], linestyle='--', linewidth=1.5)
    
    ax1.set_xlabel('$\\|K_j\\|^2$', fontweight='bold')
    ax1.set_ylabel('Avg. attention to $K_j$', fontweight='bold')
    ax1.text(0.05, 0.95, f"$\\rho$ = {metrics['r_keynorm_beta']:.3f}\n"
                         f"$p$ = {metrics['p_keynorm_beta']:.2e}",
            transform=ax1.transAxes, fontsize=6, verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='white', edgecolor='black', linewidth=0.5))
    ax1.text(-0.2, 1.05, 'a', transform=ax1.transAxes,
            fontsize=10, fontweight='bold', va='top')
    
    # Panel B: Distribution of correlations
    ax2 = fig.add_subplot(gs[0, 1])
    
    r_keynorm_all = [r['metrics_forward']['r_keynorm_beta'] for r in all_head_results]
    
    ax2.hist(r_keynorm_all, bins=20, edgecolor='white', linewidth=0.5,
            color=COLORS['secondary'], alpha=0.8)
    ax2.axvline(np.mean(r_keynorm_all), color='red', linestyle='--', linewidth=1.5,
               label=f'Mean: {np.mean(r_keynorm_all):.3f}')
    ax2.axvline(0, color=COLORS['neutral'], linestyle=':', linewidth=1, alpha=0.5)
    
    ax2.set_xlabel('Correlation $\\rho$ ($\\|K\\|^2$ vs attention)', fontweight='bold')
    ax2.set_ylabel('Number of heads', fontweight='bold')
    ax2.legend(frameon=False, loc='upper right')
    ax2.text(-0.2, 1.05, 'b', transform=ax2.transAxes,
            fontsize=10, fontweight='bold', va='top')
    
    # Panel C: Significance
    ax3 = fig.add_subplot(gs[0, 2])
    
    p_keynorm_all = [r['metrics_forward']['p_keynorm_beta'] for r in all_head_results]
    log_p = np.clip(np.log10(p_keynorm_all), -15, 0)
    
    ax3.hist(log_p, bins=20, edgecolor='white', linewidth=0.5,
            color=COLORS['accent'], alpha=0.8)
    ax3.axvline(np.log10(0.05), color='red', linestyle='--', linewidth=1.5,
               label='$p$ = 0.05')
    ax3.axvline(np.log10(0.001), color='darkred', linestyle='--', linewidth=1.5,
               label='$p$ = 0.001')
    
    ax3.set_xlabel('$\\log_{10}(p)$', fontweight='bold')
    ax3.set_ylabel('Number of heads', fontweight='bold')
    ax3.legend(frameon=False, loc='upper left', fontsize=5)
    ax3.text(-0.2, 1.05, 'c', transform=ax3.transAxes,
            fontsize=10, fontweight='bold', va='top')
    
    n_sig = np.sum(np.array(p_keynorm_all) < 0.05)
    ax3.text(0.95, 0.95, f'{n_sig}/{len(all_head_results)}\nsignificant',
            transform=ax3.transAxes, fontsize=6, ha='right', va='top',
            bbox=dict(boxstyle='round', facecolor='white', edgecolor='black', linewidth=0.5))
    
    plt.suptitle(f'Key-norm bias analysis ($\\tau$ = {tau})', fontsize=8, y=1.02)
    
    for fmt in ['pdf', 'svg', 'png']:
        plt.savefig(save_path / f"fig4_key_norm_bias.{fmt}",
                   dpi=600 if fmt == 'png' else None, bbox_inches='tight')
    
    plt.close()
    print(f"  Saved: fig4_key_norm_bias (pdf, svg, png)")


# ========================================
# SUPPLEMENTARY FIGURE: STATISTICAL SIGNIFICANCE
# ========================================

def plot_statistical_significance_publication(all_head_results: List[Dict],
                                              save_path: Path,
                                              tau: float = 20):
    """
    Supplementary figure showing statistical rigor.
    """
    apply_publication_style()
    
    fig, axes = plt.subplots(1, 3, figsize=(7, 2.5))
    
    p_vals = [r['metrics_forward']['global_p'] for r in all_head_results]
    global_rs = [r['metrics_forward']['global_r'] for r in all_head_results]
    global_cis = [r['metrics_forward']['global_ci'] for r in all_head_results]
    
    # Panel A: p-value distribution
    ax = axes[0]
    log_p = np.clip(np.log10(p_vals), -15, 0)
    
    ax.hist(log_p, bins=20, edgecolor='white', linewidth=0.5,
           color=COLORS['primary'], alpha=0.8)
    ax.axvline(np.log10(0.05), color='red', linestyle='--', linewidth=1.5,
              label='$p$ = 0.05')
    ax.axvline(np.log10(0.001), color='darkred', linestyle='--', linewidth=1.5,
              label='$p$ = 0.001')
    
    ax.set_xlabel('$\\log_{10}(p)$', fontweight='bold')
    ax.set_ylabel('Number of heads', fontweight='bold')
    ax.legend(frameon=False, loc='upper left')
    ax.text(-0.2, 1.05, 'a', transform=ax.transAxes,
           fontsize=10, fontweight='bold', va='top')
    
    n_sig = np.sum(np.array(p_vals) < 0.001)
    ax.text(0.95, 0.95, f'{n_sig}/{len(all_head_results)}\n$p < 0.001$',
           transform=ax.transAxes, fontsize=6, ha='right', va='top',
           bbox=dict(boxstyle='round', facecolor='white', linewidth=0.5))
    
    # Panel B: Correlation vs p-value
    ax = axes[1]
    
    scatter = ax.scatter(global_rs, log_p, s=15, alpha=0.6, 
                        c=global_cis, cmap='viridis', edgecolors='white', linewidth=0.2)
    ax.axhline(np.log10(0.05), color='red', linestyle='--', linewidth=1, alpha=0.7)
    
    ax.set_xlabel('Correlation $r$', fontweight='bold')
    ax.set_ylabel('$\\log_{10}(p)$', fontweight='bold')
    ax.text(-0.2, 1.05, 'b', transform=ax.transAxes,
           fontsize=10, fontweight='bold', va='top')
    
    cbar = plt.colorbar(scatter, ax=ax)
    cbar.set_label('95% CI width', rotation=270, labelpad=10, fontsize=6)
    cbar.ax.tick_params(labelsize=5)
    
    # Panel C: Confidence interval distribution
    ax = axes[2]
    
    ax.hist(global_cis, bins=20, edgecolor='white', linewidth=0.5,
           color=COLORS['success'], alpha=0.8)
    ax.axvline(np.mean(global_cis), color='red', linestyle='--', linewidth=1.5,
              label=f'Mean: {np.mean(global_cis):.4f}')
    
    ax.set_xlabel('95% CI half-width', fontweight='bold')
    ax.set_ylabel('Number of heads', fontweight='bold')
    ax.legend(frameon=False, loc='upper right')
    ax.text(-0.2, 1.05, 'c', transform=ax.transAxes,
           fontsize=10, fontweight='bold', va='top')
    
    plt.suptitle(f'Statistical significance ($\\tau$ = {tau})', fontsize=8, y=1.02)
    
    for fmt in ['pdf', 'svg', 'png']:
        plt.savefig(save_path / f"figS1_statistical_significance.{fmt}",
                   dpi=600 if fmt == 'png' else None, bbox_inches='tight')
    
    plt.close()
    print(f"  Saved: figS1_statistical_significance (pdf, svg, png)")


# ========================================
# HELPER: GENERATE ALL FIGURES
# ========================================

def generate_all_publication_figures(sweep_results: Dict, 
                                    all_head_results_optimal: List[Dict],
                                    save_path: Path,
                                    optimal_tau: float = 20):
    """
    Generate all publication-quality figures at once.
    
    Parameters:
    -----------
    sweep_results : dict
        Results from temperature sweep (dict mapping tau -> metrics)
    all_head_results_optimal : list
        Per-head results at optimal temperature
    save_path : Path
        Directory to save figures
    optimal_tau : float
        The optimal temperature value
    """
    print("\n" + "="*60)
    print("GENERATING PUBLICATION-QUALITY FIGURES")
    print("="*60)
    
    print("\nMain Figures:")
    print("  Figure 1: Temperature sweep (main result)")
    plot_temperature_sweep_publication(sweep_results, save_path)
    
    print("  Figure 2: Correlation distribution")
    plot_correlation_distribution_publication(all_head_results_optimal, 
                                             save_path, tau=optimal_tau)
    
    print("  Figure 3: Per-head heatmap")
    plot_per_head_heatmap_publication(all_head_results_optimal, 
                                     save_path, tau=optimal_tau)
    
    print("  Figure 4: Key-norm bias")
    plot_key_norm_bias_publication(all_head_results_optimal, 
                                  save_path, tau=optimal_tau)
    
    print("\nSupplementary Figures:")
    print("  Figure S1: Statistical significance")
    plot_statistical_significance_publication(all_head_results_optimal,
                                             save_path, tau=optimal_tau)
    
    print("\n" + "="*60)
    print("ALL FIGURES GENERATED")
    print("="*60)
    print(f"\nFormats: PDF (vector), SVG (vector), PNG (600 DPI raster)")
    print(f"Location: {save_path}/")
    print("\nMain figures:")
    print("  - fig1_temperature_sweep.*")
    print("  - fig2_correlation_distribution.*")
    print("  - fig3_per_head_heatmap.*")
    print("  - fig4_key_norm_bias.*")
    print("\nSupplementary:")
    print("  - figS1_statistical_significance.*")
    print("\nTotal: 5 figures × 3 formats = 15 files")


if __name__ == "__main__":
    print(__doc__)
    print("\nThis module provides publication-quality figure generation.")
    print("Import and use generate_all_publication_figures() function.")