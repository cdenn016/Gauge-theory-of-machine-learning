
from __future__ import annotations
from typing import Any, Dict
import numpy as np
from core.utils import mask_hw
from joblib import Parallel, delayed
from threadpoolctl import threadpool_limits
from core.runtime_context import cfg_get
from agents.agent_accessor import AA


def _nan_ok(x):  # small utility
    return np.all(np.isfinite(x))

def _resolve_center(agent, ref_shape: tuple[int, ...]) -> tuple[int, ...]:
    """
    Robustly resolve a single spatial index:
      1) agent.center (if present),
      2) argmax(mask),
      3) spatial midpoint of the reference shape.
    Clamps to valid range.
    """
    try:
        c = AA.get_center(agent)
    except Exception:
        c = None
    if c is None:
        try:
            m = AA.get_mask_float(agent)
            idx = np.unravel_index(np.argmax(m), m.shape)
            c = tuple(int(x) for x in idx)
        except Exception:
            c = tuple(s // 2 for s in ref_shape)
    # clamp to valid spatial box
    c = tuple(max(0, min(ci, si - 1)) for ci, si in zip(c, ref_shape))
    return c




def _phi_at_center(agent):
    """
    Returns φ(center) and φ̃(center) for one agent, via AA getters.
    """
    try:
        phi_q = AA.get_phi_q(agent)  # (*S, 3)
        phi_p = AA.get_phi_p(agent)  # (*S, 3)
    except Exception:
        return None, None

    Sshape = phi_q.shape[:-1]
    c = _resolve_center(agent, Sshape)
    try:
        v_phi  = np.asarray(phi_q[c], np.float32)[...,:3]
        v_phim = np.asarray(phi_p[c], np.float32)[...,:3]
    except Exception:
        # Fallback to spatial mean
        v_phi  = np.mean(phi_q.reshape(-1, 3), axis=0).astype(np.float32)
        v_phim = np.mean(phi_p.reshape(-1, 3), axis=0).astype(np.float32)
    return v_phi, v_phim


def log_phi_vectors(ctx, agents):
    store_phi  = ctx.__dict__.setdefault("_phi_series", {})
    store_phim = ctx.__dict__.setdefault("_phi_model_series", {})

    for a in agents:
        aid = AA.get_id(a)
        v_phi, v_phim = _phi_at_center(a)

        if v_phi is not None:
            store_phi.setdefault(aid, []).append(v_phi.copy())
        if v_phim is not None:
            store_phim.setdefault(aid, []).append(v_phim.copy())


def _safe_take_vec(arr, center_idx, components: int = 3):
    """
    Slice a vector at 'center_idx' from array shaped (*S, C).
    Returns first `components` channels (default 3). Falls back to spatial mean if OOB.
    """
    if arr is None:
        return None
    X = np.asarray(arr)
    try:
        v = X[center_idx][..., :components]
    except Exception:
        v = np.mean(X.reshape(-1, X.shape[-1]), axis=0)[:components]
    return np.asarray(v, dtype=np.float32)


def _mu_at_center(agent):
    """
    Returns:
      muq_center_full : (K_q,) or None
      mup_center_full : (K_p,) or None

    We grab μ_q_field and μ_p_field, find this agent's spatial "center" index,
    and pull the full K-dim vector at that center.
    """
    muq_full = None
    mup_full = None

    # Try to read the agent's q-belief field
    try:
        muq_full = AA.get_mu_q(agent)  # shape (*S, K_q)
    except Exception:
        muq_full = None

    # Try to read the agent's p-model field
    try:
        mup_full = AA.get_mu_p(agent)  # shape (*S, K_p)
    except Exception:
        mup_full = None

    # If we got neither, nothing to log
    if muq_full is None and mup_full is None:
        return None, None

    # Figure out spatial lattice shape from whichever exists
    if muq_full is not None:
        ref_shape = muq_full.shape[:-1]  # (*S)
    else:
        ref_shape = mup_full.shape[:-1]

    # Resolve a spatial center index (i,j) or (i,j,k,...)
    c = _resolve_center(agent, ref_shape)

    def take_center(vecfield):
        if vecfield is None:
            return None
        # vecfield[c] is (K,), pull full latent vector
        return vecfield[c].astype(np.float32, copy=True)

    muq_center_full = take_center(muq_full)
    mup_center_full = take_center(mup_full)

    return muq_center_full, mup_center_full



def log_mu_vectors(ctx, agents):
    """
    For each agent and each step, log:
      - mu_q_full_at_center : full K_q vector (np.float32)
      - mu_q_norm_at_center : scalar float
      - mu_p_full_at_center : full K_p vector (np.float32)
      - mu_p_norm_at_center : scalar float

    These go into ctx._mu_logs[agent_id] so we can plot time series later.
    """

    import numpy as np

    store = ctx.__dict__.setdefault("_mu_logs", {})
    # structure:
    # ctx._mu_logs[aid] = {
    #   "mu_q_full": [ (K_q,), ... ],
    #   "mu_q_norm": [ scalar, ... ],
    #   "mu_p_full": [ (K_p,), ... ],
    #   "mu_p_norm": [ scalar, ... ],
    # }

    for a in agents:
        aid = AA.get_id(a)
        muq_vec, mup_vec = _mu_at_center(a)

        rec = store.setdefault(aid, {
            "mu_q_full": [],
            "mu_q_norm": [],
            "mu_p_full": [],
            "mu_p_norm": [],
        })

        if muq_vec is not None:
            muq_vec = np.asarray(muq_vec, dtype=np.float32)
            rec["mu_q_full"].append(muq_vec.copy())
            rec["mu_q_norm"].append(float(np.linalg.norm(muq_vec, ord=2)))

        if mup_vec is not None:
            mup_vec = np.asarray(mup_vec, dtype=np.float32)
            rec["mu_p_full"].append(mup_vec.copy())
            rec["mu_p_norm"].append(float(np.linalg.norm(mup_vec, ord=2)))


def save_all_series_npz(ctx, path):
    """
    Dump per-agent time series (φ, φ_model, μ_q, μ_p) to a single NPZ.

    Now supports:
      - full K-dim μ_q(center) and μ_p(center)
      - their norms
      - φ and φ_model (still 3-dim Lie algebra coords)

    Output arrays are ragged object arrays indexed by agent_ids[i].
    """

    import numpy as np

    # Old-style phi logs (3 components each, already per-step lists)
    phi_series_dict   = getattr(ctx, "_phi_series", {}) or {}
    phim_series_dict  = getattr(ctx, "_phi_model_series", {}) or {}

    # New-style mu logs
    mu_logs = getattr(ctx, "_mu_logs", {}) or {}

    # Build a unified set of agent IDs
    all_ids = set()

    # from phi / phim logs
    for d in (phi_series_dict, phim_series_dict):
        for k in d.keys():
            try:
                all_ids.add(int(k))
            except Exception:
                try:
                    all_ids.add(AA.get_id(k))
                except Exception:
                    continue

    # from mu_logs
    for k in mu_logs.keys():
        try:
            all_ids.add(int(k))
        except Exception:
            try:
                all_ids.add(AA.get_id(k))
            except Exception:
                continue

    agent_ids = sorted(all_ids)

    # Helper to pack a dict[aid] -> list[...] into an object array
    def pack_simple(series_dict):
        out = []
        for aid in agent_ids:
            seq = series_dict.get(aid, [])
            if seq is None:
                seq = []
            out.append(np.asarray(seq, dtype=np.float32))
        return np.array(out, dtype=object)

    # For μ we have nested structure inside mu_logs[aid]
    def pack_mu_field(field_key, as_scalar=False):
        """
        field_key: "mu_q_full", "mu_q_norm", "mu_p_full", "mu_p_norm"
        as_scalar=True means we store 1D float array instead of vector per step.
        """
        out = []
        for aid in agent_ids:
            rec = mu_logs.get(aid, {})
            seq = rec.get(field_key, [])
            if seq is None:
                seq = []

            if as_scalar:
                # seq is list[float] -> 1D float array
                out.append(np.asarray(seq, dtype=np.float32))
            else:
                # seq is list[(K,)] -> array(object) or ragged array
                # We'll store as object array of shape (T, K) in float32.
                out.append(np.asarray(seq, dtype=np.float32))

        return np.array(out, dtype=object)

    # Old-style "mu_q_series" / "mu_p_series" for backward compatibility:
    # If downstream code still expects them, we can give it the full-dim μ_q_full
    # (first 3 dims logic is gone). If you don't need backward compat,
    # you can just drop these two and update phi_gif accordingly.
    mu_q_series_obj = pack_mu_field("mu_q_full", as_scalar=False)
    mu_p_series_obj = pack_mu_field("mu_p_full", as_scalar=False)

    # Norm-only series
    mu_q_norm_obj   = pack_mu_field("mu_q_norm", as_scalar=True)
    mu_p_norm_obj   = pack_mu_field("mu_p_norm", as_scalar=True)

    # Pack φ and φ_model
    phi_series_obj  = pack_simple(phi_series_dict)
    phim_series_obj = pack_simple(phim_series_dict)

    np.savez(
        path,
        agent_ids=np.array(agent_ids, dtype=np.int32),

        # φ terms (3D Lie algebra coords)
        phi_series=phi_series_obj,
        phim_series=phim_series_obj,

        # μ terms (full latent space at agent center over time)
        mu_q_series=mu_q_series_obj,         # full K_q now, not just [:3]
        mu_p_series=mu_p_series_obj,         # full K_p

        # diagnostics that will be awesome for analysis:
        mu_q_norm_series=mu_q_norm_obj,      # (T,) per agent
        mu_p_norm_series=mu_p_norm_obj,      # (T,) per agent
    )





def _center_index_from(agent, ref_array):
    """
    Resolve a single spatial index tuple for 'ref_array' using:
      1) agent.center if present,
      2) argmax(agent.mask) if present,
      3) spatial midpoint of ref_array.
    ref_array is any array with shape (*S, C) where C is channel/feature dim.
    """
    if ref_array is None:
        return None

    # Try explicit center first
    if hasattr(agent, "center") and agent.center is not None:
        c = tuple(int(x) for x in agent.center)
        # Clamp to valid range just in case
        S = ref_array.shape[:-1]
        c = tuple(max(0, min(ci, si - 1)) for ci, si in zip(c, S))
        return c

    # Fall back to mask if present
    m = np.asarray(getattr(agent, "mask", None))
    if m is not None and m.size:
        idx = np.unravel_index(np.argmax(m), m.shape)
        return tuple(int(x) for x in idx)

    # Finally, spatial midpoint
    return tuple(s // 2 for s in ref_array.shape[:-1])







def _sum_beta_KL_from_ctx(ctx, which: str) -> float:
    total = 0.0
    # walk all keys in the unified store for this fiber
    for (w, i_id, j_id), B in (getattr(ctx.edge, "beta", {}) or {}).items():
        if str(w) != which: 
            continue
        # shape-safe fetch (guarantees zeros if missing)
        kl_ij, beta_ij = ctx.edge.get_align(ctx, which, i_id, j_id, shape=np.asarray(B).shape)
        b = np.asarray(beta_ij, np.float32)
        k = np.asarray(kl_ij,   np.float32)
        total += float((b * k).sum())
    return float(total)



def _sum_gamma_KL_from_ctx(ctx, which_case: str, *, kappa: float | None = None, corrected: bool = False) -> float:
    if corrected and (kappa is None):
        # A uses q’s κ, B uses p’s κ (same behavior as before)
        from core.runtime_context import cfg_get
        kappa = float(cfg_get(ctx, "kappa_gamma_q" if which_case == "A" else "kappa_gamma_p", 1.0))
    kap = max(float(kappa) if kappa is not None else 1.0, 1e-12)

    tot = 0.0
    for (case, a_id, b_id), G in (getattr(ctx.edge, "gamma", {}) or {}).items():
        if str(case) != which_case:
            continue
        # use the stored gamma’s shape for a shape-safe read
        g, k = ctx.edge.get_gamma(ctx, which_case, a_id, b_id, shape=np.asarray(G).shape)
        gg = np.asarray(g, np.float32)
        kk = np.asarray(k, np.float32)
        if corrected:
            tot += float((gg * (kk - 0.5 * (kk * kk) / kap)).sum())
        else:
            tot += float((gg * kk).sum())
    return float(tot)



def total_energy(ctx, agents, *, return_breakdown=False, precomputed_metrics=None):
    M = precomputed_metrics if precomputed_metrics is not None else compute_global_metrics(ctx, agents)
    E = float(M.get("E_total", 0.0))
    if not return_breakdown:
        return E

    breakdown = {
        "self":       float(M.get("self_sum_w",     M.get("self_sum", 0.0))),
        "feedback":   float(M.get("feedback_sum_w", M.get("feedback_sum", 0.0))),
        "align_q":    float(M.get("align_q_sum_w",  M.get("align_q_sum",  0.0))),
        "align_p":    float(M.get("align_p_sum_w",  M.get("align_p_sum",  0.0))),
        
        "gamma_A":    float(M.get("gamma_A_sum_w",  M.get("gamma_A_sum",  0.0))),
        "gamma_B":    float(M.get("gamma_B_sum_w",  M.get("gamma_B_sum",  0.0))),
        "mean_total": float(M.get("mean_total",     0.0)),
    }

    return E, breakdown



def print_action_breakdown(ctx, action_dict, *, stream=None):
    step = int(getattr(ctx, "global_step", -1))
    lines = []
    lines.append(f"[Action @ step {step}]")
    lines.append(f"  Action_total = {action_dict.get('Action_total', 0.0):.6e}")
    lines.append("  ---------------------------------------")
    lines.append(f"  Geom_total   = {action_dict.get('Geom_total', 0.0):.6e}")
   
    lines.append(f"  A_curv       = {action_dict.get('A_curv', 0.0):.6e}  ")
    lines.append(f"  A_cov        = {action_dict.get('A_cov', 0.0):.6e}")
   
    print("\n".join(lines), flush=True)


def print_energy_breakdown(ctx, metrics, *, hide_zero_weight=True):
       
    rows = [
        ("self(α)",      metrics.get("self_sum_w", 0.0),      metrics.get("self_mean", 0.0),      1.0),
        ("align_q(β)",   metrics.get("align_q_sum_w", 0.0),   metrics.get("align_q_mean", 0.0),   1.0),
        ("align_p(β)",   metrics.get("align_p_sum_w", 0.0),   metrics.get("align_p_mean", 0.0),   1.0),
        ("feedback(λ)",  metrics.get("feedback_sum_w", 0.0),  metrics.get("feedback_mean", 0.0),  1.0),
        # NEW
        ("gamma_A",      metrics.get("gamma_A_sum_w", 0.0),   metrics.get("gamma_A_mean", 0.0),   1.0),
        ("gamma_B",      metrics.get("gamma_B_sum_w", 0.0),   metrics.get("gamma_B_mean", 0.0),   1.0),
    ]


    print("\n[Energy Totals @ step {}]".format(int(getattr(ctx, "global_step", -1))))
    print("  E_total = {: .6e}  |  mean_total = {: .6e}".format(
        float(metrics.get("E_total", 0.0)),
        float(metrics.get("mean_total", 0.0)),
    ))
    print("  " + "-"*60)
    print("  {:<14} {:>14} {:>18} {:>8}   {:>14}".format(
        "term", "contrib_sum", "mean_per_px", "weight", "contrib_sum"))
    for name, contrib, mean_px, w in rows:
        if hide_zero_weight and (w == 0.0):
            continue
        print("  {:<14} {:>14.6e} {:>18.6e} {:>8g}   {:>14.6e}".format(
            name, float(contrib), float(mean_px), w, float(contrib)
        ))

    # Optional diagnostics: show *raw* ungated alignments (not used in action)
    aq_raw = float(metrics.get("align_q_sum_raw", 0.0))
    ap_raw = float(metrics.get("align_p_sum_raw", 0.0))
    if abs(aq_raw) + abs(ap_raw) > 0:
        print("  (diagnostic, not in action) align_q_raw = {: .6e} | align_p_raw = {: .6e}".format(aq_raw, ap_raw))
    print()



def compute_agent_metrics(ctx: Any, agent: Any) -> Dict[str, float]:
    """
    Returns per-agent RAW (unweighted) energy components.
    Keeps self/feedback unweighted to match alignment’s convention.
    """
    tau = float(cfg_get(ctx, "support_tau", 1e-6))

    # Use AA for mask access
    m = mask_hw(AA.get_mask_float(agent), tau=tau, mode="bool2")
    if m is None or not np.any(m):
        return {
            "self_sum": 0.0, "self_mean": 0.0,
            "feedback_sum": 0.0, "feedback_mean": 0.0,
        }

    S = int(np.count_nonzero(m)) or 1
    aid = int(AA.get_id(agent))

    ea = getattr(ctx, "energy_acc", {}) or {}
    # read directly from the dict populated by the master reducer (preserve your key format)
    self_sum = float(ea.get(f"self_sum[{aid}]", 0.0))
    fb_sum   = float(ea.get(f"feedback_sum[{aid}]", 0.0))

    return {
        "self_sum":     self_sum,
        "self_mean":    self_sum / S,
        "feedback_sum": fb_sum,
        "feedback_mean": fb_sum / S,
    }

def compute_global_metrics(ctx, agents):
    tau     = cfg_get(ctx, "support_tau", 1e-6)
    n_jobs  = int(cfg_get(ctx, "metrics_n_jobs", 1))
    alpha   = float(cfg_get(ctx, "alpha", 0.0))
    lambd   = float(cfg_get(ctx, "feedback_weight", 0.0))

    def _one(a):
        # Use AA for mask access
        m = mask_hw(AA.get_mask_float(a), tau=tau, mode="bool2")
        S = int(np.count_nonzero(m))
        if S <= 0:
            return None
        d = compute_agent_metrics(ctx, a)  # RAW component pieces (self/feedback)
        return d, S

    with threadpool_limits(1):
        outs = Parallel(n_jobs=max(1, n_jobs), backend="threading", batch_size="auto")(
            delayed(_one)(a) for a in agents
        )

    totals = {"self_sum": 0.0, "feedback_sum": 0.0, "_S": 0}

    for res in outs:
        if res is None:
            continue
        d, S = res
        for k in ("self_sum", "feedback_sum"):
            totals[k] += float(d[k])
        totals["_S"] += int(S)

    S_tot = max(totals["_S"], 1)

    # Means (diagnostic)
    out = dict(totals)
    out["self_mean"]     = out["self_sum"]     / S_tot
    out["feedback_mean"] = out["feedback_sum"] / S_tot
    out["active_pixels"] = totals["_S"]  # expose this so γ means use the true active count

    # === Alignment: use β-weighted sums (variational) ===
    align_q_sum_beta = _sum_beta_KL_from_ctx(ctx, "q")
    align_p_sum_beta = _sum_beta_KL_from_ctx(ctx, "p")

    # Store the β-weighted alignment as the canonical alignment energy
    out["align_q_sum"]  = align_q_sum_beta
    out["align_p_sum"]  = align_p_sum_beta
    out["align_q_mean"] = align_q_sum_beta / S_tot
    out["align_p_mean"] = align_p_sum_beta / S_tot

    # === Build weighted contributions actually used in the action ===
    self_w     = alpha * out["self_sum"]
    feedback_w = lambd * out["feedback_sum"]
    align_q_w  = out["align_q_sum"]    # β already included
    align_p_w  = out["align_p_sum"]    # β already included

    # existing weighted pieces:
    out["E_total"] = float(
        self_w + feedback_w +
        align_q_w + align_p_w
    )

    # NEW: gamma contributions (already weighted by gamma in the product)
    gamma_A_sum = _sum_gamma_KL_from_ctx(ctx, "A", corrected=True)  # κ inferred from cfg
    gamma_B_sum = _sum_gamma_KL_from_ctx(ctx, "B", corrected=True)
    out["gamma_A_sum"] = float(gamma_A_sum)
    out["gamma_B_sum"] = float(gamma_B_sum)

    # include γ-terms in the action energy:
    out["E_total"] = float(out["E_total"] + gamma_A_sum + gamma_B_sum)

    # means (per active pixel); these are diagnostic means, not extra weights
    S_mean = float(out.get("active_pixels", 0.0) or 1.0)
    out["gamma_A_mean"] = float(gamma_A_sum / S_mean)
    out["gamma_B_mean"] = float(gamma_B_sum / S_mean)

    # expose “weighted” pieces for breakdown (γ already applied, so just pass through)
    out.update({
        "self_sum_w": self_w, "feedback_sum_w": feedback_w,
        "align_q_sum_w": align_q_w, "align_p_sum_w": align_p_w,
        "gamma_A_sum_w": float(gamma_A_sum), "gamma_B_sum_w": float(gamma_B_sum),
    })

    # (Optional) keep raw ungated alignment sums ONLY as clearly-labeled diagnostics
    # NOTE: not used in E_total; shown only if you explicitly print them
    out["align_q_sum_raw"] = float(getattr(ctx, "energy_acc", {}).get("align_q_sum", 0.0))
    out["align_p_sum_raw"] = float(getattr(ctx, "energy_acc", {}).get("align_p_sum", 0.0))

    return out


def compute_total_action(ctx, agents, precomputed_metrics=None):
    """
    Compose the total Action from:
      - Geometric piece (E_total from compute_global_metrics)
      - Gauge A-field pieces: covariance and curvature (from ctx.fields)
    """
    # 1) Geometric piece
    M_geom = precomputed_metrics if (precomputed_metrics is not None) else compute_global_metrics(ctx, agents)
    A_geom = float(M_geom.get("E_total", 0.0))

    # 2) A-field terms (as recorded in ctx.fields)
    fields = getattr(ctx, "fields", {}) or {}
    A_cov  = float(fields.get("A_cov_energy_last", 0.0))
    A_curv = float(fields.get("A_curv_energy", 0.0))

    # 3) Total
    A_tot = float(A_geom + A_curv + A_cov)

    return {
        "Action_total": A_tot,
        "Geom_total":   A_geom,
        "A_curv":       A_curv,
        "A_cov":        A_cov,
        "self_sum":     float(M_geom.get("self_sum", 0.0)),
        "feedback_sum": float(M_geom.get("feedback_sum", 0.0)),
        "align_q_sum":  float(M_geom.get("align_q_sum", 0.0)),
        "align_p_sum":  float(M_geom.get("align_p_sum", 0.0)),
        "gamma_A_sum":  float(M_geom.get("gamma_A_sum", 0.0)),
        "gamma_B_sum":  float(M_geom.get("gamma_B_sum", 0.0)),
    }






def summarize_beta_fiber(ctx, agents, *, which: str = "q") -> dict:
    """
    Collect β and KL stats for a fiber ('q' or 'p') using the unified EdgeMaps API only.
    Reads via ctx.edge.get_align(...). No direct access to ctx._edge_*.
    Also checks per-pixel softmax consistency for each receiver.

    Returns a dict with summary stats and a small per-receiver softmax report.
    """
    import numpy as np

    if which not in ("q", "p"):
        raise ValueError(f"which must be 'q' or 'p', got {which!r}")

    # Resolve kappa/mode (kept only for reporting)
    cfg = getattr(ctx, "beta_cfg", {}) or {}
    sub = cfg.get(which, cfg)
    mode   = str(sub.get("mode", "")).lower()
    kappa  = float(sub.get("kappa", 1.0))
    
  
    id2agent = {AA.get_id(a): a for a in agents}
    
    beta_vals = []
    kl_vals   = []
    per_recv_softmax_err = {}

    for i_id, ai in id2agent.items():
        # use q shape for both fibers; p has same spatial shape
        Sshape = AA.get_mu_q(ai).shape[:-1]
        sender_arrays = []
        for j_id, aj in id2agent.items():
            if i_id == j_id:
                continue
            K_ij, B_ij = ctx.edge.get_align(ctx, which, i_id, j_id, shape=Sshape)
            if B_ij is None:
                continue
            b = np.asarray(B_ij, np.float64)
            sender_arrays.append(b)
            beta_vals.append(b)
            if K_ij is not None:
                kl_vals.append(np.asarray(K_ij, np.float64))

        if sender_arrays:
            B = np.stack(sender_arrays, axis=0)            # (Ns, *S)
            any_sender = np.any(B > 0, axis=0)             # (*S,)
            tot = np.sum(B, axis=0)                        # (*S,)
            err = np.abs(tot - 1.0) * any_sender
            per_recv_softmax_err[int(i_id)] = {
                "max_abs_err": float(np.nanmax(err)) if np.any(any_sender) else 0.0,
                "mean_abs_err": float(np.nanmean(err[any_sender])) if np.any(any_sender) else 0.0,
                "frac_viol>1e-3": float(np.mean((err > 1e-3)[any_sender])) if np.any(any_sender) else 0.0,
            }

    if not beta_vals:
        raise RuntimeError(f"[β/{which}] no β maps available via ctx.edge.get_align")

    beta_flat = np.concatenate([v.ravel() for v in beta_vals])
    kl_flat   = np.concatenate([v.ravel() for v in kl_vals]) if kl_vals else np.zeros(1, np.float64)

    return {
        "which": which, "mode": mode, "kappa": kappa,
        "beta_min": float(np.nanmin(beta_flat)),
        "beta_mean": float(np.nanmean(beta_flat)),
        "beta_max": float(np.nanmax(beta_flat)),
        "kl_min": float(np.nanmin(kl_flat)),
        "kl_med": float(np.nanmedian(kl_flat)),
        "kl_mean": float(np.nanmean(kl_flat)),
        "kl_max": float(np.nanmax(kl_flat)),
        "softmax": per_recv_softmax_err,
    }



def print_beta_summary(ctx, agents):
    q = summarize_beta_fiber(ctx, agents, which="q")
    p = summarize_beta_fiber(ctx, agents, which="p")
    step = int(getattr(ctx, "global_step", -1))

    def _fmt(f):
        return (
            f"\n[β/{f['which']} | step {step}] "
            f"mode={f['mode']} κ={f['kappa']:.3g} detach={f['detach']} "
            f"| edges={f['edges']} recv={f['recv']}\n"
            f"β[min/mean/max] = {f['beta_min']:.3g} / {f['beta_mean']:.3g} / {f['beta_max']:.3g}\n"
            f"KL[min/med/mean/max] = {f['kl_min']:.3g} / {f['kl_med']:.3g} / "
            f"{f['kl_mean']:.3g} / {f['kl_max']:.3g}\n"
        )

    print(_fmt(q))
    print(_fmt(p))

    # Softmax consistency (use the precomputed worst from summarize_beta_fiber)
    for f in (q, p):
        if f["mode"] not in ("softmax", "sm", "normexp"):
            continue
        worst_dev  = float(f.get("softmax_worst_dev", 0.0))
        worst_recv = f.get("softmax_worst_recv", None)
        if worst_dev > 1e-3:
            raise RuntimeError(
                f"[β/{f['which']}] worst softmax deviation {worst_dev:.3e} "
                f"at receiver i={worst_recv}"
            )




