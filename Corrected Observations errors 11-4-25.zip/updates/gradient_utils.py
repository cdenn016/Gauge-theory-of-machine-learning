# -*- coding: utf-8 -*-
"""
Created on Thu Oct 23 14:10:10 2025

@author: chris and christine
"""
import numpy as np
from core.omega import d_exp_exact, project_phi_covector_to_step, build_dexpinv_matrix
from core.transport_cache import Jinv_grid, E_grid
from core.numerical_utils import sanitize_sigma, safe_omega_inv, push_gaussian
from core.runtime_context import cfg_get


# ═════════════════════════════════════════════════════════════════════════════
# Core Configuration Getters
# ═════════════════════════════════════════════════════════════════════════════

def get_numerical_config(ctx):
    """
    Core numerical stability parameters used across all gradients.
    
    Returns:
        dict with keys: eps, tau
    """
    return {
        'eps': float(cfg_get(ctx, "eps", 1e-8)),
        'tau': float(cfg_get(ctx, "support_tau", 1e-6)),
    }


def get_energy_weights(ctx):
    """
    Energy term coupling weights.
    
    Returns:
        dict with keys: alpha, feedback_weight
    """
    return {
        'alpha': float(cfg_get(ctx, "alpha", 0.0)),
        'feedback_weight': float(cfg_get(ctx, "feedback_weight", 0.0)),
        'obs_scale': float(cfg_get(ctx, "obs_scale", 0.0))
    }


def get_learning_rates(ctx):
    """
    Learning rates for all field updates.
    
    Returns:
        dict with tau values for each field
    """
    return {
        'tau_phi': float(cfg_get(ctx, "tau_phi", 1e-1)),
        'tau_phi_model': float(cfg_get(ctx, "tau_phi_model", 1e-1)),
        'tau_mu_belief': float(cfg_get(ctx, "tau_mu_belief", 1e-2)),
        'tau_sigma_belief': float(cfg_get(ctx, "tau_sigma_belief", 1e-2)),
        'tau_mu_model': float(cfg_get(ctx, "tau_mu_model", 1e-2)),
        'tau_sigma_model': float(cfg_get(ctx, "tau_sigma_model", 1e-2)),
        'A_lr': float(cfg_get(ctx, "A_lr", 1e-2)),
    }


# ═════════════════════════════════════════════════════════════════════════════
# μ/Σ Gradient Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_mu_sigma_config(ctx):
    """
    Configuration for μ/Σ gradient computation (both belief and model).
    Used by:
        - accumulate_mu_sigma_gradient()
        - _accum_alignment_block_mu_sigma()
        - _accum_gamma_block_mu_sigma()
        - edge_maps._edge_build_flags_from_cfg()

    NOTE: This MUST include the alignment/gamma gating flags so that
    p-fiber alignment and cross-fiber gamma can be disabled at runtime.
    """
    num_cfg    = get_numerical_config(ctx)
    energy_cfg = get_energy_weights(ctx)

    return {
        # Numerical
        'eps':  num_cfg['eps'],
        'tau':  num_cfg['tau'],

        # Energy weights
        'alpha':            energy_cfg['alpha'],
        'feedback_weight':  energy_cfg['feedback_weight'],


        # NEW: Master freeze switches
        'freeze_mu_sigma_p': bool(cfg_get(ctx, "freeze_mu_sigma_p", False)),
        
        # Behavior flags
        'accumulate_sender_grads': bool(cfg_get(ctx, "accumulate_sender_grads", False)),

        # NEW: alignment toggles
        'use_alignment_q': bool(cfg_get(ctx, "use_alignment_q", True)),
        'use_alignment_p': bool(cfg_get(ctx, "use_alignment_p", True)),

        # NEW: gamma toggles (fiber-level on/off)
        'use_gamma_block_q': bool(cfg_get(ctx, "use_gamma_block_q", False)),
        'use_gamma_block_p': bool(cfg_get(ctx, "use_gamma_block_p", False)),

        # NEW: gamma flavor toggles (A / B path selection)
        'use_gamma_A': bool(cfg_get(ctx, "use_gamma_A", False)),
        'use_gamma_B': bool(cfg_get(ctx, "use_gamma_B", False)),
    }



# ═════════════════════════════════════════════════════════════════════════════
# φ Gradient Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_phi_config(ctx, which: str):
    """
    Configuration for φ gradient computation (fiber-specific).
    
    Args:
        ctx: Runtime context
        which: Fiber identifier ('q' for belief, 'p' for model)
    
    Used by:
        - _phi_term_align_recv()
        - _phi_term_gamma_recv()
        - phi_send_align()
        - phi_send_gamma()
    
    Returns:
        dict with all φ gradient parameters for specified fiber
    """
    num_cfg = get_numerical_config(ctx)
    energy_cfg = get_energy_weights(ctx)
    eps = num_cfg['eps']
    
    return {
        # Numerical
        'eps': eps,
        'tau': num_cfg['tau'],
        
        # Energy weights
        'alpha': energy_cfg['alpha'],
        'feedback_weight': energy_cfg['feedback_weight'],
        # NEW: Master freeze switch for this fiber
        'freeze_phi': bool(cfg_get(ctx, f"freeze_phi_{which}", False)),
        # Fiber-specific kappa values
        'beta_kappa': max(float(cfg_get(ctx, f"beta_kappa_{which}", 1.0)), eps),
        'gamma_kappa': float(cfg_get(ctx, f"kappa_gamma_{which}", 1.0)),
        
        # Gamma case flags (which gamma terms to use)
        'use_gamma_A': bool(cfg_get(ctx, f"use_gamma_A_{which}", True)),
        'use_gamma_B': bool(cfg_get(ctx, f"use_gamma_B_{which}", True)),
    }


def get_phi_config_global(ctx):
    """
    Global φ configuration (not fiber-specific).
    
    Used by:
        - build_phi_self_feedback_bucket()
        - Functions that don't need fiber-specific parameters
    
    Returns:
        dict with global φ parameters
    """
    num_cfg = get_numerical_config(ctx)
    energy_cfg = get_energy_weights(ctx)
    
    return {
        'eps': num_cfg['eps'],
        'tau': num_cfg['tau'],
        'alpha': energy_cfg['alpha'],
        'feedback_weight': energy_cfg['feedback_weight'],
    }


# ═════════════════════════════════════════════════════════════════════════════
# Curvature Gradient Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_curvature_config(ctx):
    """
    Configuration for curvature (A-field) gradient computation.
    
    Used by:
        - step_global_A()
        - covariant_frame_energy_and_grads()
    
    Returns:
        dict with curvature gradient parameters
    """
    num_cfg = get_numerical_config(ctx)
    
    return {
        'eps': num_cfg['eps'],
        'lambda_A_curv': float(cfg_get(ctx, "lambda_A_curv", 1e-2)),
        'lambda_A_cov': float(cfg_get(ctx, "lambda_A_cov", 1e-2)),
        'A_lr': float(cfg_get(ctx, "A_lr", 1e-2)),
        'A_grad_clip': float(cfg_get(ctx, "A_grad_clip", -1)),
        'use_global_A': bool(cfg_get(ctx, "use_global_A", True)),
        # NEW: Master freeze switch for A field
        'freeze_A': bool(cfg_get(ctx, "freeze_A", False)),
    }


# ═════════════════════════════════════════════════════════════════════════════
# Gradient Clipping Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_gradient_clip_config(ctx):
    """
    Gradient clipping thresholds for all fields.
    
    Returns:
        dict with clip thresholds (-1 = no clipping)
    """
    return {
        'gradient_clip_phi': float(cfg_get(ctx, "gradient_clip_phi", -1)),
        'gradient_clip_phi_model': float(cfg_get(ctx, "gradient_clip_phi_model", -1)),
        'A_grad_clip': float(cfg_get(ctx, "A_grad_clip", -1)),
    }


# ═════════════════════════════════════════════════════════════════════════════
# Parallel Execution Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_parallel_config(ctx):
    """
    Configuration for parallel gradient computation.
    
    Returns:
        dict with parallel execution parameters
    """
    return {
        'n_jobs': max(1, int(cfg_get(ctx, "n_jobs", 1))),
        'joblib_prefer': str(cfg_get(ctx, "joblib_prefer", "threads")),
        'joblib_memmap_threshold': cfg_get(ctx, "joblib_memmap_threshold", "10M"),
        'blas_threads_per_worker': int(cfg_get(ctx, "blas_threads_per_worker", 1)),
    }


# ═════════════════════════════════════════════════════════════════════════════
# Complete Configuration
# ═════════════════════════════════════════════════════════════════════════════

def get_all_gradient_config(ctx):
    """
    Get complete gradient configuration for all fields.
    
    Useful for debugging or when you need access to everything at once.
    
    Returns:
        dict with all gradient-related configuration
    """
    return {
        'numerical': get_numerical_config(ctx),
        'energy_weights': get_energy_weights(ctx),
        'learning_rates': get_learning_rates(ctx),
        'mu_sigma': get_mu_sigma_config(ctx),
        'phi_q': get_phi_config(ctx, 'q'),
        'phi_p': get_phi_config(ctx, 'p'),
        'phi_global': get_phi_config_global(ctx),
        'curvature': get_curvature_config(ctx),
        'gradient_clip': get_gradient_clip_config(ctx),
        'parallel': get_parallel_config(ctx),
    }


# ═════════════════════════════════════════════════════════════════════════════
# Validation
# ═════════════════════════════════════════════════════════════════════════════

def validate_gradient_config(ctx, verbose=True):
    """
    Validate that all gradient configuration is readable and sane.
    
    Args:
        ctx: Runtime context
        verbose: Print detailed validation results
    
    Returns:
        True if validation passes, False otherwise
    """
    try:
        cfg = get_all_gradient_config(ctx)
        
        # Check numerical sanity
        if cfg['numerical']['eps'] <= 0:
            if verbose:
                print(f"❌ eps must be > 0, got {cfg['numerical']['eps']}")
            return False
        
        if cfg['numerical']['tau'] < 0:
            if verbose:
                print(f"❌ tau must be >= 0, got {cfg['numerical']['tau']}")
            return False
        
        # Check learning rates are positive
        for key, val in cfg['learning_rates'].items():
            if val < 0:
                if verbose:
                    print(f"❌ {key} must be >= 0, got {val}")
                return False
        
        # Check kappa values are positive
        for fiber in ['q', 'p']:
            phi_cfg = cfg[f'phi_{fiber}']
            if phi_cfg['beta_kappa'] <= 0:
                if verbose:
                    print(f"❌ beta_kappa_{fiber} must be > 0, got {phi_cfg['beta_kappa']}")
                return False
            if phi_cfg['gamma_kappa'] < 0:
                if verbose:
                    print(f"❌ gamma_kappa_{fiber} must be >= 0, got {phi_cfg['gamma_kappa']}")
                return False
        
        if verbose:
            print("✅ Gradient configuration validation PASSED\n")
            print("Configuration summary:")
            print(f"  eps = {cfg['numerical']['eps']}")
            print(f"  tau = {cfg['numerical']['tau']}")
            print(f"  alpha = {cfg['energy_weights']['alpha']}")
            print(f"  feedback_weight = {cfg['energy_weights']['feedback_weight']}")
            print(f"  n_jobs = {cfg['parallel']['n_jobs']}")
            print(f"  beta_kappa_q = {cfg['phi_q']['beta_kappa']}")
            print(f"  beta_kappa_p = {cfg['phi_p']['beta_kappa']}")
        
        return True
        
    except Exception as e:
        if verbose:
            print(f"❌ Gradient configuration validation FAILED: {e}")
            import traceback
            traceback.print_exc()
        return False





def push_neighbor_stats(agent_j, sigma_key: str, Omega_ij: np.ndarray, eps: float):
    """
    Returns (mu_j_t, Sigma_j_t, Sigma_j_t_inv) in agent-i frame.
    Fast path pushes the PRECISION with an explicit spectral inverse (robust),
    fallback pushes the covariance using push_gaussian.
    """
    # ---- stats (sender j) ----
    mu_j = np.asarray(getattr(agent_j, sigma_key.replace("sigma", "mu")), np.float64, order="C")

    inv_key = sigma_key.replace("_field", "_inv")
    S_inv = getattr(agent_j, inv_key, None)

    # ---- mapping ----
    Om  = np.asarray(Omega_ij, np.float64, order="C")
    
    # ---------- PRECISION FAST-PATH ----------
    if S_inv is not None:
        S_inv = np.asarray(S_inv, np.float64, order="C")
        if S_inv.size and np.all(np.isfinite(S_inv)):
            try:
                Oinv = np.asarray(safe_omega_inv(Om, eps=1e-6), np.float64, order="C")
                OinvT = np.swapaxes(Oinv, -1, -2)

                # S_inv_t = Oinv^T S_inv Oinv  (do this in fp64 + symmetrize)
                S_inv_t = np.einsum("...ik,...kl,...jl->...ij", OinvT, S_inv, Oinv, optimize=True)
                S_inv_t = 0.5 * (S_inv_t + np.swapaxes(S_inv_t, -1, -2))

                # Robust spectral inverse (clip tiny eigs; no chol)
                flat = S_inv_t.reshape(-1, S_inv_t.shape[-1], S_inv_t.shape[-1])
                w, V = np.linalg.eigh(flat)
                lo = max(eps, np.finfo(w.dtype).eps)
                w = np.clip(w, a_min=lo, a_max=None)
                w_inv = 1.0 / w
                # Reconstruct Sigma_t = (S_inv_t)^{-1}
                Sigma_t = (V * w_inv[..., None, :]) @ np.swapaxes(V, -1, -2)
                Sigma_t = Sigma_t.reshape(S_inv_t.shape)
                Sigma_t = 0.5 * (Sigma_t + np.swapaxes(Sigma_t, -1, -2))

                # Mean push μ_t = Ω μ_j  (simple, stable)
                mu_t = np.einsum("...ij,...j->...i", Om, mu_j, optimize=True)

                # Also return S_inv_t in fp32 for callers that need it
                return (mu_t.astype(np.float32, copy=False),
                        Sigma_t.astype(np.float32, copy=False),
                        S_inv_t.astype(np.float32, copy=False))
            except Exception as e:
                # fall through to covariance path
                print(f"[push_neighbor_stats] precision fast-path failed: {e}")

    # ---------- COVARIANCE FALLBACK ----------
    Sigma_j = sanitize_sigma(np.asarray(getattr(agent_j, sigma_key), np.float64))
    # Be conservative about orthogonality; only assume if clearly near-ortho
    def _near_ortho(M, tol=1e-3):
        K = M.shape[-1]
        I = np.eye(K, dtype=M.dtype)
        M0 = M.reshape(-1, K, K)[0]
        return np.linalg.norm(M0.T @ M0 - I, ord='fro') / K < tol

    assume_ortho = _near_ortho(Om)

    mu_t, Sigma_t, Sigma_t_inv = push_gaussian(
        mu=mu_j, Sigma=Sigma_j, M=Om, eps=eps,
        return_inv=True, assume_orthogonal=assume_ortho, sanitize_input=False
    )
    return (mu_t.astype(np.float32, copy=False),
            Sigma_t.astype(np.float32, copy=False),
            Sigma_t_inv.astype(np.float32, copy=False))






def iter_overlap_pairs(agent_i, agents, tau, which, mu_key, ctx):
    """
    Pure generator for overlapping neighbors.
    
    Yields
    ------
    (agent_j, overlap_mask) : (Agent, ndarray (*S,) bool)
    """
    from core.utils import joint_masks
    
    for aj in (agents or []):
        if aj is agent_i:
            continue
        
        m_bool, m_vec = joint_masks(ctx, agent_i, aj)
        if not np.any(m_bool):
            continue
        
        yield aj, m_bool





def get_neighbors(agent_i, agents, *, dedup=True, exclude_self=True):
    """
    Resolve agent_i.neighbors -> list[Agent]. Accepts neighbors as dicts with 'id' or raw ints.
    Works with `agents` as a list (id from agent.id or index) or dict keyed by id.
    """
    raw = getattr(agent_i, "neighbors", []) or []

    if isinstance(agents, dict):
        lookup = {int(k): v for k, v in agents.items()}
    else:
        lookup = {int(getattr(a, "id", i)): a for i, a in enumerate(agents)}

    out, seen = [], set()
    self_id = int(getattr(agent_i, "id", -1))

    for nb in raw:
        try:
            j = int(nb["id"]) if isinstance(nb, dict) else int(nb)
        except Exception:
            continue
        if exclude_self and j == self_id:
            continue
        if dedup and j in seen:
            continue
        a = lookup.get(j)
        if a is not None:
            out.append(a)
            if dedup:
                seen.add(j)
    return out









def zero_all_gradients(agent):
    """
    Zero (and if missing, create) all gradient buffers,
    keeping legacy aliases in sync and ensuring arrays are writeable.
    """
    def ensure_buf(name, like):
        arr = getattr(agent, name, None)
        if arr is None and like is not None:
            arr = np.zeros_like(like)
        elif arr is not None and not arr.flags.writeable:
            arr = np.array(arr, copy=True)
        setattr(agent, name, arr)
        return arr

    g_mu_q   = ensure_buf("grad_mu_q",    getattr(agent, "mu_q_field", None))
    g_sg_q   = ensure_buf("grad_sigma_q", getattr(agent, "sigma_q_field", None))
    g_mu_p   = ensure_buf("grad_mu_p",    getattr(agent, "mu_p_field", None))
    g_sg_p   = ensure_buf("grad_sigma_p", getattr(agent, "sigma_p_field", None))
    g_phi    = ensure_buf("grad_phi",       getattr(agent, "phi", None))
    g_phit   = ensure_buf("grad_phi_tilde", getattr(agent, "phi_model", None))

    # legacy aliases
    if g_mu_q is not None: agent.grad_mu_q_field    = g_mu_q
    if g_sg_q is not None: agent.grad_sigma_q_field = g_sg_q
    if g_mu_p is not None: agent.grad_mu_p_field    = g_mu_p
    if g_sg_p is not None: agent.grad_sigma_p_field = g_sg_p

    for arr in (g_mu_q, g_sg_q, g_mu_p, g_sg_p, g_phi, g_phit):
        if isinstance(arr, np.ndarray):
            arr.fill(0)





# ============================================================================
# Sender Inbox Drain (Pure)
# ============================================================================

def drain_inbox_pure(agent, which):
    """
    Drain accumulated sender contributions from agent's inbox.
    
    Returns
    -------
    dmu : ndarray (*S, K)
    dS : ndarray (*S, K, K)
    """
    inbox_key = f"_inbox_{which}"
    inbox = getattr(agent, inbox_key, None)
    
    if inbox is None or not inbox:
        mu = getattr(agent, f"mu_{which}_field")
        S = getattr(agent, f"sigma_{which}_field")
        return np.zeros_like(mu), np.zeros_like(S)
    
    dmu_total = inbox.get('mu', None)
    dS_total = inbox.get('S', None)
    
    # Clear inbox after draining
    setattr(agent, inbox_key, {'mu': None, 'S': None})
    
    if dmu_total is None:
        mu = getattr(agent, f"mu_{which}_field")
        dmu_total = np.zeros_like(mu)
    if dS_total is None:
        S = getattr(agent, f"sigma_{which}_field")
        dS_total = np.zeros_like(S)
    
    return np.asarray(dmu_total, np.float32), np.asarray(dS_total, np.float32)


# ============================================================================
# Helper: Fiber Keys
# ============================================================================



def _accumulate_into_agent(agent, gmu_attr: str, gS_attr: str, dmu: np.ndarray, dS: np.ndarray):
    """
    Create grad buffers if missing and add in-place (float32).
    """
    if getattr(agent, gmu_attr, None) is None:
        setattr(agent, gmu_attr, np.zeros_like(dmu, dtype=np.float32))
    if getattr(agent, gS_attr, None) is None:
        setattr(agent, gS_attr, np.zeros_like(dS, dtype=np.float32))
    setattr(agent, gmu_attr, getattr(agent, gmu_attr) + np.asarray(dmu, np.float32))
    setattr(agent, gS_attr,  getattr(agent, gS_attr)  + np.asarray(dS,  np.float32))




def project_phi_covector(cov, Jinv, Finv):
    """
    Project φ-space covector to parameter-space step.
    
    Parameters
    ----------
    cov : ndarray (*S, 3)
        Unprojected covector
    Jinv : ndarray (*S, 3, 3)
    Finv : ndarray (*S, 3, 3)
    
    Returns
    -------
    step : ndarray (*S, 3)
    """
    
    return project_phi_covector_to_step(
        np.asarray(cov, np.float32), Jinv, Finv
    )



 


# ═════════════════════════════════════════════════════════════════════════════
# Fiber Resolution (UNCHANGED from original)
# ═════════════════════════════════════════════════════════════════════════════

def _fiber_keys_from_mode(mode: str):
    """Map 'belief'/'model' → fiber and attribute names (q/p)."""
    which = "q" if mode == "belief" else "p"
    field = "phi" if which == "q" else "phi_model"
    mu_key = "mu_q_field" if which == "q" else "mu_p_field"
    S_key  = "sigma_q_field" if which == "q" else "sigma_p_field"
    gmu_key= "grad_mu_q" if which == "q" else "grad_mu_p"
    gS_key = "grad_sigma_q" if which == "q" else "grad_sigma_p"
    return which, field, mu_key, S_key, gmu_key, gS_key




def _add_to_inbox(agent, which, add_mu, add_S, mask):
    """Enqueue sender-side alignment grads into agent's inbox (no projection)."""
    mu_key = "inbox_align_mu_q" if which == "q" else "inbox_align_mu_p"
    S_key  = "inbox_align_S_q"  if which == "q" else "inbox_align_S_p"

    # lazy init on first use (idempotent)
    if getattr(agent, mu_key, None) is None:
        base_mu = getattr(agent, "mu_q_field" if which == "q" else "mu_p_field")
        setattr(agent, mu_key, np.zeros_like(base_mu, dtype=np.float32))
    if getattr(agent, S_key, None) is None:
        base_S = getattr(agent, "sigma_q_field" if which == "q" else "sigma_p_field")
        setattr(agent, S_key, np.zeros_like(base_S, dtype=np.float32))

    # --- re-fetch; re-initialize if another thread cleared them in-between ---
    inbox_mu = getattr(agent, mu_key, None)
    inbox_S  = getattr(agent, S_key, None)
    if inbox_mu is None:
        base_mu = getattr(agent, "mu_q_field" if which == "q" else "mu_p_field")
        inbox_mu = np.zeros_like(base_mu, dtype=np.float32)
        setattr(agent, mu_key, inbox_mu)
    if inbox_S is None:
        base_S = getattr(agent, "sigma_q_field" if which == "q" else "sigma_p_field")
        inbox_S = np.zeros_like(base_S, dtype=np.float32)
        setattr(agent, S_key, inbox_S)

    # scatter-add only where overlap is true
    inbox_mu[mask] += add_mu[mask]
    inbox_S [mask] += add_S [mask]


def _drain_inbox_into_dalign(agent, which, dmu_align, dS_align):
    """Pull any queued sender grads into receiver's running align grads, then clear."""
    mu_key = "inbox_align_mu_q" if which == "q" else "inbox_align_mu_p"
    S_key  = "inbox_align_S_q"  if which == "q" else "inbox_align_S_p"
    have_mu = getattr(agent, mu_key, None)
    have_S  = getattr(agent, S_key, None)
    if have_mu is not None:
        dmu_align += have_mu.astype(np.float32, copy=False)
        setattr(agent, mu_key, None)    # clear
    if have_S is not None:
        dS_align  += have_S.astype(np.float32, copy=False)
        setattr(agent, S_key, None)     # clear
    return dmu_align, dS_align



# ═════════════════════════════════════════════════════════════════════════════
# Field Metadata (UNCHANGED from original)
# ═════════════════════════════════════════════════════════════════════════════

_FIELD_META = {
    "phi": {
        "which": "q",
        "mu_key": "mu_q_field",
        "sigma_key": "sigma_q_field",
        "fisher_inv_key": "inverse_fisher_phi",
        "grad_key": "grad_phi",
        "phi_attr": "phi",
        "qall_func": d_exp_exact,
    },
    "phi_model": {
        "which": "p",
        "mu_key": "mu_p_field",
        "sigma_key": "sigma_p_field",
        "fisher_inv_key": "inverse_fisher_phi_model",
        "grad_key": "grad_phi_tilde",
        "phi_attr": "phi_model",
        "qall_func": d_exp_exact,
    },
}


def _which_meta(field: str):
    """Extract metadata for given field name."""
    meta = _FIELD_META[field]
    return (
        meta["which"],
        meta["phi_attr"],
        meta["mu_key"],
        meta["sigma_key"],
        meta["fisher_inv_key"],
        meta["grad_key"],
    )





def get_preconds(ctx, agent, which, fisher_inv_key: str):
    """
    Fetch (E, Jinv, Finv) for the given fiber `which` using an explicit
    Fisher^{-1} attribute name. No identity fallback.
    """
    E    = np.asarray(E_grid(ctx, agent, which=which), np.float32)

    Jinv = Jinv_grid(ctx, agent, which=which)
    if Jinv is None:
        base_phi = np.asarray(getattr(agent, "phi" if which == "q" else "phi_model"), np.float32)
        Jinv = build_dexpinv_matrix(base_phi)

    Finv = getattr(agent, fisher_inv_key, None)
    if Finv is None:
        aid = getattr(agent, "id", "?")
        raise AttributeError(
            f"Agent(id={aid}) missing required Fisher inverse '{fisher_inv_key}' "
            f"for which='{which}'. Populate this field before calling the accumulator."
        )

    Finv = np.asarray(Finv, np.float32)
    if Finv.shape != Jinv.shape:
        raise ValueError(f"Finv shape {Finv.shape} mismatches Jinv shape {Jinv.shape}")
    if not (np.isfinite(E).all() and np.isfinite(Jinv).all() and np.isfinite(Finv).all()):
        raise FloatingPointError("non-finite values in E/Jinv/Finv")
    return E, Jinv, Finv



def _accum(agent, grad_key: str, step: np.ndarray):
    prev = getattr(agent, grad_key, None)
    setattr(agent, grad_key, (np.zeros_like(step) if prev is None else prev) + step)




def _preconds_min(ctx, agent, *, which: str, fisher_inv_key: str):
    E, Jinv, Finv = get_preconds(ctx, agent, which=which, fisher_inv_key=fisher_inv_key)
    return E, Jinv, Finv



def _project_phi_cov(cov, Jinv, Finv):
    return project_phi_covector_to_step(np.asarray(cov, np.float32), Jinv, Finv)