from __future__ import annotations

"""
Created on Tue Aug 12 20:15:47 2025

@author: chris and christine
"""
import time
from threadpoolctl import threadpool_limits
from joblib import Parallel, delayed
from joblib import parallel_backend
from agents.agent_accessor import AA

import numpy as np

from core.numerical_utils import sanitize_sigma
from core.omega import retract_phi_principal, d_exp_exact
from core.runtime_context import ctx_view_for_workers, ensure_shared_cache_attached, cfg_get

from updates.update_terms_mu_sigma import accumulate_mu_sigma_gradient
from updates.update_helpers import dirty_manager
from updates.update_terms_curvature_A import covariant_frame_energy_and_grads
from updates.update_terms_phi import _run_phi_phase
from updates.gradient_utils import get_neighbors, zero_all_gradients
from updates.gradient_terms import (grad_feedback_phi_direct, grad_feedback_phi_tilde_direct,
                                    grad_self_phi_direct, grad_self_phi_tilde_direct )

from updates.gradient_utils import get_learning_rates, get_parallel_config, get_curvature_config







_FIELD_META = {
    "phi": {
        "which": "q",
        "mu_key": "mu_q_field",
        "sigma_key": "sigma_q_field",
        "fisher_inv_key": "inverse_fisher_phi",
        "grad_key": "grad_phi",
        "phi_attr": "phi",
        "qall_func": d_exp_exact,
    },
    "phi_model": {
        "which": "p",
        "mu_key": "mu_p_field",
        "sigma_key": "sigma_p_field",
        "fisher_inv_key": "inverse_fisher_phi_model",
        "grad_key": "grad_phi_tilde",
        "phi_attr": "phi_model",
        "qall_func": d_exp_exact,
    },
}





def compute_all_gradients(agent_i, agents, all_agents, generators_q, generators_p, runtime_ctx=None):
    """
    Single-scale gradient orchestrator (no parents / no cross-scale).

      Phase 0: thread runtime ctx
      Phase 1: μ, Σ (belief/model) — same-level only
      Phase 2: warm neighbors + Fisher preconds
      Phase 3: φ / φ̃ (ALIGN + Γ + self/feedback) on receiver
               + ALIGN sender terms + Γ sender terms (parity with legacy)
      Phase 4: return gradients (+ per-agent θ grads; DO NOT APPLY HERE)
    """
    
    
    ctx = runtime_ctx
 

    # NEW: per-agent energy accumulators (local to this worker)
    self_sum_raw = 0.0
    fb_sum_raw   = 0.0

    # reset grads, timers
    zero_all_gradients(agent_i)
    timings = {}

    # -------- Phase 1 — μ, Σ (same-level only) --------
    t0 = time.perf_counter()
    _, _, (self_bel, fb_bel) = accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode="belief")
    timings["mu_sigma_belief"] = time.perf_counter() - t0
    
    t0 = time.perf_counter()
    _, _, (self_mod, fb_mod) = accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode="model")
    timings["mu_sigma_model"] = time.perf_counter() - t0
    
    # NEW: initialize worker-local energy tallies here
    self_sum_raw = float(self_bel + self_mod)
    fb_sum_raw   = float(fb_bel   + fb_mod)


    # -------- Phase 2 — neighbors --------
    t0 = time.perf_counter()
    neighbors = get_neighbors(agent_i, agents)
    timings["neighbors"] = time.perf_counter() - t0
    timings["neighbors_count"] = len(neighbors) if neighbors else 0

    recv_phi       = np.zeros_like(AA.get_phi_q(agent_i),       dtype=np.float32)
    recv_phi_tilde = np.zeros_like(AA.get_phi_p(agent_i), dtype=np.float32)
    send_phi       = []
    send_phi_tilde = []

    
    if neighbors:
        neighbors = sorted(neighbors, key=lambda a: AA.get_id(a))

        
        # ---- φ phase ----
        _res = _run_phi_phase(
            ctx, agent_i, neighbors,
            field="phi",
            generators_q=generators_q, generators_p=generators_p,
            fisher_inv_key=_FIELD_META["phi"]["fisher_inv_key"],
            grad_key=_FIELD_META["phi"]["grad_key"],
            phi_self_func=grad_self_phi_direct,
            phi_feedback_func=grad_feedback_phi_direct,
            timings=timings, prefix="phi",
        )
        # tolerant unpack: support legacy (r,s) and new (r,s,(self_raw,fb_raw))
        if isinstance(_res, tuple) and len(_res) == 3:
            r, s, (self_raw_phi, fb_raw_phi) = _res
            self_sum_raw += float(self_raw_phi)
            fb_sum_raw   += float(fb_raw_phi)
        else:
            r, s = _res
        recv_phi = np.asarray(r, np.float32)
        send_phi = [(AA.get_id(aj), np.asarray(dphi_j, np.float32)) for (aj, dphi_j) in (s or [])]
        
        # ---- φ̃ phase ----
        _res = _run_phi_phase(
            ctx, agent_i, neighbors,
            field="phi_model",
            generators_q=generators_q, generators_p=generators_p,
            fisher_inv_key=_FIELD_META["phi_model"]["fisher_inv_key"],
            grad_key=_FIELD_META["phi_model"]["grad_key"],
            phi_self_func=grad_self_phi_tilde_direct,
            phi_feedback_func=grad_feedback_phi_tilde_direct,
            timings=timings, prefix="phi_tilde",
        )
        if isinstance(_res, tuple) and len(_res) == 3:
            r, s, (self_raw_t, fb_raw_t) = _res
            self_sum_raw += float(self_raw_t)
            fb_sum_raw   += float(fb_raw_t)
        else:
            r, s = _res
        recv_phi_tilde = np.asarray(r, np.float32)
        send_phi_tilde = [(AA.get_id(aj), np.asarray(dphi_j, np.float32)) for (aj, dphi_j) in (s or [])]
        
    dtheta_i = None
    # bundle this agent's energy for master reduction
    ener_tuple = (AA.get_id(agent_i), float(self_sum_raw), float(fb_sum_raw))

    # NOTE: do not mutate other agents here; just return pure outputs
    return (
        (agent_i.grad_mu_q, agent_i.grad_sigma_q),
        (agent_i.grad_mu_p, agent_i.grad_sigma_p),
        recv_phi,
        recv_phi_tilde,
        dtheta_i,
        send_phi,
        send_phi_tilde,
        ener_tuple,   # << NEW 8th item
    )






def worker_entry(ctx_view, Ai, agents, all_agents, Gq, Gp):
    """Executed in each loky worker."""
    ctx = ensure_shared_cache_attached(ctx_view)
   
    if not hasattr(ctx, "cache"):                # <- optional convenience alias
        ctx.cache = ctx.shared
    with threadpool_limits(1):
        return compute_all_gradients(Ai, agents, all_agents, Gq, Gp, runtime_ctx=ctx)



def _compute_child_grads(ctx, agents, all_agents, Gq, Gp):
    
    if not agents:
        return ([], [], [], [], [])

    par_cfg = get_parallel_config(ctx)
    n_jobs = par_cfg['n_jobs']
    max_nbytes = par_cfg['joblib_memmap_threshold']

    if n_jobs <= 1:
        ctx = ensure_shared_cache_attached(ctx)
        
        results = [compute_all_gradients(Ai, agents, all_agents, Gq, Gp, runtime_ctx=ctx)
                   for Ai in agents]
    else:
        ctx_view = ctx_view_for_workers(ctx)
        with threadpool_limits(1), parallel_backend("loky"):
            results = Parallel(
                n_jobs=n_jobs,
                batch_size="auto",
                max_nbytes=max_nbytes,
                # don't pass prefer when you've forced backend; loky ignores it anyway
            )(delayed(worker_entry)(ctx_view, Ai, agents, all_agents, Gq, Gp) for Ai in agents)


    q_updates, p_updates, phi_recv, phi_m_recv, dtheta_parts = [], [], [], [], []
    send_phi_all, send_phi_m_all = [], []
    energy_items = []   # << NEW

    for out in results:
        if len(out) == 8:
            qU, pU, gphi_r, gphim_r, dth, sphi, sphim, ener = out
            send_phi_all.append(sphi)
            send_phi_m_all.append(sphim)
            energy_items.append(ener)  # (recv_id, self_sum_raw, fb_sum_raw)
        elif len(out) == 7:
            qU, pU, gphi_r, gphim_r, dth, sphi, sphim = out
            send_phi_all.append(sphi)
            send_phi_m_all.append(sphim)
        else:
            qU, pU, gphi_r, gphim_r, dth = out

        q_updates.append(qU)
        p_updates.append(pU)
        phi_recv.append(np.asarray(gphi_r,  dtype=np.float32))
        phi_m_recv.append(np.asarray(gphim_r, dtype=np.float32))
        dtheta_parts.append(dth)

    # id → index map (deterministic)
    id_to_idx = {int(getattr(a, "id", i)): i for i, a in enumerate(agents)}

    # start from receiver grads
    phi_grads   = [np.asarray(g, np.float32) for g in phi_recv]
    phi_m_grads = [np.asarray(g, np.float32) for g in phi_m_recv]

    # reduce φ sender contributions (deterministic)
    for send_list in send_phi_all:
        for recv_id, dphi in sorted(send_list or [], key=lambda t: int(t[0])):
            j = id_to_idx.get(int(recv_id))
            if j is None: 
                continue
            dphi = np.asarray(dphi, np.float32)
            if phi_grads[j] is None or np.isscalar(phi_grads[j]):
                phi_grads[j] = dphi.copy()
            else:
                phi_grads[j] = np.asarray(phi_grads[j], np.float32) + dphi

    # reduce φ̃ sender contributions (deterministic)
    for send_list in send_phi_m_all:
        for recv_id, dphi in sorted(send_list or [], key=lambda t: int(t[0])):
            j = id_to_idx.get(int(recv_id))
            if j is None:
                continue
            dphi = np.asarray(dphi, np.float32)
            if phi_m_grads[j] is None or np.isscalar(phi_m_grads[j]):
                phi_m_grads[j] = dphi.copy()
            else:
                phi_m_grads[j] = np.asarray(phi_m_grads[j], np.float32) + dphi

    # keep A–φ coupling in same place as before
    phi_grads, A_bucket, E_cov_total = apply_A_phi_covariant_coupling(ctx, agents, phi_grads)

    # >>> ADD THIS: publish energy & grad so diagnostics/printers can see it
    ctx.fields = getattr(ctx, "fields", {}) or {}
    ctx.fields["A_cov_energy_last"] = float(E_cov_total)          # <- makes it printable
    ctx.fields["A_grad_accum"]      = np.asarray(A_bucket) if A_bucket is not None else None


    # ---------- NEW: reduce per-agent energies on the master ----------
    # totals per agent id
    self_tot = {}
    fb_tot   = {}
    for rid, self_raw, fb_raw in energy_items:
        rid = int(rid)
        self_tot[rid] = self_tot.get(rid, 0.0) + float(self_raw)
        fb_tot[rid]   = fb_tot.get(rid,   0.0) + float(fb_raw)

    # publish into ctx.energy_acc (read by diagnostics.energy_acc_get)
    if not hasattr(ctx, "energy_acc"):
        ctx.energy_acc = {}

    # zero-initialize all keys to keep metrics tables stable
    for j, a in enumerate(agents):
        rid = int(getattr(a, "id", j))
        ctx.energy_acc[f"self_sum[{rid}]"]     = 0.0
        ctx.energy_acc[f"feedback_sum[{rid}]"] = 0.0

    # write the ones we have
    for rid, v in self_tot.items():
        ctx.energy_acc[f"self_sum[{rid}]"] = float(v)
    for rid, v in fb_tot.items():
        ctx.energy_acc[f"feedback_sum[{rid}]"] = float(v)

    # global totals used by your summary table
    ctx.energy_acc["self_sum"]     = float(sum(self_tot.values()))
    ctx.energy_acc["feedback_sum"] = float(sum(fb_tot.values()))
    # ------------------------------------------------------------------

    return (q_updates, p_updates, phi_grads, phi_m_grads, dtheta_parts, A_bucket, E_cov_total)



def apply_phi_updates(agent, grad_phi, grad_phi_m, mask, *, ctx=None, debug: bool = False):
    """
    Minimal φ / φ̃ updater with safe π-cut handling.
    
    NEW: Respects freeze_phi_q and freeze_phi_p flags.
    
    - Does the step in float64 to avoid rounding under the cut.
    - Optional boundary projector.
    - Reflect->clamp principalization in retract (must be implemented there).
    """
    from updates.gradient_utils import get_phi_config
    
    # ===== NEW: CHECK FREEZE FLAGS =====
    cfg_q = get_phi_config(ctx, 'q')
    cfg_p = get_phi_config(ctx, 'p')
    
    freeze_phi_q = cfg_q.get('freeze_phi', False)
    freeze_phi_p = cfg_p.get('freeze_phi', False)
    
    # If both frozen, do nothing
    if freeze_phi_q and freeze_phi_p:
        return
    # ====================================

    lr = get_learning_rates(ctx)
    eta_phi = lr['tau_phi']
    eta_phi_m = lr['tau_phi_model']
    margin = float(cfg_get(ctx, "phi_principal_margin", 1e-2))

    # ---- Work in float64 internally (critical near π) ----
    phi    = np.asarray(agent.phi,       np.float64)
    phi_m  = np.asarray(agent.phi_model, np.float64)
    gphi   = np.asarray(grad_phi,        np.float64)
    gphim  = np.asarray(grad_phi_m,      np.float64)

    # shape checks
    if gphi.shape  != phi.shape:   raise ValueError(f"grad_phi {gphi.shape} != phi {phi.shape}")
    if gphim.shape != phi_m.shape: raise ValueError(f"grad_phi_m {gphim.shape} != phi_model {phi_m.shape}")

    # mask → broadcast multiplier
    if mask is None:
        m = 1.0
    else:
        m = np.asarray(mask)
        if m.dtype == np.bool_: m = m.astype(np.float64)
        if m.ndim == phi.ndim - 1:  # (*S,) -> (*S,1)
            m = m[..., None]
        m = m.astype(np.float64, copy=False)

    # (optional) stash grads for debugging (keep original dtype)
    agent.grad_phi       = np.asarray(grad_phi, np.float32).copy()
    agent.grad_phi_tilde = np.asarray(grad_phi_m, np.float32).copy()

    # ===== NEW: CONDITIONAL STEPS =====
    if not freeze_phi_q:
        step_phi  = -eta_phi * gphi
        cand_phi  = phi + step_phi * m
        phi_out   = retract_phi_principal(cand_phi, margin=margin, use_float64=True)
        agent.phi = np.asarray(phi_out, dtype=np.float32, order="C")
    
    if not freeze_phi_p:
        step_phim = -eta_phi_m * gphim
        cand_phim = phi_m + step_phim * m
        phim_out  = retract_phi_principal(cand_phim, margin=margin, use_float64=True)
        agent.phi_model = np.asarray(phim_out, dtype=np.float32, order="C")
    # ==================================

    # mark dirty so transports/KL recompute (only if something changed)
    if ctx is not None and (not freeze_phi_q or not freeze_phi_p):
        dirty_manager(ctx).mark(agent, kl=True)




def _apply_sigma_masked(ctx, old_S, dS, tau, mask_bool, *, grad_type: str = "tangent"):
    """
    SPD-safe masked Sigma update with exact affine-invariant trust region.

    Grad semantics
    --------------
    grad_type = "tangent":   dS is an intrinsic tangent V at Σ (e.g. V = -2 Σ sym(∇) Σ)
    grad_type = "euclidean": dS is a Euclidean gradient ∇_Σ L; we convert to tangent internally

    Retraction modes (config: sigma_retraction_mode)
    ------------------------------------------------
      "exp"    : affine-invariant exponential map (default, recommended)
      "linear" : first-order step in the whitened tangent: Σ_{+} = Σ^{1/2}(I+R)Σ^{1/2}

    Trust region (config)
    ---------------------
      sigma_rel_step_max (rho) limits ||R||_F where R = Σ^{-1/2} (τ · V) Σ^{-1/2}
      sigma_skip_trust_region : bool  (if True, skip clipping of R)

    Other config keys
    -----------------
      support_tau               : SPD floor for eigenvalues (default 1e-8)
      sigma_update_gmax         : per-eigen cap for EXP via |log multiplier|; >1.0 enables cap
      sigma_assert_order1_match : print whitened ||R|| diagnostics if True
      sigma_skip_sanitize       : if True, do not sanitize on write-back
    """
    
    from core.runtime_context import cfg_get
    

    # ---------- inputs & checks ----------
    S  = np.asarray(old_S, dtype=np.float32, order="C")
    D  = np.asarray(dS,    dtype=np.float32, order="C")
    mb = np.asarray(mask_bool)

    if S.shape != D.shape:
        raise ValueError(f"_apply_sigma_masked: shape mismatch {S.shape} vs {D.shape}")
    if S.ndim < 2 or S.shape[-1] != S.shape[-2]:
        raise ValueError(f"_apply_sigma_masked: covariance must be square; got {S.shape[-2:]}")
    Sshape, K = S.shape[:-2], int(S.shape[-1])

    if tuple(mb.shape) != Sshape:
        raise ValueError(f"_apply_sigma_masked: mask shape {mb.shape} != spatial shape {Sshape}")
    if not (np.isfinite(S).all() and np.isfinite(D).all()):
        raise FloatingPointError("_apply_sigma_masked: non-finite inputs")

    mb = (mb > 0)
    if not np.any(mb):
        return S  # nothing to do

    tau     = float(tau)
    eps_spd = float(cfg_get(ctx, "support_tau", 1e-8))
    rho     = float(cfg_get(ctx, "sigma_rel_step_max", 0.25))
    mode    = str(cfg_get(ctx, "sigma_retraction_mode", "exp")).lower()
    gmax    = float(cfg_get(ctx, "sigma_update_gmax", 1.0))

    skip_trust    = bool(cfg_get(ctx, "sigma_skip_trust_region", False))
    skip_sanitize = bool(cfg_get(ctx, "sigma_skip_sanitize", False))
    assert mode in ("exp", "linear"), f"unknown sigma_retraction_mode={mode!r}"
    assert rho >= 0.0, "sigma_rel_step_max must be nonnegative"

    # ---------- flatten active ----------
    N   = int(np.prod(Sshape)) if Sshape else 1
    idx = np.flatnonzero(mb.reshape(N))
    Sflat, Dflat = S.reshape(N, K, K), D.reshape(N, K, K)
    S_act = Sflat[idx].astype(np.float64, copy=False)  # (M,K,K) math in f64
    D_act = Dflat[idx].astype(np.float64, copy=False)

    # ---------- intrinsic tangent (Delta) ----------
    if grad_type == "tangent":
        Delta = tau * 0.5 * (D_act + np.swapaxes(D_act, -1, -2))
    elif grad_type == "euclidean":
        Dsym  = 0.5 * (D_act + np.swapaxes(D_act, -1, -2))
        # convention: V = -2 Σ sym(∇) Σ  (your suite’s choice; keep consistent)
        V     = -2.0 * np.einsum("...ik,...kl,...lj->...ij", S_act, Dsym, S_act, optimize=True)
        Delta = tau * V
    else:
        raise ValueError(f"_apply_sigma_masked: unknown grad_type={grad_type!r}")

    # ---------- whitened tangent R via eig(Σ) ----------
    try:
        w, Q = np.linalg.eigh(S_act)
    except np.linalg.LinAlgError as e:
        raise np.linalg.LinAlgError(f"_apply_sigma_masked: eigh(Σ) failed: {e}") from e
    w = np.clip(w, eps_spd, None)
    Qt       = np.swapaxes(Q, -1, -2)
    sqrt_w   = np.sqrt(w)
    inv_sqrt = 1.0 / sqrt_w

    # Deig = Q^T Delta Q ;  R = inv_sqrt * Deig * inv_sqrt  (symmetrized)
    Deig = np.einsum("...ik,...kl,...jl->...ij", Qt, Delta, Q, optimize=True)
    R    = (inv_sqrt[..., :, None] * Deig) * inv_sqrt[..., None, :]
    R    = 0.5 * (R + np.swapaxes(R, -1, -2))

    # ---------- exact geodesic trust region in whitened frame ----------
    if not skip_trust:
        Rnorm = np.linalg.norm(R, axis=(-2, -1), keepdims=True)  # (M,1,1)
        alpha = np.minimum(1.0, rho / np.maximum(Rnorm, eps_spd))
        R    *= alpha
        if bool(cfg_get(ctx, "sigma_assert_order1_match", False)):
            # print post-clip max geodesic step for active pixels
            print(f"[Σ intrinsic step] max ||R||_F (clipped) = {float(np.max(alpha * Rnorm)):.3e}", flush=True)

    # ---------- retraction ----------
    if mode == "linear":
        # Σ_{+} = Σ^{1/2} (I + R) Σ^{1/2}  (first-order; may leave SPD if ||R|| large)
        Deig_lin    = (sqrt_w[..., :, None] * R) * sqrt_w[..., None, :]
        Delta_linear = np.einsum("...ik,...kl,...jl->...ij", Q, Deig_lin, Qt, optimize=True)
        S_new_act    = S_act + Delta_linear
    else:
        # EXP retraction: Σ_{+} = Σ^{1/2} exp(R) Σ^{1/2}  (exact SPD-preserving)
        lam, U = np.linalg.eigh(R)  # R is symmetric
        if gmax > 1.0:  # only clamp when requested
            lam = np.clip(lam, -np.log(gmax), np.log(gmax))
        exp_lam = np.exp(lam)
        expR    = (U * exp_lam[..., None, :]) @ np.swapaxes(U, -1, -2)
        # compute Σ^{1/2}(expR - I)Σ^{1/2} and add to Σ to improve numerical stability
        eye   = np.eye(K, dtype=np.float64)[None, ...]
        Teig  = (sqrt_w[..., :, None] * (expR - eye)) * sqrt_w[..., None, :]
        Delta_exp = np.einsum("...ik,...kl,...jl->...ij", Q, Teig, Qt, optimize=True)
        S_new_act = S_act + Delta_exp  # equals Σ^{1/2}exp(R)Σ^{1/2}

    # ---------- finalize ----------
    if not skip_sanitize:
        S_new_act = sanitize_sigma(S_new_act, eps=eps_spd).astype(np.float32, copy=False)
    else:
        # still symmetrize on write-back to avoid drift
        S_new_act = (0.5 * (S_new_act + np.swapaxes(S_new_act, -1, -2))).astype(np.float32, copy=False)

    out = S.copy()  # f32 buffer
    out.reshape(N, K, K)[idx] = S_new_act
    return out




def _apply_children(agents, grads, n_jobs, *, ctx=None):
    """
    Apply per-agent updates for μ/Σ (belief+model) and φ/φ̃ over arbitrary S.
    Frozen levels removed; updates applied wherever mask > 0.
    Hard-fails on shape/finiteness mismatches.
    """
   

    tau_mu_belief    = float(cfg_get(ctx, "tau_mu_belief",    1e-2))
    tau_sigma_belief = float(cfg_get(ctx, "tau_sigma_belief", 1e-2))
    tau_mu_model     = float(cfg_get(ctx, "tau_mu_model",     1e-2))
    tau_sigma_model  = float(cfg_get(ctx, "tau_sigma_model",  1e-2))
    DEBUG_APPLY      = bool(cfg_get(ctx, "DEBUG_APPLY", False))

    (q_updates, p_updates, phi_grads, phi_m_grads) = grads

    # Establish canonical S from first agent’s mask
    S0 = tuple(AA.get_mask_float(agents[0]).shape)
    
    def _one(i):
        A = agents[i]
        mask = AA.get_mask_float(A)
        if tuple(mask.shape) != S0:
            raise ValueError(f"[apply] agent {AA.get_id(A)} mask shape {mask.shape} != canonical {S0}")
        mask_mu = mask[..., None]  # broadcast over last feature dim
        
        dmu_q, dsg_q = q_updates[i]
        dmu_p, dsg_p = p_updates[i]

        mu_q_old = np.asarray(AA.get_mu_q(A), np.float32)
        mu_p_old = np.asarray(AA.get_mu_p(A), np.float32)
        sig_q_old = np.asarray(AA.get_sigma_q(A, sanitize=False), np.float32)
        sig_p_old = np.asarray(AA.get_sigma_p(A, sanitize=False), np.float32)
 
        # Finite checks
        for name, arr in (("mu_q", mu_q_old), ("mu_p", mu_p_old), ("sig_q", sig_q_old), ("sig_p", sig_p_old)):
            if not np.isfinite(arr).all():
                raise FloatingPointError(f"[apply] non-finite in {name} for agent {AA.get_id(A)}")

        # Shape checks vs S0
        if mu_q_old.shape[:-1] != S0: raise ValueError(f"[apply] mu_q_field shape {mu_q_old.shape} incompatible with {S0}")
        if mu_p_old.shape[:-1] != S0: raise ValueError(f"[apply] mu_p_field shape {mu_p_old.shape} incompatible with {S0}")
        if sig_q_old.shape[:-2] != S0: raise ValueError(f"[apply] sigma_q_field shape {sig_q_old.shape} incompatible with {S0}")
        if sig_p_old.shape[:-2] != S0: raise ValueError(f"[apply] sigma_p_field shape {sig_p_old.shape} incompatible with {S0}")

        # ---- μ updates (masked) ----
        A.mu_q_field = (mu_q_old + tau_mu_belief * np.asarray(dmu_q, np.float32) * mask_mu).astype(np.float32, copy=False)
        A.mu_p_field = (mu_p_old + tau_mu_model  * np.asarray(dmu_p, np.float32) * mask_mu).astype(np.float32, copy=False)

        # ---- Σ updates (masked, SPD-safe) ----
        A.sigma_q_field = _apply_sigma_masked(ctx, sig_q_old, np.asarray(dsg_q, np.float32),
                                              tau_sigma_belief, mask > 0.0, grad_type="tangent")
        A.sigma_p_field = _apply_sigma_masked(ctx, sig_p_old, np.asarray(dsg_p, np.float32),
                                              tau_sigma_model,  mask > 0.0, grad_type="tangent")

           
        if DEBUG_APPLY:
            dmuq_mean  = float(np.mean(np.abs(AA.get_mu_q(A) - mu_q_old)))
            dmup_mean  = float(np.mean(np.abs(AA.get_mu_p(A) - mu_p_old)))
            dsigq_mean = float(np.mean(np.abs(AA.get_sigma_q(A, sanitize=False) - sig_q_old)))
            dsigp_mean = float(np.mean(np.abs(AA.get_sigma_p(A, sanitize=False) - sig_p_old)))
            print(
                f"[APPLY] id={getattr(A,'id',i)} "
                f"|Δμ_q|={dmuq_mean:.3e} |Δμ_p|={dmup_mean:.3e} "
                f"|ΔΣ_q|={dsigq_mean:.3e} |ΔΣ_p|={dsigp_mean:.3e} "
                f"(τμ_q={tau_mu_belief:g}, τμ_p={tau_mu_model:g}, "
                f"τσ_q={tau_sigma_belief:g}, τσ_p={tau_sigma_model:g})",
                flush=True,
            )

        # ---- φ updates (masked internally) ----
        gp  = phi_grads[i];   gp  = np.zeros_like(AA.get_phi_q(A),       dtype=np.float32) if gp  is None else gp
        gpm = phi_m_grads[i]; gpm = np.zeros_like(AA.get_phi_p(A), dtype=np.float32) if gpm is None else gpm
        apply_phi_updates(A, gp, gpm, mask, ctx=ctx)

        # Mark morphisms dirty only (μ/Σ changes already imply transport recompute elsewhere)
        dirty_manager(ctx).mark_morphism_only(A)

    Parallel(n_jobs=int(n_jobs) if n_jobs is not None else 1, backend="threading", batch_size="auto")(
        delayed(_one)(i) for i in range(len(agents))
    )
    

    
    



def apply_A_phi_covariant_coupling(ctx, agents, phi_grads):
    """
    A–φ covariant coupling (N-D):
      - Adds covariant frame grad to each child's φ-grad (BODY coords)
      - Returns (out_phi_grads, A_grad, E_cov_total) with:
          out_phi_grads : list[np.ndarray] same length as agents
          A_grad        : np.ndarray of same shape as ctx.fields['A'] (fp32), or None if disabled
          E_cov_total   : float total covariant energy over all agents
    """
    
    
    from core.transport_cache import Jinv_grid
    from core.omega import build_dexpinv_matrix

    if ctx is None:
        return list(phi_grads), None, 0.0

    curv_cfg = get_curvature_config(ctx)
    use_A = curv_cfg['use_global_A']
    lam_cov = curv_cfg['lambda_A_cov']
    
    if not (use_A and lam_cov > 0.0):
        return list(phi_grads), None, 0.0

    # ---- fetch global A ----
    A = getattr(ctx, "fields", {}).get("A", None)   # (*S, ndim, 3)
    if A is None:
        raise RuntimeError("Global A missing; ensure_global_A(...) set ctx.fields['A'] before coupling.")

    A = np.asarray(A, np.float32, order="C")
    A_acc64     = np.zeros_like(A, dtype=np.float64)  # accumulate in fp64
    E_cov_total = 0.0
    out_phi     = list(phi_grads)

    dx = float(cfg_get(ctx, "grid_dx", 1.0))

    for i, a in enumerate(agents):
        phi_i  = AA.get_phi_q(a)
        try:
            mask_i = AA.get_mask_float(a)
        except ValueError:
            mask_i = None

        # energy + grads in PARAM coords (algebra), and A-grad
        E_cov, g_phi_cov, gA_cov = covariant_frame_energy_and_grads(
            phi=phi_i,
            A=A,
            weight=lam_cov,
            mask=mask_i,   # routine may already apply it; we re-apply below to be safe
            dx=dx,
        )

        # Project φ-grad to BODY coords with Jinv^T
        Jinv = Jinv_grid(ctx, a, which="q")
        if Jinv is None:
            Jinv = build_dexpinv_matrix(phi_i)  # (*S,3,3)
        g_body = np.einsum("...ji,...j->...i", Jinv, g_phi_cov, optimize=True)

        # Defensive mask
        if mask_i is not None:
            g_body = g_body * mask_i[..., None]

        # add into outgoing φ-grad list
        gi = out_phi[i]
        out_phi[i] = (np.asarray(gi, np.float32) if gi is not None else 0.0) + g_body

        # accumulate global A-grad and energy (fp64)
        A_acc64     += np.asarray(gA_cov, np.float64)
        E_cov_total += float(E_cov)

    # final A gradient as fp32 ndarray (same shape as A)
    A_grad = np.asarray(A_acc64, np.float32)
    return out_phi, A_grad, E_cov_total









