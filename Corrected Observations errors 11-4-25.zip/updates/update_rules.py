# -*- coding: utf-8 -*-
"""
Created on Wed Jul 23 10:32:58 2025

@author: chris and christine
"""
import time
from core.runtime_context import ensure_runtime_defaults, cfg_get, ensure_shared_cache_attached
from updates.update_compute_all_gradients import _apply_children, _compute_child_grads
from updates.update_helpers import dirty_manager,  refresh_agents, ensure_dirty
from updates.update_terms_curvature_A import step_global_A
from core.edge_maps import compute_all_edge_maps
from core.clock import update_intrinsic_clock

#apply_global_phi_gauge_fix(agents,*, include_model_in_mean: bool = True, mask_weighted: bool = True,  zero_outside_mask: bool = True,
#    max_iters: int = 15, tol: float = 1e-7,)

class PhaseTimer:
    """Context-manager timer that aggregates per-phase wall time on runtime_ctx."""
    def __init__(self, ctx):
        self.ctx = ctx
        if not hasattr(ctx, "timings") or getattr(ctx, "timings") is None:
            ctx.timings = {}

    def __call__(self, name: str):
        ctx = self.ctx
        class _T:
            def __enter__(_s):
                _s.t0 = time.perf_counter()
                return _s
            def __exit__(_s, *_):
                dt = time.perf_counter() - _s.t0
                ctx.timings[name] = ctx.timings.get(name, 0.0) + dt
        return _T()



debug_beta_viz = False




def synchronous_step(agents, generators_q, generators_p, n_jobs=1, runtime_ctx=None):
    """
    Single-scale (children-only) synchronous update step.
    Evolves child agents, enforces caches, computes per-edge maps (β/KL/Γ),
    applies child updates, warms caches for the next step, and registers children.
    No parents/detection/spawn/xscale.
    """
    assert runtime_ctx is not None, "synchronous_step: pass runtime_ctx"
    assert agents and (len(agents) > 0), "synchronous_step: no agents"

   

    
    runtime_ctx = ensure_runtime_defaults(runtime_ctx)
    ensure_shared_cache_attached(runtime_ctx)  # <-- important for β/γ writes

       # Cache should already be initialized in run_simulation()
    assert hasattr(runtime_ctx, "cache") and runtime_ctx.cache is not None, \
       "SharedDiskCache should be initialized in run_simulation()"


    step_now = int(getattr(runtime_ctx, "global_step", 0))
    runtime_ctx.cache.clear_on_step(step_now)

    # ---- unified dirty manager ----
    DM = dirty_manager(runtime_ctx)

    T = PhaseTimer(runtime_ctx)

    # ---------------- Phase 0: pre ----------------
    with T("pre"):
        if not agents:
            runtime_ctx.register_agents(0, [])
            runtime_ctx.global_step += 1
            return agents

        children = agents

        # Ensure Σ are sanitized/invertible before any pushes/KL
        refresh_agents(children, generators_q, generators_p, ctx=runtime_ctx)
        
        
        compute_all_edge_maps(runtime_ctx, children)
        
       
    

    with T("child_grad"):
        out = _compute_child_grads(runtime_ctx, children, children, generators_q, generators_p)

        # Accept old/new result tuples
        if len(out) == 7:
            q_updates, p_updates, phi_grads, phi_m_grads, dtheta_parts, A_bucket, E_cov = out
    
    # ---------- NEW: intrinsic clock increment (1 bit-per-unit if enabled) ----------
    with T("clock"):
        dt_clock = update_intrinsic_clock(
            runtime_ctx,
            children,
            q_updates,
            p_updates,
            phi_grads,
            phi_m_grads,
            A_bucket=A_bucket,
            measure_in_bits=True,   # 1 unit of t == 1 bit of inference
        )
        
    # -------------------------------------------------------------------------------

    with T("child_apply"):
        _apply_children(children, (q_updates, p_updates, phi_grads, phi_m_grads), n_jobs, ctx=runtime_ctx)
        # Mark children dirty for pairwise/KL refresh in the ensure phase
        DM.mark(*children, kl=True) 

    # ---------------- Phase 2: ensure/caches -------
    with T("ensure_dirty"):
        ensure_dirty(runtime_ctx, generators_q, generators_p, scope="children")

    # ---------------- Phase 3: optional global A update -------
    with T("A_update"):
        _ = step_global_A(
            runtime_ctx,
            children
           )

    # ---------------- Phase 4: register/step -------
    with T("register"):
        runtime_ctx.register_agents(0, children)
        runtime_ctx.children_latest = children
        runtime_ctx.global_step += 1

    # ---------------- Phase 5: timing --------------
    dbg = bool(cfg_get(runtime_ctx, "debug_phase_timing", True))
    if dbg:
        print("[timings]")
        for name, dt in sorted(getattr(runtime_ctx, "timings", {}).items()):
            print(f"  {name:20s} {dt:8.3f}s")
        if getattr(runtime_ctx, "counters", None):
            print("[counts]", runtime_ctx.counters)

    return agents









