# -*- coding: utf-8 -*-
"""
φ Gradient Computation - MINIMAL REFACTOR

This file contains the EXACT SAME mathematics as update_terms_phi.py,
just organized with cleaner config reading. No algorithms changed.

CHANGES FROM ORIGINAL:
1. Extracted config reading into _get_phi_config()
2. Added clear docstrings
3. Zero mathematical changes

PRESERVED:
- All gradient formulas
- All energy computations
- All transport operations
- All Fisher metric operations
- All alignment/gamma calculations
"""

import numpy as np
from core.numerical_utils import safe_omega_inv
from core.transport_cache import E_grid, Omega, exp_and_jinv_single, Phi_cached
from core.omega import d_exp_exact
from agents.agent_accessor import AA
from core.utils import mask_hw, joint_masks
from core.numerical_utils import push_gaussian
from core.edge_maps import beta_align_maps
from typing import Tuple

from updates.gradient_terms import grad_gamma_phi_covectors, grad_kl_wrt_phi_j, grad_kl_wrt_phi_i

from updates.gradient_utils import (  _which_meta, _project_phi_cov, _preconds_min, 
                                    push_neighbor_stats  )

from updates.gradient_utils import get_phi_config, get_phi_config_global, get_mu_sigma_config
# ═════════════════════════════════════════════════════════════════════════════
# Main Entry Points (REFACTORED to use config helpers)
# ═════════════════════════════════════════════════════════════════════════════


def _run_phi_phase(
    ctx, agent_i, neighbors, *,
    field: str,
    generators_q, generators_p,
    fisher_inv_key: str,
    grad_key: str,
    phi_self_func, phi_feedback_func,
    timings: dict, prefix: str,
):
    """
    Orchestrate φ gradient computation for one fiber (q or p).

    Now respects alignment/gamma toggles per fiber AND freeze flags.

    No math changes inside the term builders; we just decide which
    terms/strategies to even request, and whether to update at all.
    """
    import time
    t0 = time.perf_counter()

    # Figure out which fiber we're doing ("q" ↔ phi, "p" ↔ phi_tilde)
    which, _, _, _, _, _ = _which_meta(field)

    # ===== NEW: CHECK FREEZE FLAG FIRST =====
    cfg_phi = get_phi_config(ctx, which)
    if cfg_phi.get('freeze_phi', False):
        # Return zero gradients - no update
        phi_attr = "phi" if which == "q" else "phi_model"
        zero_grad = np.zeros_like(getattr(agent_i, phi_attr), np.float32)
        timings[f"{prefix}_frozen"] = True
        return zero_grad, [], (0.0, 0.0)
    # ========================================

    # Pull φ config once
    cfg_muS = get_mu_sigma_config(ctx)

    # Alignment toggles per fiber
    use_align_q = cfg_muS.get("use_alignment_q", True)
    use_align_p = cfg_muS.get("use_alignment_p", False)
    want_align = (which == "q" and use_align_q) or (which == "p" and use_align_p)

    # Gamma toggles per fiber (high-level on/off)
    use_gamma_q = cfg_muS.get("use_gamma_block_q", False)
    use_gamma_p = cfg_muS.get("use_gamma_block_p", False)
    want_gamma = (which == "q" and use_gamma_q) or (which == "p" and use_gamma_p)

    # Build the term lists we'll actually request
    recv_terms = ["self"]
    send_strats = []
    if want_align:
        recv_terms.append("align")
        send_strats.append("align")
    if want_gamma:
        recv_terms.append("gamma")
        send_strats.append("gamma")

    # ---------------- Receiver step ----------------
    recv_step, ener_pair = phi_recv_step(
        ctx, agent_i, neighbors, generators_q, generators_p,
        field=field, fisher_inv_key=fisher_inv_key,
        terms=tuple(recv_terms),
        phi_self_func=phi_self_func,
        phi_feedback_func=phi_feedback_func,
    )
    recv_step = recv_step.astype(np.float32, copy=False)
    timings[f"{prefix}_recv_total"] = time.perf_counter() - t0

    # ---------------- Sender steps -----------------
    t1 = time.perf_counter()
    send_list = phi_send_steps(
        ctx, agent_i, neighbors, generators_q, generators_p,
        field=field, fisher_inv_key=fisher_inv_key,
        strategies=tuple(send_strats),
    ) or []
    timings[f"{prefix}_send_align_total"] = time.perf_counter() - t1

    # γ sender timing can still be split if you want granular timers
    timings[f"{prefix}_send_gamma_total"] = 0.0

    return recv_step, send_list, ener_pair






def phi_recv_step(ctx, agent_i, neighbors, generators_q, generators_p, *,
                  field: str, fisher_inv_key: str,
                  terms=("align","gamma","self"),
                  phi_self_func=None, phi_feedback_func=None):
    """
    Compute receiver-side φ gradient step.
    
    UNCHANGED from original - all mathematics preserved.
    """
    import numpy as np

    which, phi_attr, mu_key, S_key, _, _ = _which_meta(field)
    gens = generators_q if field == "phi" else generators_p

    # Import here to avoid circular dependency
    from updates.update_terms_phi import _preconds_min
    E_i, Jinv_i, Finv_i = _preconds_min(ctx, agent_i, which=which, fisher_inv_key=fisher_inv_key)

    parts = []
    self_n = 0.0
    fb_n   = 0.0

    if "align" in terms:
        parts.append(np.asarray(
            _phi_term_align_recv(ctx, agent_i, neighbors,
                                 which=which, gens=gens, E_i=E_i, Jinv_i=Jinv_i, Finv_i=Finv_i,
                                 mu_key=mu_key, S_key=S_key, phi_attr=phi_attr),
            np.float32
        ))

    if "gamma" in terms:
        parts.append(np.asarray(
            _phi_term_gamma_recv(ctx, agent_i, neighbors,
                                 which=which, gens=gens, E_i=E_i, Jinv_i=Jinv_i, Finv_i=Finv_i),
            np.float32
        ))

    if "self" in terms:
        dphi_self, (self_n, fb_n) = build_phi_self_feedback_bucket(
            ctx, agent_i, generators_q, generators_p,
            field=field, fisher_inv_key=fisher_inv_key,
            phi_self_func=phi_self_func, phi_feedback_func=phi_feedback_func
        )
        parts.append(np.asarray(dphi_self, np.float32))

    if not parts:
        phi = np.asarray(getattr(agent_i, phi_attr), np.float32)
        return np.zeros_like(phi, np.float32), (0.0, 0.0)

    recv = np.sum(parts, axis=0, dtype=np.float32)
    return recv, (float(self_n), float(fb_n))







def _phi_term_align_recv(ctx, ai, neighbors, *, which, gens, E_i, Jinv_i, Finv_i, mu_key, S_key, phi_attr):
    """
    ALIGN receiver-side φ-step for agent i with TRUE softmax-β gradient.

    Energy:      E_i = Σ_j β_ij KL_ij,  β = softmax(-KL/κ) over j
    Gradient:    ∇φ_i E_i
               = Σ_j β_ij (1 - KL_ij/κ) g_ij  +  ( (Σ_j β_ij KL_ij) / κ ) · ḡ_i
      where      g_ij   = ∂ KL_ij / ∂φ_i   (receiver-frame covector, unprojected)
                 ḡ_i   = Σ_j β_ij g_ij

    We compute g_ij per neighbor, accumulate ḡ_i and Σ β KL, then project once.
    """
    cfg = get_phi_config(ctx, which)
    eps = cfg['eps']
    kappa = cfg['beta_kappa']


    # Receiver stats / params
    mu_i  = getattr(ai, mu_key)
    S_i   = getattr(ai, S_key)
    phi_i = np.asarray(getattr(ai, phi_attr), np.float32)

    # dExp at receiver once
    Q_all_i = d_exp_exact(phi_i, gens)

    # Accumulators in receiver frame (unprojected covectors)
    step_core = np.zeros_like(phi_i, np.float32)   # Σ_j β_ij (1 - KL_ij/κ) g_ij
    gbar      = np.zeros_like(phi_i, np.float32)   # ḡ_i = Σ_j β_ij g_ij
    sum_beta_KL = 0.0                              # scalar field per voxel: Σ_j β_ij KL_ij

    i_id = int(getattr(ai, "id", -1))
    Sshape = np.asarray(mu_i).shape[:-1]

    for aj in (neighbors or []):
        # Joint mask on receiver grid
        m_bool, m_vec = joint_masks(ctx, ai, aj)    # (*S,), (*S,1)
        if not np.any(m_bool):
            continue
        m = m_vec[..., 0].astype(np.float32, copy=False)  # (*S,)

        # Pull normalized β map and KL for this pair from the edge store
        j_id = AA.get_id(aj)
        KL_map, beta_map = ctx.edge.get_align(ctx, which, i_id, j_id, shape=Sshape)
        if beta_map is None:
            continue

        beta = (np.asarray(beta_map, np.float32) * m)     # masked β
        if not np.any(beta):
            continue
        KL1  = np.asarray(KL_map,  np.float32) * m        # masked KL

        # Transport & sender stats in receiver frame
        Om  = Omega(ctx, ai, aj, which=which)
        E_j = E_grid(ctx, aj, which=which)
        exp_neg_phi_j = safe_omega_inv(E_j)

        mu_j_t, _, S_j_t_inv = push_neighbor_stats(aj, S_key, Om, eps)

        # Receiver covector wrt φ_i for this neighbor (unprojected)
        g_ij = grad_kl_wrt_phi_i(
            mu_i, S_i,
            None, None,                  # keep legacy placeholders
            phi_i, None,
            Om, gens, E_i, E_j,
            mu_j_t, S_j_t_inv, eps,
            exp_neg_phi_j=exp_neg_phi_j,
            Q_all=Q_all_i,
        ).astype(np.float32, copy=False)

        # Accumulate pieces
        gbar      += beta[..., None] * g_ij
        step_core += (beta * (1.0 - KL1 / kappa))[..., None] * g_ij
        sum_beta_KL += (beta * KL1)

    # If no contributing neighbors, return zeros
    if not (np.any(step_core) or np.any(gbar)):
        return np.zeros_like(phi_i, np.float32)

    # Full unprojected covector:
    #   Σ_j β_ij (1 - KL_ij/κ) g_ij  +  ((Σ_j β_ij KL_ij)/κ) ḡ_i
    full_cov = step_core + (sum_beta_KL / kappa)[..., None] * gbar

    # Project once with receiver's preconditioners
    return _project_phi_cov(full_cov, Jinv_i, Finv_i).astype(np.float32, copy=False)










def _phi_term_gamma_recv(ctx, ai, neighbors, *, which, gens, E_i, Jinv_i, Finv_i):
    """
    Receiver-side φ-step from γ terms for agent i (q or p depending on `which`).
    Uses covector-first pure dispatcher; multiplies by true overlap mask.
    Returns (*S, Dphi).
    """
    cfg = get_phi_config(ctx, which)
    eps = cfg['eps']
    kap = cfg['gamma_kappa']
    use_A = cfg['use_gamma_A']
    use_B = cfg['use_gamma_B']

    # Fast exit if γ is off
    if not (use_A or use_B):
        phi_attr = "phi" if which == "q" else "phi_model"
        Dphi = int(np.asarray(getattr(ai, phi_attr)).shape[-1])
        Sshape = np.asarray(getattr(ai, "mu_q_field" if which == "q" else "mu_p_field")).shape[:-1]
        return np.zeros(Sshape + (Dphi,), np.float32)

    out = None

    # Receiver grid shape for γ maps
    Sshape_recv = np.asarray(
        getattr(ai, "mu_q_field" if which == "q" else "mu_p_field")
    ).shape[:-1]

    # ---- Prefetch receiver frames/stats (i) ----
    Eqi = np.asarray(E_grid(ctx, ai, which="q"), np.float64)  # (*S,Kq,Kq)
    Epi = np.asarray(E_grid(ctx, ai, which="p"), np.float64)  # (*S,Kp,Kp)
    mu_p_i  = np.asarray(ai.mu_p_field,    np.float64, order="C")
    Sig_p_i = np.asarray(ai.sigma_p_field, np.float64, order="C")

    for aj in (neighbors or []):
        i_id = int(getattr(ai, "id", -1)); j_id = AA.get_id(aj)

        # γ maps live on receiver grid (i)
        gA, KA = ctx.edge.get_gamma(ctx, "A", j_id, i_id, shape=Sshape_recv) if use_A else (None, None)
        gB, KB = ctx.edge.get_gamma(ctx, "B", i_id, j_id, shape=Sshape_recv) if use_B else (None, None)
        if (gA is None or not np.any(gA)) and (gB is None or not np.any(gB)):
            continue

        # Joint overlap mask on receiver grid (safeguard)
        m_bool, m_vec = joint_masks(ctx, ai, aj)          # (*S,), (*S,1)
        if not np.any(m_bool):
            continue
        m = m_vec[..., 0].astype(np.float32, copy=False)  # (*S,)

        # Sender stats/frame (j)
        Eqj     = np.asarray(E_grid(ctx, aj, which="q"), np.float64)         # (*S,Kq,Kq)
        mu_q_j  = AA.get_mu_q(aj).astype(np.float64, order="C")
        Sig_q_j = AA.get_sigma_q(aj, sanitize=False).astype(np.float64, order="C")

        def _accum(Wmap, Kmap, basis):
            nonlocal out
            if Wmap is None or not np.any(Wmap):
                return
            W = np.asarray(Wmap, np.float32) * m
            if Kmap is not None:
                K = np.asarray(Kmap, np.float32) * m
                W = W * (1.0 - K / max(kap, eps))
            if not np.any(W):
                return

            # Pure dispatcher call: feed frames & stats directly
            cov_i_q, _, cov_i_p = grad_gamma_phi_covectors(
                Eqi=Eqi, Eqj=Eqj, Epi=Epi,
                mu_q_j=mu_q_j,  Sigma_q_j=Sig_q_j,
                mu_p_i=mu_p_i,  Sigma_p_i=Sig_p_i,
                generators_irrep=gens,
                basis=basis, eps=eps,
            )

            cov_i = cov_i_q if which == "q" else cov_i_p
            term = W[..., None] * _project_phi_cov(cov_i.astype(np.float32, copy=False), Jinv_i, Finv_i)
            out = term if out is None else (out + term)

        if use_A: _accum(gA, KA, "a")
        if use_B: _accum(gB, KB, "b")

    if out is None:
        phi_attr = "phi" if which == "q" else "phi_model"
        return np.zeros_like(getattr(ai, phi_attr), np.float32)
    return out





# ---------- Sender terms ----------
# OPTIMIZED VERSION of phi_send_steps()
# Drop-in replacement - just copy this function

def phi_send_steps(ctx, agent_i, neighbors, generators_q, generators_p, *, 
                   field: str, fisher_inv_key: str, strategies=("align","gamma")):
    """
    OPTIMIZED: Config fetched once before loop (was 2x per neighbor).
    
    Returns [(agent_j, dphi_j)] where dphi_j is a (*S,3) covector step
    projected with the sender's Fisher inverse / Jacobian inverse.
    """
    which, phi_attr, mu_key, S_key, _, grad_key = _which_meta(field)
    gens = generators_q if field in ("phi","phi_q") else generators_p

    # receiver frame for ALIGN sender term
    E_i, _, _ = _preconds_min(ctx, agent_i, which=("q" if field in ("phi","phi_q") else "p"),
                              fisher_inv_key=fisher_inv_key)

    # ✅ OPTIMIZATION: Get config ONCE for all neighbors (not per-neighbor)
    cfg = get_phi_config(ctx, which)
    eps = cfg['eps']
    kappa = cfg['beta_kappa']
    kap = cfg['gamma_kappa']
    use_A = cfg['use_gamma_A']
    use_B = cfg['use_gamma_B']
    kap_safe = max(kap, eps)  # Precompute this too

    
    out = []
    # gamma maps live on the receiver grid; use agent_i's base shape
    Sshape_recv = np.asarray(
        getattr(agent_i, "mu_q_field" if which in ("q","phi","phi_q") else "mu_p_field")
    ).shape[:-1]

    # Pre-fetch frames/stats needed for γ covectors (pure path)
    Eqi_cache = np.asarray(E_grid(ctx, agent_i, which="q"), np.float64)
    Epi_cache = np.asarray(E_grid(ctx, agent_i, which="p"), np.float64)
    mu_p_i    = AA.get_mu_p(agent_i).astype(np.float64, order="C")
    Sig_p_i   = AA.get_sigma_p(agent_i, sanitize=False).astype(np.float64, order="C")

    for aj in (neighbors or []):
        _, Jinv_j, Finv_j = _preconds_min(ctx, aj, which=which, fisher_inv_key=fisher_inv_key)

        steps = []

        # ---------------- ALIGN sender step ----------------
        if "align" in strategies:
            # ✅ NO cfg call here - use variables from above
            KL1, beta = beta_align_maps(ctx, agent_i, aj, which=which)
            if np.any(beta):
                scale = beta * (1.0 + (KL1 / kappa) * (beta - 1.0))
                Om  = Omega(ctx, agent_i, aj, which=which)
                E_j = E_grid(ctx, aj, which=which)
                exp_neg_phi_j = safe_omega_inv(E_j)
                mu_j_t, _, S_j_t_inv = push_neighbor_stats(aj, S_key, Om, eps)
                phi_j = np.asarray(getattr(aj, phi_attr), np.float32)
                R_all_j = d_exp_exact(phi_j, gens)
                g_s = grad_kl_wrt_phi_j(
                    getattr(agent_i, mu_key), getattr(agent_i, S_key),
                    getattr(aj,    mu_key),   getattr(aj,    S_key),
                    mu_j_t, phi_j, Om, gens, E_i, E_j, mu_j_t, S_j_t_inv, eps,
                    exp_neg_phi_j=exp_neg_phi_j, R_all=R_all_j,
                ).astype(np.float32, copy=False)
                steps.append(scale[...,None] * _project_phi_cov(g_s, Jinv_j, Finv_j))

        # ---------------- GAMMA sender step (pure dispatcher) ----------------
        if "gamma" in strategies:
            # ✅ NO cfg call here - use variables from above
            i_id = int(getattr(agent_i,"id",-1)); j_id = int(getattr(aj,"id",-1))
            gA, KA = ctx.edge.get_gamma(ctx, "A", j_id, i_id, shape=Sshape_recv) if use_A else (None,None)
            gB, KB = ctx.edge.get_gamma(ctx, "B", i_id, j_id, shape=Sshape_recv) if use_B else (None,None)

            # Joint overlap mask on receiver grid (safeguard)
            m_bool, m_vec = joint_masks(ctx, agent_i, aj)
            if not np.any(m_bool):
                pass  # nothing to do for this neighbor
            else:
                m = m_vec[..., 0].astype(np.float32, copy=False)

                # Pre-fetch sender stats + frame for j
                Eqj_cache = np.asarray(E_grid(ctx, aj, which="q"), np.float64)
                mu_q_j    = AA.get_mu_q(aj).astype(np.float64, order="C")
                Sig_q_j   = AA.get_sigma_q(aj, sanitize=False).astype(np.float64, order="C")

                def _add(Wmap, Kmap, basis):
                    if Wmap is None or not np.any(Wmap):
                        return
                    W = np.asarray(Wmap, np.float32) * m
                    if Kmap is not None:
                        K = np.asarray(Kmap, np.float32) * m
                        W = W * (1.0 - K / kap_safe)  # ✅ Use precomputed kap_safe
                    if not np.any(W):
                        return

                    # Pure covector dispatcher: feed frames & stats directly
                    _, cov_jq, _ = grad_gamma_phi_covectors(
                        Eqi=Eqi_cache, Eqj=Eqj_cache, Epi=Epi_cache,
                        mu_q_j=mu_q_j,  Sigma_q_j=Sig_q_j,
                        mu_p_i=mu_p_i,  Sigma_p_i=Sig_p_i,
                        generators_irrep=gens,
                        basis=basis, eps=eps,
                    )
                    steps.append(W[...,None] * _project_phi_cov(cov_jq, Jinv_j, Finv_j))

                if use_A: _add(gA, KA, "a")
                if use_B: _add(gB, KB, "b")

        if steps:
            dphi_j = np.sum(steps, axis=0).astype(np.float32, copy=False)
            out.append((aj, dphi_j))

    return out






# ==================== END MINIMAL φ PIPELINE (DROP-IN) ====================





def build_phi_self_feedback_bucket(
    ctx, agent_i, generators_q, generators_p, *,
    field: str,                 # "phi" or "phi_tilde"
    fisher_inv_key: str,        # "fisher_inv_q" / "fisher_inv_p"
    phi_self_func=None,
    phi_feedback_func=None,
) -> Tuple[np.ndarray, Tuple[float, float]]:
    """
    Returns:
      dphi      : (*S, 3) fp32 gradient contribution for this (self+feedback) term
      (self_n, fb_n) : L1 magnitudes for debug/diagnostics (floats)
    No side-effects.
    """
   
    cfg = get_phi_config_global(ctx)
    eps = cfg['eps']
    tau = cfg['tau']
    alpha = cfg['alpha']
    fbw = cfg['feedback_weight']

    mask3 = mask_hw(agent_i, tau=tau, mode="float3")
    if not np.any(mask3):
        # return zeros and zero diagnostics
        return np.zeros_like(getattr(agent_i, field), np.float32), (0.0, 0.0)

    mu_q,  sigma_q  = AA.get_mu_q(agent_i),  AA.get_sigma_q(agent_i, sanitize=False)
    mu_p,  sigma_p  = AA.get_mu_p(agent_i),  AA.get_sigma_p(agent_i, sanitize=False)
    phi     = AA.get_phi_q(agent_i)
    phi_t   = AA.get_phi_p(agent_i)
    base_phi = phi if field == "phi" else phi_t

    exp_this, exp_other, Jinv, _, G_q, G_p = exp_and_jinv_single(
        ctx, agent_i, field, base_phi, generators_q, generators_p
    )

    Phi_tilde = Phi_cached(ctx, agent_i, kind="p_to_q")
    mu_p_push  = getattr(agent_i, "_mu_p_push",         None)
    A_inv_push = getattr(agent_i, "_Sigma_p_push_inv",  None)
    if (mu_p_push is None) or (A_inv_push is None):
        mu_p_push, _, A_inv_push = push_gaussian(
            mu=mu_p, Sigma=sigma_p, M=Phi_tilde,
            eps=eps, return_inv=True, assume_orthogonal=False
        )
        setattr(agent_i, "_mu_p_push",        mu_p_push.astype(np.float32, copy=False))
        setattr(agent_i, "_Sigma_p_push_inv", A_inv_push.astype(np.float32, copy=False))

    Fi = getattr(agent_i, fisher_inv_key, None)
    Fi = np.eye(base_phi.shape[-1], dtype=np.float32) if Fi is None else np.asarray(Fi, np.float32, order="C")

    total = np.zeros_like(base_phi, dtype=np.float32)
    self_n = 0.0
    fb_n   = 0.0

    if alpha > 0.0 and phi_self_func is not None:
        g_param = phi_self_func(
            mu_q=mu_q, sigma_q=sigma_q,
            mu_p=mu_p, sigma_p=sigma_p,
            Phi_tilde_0=getattr(agent_i, "Phi_tilde_0", None),
            phi=phi, phi_tilde=phi_t,
            generators_q=G_q, generators_p=G_p,
            exp_phi=exp_this if field == "phi" else exp_other,
            exp_phi_tilde=exp_other if field == "phi" else exp_this,
            Phi_tilde=Phi_tilde,
            A_inv_cached=A_inv_push,
            mu_t_cached=mu_p_push,
            eps=eps,
        )
        g_body = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        v_body = np.einsum("...ab,...b->...a", Fi,   g_body,  optimize=True)
        v_param= np.einsum("...ab,...b->...a", Jinv, v_body,  optimize=True)
        contrib = (alpha * v_param * mask3)
        total  += contrib.astype(np.float32, copy=False)
        self_n  = float(np.sum(np.abs(contrib)))

    if fbw > 0.0 and phi_feedback_func is not None:
        g_param = phi_feedback_func(
            mu_p=mu_p, sigma_p=sigma_p,
            mu_q=mu_q, sigma_q=sigma_q,
            Phi_0=getattr(agent_i, "Phi_0", None),
            phi=phi, phi_tilde=phi_t,
            exp_phi=exp_this if field == "phi" else exp_other,
            exp_phi_tilde=exp_other if field == "phi" else exp_this,
            eps=eps,
            generators_q=G_q, generators_p=G_p,
        )
        g_body = np.einsum("...ji,...j->...i", Jinv, g_param, optimize=True)
        v_body = np.einsum("...ab,...b->...a", Fi,   g_body,  optimize=True)
        v_param= np.einsum("...ab,...b->...a", Jinv, v_body,  optimize=True)
        contrib = (fbw * v_param * mask3)
        total  += contrib.astype(np.float32, copy=False)
        fb_n    = float(np.sum(np.abs(contrib)))

    return total.astype(np.float32, copy=False), (self_n, fb_n)



