# -*- coding: utf-8 -*-
"""
μ/Σ Gradient Computation - MINIMAL REFACTOR

This file contains the EXACT SAME mathematics as update_terms_mu_sigma.py,
just organized into cleaner helper functions. No algorithms changed.

CHANGES FROM ORIGINAL:
1. Extracted config reading into _get_mu_sigma_config()
2. Added clear docstrings
3. Zero mathematical changes

PRESERVED:
- All gradient formulas
- All energy computations
- All transport operations
- All numerical behavior
"""

import numpy as np
from core.edge_maps import gamma_maps, beta_align_maps
from core.transport_cache import Omega, Phi_cached
from core.runtime_context import cfg_get
from agents.agent_accessor import AA


from core.numerical_utils import (kl_gaussian, sanitize_sigma,push_gaussian, plain_rule,
                                  softmax_align_rule_receiver, softmax_align_rule_sender)

from updates.gradient_terms import (grad_gamma_mu_sigma_dispatch, _self_and_feedback_grads, 
                                    grad_alignment_energy_source, grad_alignment_energy_target)


from updates.gradient_utils import ( _fiber_keys_from_mode, get_mu_sigma_config, get_phi_config,
                                    iter_overlap_pairs, _accumulate_into_agent,
                                    _drain_inbox_into_dalign, _add_to_inbox)


# ═════════════════════════════════════════════════════════════════════════════
# Pipeline Orchestration (UNCHANGED from original)
# ═════════════════════════════════════════════════════════════════════════════

def _run_mu_sigma_pipeline(
    *,
    ctx,
    agent_i,
    which: str,                 # "q" or "p"
    dmu_self=None, dS_self=None,
    dmu_feedback=None, dS_feedback=None,
    dmu_align=None, dS_align=None,
    dmu_gamma=None, dS_gamma=None,
    dmu_obs=None,  dS_obs=None,   # <<< NEW
):
    
        
    """
    Canonical μ/Σ post-processing and (optionally) accumulation for one fiber.

    Steps:
      1) Sum all provided buckets (treat missing as zeros).
      2) Symmetrize Σ-gradient.
      3) Natural-gradient projection (uses apply_natural_gradient_batch).
      4) Return (delta_mu, delta_S); caller can accumulate.
      
    UNCHANGED FROM ORIGINAL - exact same algorithm.
    """
    
    # Fiber-specific keys
    mu_key  = "mu_q_field"    if which == "q" else "mu_p_field"
    S_key   = "sigma_q_field" if which == "q" else "sigma_p_field"
    
    obs_scale = float(cfg_get(ctx, "obs_scale", 0))
    # Shapes / zeros
    mu_i = np.asarray(getattr(agent_i, mu_key), np.float32)
    
    S    = mu_i.shape[:-1]
    K    = mu_i.shape[-1]

    def _zmu(x): return np.zeros(S + (K,),   np.float32) if x is None else np.asarray(x, np.float32, order="C")
    def _zS (x): return np.zeros(S + (K,K),  np.float32) if x is None else np.asarray(x, np.float32, order="C")

    # 1) sum buckets
    dmu_total = _zmu(dmu_self) + 0*_zmu(dmu_feedback) + _zmu(dmu_align) + _zmu(dmu_gamma) + obs_scale *_zmu(dmu_obs)        # NEW
    dS_total  = _zS (dS_self)  + 0*_zS (dS_feedback)  + _zS (dS_align)  + _zS (dS_gamma) + obs_scale *_zS(dS_obs)    

    # 2) symmetrize
    dS_total = 0.5 * (dS_total + np.swapaxes(dS_total, -1, -2))

    
    # 3) natural projection (correct signature — no Sigma/Sigma_inv kwargs)
    
    
    delta_mu, delta_S = apply_natural_gradient_batch(
        ctx,
        getattr(agent_i, mu_key),
        getattr(agent_i, S_key),
        dmu_total,
        dS_total,
        mask=getattr(agent_i, "mask", None),
        assume_sanitized=True,
        grad_sigma_is_symmetric=True,
        use_float64=True,
    )

    # 4) return to caller; accumulation can be handled outside
    return delta_mu, delta_S


# ═════════════════════════════════════════════════════════════════════════════
# Main Entry Point (REFACTORED to use config helper)
# ═════════════════════════════════════════════════════════════════════════════
def accumulate_mu_sigma_gradient(ctx, agent_i, agents, mode):
    """
    Accumulate natural gradients (μ, Σ) for belief or model.

    Pipeline:
      1) Resolve fiber (which ∈ {"q","p"}) and key names
      2) Push Gaussians across Φ / Φ̃ once
      3) Self + feedback terms
      4) Optional β·ALIGN term (config-gated; can disable for p)
      5) Optional γ-coupling term(s) (config-gated; can disable for p
         and/or choose A vs B style)
      6) Optional observation tether for q
      7) Combine -> natural projection -> accumulate into agent

    Config keys expected from get_mu_sigma_config(ctx):
        eps, tau, alpha, feedback_weight, accumulate_sender_grads
        use_alignment_q / use_alignment_p
        use_gamma_block_q / use_gamma_block_p
        use_gamma_A / use_gamma_B
        freeze_mu_sigma_q / freeze_mu_sigma_p  # NEW
    """
    if ctx is None:
        raise RuntimeError("accumulate_mu_sigma_gradient: ctx required.")

    # ===== 1) config =====
    cfg    = get_mu_sigma_config(ctx)
    eps    = cfg['eps']
    tau    = cfg['tau']
    alpha  = cfg['alpha']
    lambd  = cfg['feedback_weight']
    accum_send_cfg = cfg['accumulate_sender_grads']

    use_align_q  = cfg.get('use_alignment_q',  True)
    use_align_p  = cfg.get('use_alignment_p',  False)
    use_gamma_q  = cfg.get('use_gamma_block_q', False)
    use_gamma_p  = cfg.get('use_gamma_block_p', False)

    use_gamma_A  = cfg.get('use_gamma_A', False)
    use_gamma_B  = cfg.get('use_gamma_B', False)

    which, field, mu_key, S_key, gmu_key, gS_key = _fiber_keys_from_mode(mode)
    # which is "q" or "p"

    # ===== NEW: FREEZE CHECK =====
    freeze_q = cfg.get('freeze_mu_sigma_q', False)
    freeze_p = cfg.get('freeze_mu_sigma_p', False)
    
    if (which == "q" and freeze_q) or (which == "p" and freeze_p):
        # Return zero gradients with correct shapes
        mu_template = np.asarray(getattr(agent_i, mu_key), np.float32)
        S_template  = np.asarray(getattr(agent_i, S_key),  np.float32)
        
        # Still accumulate zero into agent to maintain contract
        _accumulate_into_agent(
            agent_i, gmu_key, gS_key,
            np.zeros_like(mu_template, dtype=np.float32),
            np.zeros_like(S_template, dtype=np.float32)
        )
        
        # Energy still computes (for diagnostics) but gradients are zero
        # Return zero tuple for energy if you want to suppress that too
        return (
            np.zeros_like(mu_template, dtype=np.float32),
            np.zeros_like(S_template, dtype=np.float32),
            (0.0, 0.0)
        )
    # =============================

    # ===== 2) Φ / Φ̃ pushes once =====
    Phi  = Phi_cached(ctx, agent_i, kind="q_to_p")
    Phit = Phi_cached(ctx, agent_i, kind="p_to_q")

    mu_q = getattr(agent_i, "mu_q_field")
    S_q  = getattr(agent_i, "sigma_q_field")
    mu_p = getattr(agent_i, "mu_p_field")
    S_p  = getattr(agent_i, "sigma_p_field")

    mu_q_push, S_q_push, inv_q_push = push_gaussian(
        mu_q, S_q, Phi,
        eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_q_inv", None),
        assume_orthogonal=False,
    )
    mu_p_push, S_p_push, inv_p_push = push_gaussian(
        mu_p, S_p, Phit,
        eps=eps, return_inv=True,
        Sigma_inv=getattr(agent_i, "sigma_p_inv", None),
        assume_orthogonal=False,
    )

    # ===== energy bookkeeping (unchanged) =====
    self_raw, fb_raw = accumulate_self_feedback_energies(
        ctx, agent_i,
        mu_q=mu_q, S_q=S_q,
        mu_p=mu_p, S_p=S_p,
        mu_q_push=mu_q_push, S_q_push=S_q_push,
        mu_p_push=mu_p_push, S_p_push=S_p_push,
    )

    # ===== 3) self + feedback grads =====
    # ===== MODIFIED: Now respects which fiber is being updated =====
    g_self_mu, g_self_S, g_fb_mu, g_fb_S = _self_and_feedback_grads(
        mode,
        mu_q, S_q, mu_p, S_p,
        mu_q_push, S_q_push, inv_q_push,
        mu_p_push, S_p_push, inv_p_push,
        Phi, Phit, eps,
        sigma_q_inv=getattr(agent_i, "sigma_q_inv", None),
        sigma_p_inv=getattr(agent_i, "sigma_p_inv", None),
        mask=getattr(agent_i, "mask", None),
    )
    # Note: _self_and_feedback_grads now only returns gradients for the
    # fiber specified by 'mode', so if mode='belief', these are q-gradients
    # and if mode='model', these are p-gradients

    # ===== 4) β·ALIGN block (config-gated) =====
    want_align = (which == "q" and use_align_q) or (which == "p" and use_align_p)
    if want_align:
        dmu_align, dS_align = _accum_alignment_block_mu_sigma(
            ctx, agent_i, agents,
            which=which,
            mu_key=mu_key, S_key=S_key,
            eps=eps, tau=tau,
            accum_send=accum_send_cfg,
        )
    else:
        # alignment disabled => zeros matching field shapes
        dmu_align = np.zeros_like(getattr(agent_i, mu_key), dtype=np.float32)
        dS_align  = np.zeros_like(getattr(agent_i, S_key),  dtype=np.float32)

    # ===== 5) γ-block(s) (config-gated) =====
    want_gamma = (which == "q" and use_gamma_q) or (which == "p" and use_gamma_p)
    
    if want_gamma:
        dmu_gamma, dS_gamma = _accum_gamma_block_mu_sigma(
            ctx, agent_i, agents,
            which=which,
            mu_key=mu_key, S_key=S_key,
            eps=eps, tau=tau,
            accum_send=accum_send_cfg,
            Phi=Phi, Phit=Phit,
            # tell gamma block which sub-terms to include
            use_gamma_A=use_gamma_A,
            use_gamma_B=use_gamma_B,
        )
    else:
        dmu_gamma = np.zeros_like(getattr(agent_i, mu_key), dtype=np.float32)
        dS_gamma  = np.zeros_like(getattr(agent_i, S_key),  dtype=np.float32)

    # ===== 6) observation tether (belief only) =====
    g_obs_mu = None
    g_obs_S  = None
    if which == "q":
        g_obs_mu, g_obs_S = _obs_grads_for_agent(ctx, agent_i, which="q")

    # ===== 7) combine → natural projection → accumulate =====
    delta_mu, delta_S = _run_mu_sigma_pipeline(
        ctx=ctx, agent_i=agent_i, which=which,
        dmu_self=alpha * g_self_mu,    dS_self=alpha * g_self_S,
        dmu_feedback=lambd * g_fb_mu,  dS_feedback=lambd * g_fb_S,
        dmu_align=dmu_align,           dS_align=dS_align,
        dmu_gamma=dmu_gamma,           dS_gamma=dS_gamma,
        dmu_obs=g_obs_mu,              dS_obs=g_obs_S,
    )

    _accumulate_into_agent(agent_i, gmu_key, gS_key, delta_mu, delta_S)
    return delta_mu, delta_S, (float(self_raw), float(fb_raw))




def _accum_alignment_block_mu_sigma(
    ctx,
    agent_i,
    agents,
    *,
    which: str,             # 'q' or 'p'
    mu_key: str,
    S_key: str,
    eps: float,
    tau: float,
    accum_send: bool,
):
    """
    β-align only. Computes pairwise ALIGN β-weighted μ/Σ gradients for receiver i
    (and enqueues sender j) using the exact softmax product rule with KL1 := ALIGN KL.
    """
    
    kappa = max(float(cfg_get(ctx, f"beta_kappa_{which}", 1.0)), 1e-12)
    # Precompute receiver stats once
    mu_i_arr = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i_arr  = sanitize_sigma(np.asarray(getattr(agent_i, S_key), np.float64), eps=eps)\
                  .astype(np.float32, copy=False)

    dmu_align = np.zeros_like(mu_i_arr, dtype=np.float32)
    dS_align  = np.zeros_like(S_i_arr,  dtype=np.float32)

    Sshape = tuple(mu_i_arr.shape[:-1])
    Ki = int(mu_i_arr.shape[-1])
    gbar_mu_i = np.zeros(Sshape + (Ki,),    np.float32)
    gbar_S_i  = np.zeros(Sshape + (Ki, Ki), np.float32)

    
    
    pairs = []

    for agent_j, overlap in iter_overlap_pairs(agent_i, agents, tau=tau, which=which, mu_key=mu_key, ctx = ctx):
        if not np.any(overlap):
            continue

        KL1_map, beta_map = beta_align_maps(ctx, agent_i, agent_j, which=which)
        
        m        = overlap.astype(np.float32, copy=False)
        beta_ij  = beta_map * m
        KL1      = KL1_map  * m
        if not np.any(beta_ij > 0):
            continue

        Om_align = Omega(ctx, agent_i, agent_j, which=which)

        mu_j_arr = np.asarray(getattr(agent_j, mu_key), np.float32, order="C")
        S_j_arr  = sanitize_sigma(np.asarray(getattr(agent_j, S_key), np.float64), eps=eps)\
                      .astype(np.float32, copy=False)

        mu_j_t, S_j_t, inv_j_t = push_gaussian(
            mu_j_arr, S_j_arr, Om_align, eps=eps, return_inv=True, sanitize_input=False
        )
     
        gmu_align, gS_align = grad_alignment_energy_source(
            mu_i_arr, S_i_arr, mu_j_t, inv_j_t, eps=eps, sigma_i_inv=None, assume_sanitized=True
        )
        
       
        gmu_align_j, gS_align_j = grad_alignment_energy_target(
            mu_i=mu_i_arr, sigma_i=S_i_arr,
            mu_j_t=mu_j_t, sigma_j_t_inv=inv_j_t,
            Omega_ij=Om_align, eps=eps, assume_sanitized=True
        )
        
        # shape guards
        assert beta_ij.shape == KL1.shape
        assert gmu_align.shape[:-1] == KL1.shape
        assert gS_align.shape[:-2] == KL1.shape

        # β-averages for softmax rule
        gbar_mu_i += beta_ij[..., None]       * gmu_align
        gbar_S_i  += beta_ij[..., None, None] * gS_align

        pairs.append(dict(
            j=agent_j, overlap=overlap,
            beta_ij=beta_ij, KL1=KL1,
            gmu_align=gmu_align, gS_align=gS_align,
            gmu_align_j=gmu_align_j, gS_align_j=gS_align_j,
        ))

        
    # second pass: exact softmax product rule
    for P in pairs:
        agent_j     = P["j"]
        overlap     = P["overlap"]
        beta_ij     = P["beta_ij"]
        KL1         = P["KL1"]
        gmu_align   = P["gmu_align"]
        gS_align    = P["gS_align"]
        gmu_align_j = P["gmu_align_j"]
        gS_align_j  = P["gS_align_j"]

       
        

        add_mu_i = softmax_align_rule_receiver(beta_ij, KL1, kappa, gmu_align, gbar_mu_i)
        add_S_i  = softmax_align_rule_receiver(beta_ij, KL1, kappa, gS_align,  gbar_S_i)
        add_mu_j = softmax_align_rule_sender  (beta_ij, KL1, kappa, gmu_align_j)
        add_S_j  = softmax_align_rule_sender  (beta_ij, KL1, kappa, gS_align_j)

        dmu_align[overlap] += add_mu_i[overlap]
        dS_align [overlap] += add_S_i [overlap]
        
        if accum_send:
            _add_to_inbox(agent_j, which, add_mu_j, add_S_j, overlap)
            
    # final guards
    assert np.all(np.isfinite(dmu_align)) and np.all(np.isfinite(dS_align)), "β-align NaN/Inf"
    return dmu_align, dS_align



def _accum_gamma_block_mu_sigma(
    ctx,
    agent_i,
    agents,
    *,
    which: str,             # 'q' or 'p'
    mu_key: str,
    S_key: str,
    eps: float,
    tau: float,
    accum_send: bool,
    Phi=None,
    Phit=None,
    use_gamma_A: bool | None = None,
    use_gamma_B: bool | None = None,
):
    """
    γ-only block. Centralized product rule per *case*:
        ∂(γ KL) = γ * (1 - KL/κ_γ) * ∂KL
    No softmax. Optional per-receiver γ normalization (sum-cap / row-sum).
    """

# WITH THIS:
    cfg = get_phi_config(ctx, which)
    
    if use_gamma_A is None:
        use_gamma_A = cfg['use_gamma_A']
    if use_gamma_B is None:
        use_gamma_B = cfg['use_gamma_B']
    
    kap = max(cfg['gamma_kappa'], 1e-12)
    
    # TODO: Add these to gradient_config.py if important:
    use_gamma_norm  = bool(cfg_get(ctx, "normalize_gamma", False))
    gamma_norm_mode = str(cfg_get(ctx, "gamma_norm_mode", "sumcap")).lower()
    gamma_sumcap    = float(cfg_get(ctx, "gamma_sumcap", 1.0))

   

    kap = max(float(cfg_get(ctx, f"kappa_gamma_{which}", 1.0)), 1e-12)

    # ---- init accumulators (receiver i) ----
    mu_i_arr0 = np.asarray(getattr(agent_i, mu_key), np.float32, order="C")
    S_i_arr0  = np.asarray(getattr(agent_i, S_key),  np.float32, order="C")
    dmu_G = np.zeros_like(mu_i_arr0, dtype=np.float32)
    dS_G  = np.zeros_like(S_i_arr0,  dtype=np.float32)

    # ---- gather pass (collect per-neighbor, per-case entries) ----
    entries_A = []   # list of dicts with keys: w, K, mu_rec, S_rec, mu_send, S_send, overlap, agent_j
    entries_B = []

    # Pre-cached receiver fields for dispatcher
    Omega_q = {}  # cache Ω_ij per neighbor
    for agent_j, overlap in iter_overlap_pairs(agent_i, agents, tau=tau, which=which, mu_key=mu_key, ctx=ctx):
        if not np.any(overlap):
            continue

        Om_q_ij = Omega_q.get(id(agent_j))
        if Om_q_ij is None:
            Om_q_ij = Omega(ctx, agent_i, agent_j, which="q")
            Omega_q[id(agent_j)] = Om_q_ij

        gam = gamma_maps(ctx, agent_i, agent_j)  # {"A": (KL_A, γ_A), "B": (KL_B, γ_B)}
        if not gam:
            continue

        # Case A
        if use_gamma_A and ("A" in gam):
            KLc, Gc = gam["A"]  # (*S,), (*S,)
            outA = grad_gamma_mu_sigma_dispatch(
                ctx, agent_i, agent_j,
                basis="a",
                Omega_ij=Om_q_ij,
                Phi_i=Phi,
                Phi_tilde_i=Phit,
                eps=eps,
            )
            m = overlap.astype(np.float32, copy=False)
            w = (np.asarray(Gc,  np.float32) * m).astype(np.float32, copy=False)
            K = (np.asarray(KLc, np.float32) * m).astype(np.float32, copy=False)

           
            entries_A.append(dict(
                w=w, K=K, overlap=overlap, agent_j=agent_j,
                mu_rec=np.asarray(outA["mu_rec"],  np.float32, order="C"),
                S_rec =np.asarray(outA["S_rec"],   np.float32, order="C"),
                mu_send=np.asarray(outA["mu_send"],np.float32, order="C"),
                S_send =np.asarray(outA["S_send"], np.float32, order="C"),
            ))

        # Case B
        if use_gamma_B and ("B" in gam):
            KLc, Gc = gam["B"]
            outB = grad_gamma_mu_sigma_dispatch(
                ctx, agent_i, agent_j,
                basis="b",
                Omega_ij=Om_q_ij,
                Phi_i=Phi,
                Phi_tilde_i=Phit,
                eps=eps,
            )
            m = overlap.astype(np.float32, copy=False)
            w = (np.asarray(Gc,  np.float32) * m).astype(np.float32, copy=False)
            K = (np.asarray(KLc, np.float32) * m).astype(np.float32, copy=False)

          
            entries_B.append(dict(
                w=w, K=K, overlap=overlap, agent_j=agent_j,
                mu_rec=np.asarray(outB["mu_rec"],  np.float32, order="C"),
                S_rec =np.asarray(outB["S_rec"],   np.float32, order="C"),
                mu_send=np.asarray(outB["mu_send"],np.float32, order="C"),
                S_send =np.asarray(outB["S_send"], np.float32, order="C"),
            ))

    # ---- optional per-receiver γ normalization (per case separately) ----
    def _normalize_entries(entries, mode, cap_val):
        if (not use_gamma_norm) or (not entries):
            return [e["w"] for e in entries]
        # Stack all w maps: shape (*S, J)
        W = np.stack([e["w"] for e in entries], axis=-1)
        Ssum = np.sum(W, axis=-1, keepdims=True)  # (*S,1)
        eps_ = 1e-6
        if mode == "rowsum":
            Wn = W / (Ssum + eps_)
        else:  # "sumcap" default
            scale = np.minimum(1.0, cap_val / (Ssum + eps_))
            Wn = W * scale
        # split back per-entry
        return [Wn[..., j] for j in range(Wn.shape[-1])]

    wA_norm = _normalize_entries(entries_A, gamma_norm_mode, gamma_sumcap)
    wB_norm = _normalize_entries(entries_B, gamma_norm_mode, gamma_sumcap)
    # ---- accumulate pass (apply product rule per entry with normalized w) ----
    def _accumulate(entries, w_norm_list):
        nonlocal dmu_G, dS_G
        for e, w_norm in zip(entries, w_norm_list):
            w = np.asarray(w_norm, np.float32, order="C")
            K = np.asarray(e["K"], np.float32, order="C")

            add_mu_i = plain_rule(w, K, kap, e["mu_rec"])
            add_S_i  = plain_rule(w, K, kap, e["S_rec"])
            dmu_G += add_mu_i
            dS_G  += add_S_i

            if accum_send:
                add_mu_j = plain_rule(w, K, kap, e["mu_send"])
                add_S_j  = plain_rule(w, K, kap, e["S_send"])
                _add_to_inbox(e["agent_j"], which, add_mu_j, add_S_j, e["overlap"])

    _accumulate(entries_A, wA_norm)
    _accumulate(entries_B, wB_norm)

    # Optional: drain sender inbox into d_align buckets here
    if accum_send:
        dmu_G, dS_G = _drain_inbox_into_dalign(agent_i, which, dmu_G, dS_G)

    # Final sanity
    assert np.all(np.isfinite(dmu_G)) and np.all(np.isfinite(dS_G)), "γ NaN/Inf"
    return dmu_G, dS_G




def _accum_gamma_mu_sigma_for_pair(
    ctx,
    agent_i, agent_j,
    *,
    mu_key: str,
    S_key: str,
    overlap_mask: np.ndarray,
    eps: float,
    Phi_i,            # Φ_i (Q→P)
    Phi_tilde_i,      # Φ̃_i (P→Q) (kept for signature symmetry)
    Omega_q_ij,       # Ω^q_ij (reused; no recompute)
):
    """
    Return *raw* ∂KL tensors (masked to overlap) for γ Cases A/B, summed:
      (g_mu_i_raw, g_S_i_raw, g_mu_j_raw, g_S_j_raw, {"A": KL_A, "B": KL_B})
    Weighting by γ and (1 - KL/κ) is applied by the caller.
    """

    i_id = AA.get_id(agent_i)
    j_id = int(getattr(agent_j, "id", -1))

    Sshape = tuple(overlap_mask.shape)
    Ki = int(getattr(agent_i, mu_key).shape[-1])
    Kj = int(getattr(agent_j, mu_key).shape[-1])

    g_mu_i = np.zeros(Sshape + (Ki,),    np.float32)
    g_S_i  = np.zeros(Sshape + (Ki, Ki), np.float32)
    g_mu_j = np.zeros(Sshape + (Kj,),    np.float32)
    g_S_j  = np.zeros(Sshape + (Kj, Kj), np.float32)

    if not np.any(overlap_mask):
        return g_mu_i, g_S_i, g_mu_j, g_S_j, {}

    m = overlap_mask.astype(np.float32, copy=False)

    # --- Use EdgeMaps: always returns arrays (zeros if missing) ---
    # Keys are (case, i_id, j_id) with i <- j
    gA_map, KL_A = ctx.edge.get_gamma(ctx, "A", i_id, j_id, shape=Sshape)
    gB_map, KL_B = ctx.edge.get_gamma(ctx, "B", i_id, j_id, shape=Sshape)
    
    # --- Case A raw grads (FIX: pass Phi_tilde_i) ---
    if np.any(gA_map) or np.any(KL_A):
        outA = grad_gamma_mu_sigma_dispatch(
            ctx, agent_i, agent_j,
            basis="a",
            Omega_ij=Omega_q_ij,
            Phi_tilde_i=Phi_tilde_i,   # <-- was missing
            eps=eps,
        )
        g_mu_i += m[..., None]       * np.asarray(outA["mu_rec"],  np.float32)
        g_S_i  += m[..., None, None] * np.asarray(outA["S_rec"],   np.float32)
        g_mu_j += m[..., None]       * np.asarray(outA["mu_send"], np.float32)
        g_S_j  += m[..., None, None] * np.asarray(outA["S_send"],  np.float32)


    # Case B raw grads
    if np.any(gB_map) or np.any(KL_B):
        outB = grad_gamma_mu_sigma_dispatch(
            ctx, agent_i, agent_j,
            basis="b",
            Omega_ij=Omega_q_ij,
            Phi_i=Phi_i,
            eps=eps,
        )
        g_mu_i += m[..., None]       * np.asarray(outB["mu_rec"],  np.float32)
        g_S_i  += m[..., None, None] * np.asarray(outB["S_rec"],   np.float32)
        g_mu_j += m[..., None]       * np.asarray(outB["mu_send"], np.float32)
        g_S_j  += m[..., None, None] * np.asarray(outB["S_send"],  np.float32)

    KLs = {}
    if np.any(KL_A): KLs["A"] = KL_A.astype(np.float32, copy=False)
    if np.any(KL_B): KLs["B"] = KL_B.astype(np.float32, copy=False)

    return g_mu_i, g_S_i, g_mu_j, g_S_j, KLs





# --- Self / Feedback energy accumulation (shared with diagnostics) ---


def accumulate_self_feedback_energies(
    ctx,
    agent_i,
    *,
    mu_q, S_q,
    mu_p, S_p,
    mu_q_push, S_q_push,
    mu_p_push, S_p_push,
):
    """
    Returns (self_raw, feedback_raw) as plain floats.
    No side effects here; the master will aggregate.
    """
    eps = float(cfg_get(ctx, "eps", 1e-8))
    tau = float(cfg_get(ctx, "support_tau", 1e-6))
    fb = float(cfg_get(ctx, "feedback_weight", 0))
    
    m  = np.asarray(getattr(agent_i, "mask", 1.0), np.float32)
    mm = (m > tau) if (m.dtype != bool) else m
    if not np.any(mm):
        return 0.0, 0.0

    μq  = np.asarray(mu_q[mm],        np.float64, order="C")
    Σq  = sanitize_sigma(np.asarray(S_q[mm],      np.float64, order="C"), eps=eps)
    μp  = np.asarray(mu_p[mm],        np.float64, order="C")
    Σp  = sanitize_sigma(np.asarray(S_p[mm],      np.float64, order="C"), eps=eps)
    μqʹ = np.asarray(mu_q_push[mm],   np.float64, order="C")
    Σqʹ = sanitize_sigma(np.asarray(S_q_push[mm], np.float64, order="C"), eps=eps)
    μpʹ = np.asarray(mu_p_push[mm],   np.float64, order="C")
    Σpʹ = sanitize_sigma(np.asarray(S_p_push[mm], np.float64, order="C"), eps=eps)

    self_px     = kl_gaussian(μq, Σq, μpʹ, Σpʹ, eps=eps)   # KL(q || p')
    feedback_px = kl_gaussian(μp, Σp, μqʹ, Σqʹ, eps=eps)   # KL(p || q')

    self_raw = float(np.sum(self_px))
    fb_raw   = float(np.sum(feedback_px))
   
    return self_raw, fb*fb_raw









def apply_natural_gradient_batch(
    ctx,
    mu_field,
    sigma_field,
    grad_mu_field,
    grad_sigma_field,
    mask=None,
    *,
    use_float64: bool = True,
    assume_sanitized: bool = True,
    grad_sigma_is_symmetric: bool = False,
    assert_finite: bool = False,
):
    """
    Vectorized natural gradient for Gaussian fields on an N-D periodic grid:
        δμ = -Σ ∇_μ L
        δΣ = -2 Σ sym(∇_Σ L) Σ

    Inputs:
      mu_field          : (*S, K)
      sigma_field       : (*S, K, K)   [SPD]
      grad_mu_field     : (*S, K)
      grad_sigma_field  : (*S, K, K)
      mask (optional)   : (*S,) bool or float weights

    Returns:
      delta_mu          : (*S, K)
      delta_sigma       : (*S, K, K)
    """
    import numpy as np
    from core.runtime_context import cfg_get

    # ---- config ----
    eps         = float(cfg_get(ctx, "eps", 1e-10))
    support_tau = float(cfg_get(ctx, "support_tau", 1e-6))
    dtype_work  = np.float64 if use_float64 else np.float32
    dtype_out   = np.float32 if not use_float64 else dtype_work

    # ---- infer spatial shape S, fiber dim K ----
    mu = np.asarray(mu_field)
    Sig = np.asarray(sigma_field)
    gmu = np.asarray(grad_mu_field)
    gSig = np.asarray(grad_sigma_field)

    if mu.ndim < 2 or Sig.ndim < 3:
        raise ValueError(f"Bad shapes: mu {mu.shape}, Sigma {Sig.shape}")

    S = mu.shape[:-1]               # *S
    K = mu.shape[-1]
    if Sig.shape[:-2] != S or Sig.shape[-2:] != (K, K):
        raise ValueError(f"sigma_field shape {Sig.shape} incompatible with mu_field {mu.shape}")

    # ---- flatten spatial for batched einsum ----
    N = int(np.prod(S, dtype=int))
    mu  = mu.astype(dtype_work, copy=False).reshape(N, K)
    Sig = Sig.astype(dtype_work, copy=False).reshape(N, K, K)
    gmu  = gmu.astype(dtype_work, copy=False).reshape(N, K)
    gSig = gSig.astype(dtype_work, copy=False).reshape(N, K, K)

    # ---- SPD sanitize Σ and symmetrize ∇Σ ----
    if not assume_sanitized:
        Sig = sanitize_sigma(Sig, eps=eps)  # must return symmetric SPD in dtype_work
    if not grad_sigma_is_symmetric:
        gSig = 0.5 * (gSig + np.swapaxes(gSig, -1, -2))

    # ---- natural steps ----
    # δμ = -Σ ∇_μ
    dmu = -np.einsum("nik,nk->ni", Sig, gmu, optimize=True)
    # δΣ = -2 Σ sym(∇_Σ) Σ
    tmp =  np.einsum("nij,njk->nik", Sig, gSig, optimize=True)
    dS  = -2.0 * np.einsum("nij,njk->nik", tmp, Sig, optimize=True)
    dS  = 0.5 * (dS + np.swapaxes(dS, -1, -2))  # symmetry guard

    # ---- mask / weights ----
    if mask is not None:
        m = np.asarray(mask)

        m_flat = m.reshape(N)
        if m.dtype == bool:
            active = m_flat
            wts = None
        else:
            wts = m_flat.astype(dtype_work, copy=False)
            active = wts > support_tau
            # soft weights
            dmu *= wts[:, None]
            dS  *= wts[:, None, None]

        # zero outside support
        if not np.all(active):
            ia = ~active
            dmu[ia] = 0.0
            dS[ia]  = 0.0


    if assert_finite:
        if not (np.isfinite(dmu).all() and np.isfinite(dS).all()):
            raise FloatingPointError("Nonfinite natural gradient (μ or Σ).")

    # ---- restore shapes / cast ----
    return (
        dmu.reshape(S + (K,)).astype(dtype_out, copy=False),
        dS.reshape(S + (K, K)).astype(dtype_out, copy=False),
    )



def _obs_grads_for_agent(ctx, agent_i, which: str):
    import numpy as np, os, sys
    

    def dprint(msg):
        sys.stdout.write(f"[pid %s] %s\n" % (os.getpid(), msg))
        sys.stdout.flush()

    # ---------- guard ----------
    has_x   = hasattr(agent_i, "x_obs")
    has_W   = getattr(ctx, "W_obs", None) is not None
    has_Lam = getattr(ctx, "Lambda_obs", None) is not None

    if not has_x:   dprint("no x_obs on agent")
    if not has_W:   dprint("no W_obs on ctx")
    if not has_Lam: dprint("no Lambda_obs on ctx")

    if (not has_x) or (not has_W) or (not has_Lam):
        # graceful no-op grad
        if which == "q":
            mu_template = np.asarray(agent_i.mu_q_field, np.float32)
            S_template  = np.asarray(agent_i.sigma_q_field, np.float32)
        else:
            mu_template = np.asarray(agent_i.mu_p_field, np.float32)
            S_template  = np.asarray(agent_i.sigma_p_field, np.float32)

        return (np.zeros_like(mu_template, dtype=np.float32),
                np.zeros_like(S_template, dtype=np.float32))

    # ---------- pull fields ----------
    if which == "q":
        mu    = np.asarray(agent_i.mu_q_field,    np.float32)  # (*S, K_q)
        Sigma = np.asarray(agent_i.sigma_q_field, np.float32)  # (*S, K_q, K_q)
    else:
        mu    = np.asarray(agent_i.mu_p_field,    np.float32)  # (*S, K_p)
        Sigma = np.asarray(agent_i.sigma_p_field, np.float32)  # (*S, K_p, K_p)

    x_obs = np.asarray(agent_i.x_obs, np.float32)        # (*S, D_x)
    W     = np.asarray(ctx.W_obs, np.float32)            # (D_x, K_q)
    Lam_raw = np.asarray(ctx.Lambda_obs, np.float32)     # (D_x, D_x)

    # force precision SPD and well-conditioned
    Lam = sanitize_sigma(Lam_raw, debug=False)           # (D_x, D_x)

    # ========== IMPORTANT SHAPE ASSERTION ==========
    K_latent = mu.shape[-1]
    if W.shape[1] != K_latent:
        # We don't have a sensor model for this latent space. Return zeros.
        Sshape = Sigma.shape[:-2]
        zero_mu = np.zeros_like(mu, dtype=np.float32)
        zero_S  = np.zeros(Sshape + (K_latent, K_latent), dtype=np.float32)
        return zero_mu, zero_S
    # ===============================================

    # ---------- predicted observation y_pred = W μ ----------
    y_pred = np.einsum("dk,...k->...d", W, mu, optimize=True)  # (*S, D_x)

    # residual
    r = x_obs - y_pred                                         # (*S, D_x)

    # ---------- grad_mu_obs = - W^T (Λ r) ----------
    tmp = np.einsum("ab,...b->...a", Lam, r, optimize=True)    # (*S, D_x)
    grad_mu_obs = -np.einsum("ba,...b->...a", W, tmp, optimize=True)  # (*S, K_q)

    # ---------- grad_Sigma_obs = 0.5 * (W^T Λ W), broadcast ----------
    #
    # A = Λ W            (D_x, D_x) @ (D_x, K_q) -> (D_x, K_q)
    A = Lam @ W                        # (D_x, K_q)

    # G = W^T A          (K_q, D_x) @ (D_x, K_q) -> (K_q, K_q)
    G = W.T @ A                        # (K_q, K_q)

    # Symmetrize to avoid fp32 junk
    G = 0.5 * (G + G.T)

    grad_Sigma_single = 0.5 * G        # (K_q, K_q)

    # Broadcast across spatial sites, to match Sigma shape (*S, K_q, K_q)
    Sshape = Sigma.shape[:-2]          # (*S,)
    grad_Sigma_obs = np.broadcast_to(
        grad_Sigma_single,
        Sshape + grad_Sigma_single.shape
    ).astype(np.float32, copy=False)

    return grad_mu_obs, grad_Sigma_obs





def q_obs_grads_for_agent(ctx, agent_i, which: str):
    import numpy as np, os, sys
    
    def dprint(msg):
        sys.stdout.write(f"[pid {os.getpid()}] {msg}\n")
        sys.stdout.flush()

    #dprint(f"[_obs_grads_for_agent] start agent={getattr(agent_i, 'id', '?')} which={which}")
    
    if not hasattr(agent_i, "x_obs"):
        dprint("no x_obs on agent")
    if getattr(ctx, "W_obs", None) is None:
        dprint("no W_obs on ctx")
    if getattr(ctx, "Lambda_obs", None) is None:
        dprint("no Lambda_obs on ctx")

    # ... (your same body)
    

    # ---------- safety guard so workers don't hard-crash ----------
    if (not hasattr(agent_i, "x_obs")
        or getattr(ctx, "W_obs", None) is None
        or getattr(ctx, "Lambda_obs", None) is None):

        if which == "q":
            mu_template = np.asarray(agent_i.mu_q_field, np.float32)
            S_template  = np.asarray(agent_i.sigma_q_field, np.float32)
        else:
            mu_template = np.asarray(agent_i.mu_p_field, np.float32)
            S_template  = np.asarray(agent_i.sigma_p_field, np.float32)

        return (np.zeros_like(mu_template, dtype=np.float32),
                np.zeros_like(S_template, dtype=np.float32))

    # ---------- pull fields ----------
    if which == "q":
        mu = np.asarray(agent_i.mu_q_field, np.float32)        # (*S, K)
        Sigma = np.asarray(agent_i.sigma_q_field, np.float32)  # (*S, K, K)
    else:
        mu = np.asarray(agent_i.mu_p_field, np.float32)
        Sigma = np.asarray(agent_i.sigma_p_field, np.float32)

    x_obs = np.asarray(agent_i.x_obs, np.float32)             # (*S, D_x)
    W     = np.asarray(ctx.W_obs, np.float32)                 # (D_x, K)
    Lam   = np.asarray(ctx.Lambda_obs, np.float32)            # (D_x, D_x)

    # ---------- predicted observation y_pred = W μ ----------
    # y_pred shape: (*S, D_x)
    y_pred = np.einsum("dk,...k->...d", W, mu, optimize=True)

    # residual r = x_obs - y_pred  (shape: *S, D_x)
    r = x_obs - y_pred

    # ---------- grad_mu_obs = - W^T (Λ r) ----------
    #
    # tmp = Λ r
    # Lam: (D_x, D_x)
    # r:   (*S, D_x)
    # tmp: (*S, D_x)
    tmp = np.einsum("ab,...b->...a", Lam, r, optimize=True)

    # grad_mu_obs = - W^T tmp
    # W:        (D_x, K)
    # tmp:      (*S, D_x)
    # result:   (*S, K)
    grad_mu_obs = -np.einsum("ba,...b->...a", W, tmp, optimize=True)

    # ---------- grad_Sigma_obs = 0.5 * (W^T Λ W), broadcast ----------
    #
    # A = Λ W            (D_x, D_x) @ (D_x, K) -> (D_x, K)
    A = Lam @ W                        # (D_x, K)

    # G = W^T A          (K, D_x) @ (D_x, K) -> (K, K)
    G = W.T @ A                        # (K, K)

    # make symmetric just in case of numeric noise
    G = 0.5 * (G + G.T)                # (K, K)

    grad_Sigma_single = 0.5 * G        # (K, K)

    # broadcast over spatial sites
    Sshape = Sigma.shape[:-2]          # (*S)
    grad_Sigma_obs = np.broadcast_to(
        grad_Sigma_single,
        Sshape + grad_Sigma_single.shape
    ).astype(np.float32, copy=False)   # (*S, K, K)

    
    return grad_mu_obs, grad_Sigma_obs





