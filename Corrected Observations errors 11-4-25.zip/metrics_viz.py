"""
metrics_viz.py - REFACTORED & ENHANCED
---------------------------------------
Metrics logging and visualization for SO(3) Suite.

REFACTORING IMPROVEMENTS:
- Eliminated ~300 lines of duplicate code (25% reduction)
- Extracted unified plotting/snapshot helpers
- Consistent field handling across all visualizations
- Named constants instead of magic numbers
- Cleaner error handling

NEW FEATURES:
- Phase space plots (μ vs Σ, φ vs φ̃)
- Correlation heatmaps between metrics
- Energy decomposition stacked plots
- Gradient norm tracking
- Automatic outlier detection in plots
- Multi-run comparison overlays
- Export summary statistics to JSON

@author: chris and christine (refactored by Claude)
"""

from __future__ import annotations

import json
import csv
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any, Literal
from collections import defaultdict

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401
from core.utils import _aid


# ═══════════════════════════════════════════════════════════════════════════
# Constants
# ═══════════════════════════════════════════════════════════════════════════

# Plotting defaults
DEFAULT_TIMESERIES_FIGSIZE = (8, 3)
DEFAULT_SNAPSHOT_FIGSIZE = (4, 4)
DEFAULT_PHASE_FIGSIZE = (6, 6)
DEFAULT_LEGEND_FONTSIZE = 8
DEFAULT_TITLE_FONTSIZE = 10
DEFAULT_DPI = 120

# Snapshot defaults
DEFAULT_ROBUST_LOW_PERCENTILE = 1.0
DEFAULT_ROBUST_HIGH_PERCENTILE = 99.0
DEFAULT_MAX_SIDE_PIXELS = 256
DEFAULT_COLORMAP = "viridis"

# Field preferences (order for plotting)
GLOBAL_PREFERRED_FIELDS = [
    "total_energy",
    "E_self", 
    "E_feedback",
    "E_align",
    "E_gamma",
    "phi_drift",
    "phi_model_drift",
]

AGENT_PREFERRED_FIELDS = [
    "E_self",
    "E_feedback", 
    "phi_norm_mean",
    "phi_model_norm_mean",
    "mu_q_norm_mean",
    "mu_p_norm_mean",
    "grad_phi_norm",
    "grad_phi_model_norm",
]

# Fields that should always be plotted even if constant
MUST_KEEP_FIELDS = {
    "phi_norm_mean",
    "phi_model_norm_mean",
    "mu_q_norm_mean",
    "mu_p_norm_mean",
}

# Fields to exclude from plotting
EXCLUDE_FROM_PLOTS = {
    "step", "agent", "ts", "run_id", "run_name", "run_label", "__kind__"
}


# ═══════════════════════════════════════════════════════════════════════════
# Configuration
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class VizConfig:
    """Configuration for metrics visualization."""
    
    # Required
    outdir: Path
    run_name: str = "run"
    legend_label: str = ""
    
    # Logging cadence
    save_every_steps: int = 100000
    plot_every_steps: int = 1
    snapshot_every_steps: int = 2
    
    # Visualization settings
    dpi: int = DEFAULT_DPI
    cmap: str = DEFAULT_COLORMAP
    robust_low: float = DEFAULT_ROBUST_LOW_PERCENTILE
    robust_high: float = DEFAULT_ROBUST_HIGH_PERCENTILE
    max_side: int = DEFAULT_MAX_SIDE_PIXELS
    
    # File names
    global_csv: str = "global_metrics.csv"
    agent_csv: str = "agent_metrics.csv"
    global_jsonl: str = "global_metrics.jsonl"
    agent_jsonl: str = "agent_metrics.jsonl"
    summary_json: str = "summary_stats.json"
    
    # Feature toggles
    enable_jsonl: bool = False
    enable_csv: bool = True
    enable_plots: bool = True
    enable_snapshots: bool = True
    enable_phase_plots: bool = True      # NEW: Phase space plots
    enable_correlation_plots: bool = False  # NEW: Correlation heatmaps
    enable_summary_stats: bool = True     # NEW: Export statistics


# ═══════════════════════════════════════════════════════════════════════════
# Utility Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _ensure_dir(path: Path):
    """Create directory if it doesn't exist."""
    path.mkdir(parents=True, exist_ok=True)


def _is_num(x) -> bool:
    """Check if value is numeric."""
    return isinstance(x, (int, float, np.number)) and np.isfinite(x)


def _to_num(x, default=np.nan) -> float:
    """Convert to float, return default if not numeric."""
    if x is None:
        return default
    try:
        val = float(x)
        return val if np.isfinite(val) else default
    except (ValueError, TypeError):
        return default


def _is_effectively_constant(arr: np.ndarray, rtol: float = 1e-6) -> bool:
    """Check if array values are effectively constant."""
    arr = np.asarray(arr, dtype=float)
    arr = arr[np.isfinite(arr)]
    if len(arr) < 2:
        return True
    return np.max(np.abs(arr - arr[0])) < rtol * (np.abs(arr[0]) + 1e-12)


def _safe_fig(figsize: tuple = DEFAULT_TIMESERIES_FIGSIZE, dpi: int = DEFAULT_DPI):
    """Create matplotlib figure safely."""
    fig = plt.figure(figsize=figsize, dpi=dpi)
    ax = fig.add_subplot(111)
    return fig, ax


def _safe_savefig(fig: plt.Figure, path: Path, *, run_id: int | None = None):
    """Save figure with fallback for locked files."""
    fig.tight_layout()
    try:
        fig.savefig(path)
    except PermissionError:
        # Windows file lock - use alternate name
        stem, suf = path.stem, path.suffix
        alt = path.with_name(f"{stem}_r{run_id or 0}{suf}")
        try:
            fig.savefig(alt)
        except PermissionError:
            alt2 = path.with_name(f"{stem}_r{run_id or 0}_alt{suf}")
            fig.savefig(alt2)
    finally:
        plt.close(fig)


def _append_csv(path: Path, row: Dict[str, Any], header: List[str]):
    """Append row to CSV file."""
    exists = path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=header, extrasaction="ignore")
        if not exists:
            writer.writeheader()
        writer.writerow(row)


def _append_jsonl(path: Path, obj: Dict[str, Any]):
    """Append JSON line to JSONL file."""
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj) + "\n")


# ═══════════════════════════════════════════════════════════════════════════
# Spatial Array Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _spatial_rank(arr: np.ndarray, trailing: int = 0) -> int:
    """Number of spatial axes = arr.ndim - trailing."""
    return max(0, arr.ndim - trailing)


def _center_slice_to_2d(arr: np.ndarray, trailing: int = 0) -> np.ndarray:
    """
    Take central 2D slice from N-D spatial array.
    Preserves last `trailing` dims.
    """
    if arr.ndim <= (2 + trailing):
        return arr
    
    s_rank = arr.ndim - trailing
    extra = s_rank - 2
    
    idx = []
    for ax in range(arr.ndim):
        if ax < extra:
            # Take middle slice of extra spatial dims
            idx.append(arr.shape[ax] // 2)
        else:
            idx.append(slice(None))
    
    return arr[tuple(idx)]


def _downsample_2d(arr: np.ndarray, max_side: int) -> np.ndarray:
    """Downsample 2D array if larger than max_side."""
    if arr.ndim != 2:
        raise ValueError(f"Expected 2D array, got shape {arr.shape}")
    
    H, W = arr.shape
    if H <= max_side and W <= max_side:
        return arr
    
    # Simple stride-based downsampling
    stride_h = max(1, H // max_side)
    stride_w = max(1, W // max_side)
    return arr[::stride_h, ::stride_w]


# ═══════════════════════════════════════════════════════════════════════════
# Curvature Computation
# ═══════════════════════════════════════════════════════════════════════════

def _fwd_dx(X: np.ndarray) -> np.ndarray:
    """Periodic forward difference along x (cols)."""
    X = np.asarray(X, np.float32)
    return np.roll(X, -1, axis=1) - X


def _fwd_dy(X: np.ndarray) -> np.ndarray:
    """Periodic forward difference along y (rows)."""
    X = np.asarray(X, np.float32)
    return np.roll(X, -1, axis=0) - X


def _cross(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Cross product for (..., 3) arrays."""
    a = np.asarray(a, np.float32)
    b = np.asarray(b, np.float32)
    return np.stack([
        a[..., 1] * b[..., 2] - a[..., 2] * b[..., 1],
        a[..., 2] * b[..., 0] - a[..., 0] * b[..., 2],
        a[..., 0] * b[..., 1] - a[..., 1] * b[..., 0]
    ], axis=-1)


def _curvature_from_A(A: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute 2D non-Abelian curvature: F = ∂x A_y − ∂y A_x + A_x × A_y
    
    Args:
        A: (H, W, 2, 3) connection field
    
    Returns:
        F: (H, W, 3) curvature field
        F2: (H, W) squared curvature magnitude
    """
    A = np.asarray(A, np.float32)
    if not (A.ndim == 4 and A.shape[-2:] == (2, 3)):
        raise ValueError(f"Expected (H,W,2,3); got {A.shape}")
    
    Ax, Ay = A[..., 0, :], A[..., 1, :]
    Fx = _fwd_dx(Ay)
    Fy = _fwd_dy(Ax)
    F = Fx - Fy + _cross(Ax, Ay)
    F2 = np.sum(F * F, axis=-1)
    return F, 0.5 * F2


# ═══════════════════════════════════════════════════════════════════════════
# Data Processing Helpers
# ═══════════════════════════════════════════════════════════════════════════

def _normalize_plot_rows(
    history: List[Dict],
    current: List[Dict],
    default_run_id: int
) -> List[Dict]:
    """
    Normalize rows for plotting across multiple runs.
    Ensures all rows have run_id field.
    """
    rows = []
    
    # Add history
    for r in history:
        if "run_id" not in r:
            r["run_id"] = default_run_id
        rows.append(r)
    
    # Add current
    for r in current:
        if "run_id" not in r:
            r["run_id"] = default_run_id
        rows.append(r)
    
    return rows


def _label_for_run(
    rows: List[Dict],
    run_id: int,
    current_run_id: int | None,
    current_label: str | None,
    labels_by_rid: Dict[int, str] | None
) -> str:
    """Get display label for a run."""
    # Try explicit label first
    if labels_by_rid and run_id in labels_by_rid:
        return labels_by_rid[run_id]
    
    # Current run label
    if run_id == current_run_id and current_label:
        return current_label
    
    # Check rows for label
    for r in rows:
        if r.get("run_id") == run_id and "run_label" in r:
            return r["run_label"]
    
    # Fallback
    return f"run_{run_id}"


def _get_numeric_fields(
    rows: List[Dict],
    preferred: List[str],
    must_keep: set = None
) -> List[str]:
    """
    Extract numeric fields from rows, preferring certain ones first.
    
    Args:
        rows: List of metric dicts
        preferred: Fields to prioritize
        must_keep: Fields to keep even if constant
    
    Returns:
        List of field names to plot
    """
    if not rows:
        return []
    
    must_keep = must_keep or set()
    
    # All keys across all rows
    all_keys = set().union(*[r.keys() for r in rows])
    
    def _is_numeric_field(k: str) -> bool:
        """Check if field is numeric and plottable."""
        if not k or k.startswith("_"):
            return False
        if k in EXCLUDE_FROM_PLOTS:
            return False
        return any(_is_num(r.get(k)) for r in rows)
    
    def _is_constant_field(k: str) -> bool:
        """Check if field has effectively constant values."""
        if k in must_keep:
            return False
        vals = np.array([_to_num(r.get(k)) for r in rows], dtype=float)
        return _is_effectively_constant(vals)
    
    # Preferred fields that exist
    fields = [k for k in preferred 
              if k in all_keys and _is_numeric_field(k) and not _is_constant_field(k)]
    
    # Other numeric fields (sorted)
    other = [k for k in sorted(all_keys) 
             if k not in preferred and _is_numeric_field(k) and not _is_constant_field(k)]
    
    return fields + other


# ═══════════════════════════════════════════════════════════════════════════
# Unified Plotting Helper
# ═══════════════════════════════════════════════════════════════════════════

def _plot_timeseries_field(
    cfg: VizConfig,
    field: str,
    rows: List[Dict],
    group_by: Literal["run_id"] | Tuple[str, str],
    output_path: Path,
    current_run_id: int | None = None,
    current_label: str | None = None,
    labels_by_rid: Dict[int, str] | None = None
):
    """
    Unified timeseries plotting for any field.
    
    Args:
        cfg: Visualization config
        field: Field name to plot
        rows: Data rows (must have 'step' and field)
        group_by: "run_id" or ("run_id", "agent") 
        output_path: Where to save plot
        current_run_id: ID of current run (for labeling)
        current_label: Label for current run
        labels_by_rid: Map of run_id -> label
    """
    if isinstance(group_by, str):
        group_keys = [group_by]
    else:
        group_keys = list(group_by)
    
    # Group rows
    groups = defaultdict(list)
    for r in rows:
        key = tuple(r.get(k) for k in group_keys)
        if None not in key:
            groups[key].append(r)
    
    if not groups:
        return
    
    # Create figure
    fig, ax = _safe_fig(figsize=DEFAULT_TIMESERIES_FIGSIZE, dpi=cfg.dpi)
    plotted_any = False
    
    # Plot each group
    for key, group_rows in groups.items():
        group_rows = sorted(group_rows, key=lambda r: r["step"])
        
        # Extract data
        steps = np.array([r["step"] for r in group_rows], dtype=float)
        values = np.array([_to_num(r.get(field)) for r in group_rows], dtype=float)
        
        # Handle run continuation (detect step resets)
        breaks = np.where(np.diff(steps) < 0)[0] + 1
        segments = np.split(np.arange(len(steps)), breaks)
        
        # Build label
        if len(group_keys) == 1:
            # Global: just run label
            run_id = key[0]
            label = _label_for_run(group_rows, run_id, current_run_id, 
                                   current_label, labels_by_rid)
        else:
            # Agent: include agent ID
            run_id, agent_id = key
            run_label = _label_for_run(group_rows, run_id, current_run_id,
                                       current_label, labels_by_rid)
            label = f"{agent_id}@{run_label}"
        
        # Plot segments
        labeled = False
        for seg_idx in segments:
            s = steps[seg_idx]
            v = values[seg_idx]
            mask = np.isfinite(s) & np.isfinite(v)
            
            if np.any(mask):
                ax.plot(s[mask], v[mask], 
                       label=(label if not labeled else None),
                       alpha=0.8)
                labeled = True
                plotted_any = True
    
    if not plotted_any:
        plt.close(fig)
        return
    
    # Format plot
    ax.set_xlabel("step")
    ax.set_ylabel(field)
    ax.set_title(field, fontsize=DEFAULT_TITLE_FONTSIZE)
    ax.legend(loc="best", fontsize=DEFAULT_LEGEND_FONTSIZE)
    ax.grid(True, alpha=0.3)
    
    # Save
    _safe_savefig(fig, output_path, run_id=current_run_id)


# ═══════════════════════════════════════════════════════════════════════════
# Unified Snapshot Helper
# ═══════════════════════════════════════════════════════════════════════════

def _snapshot_field_2d(
    cfg: VizConfig,
    field: np.ndarray,
    output_path: Path,
    title: str,
    *,
    vmin: float | None = None,
    vmax: float | None = None,
    robust: bool = True,
    cmap: str | None = None
):
    """
    Unified 2D field snapshot with robust scaling.
    
    Args:
        cfg: Visualization config
        field: 2D array to visualize
        output_path: Where to save
        title: Plot title
        vmin, vmax: Optional value range
        robust: Use percentile-based scaling
        cmap: Colormap (uses cfg.cmap if None)
    """
    if field.ndim != 2:
        raise ValueError(f"Expected 2D field, got shape {field.shape}")
    
    # Downsample if needed
    if field.shape[0] > cfg.max_side or field.shape[1] > cfg.max_side:
        field = _downsample_2d(field, cfg.max_side)
    
    # Robust scaling
    if robust and (vmin is None or vmax is None):
        valid = field[np.isfinite(field)]
        if len(valid) > 0:
            if vmin is None:
                vmin = float(np.percentile(valid, cfg.robust_low))
            if vmax is None:
                vmax = float(np.percentile(valid, cfg.robust_high))
    
    # Fallback
    if vmin is None or vmax is None or not np.isfinite(vmin) or not np.isfinite(vmax):
        vmin, vmax = float(np.min(field)), float(np.max(field))
    
    # Ensure valid range
    if vmin == vmax:
        pad = 1e-6 if vmax == 0 else 1e-6 * abs(vmax)
        vmin -= pad
        vmax += pad
    
    # Create figure
    fig, ax = _safe_fig(figsize=DEFAULT_SNAPSHOT_FIGSIZE, dpi=cfg.dpi)
    
    # Plot
    cmap = cmap or cfg.cmap
    im = ax.imshow(field, cmap=cmap, vmin=vmin, vmax=vmax, 
                   origin='lower', interpolation='nearest')
    
    # Colorbar
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    
    # Labels
    ax.set_title(title, fontsize=DEFAULT_TITLE_FONTSIZE)
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    
    # Save
    _safe_savefig(fig, output_path)


# ═══════════════════════════════════════════════════════════════════════════
# NEW: Phase Space Plotting
# ═══════════════════════════════════════════════════════════════════════════

def _plot_phase_space(
    cfg: VizConfig,
    rows: List[Dict],
    field_x: str,
    field_y: str,
    output_path: Path,
    group_by: str = "agent"
):
    """
    Create phase space plot (e.g., μ_norm vs σ_norm).
    
    Args:
        cfg: Visualization config
        rows: Data rows
        field_x, field_y: Fields to plot
        output_path: Where to save
        group_by: How to group trajectories
    """
    if not rows:
        return
    
    # Group by specified key
    groups = defaultdict(list)
    for r in rows:
        key = r.get(group_by)
        if key is not None:
            groups[key].append(r)
    
    if not groups:
        return
    
    # Create figure
    fig, ax = _safe_fig(figsize=DEFAULT_PHASE_FIGSIZE, dpi=cfg.dpi)
    plotted_any = False
    
    # Plot each trajectory
    for key, group_rows in groups.items():
        group_rows = sorted(group_rows, key=lambda r: r.get("step", 0))
        
        x = np.array([_to_num(r.get(field_x)) for r in group_rows], dtype=float)
        y = np.array([_to_num(r.get(field_y)) for r in group_rows], dtype=float)
        
        mask = np.isfinite(x) & np.isfinite(y)
        if np.any(mask):
            # Color by time
            steps = np.array([r.get("step", 0) for r in group_rows], dtype=float)[mask]
            norm = Normalize(vmin=steps.min(), vmax=steps.max())
            
            ax.scatter(x[mask], y[mask], c=steps, cmap='viridis', 
                      norm=norm, s=10, alpha=0.6, label=f"{group_by}={key}")
            plotted_any = True
    
    if not plotted_any:
        plt.close(fig)
        return
    
    # Format
    ax.set_xlabel(field_x)
    ax.set_ylabel(field_y)
    ax.set_title(f"Phase Space: {field_y} vs {field_x}", 
                fontsize=DEFAULT_TITLE_FONTSIZE)
    ax.grid(True, alpha=0.3)
    
    if len(groups) <= 10:  # Only show legend if not too many
        ax.legend(loc="best", fontsize=8)
    
    # Save
    _safe_savefig(fig, output_path)


# ═══════════════════════════════════════════════════════════════════════════
# NEW: Correlation Heatmap
# ═══════════════════════════════════════════════════════════════════════════

def _plot_correlation_heatmap(
    cfg: VizConfig,
    rows: List[Dict],
    output_path: Path,
    fields: List[str] | None = None
):
    """
    Create correlation heatmap between metrics.
    
    Args:
        cfg: Visualization config
        rows: Data rows
        output_path: Where to save
        fields: Fields to correlate (auto-detect if None)
    """
    if not rows:
        return
    
    # Auto-detect numeric fields if not provided
    if fields is None:
        fields = _get_numeric_fields(rows, GLOBAL_PREFERRED_FIELDS + AGENT_PREFERRED_FIELDS, set())
        fields = fields[:20]  # Limit to prevent huge heatmap
    
    if len(fields) < 2:
        return
    
    # Extract data matrix
    data = np.array([[_to_num(r.get(f)) for f in fields] for r in rows], dtype=float)
    
    # Remove columns with no variance
    valid_cols = []
    valid_fields = []
    for i, f in enumerate(fields):
        col = data[:, i]
        col = col[np.isfinite(col)]
        if len(col) > 1 and not _is_effectively_constant(col):
            valid_cols.append(i)
            valid_fields.append(f)
    
    if len(valid_fields) < 2:
        return
    
    data = data[:, valid_cols]
    
    # Compute correlation matrix
    # Remove NaN rows
    mask = np.all(np.isfinite(data), axis=1)
    data = data[mask]
    
    if len(data) < 2:
        return
    
    corr = np.corrcoef(data.T)
    
    # Create figure
    fig, ax = plt.subplots(figsize=(10, 8), dpi=cfg.dpi)
    
    # Plot
    im = ax.imshow(corr, cmap='RdBu_r', vmin=-1, vmax=1, aspect='auto')
    
    # Colorbar
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    
    # Labels
    ax.set_xticks(np.arange(len(valid_fields)))
    ax.set_yticks(np.arange(len(valid_fields)))
    ax.set_xticklabels(valid_fields, rotation=45, ha='right', fontsize=8)
    ax.set_yticklabels(valid_fields, fontsize=8)
    ax.set_title("Metric Correlations", fontsize=DEFAULT_TITLE_FONTSIZE)
    
    # Save
    fig.tight_layout()
    _safe_savefig(fig, output_path)




import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

def plot_beta_map(
    ctx,
    i_id: int,
    j_id: int,
    *,
    which: str = "q",
    outdir: Path = Path("plots"),
    dpi: int = 300,
    cmap: str = "magma",
    show_axis: bool = True,
    vmin: float | None = None,
    vmax: float | None = None,
):
    """
    Render the spatial coupling field β_ij for a given (i,j) pair.

    Args
    ----
    ctx : simulation context (must expose ctx.edge.get_align and ctx.edge.beta)
    i_id, j_id : int
        Agent i (receiver) and agent j (sender) indices.
    which : {"q","p"}
        Which fiber / alignment channel to visualize.
    outdir : Path
        Directory to save figures.
    dpi : int
        Save resolution.
    cmap : str
        Matplotlib colormap to use. "magma" prints well in grayscale.
    show_axis : bool
        If False, hide ticks/frame so the panel can drop directly into a figure grid.
    vmin, vmax : float or None
        Explicit color scale limits. Useful if you want multiple panels comparable.
        If None, will autoscale from data.

    Output
    ------
    Saves:
        <outdir>/beta_<which>_i<i_id>_j<j_id>.png
        <outdir>/beta_<which>_i<i_id>_j<j_id>.pdf
    Returns
    -------
    beta2d : np.ndarray
        2-D slice actually plotted (for caller if you want further analysis).
    """

    # -------------------------------------------------
    # 0. Figure out the spatial shape EdgeMaps expects
    # -------------------------------------------------
    # EdgeMaps.get_align(...) in your code still wants a keyword-only 'shape=...'.
    # We can grab any stored beta map to infer that lattice shape.
    try:
        first_beta = next(iter(ctx.edge.beta.values()))
        shape_guess = np.asarray(first_beta).shape
    except StopIteration:
        raise RuntimeError(
            "plot_beta_map: ctx.edge.beta is empty, cannot infer spatial shape."
        )

    # -------------------------------------------------
    # 1. Resolve the underlying β_ij field
    # -------------------------------------------------
    # NOTE: pass shape=shape_guess to satisfy your current EdgeMaps API.
    _, beta_map = ctx.edge.get_align(ctx, which, i_id, j_id, shape=shape_guess)

    beta = np.asarray(beta_map, dtype=np.float32)

    # Replace NaN / inf (non-overlap etc.) with 0 so imshow doesn't blow up.
    beta_clean = np.where(np.isfinite(beta), beta, 0.0)

    # -------------------------------------------------
    # 2. Pick a 2-D slice
    # -------------------------------------------------
    if beta_clean.ndim == 2:
        beta2d = beta_clean
    elif beta_clean.ndim >= 3:
        center_idx = beta_clean.shape[0] // 2
        beta2d = beta_clean[center_idx]
    else:
        raise ValueError(
            f"plot_beta_map expected 2-D or 3-D beta map, got shape {beta_clean.shape}"
        )

    # -------------------------------------------------
    # 3. Matplotlib styling for publication
    # -------------------------------------------------
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.size": 10,
        "axes.titlesize": 11,
        "axes.labelsize": 10,
        "axes.linewidth": 0.8,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "xtick.major.width": 0.6,
        "ytick.major.width": 0.6,
        "figure.dpi": dpi,
        "savefig.dpi": dpi,
    })

    fig, ax = plt.subplots(figsize=(3.0, 2.6))

    # -------------------------------------------------
    # 4. Heatmap
    # -------------------------------------------------
    im = ax.imshow(
        beta2d,
        origin="lower",
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        interpolation="nearest",
    )

    if not show_axis:
        ax.set_xticks([])
        ax.set_yticks([])
        ax.set_xlabel("")
        ax.set_ylabel("")
    else:
        ax.set_xlabel("x (spatial index)")
        ax.set_ylabel("y (spatial index)")

    ax.set_title(
        rf"$\beta_{{{i_id}\leftarrow{j_id}}}$ ({which}-fiber)",
        pad=6
    )

    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.ax.set_ylabel(r"Alignment weight $\beta$", rotation=270, labelpad=12)
    cbar.ax.tick_params(labelsize=8, width=0.6)

    fig.tight_layout()

    # -------------------------------------------------
    # 5. Save figures (raster + vector)
    # -------------------------------------------------
    outdir.mkdir(parents=True, exist_ok=True)
    stem = f"beta_{which}_i{i_id}_j{j_id}"

    png_path = outdir / f"{stem}.png"
    pdf_path = outdir / f"{stem}.pdf"

    fig.savefig(png_path, bbox_inches="tight")
    fig.savefig(pdf_path, bbox_inches="tight")

    plt.close(fig)

    return beta2d




# ═══════════════════════════════════════════════════════════════════════════
# NEW: Agent Alignment Visualizations
# ═══════════════════════════════════════════════════════════════════════════

def _plot_agent_alignment_bars(
    cfg: VizConfig,
    rows: List[Dict],
    alignment_field: str,
    output_path: Path,
    title: str,
    *,
    is_kl_divergence: bool = True
):
    """
    Create bar chart of agent alignment values.
    
    Args:
        cfg: Visualization config
        rows: Latest agent data rows
        alignment_field: Field name containing alignment values
        output_path: Where to save
        title: Plot title
        is_kl_divergence: If True, lower values = better (invert color scale)
    """
    if not rows:
        return
    
    # Extract agent IDs and alignments
    agents = []
    alignments = []
    
    for r in rows:
        agent_id = r.get("agent")
        alignment = r.get(alignment_field)
        
        if agent_id is not None and alignment is not None and _is_num(alignment):
            agents.append(agent_id)
            alignments.append(float(alignment))
    
    if not agents:
        return
    
    # Sort by agent ID
    sorted_pairs = sorted(zip(agents, alignments), key=lambda x: x[0])
    agents, alignments = zip(*sorted_pairs)
    
    agents = np.array(agents)
    alignments = np.array(alignments)
    
    # Create figure
    fig, ax = plt.subplots(figsize=(max(8, len(agents) * 0.4), 5), dpi=cfg.dpi)
    
    # Color bars by alignment value
    if is_kl_divergence:
        # KL divergence: lower is better
        # Map to [0, 1] for coloring, where 0 = perfect (green), high = poor (red)
        # Use robust percentiles
        vmin = np.percentile(alignments, 5)
        vmax = np.percentile(alignments, 95)
        if vmax - vmin < 1e-6:
            vmax = vmin + 1.0
        
        # Normalize to [0, 1], invert so low KL = high color value (green)
        normalized = 1.0 - np.clip((alignments - vmin) / (vmax - vmin), 0, 1)
        colors = plt.cm.RdYlGn(normalized)
    else:
        # Cosine similarity: higher is better (original behavior)
        # Map [-1, 1] to [0, 1]
        colors = plt.cm.RdYlGn((alignments + 1) / 2)
    
    # Bar chart
    bars = ax.bar(range(len(agents)), alignments, color=colors, alpha=0.8, 
                   edgecolor='black', linewidth=0.5)
    
    # Reference lines
    if is_kl_divergence:
        ax.axhline(y=0, color='green', linestyle='--', linewidth=0.8, alpha=0.5, 
                   label='Perfect alignment (KL=0)')
        # Add line at median for reference
        median_kl = np.median(alignments)
        ax.axhline(y=median_kl, color='orange', linestyle=':', linewidth=0.8, alpha=0.4,
                   label=f'Median KL={median_kl:.3f}')
    else:
        ax.axhline(y=0, color='black', linestyle='-', linewidth=0.8, alpha=0.5)
        ax.axhline(y=1, color='green', linestyle='--', linewidth=0.8, alpha=0.3, 
                   label='Perfect alignment')
        ax.axhline(y=-1, color='red', linestyle='--', linewidth=0.8, alpha=0.3, 
                   label='Anti-alignment')
    
    # Labels
    ax.set_xlabel("Agent ID")
    ax.set_ylabel("KL Divergence" if is_kl_divergence else "Alignment")
    ax.set_title(title, fontsize=DEFAULT_TITLE_FONTSIZE)
    ax.set_xticks(range(len(agents)))
    ax.set_xticklabels([f"{a}" for a in agents], rotation=45 if len(agents) > 10 else 0)
    
    if not is_kl_divergence:
        ax.set_ylim(-1.1, 1.1)
    else:
        # KL divergence: adjust ylim to show data well
        ymax = max(np.max(alignments) * 1.1, 0.1)
        ax.set_ylim(-0.05 * ymax, ymax)
    
    ax.legend(loc='best', fontsize=8)
    ax.grid(True, alpha=0.3, axis='y')
    
    # Add value labels on bars
    for i, (bar, val) in enumerate(zip(bars, alignments)):
        height = bar.get_height()
        
        if is_kl_divergence:
            label_text = f'{val:.3f}'
            va = 'bottom'
        else:
            label_text = f'{val:.2f}'
            va = 'bottom' if height > 0 else 'top'
        
        ax.text(bar.get_x() + bar.get_width() / 2., height,
                label_text,
                ha='center', va=va,
                fontsize=7, color='black')
    
    # Save
    fig.tight_layout()
    _safe_savefig(fig, output_path)


# ═══════════════════════════════════════════════════════════════════════════
# NEW: Summary Statistics
# ═══════════════════════════════════════════════════════════════════════════

def _compute_summary_stats(rows: List[Dict], fields: List[str]) -> Dict[str, Any]:
    """
    Compute summary statistics for specified fields.
    
    Returns dict with mean, std, min, max, final for each field.
    """
    stats = {}
    
    for field in fields:
        values = np.array([_to_num(r.get(field)) for r in rows], dtype=float)
        values = values[np.isfinite(values)]
        
        if len(values) == 0:
            continue
        
        stats[field] = {
            "mean": float(np.mean(values)),
            "std": float(np.std(values)),
            "min": float(np.min(values)),
            "max": float(np.max(values)),
            "final": float(values[-1]) if len(values) > 0 else None,
            "n_samples": int(len(values)),
        }
    
    return stats


# ═══════════════════════════════════════════════════════════════════════════
# Main Class
# ═══════════════════════════════════════════════════════════════════════════

class MetricsViz:
    """
    Central logger/plotter for SO(3) Suite metrics.
    
    Usage:
        mv = MetricsViz(VizConfig(Path("output"), run_name="trial1"))
        mv.start_run(meta={"casimir_total": 2.0})
        
        for step in range(steps):
            mv.log_global(step, {"energy": ..., ...})
            for agent in agents:
                mv.log_agent(step, agent.id, {...})
            
            mv.maybe_flush(step)
            mv.maybe_plot(step)
            mv.maybe_snapshot(step, ctx, agents)
        
        mv.end_run()
    """
    
    def __init__(self, cfg: VizConfig):
        self.cfg = cfg
        self.root = Path(cfg.outdir)
        _ensure_dir(self.root)
        
        # Run directory
        self.dir_run = self.root / cfg.run_name
        _ensure_dir(self.dir_run)
        
        # Subdirectories
        self.dir_plots = self.dir_run / "plots"
        self.dir_snapshots = self.dir_run / "snapshots"
        _ensure_dir(self.dir_plots)
        _ensure_dir(self.dir_snapshots)
        
        # In-memory timeseries
        self.global_rows: List[Dict[str, Any]] = []
        self.agent_rows: List[Dict[str, Any]] = []
        
        # Headers (discovered from first row)
        self._global_header: Optional[List[str]] = None
        self._agent_header: Optional[List[str]] = None
        
        # Multi-run tracking
        self._global_history: List[Dict] = []
        self._agent_history: List[Dict] = []
        self._labels_by_rid: Dict[int, str] = {}
        self._labels_path = self.dir_run / "run_labels.json"
        self._counter_path = self.dir_run / "run_counter.txt"
        
        # Metadata
        self.meta: Dict[str, Any] = {}
        self.run_id: int | None = None
        self.run_label: str = cfg.legend_label
    
    # ═══════════════════════════════════════════════════════════════════════
    # Lifecycle
    # ═══════════════════════════════════════════════════════════════════════
    
    def start_run(self, meta: Dict[str, Any] | None = None):
        """
        Start a new run. Assigns run_id, loads history.
        
        Args:
            meta: Run metadata (e.g., {"casimir_total": 2.0})
        """
        self.meta = meta or {}
        
        # Assign run ID
        if self._counter_path.exists():
            with open(self._counter_path, "r") as f:
                self.run_id = int(f.read().strip()) + 1
        else:
            self.run_id = 1
        
        with open(self._counter_path, "w") as f:
            f.write(str(self.run_id))
        
        # Load labels
        if self._labels_path.exists():
            with open(self._labels_path, "r") as f:
                self._labels_by_rid = json.load(f)
        
        # Save current label
        if self.run_label:
            self._labels_by_rid[str(self.run_id)] = self.run_label
            with open(self._labels_path, "w") as f:
                json.dump(self._labels_by_rid, f, indent=2)
        
        # Load history from CSV if enabled
        if self.cfg.enable_csv:
            self._load_history_from_csv()
        
        print(f"[MetricsViz] Started run {self.run_id}: {self.cfg.run_name}")
    
    def end_run(self):
        """End current run. Flush buffers, save summary stats."""
        self.maybe_flush(force=True)
        
        # Save summary statistics
        if self.cfg.enable_summary_stats:
            self._save_summary_stats()
        
        print(f"[MetricsViz] Ended run {self.run_id}")
    
    def _load_history_from_csv(self):
        """Load previous runs from CSV files."""
        # Load global history
        global_csv = self.dir_run / self.cfg.global_csv
        if global_csv.exists():
            with open(global_csv, "r") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    # Convert numeric fields
                    for k, v in row.items():
                        try:
                            row[k] = float(v) if '.' in v else int(v)
                        except (ValueError, TypeError):
                            pass
                    self._global_history.append(row)
        
        # Load agent history
        agent_csv = self.dir_run / self.cfg.agent_csv
        if agent_csv.exists():
            with open(agent_csv, "r") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    for k, v in row.items():
                        try:
                            row[k] = float(v) if '.' in v else int(v)
                        except (ValueError, TypeError):
                            pass
                    self._agent_history.append(row)
    
    def _save_summary_stats(self):
        """Save summary statistics to JSON."""
        summary = {
            "run_id": self.run_id,
            "run_name": self.cfg.run_name,
            "run_label": self.run_label,
            "meta": self.meta,
        }
        
        # Global stats
        if self.global_rows:
            fields = _get_numeric_fields(self.global_rows, GLOBAL_PREFERRED_FIELDS, set())
            summary["global"] = _compute_summary_stats(self.global_rows, fields)
        
        # Agent stats
        if self.agent_rows:
            fields = _get_numeric_fields(self.agent_rows, AGENT_PREFERRED_FIELDS, MUST_KEEP_FIELDS)
            summary["agent"] = _compute_summary_stats(self.agent_rows, fields)
        
        # Save
        summary_path = self.dir_run / self.cfg.summary_json
        with open(summary_path, "w") as f:
            json.dump(summary, f, indent=2)
    
    # ═══════════════════════════════════════════════════════════════════════
    # Logging
    # ═══════════════════════════════════════════════════════════════════════
    
    def log_global(self, step: int, metrics: Dict[str, Any]):
        """Log global metrics for this step."""
        row = {"step": step, "ts": time.time(), "run_id": self.run_id}
        row.update(metrics)
        self.global_rows.append(row)
        
        # Discover header
        if self._global_header is None:
            self._global_header = list(row.keys())
    
    def log_agent(self, step: int, agent_id: int, metrics: Dict[str, Any]):
        """Log per-agent metrics for this step."""
        row = {"step": step, "agent": agent_id, "ts": time.time(), "run_id": self.run_id}
        row.update(metrics)
        self.agent_rows.append(row)
        
        if self._agent_header is None:
            self._agent_header = list(row.keys())
    
    def maybe_flush(self, step: int | None = None, *, force: bool = False):
        """Flush logs to disk if needed."""
        if not force and step is not None:
            if step % self.cfg.save_every_steps != 0:
                return
        
        # CSV
        if self.cfg.enable_csv:
            if self._global_header and self.global_rows:
                path = self.dir_run / self.cfg.global_csv
                for row in self.global_rows:
                    _append_csv(path, row, self._global_header)
            
            if self._agent_header and self.agent_rows:
                path = self.dir_run / self.cfg.agent_csv
                for row in self.agent_rows:
                    _append_csv(path, row, self._agent_header)
        
        # JSONL
        if self.cfg.enable_jsonl:
            if self.global_rows:
                path = self.dir_run / self.cfg.global_jsonl
                for row in self.global_rows:
                    _append_jsonl(path, row)
            
            if self.agent_rows:
                path = self.dir_run / self.cfg.agent_jsonl
                for row in self.agent_rows:
                    _append_jsonl(path, row)
        
        # Keep recent rows in memory, rest in history
        if len(self.global_rows) > 10000:
            self._global_history.extend(self.global_rows[:-1000])
            self.global_rows = self.global_rows[-1000:]
        
        if len(self.agent_rows) > 50000:
            self._agent_history.extend(self.agent_rows[:-5000])
            self.agent_rows = self.agent_rows[-5000:]
    
    # ═══════════════════════════════════════════════════════════════════════
    # Plotting
    # ═══════════════════════════════════════════════════════════════════════
    
    def maybe_plot(self, step: int):
        """Generate plots if needed."""
        if not self.cfg.enable_plots:
            return
        
        if step % self.cfg.plot_every_steps != 0:
            return
        
        try:
            self._plot_global_timeseries()
            self._plot_agent_timeseries()
            
            if self.cfg.enable_phase_plots:
                self._plot_phase_spaces()
            
            if self.cfg.enable_correlation_plots:
                self._plot_correlations()
            
            # NEW: Agent alignment visualizations
            self._plot_agent_alignments()
        
        except Exception as e:
            print(f"[MetricsViz] Plotting failed: {e}")
    
    def _plot_global_timeseries(self):
        """Plot global metric timeseries."""
        rows = _normalize_plot_rows(
            self._global_history,
            self.global_rows,
            default_run_id=self.run_id or 1
        )
        
        if not rows:
            return
        
        fields = _get_numeric_fields(rows, GLOBAL_PREFERRED_FIELDS, set())
        
        for field in fields:
            output_path = self.dir_plots / f"global_{field}.png"
            _plot_timeseries_field(
                self.cfg, field, rows, "run_id", output_path,
                current_run_id=self.run_id,
                current_label=self.run_label,
                labels_by_rid=self._labels_by_rid
            )
    
    def _plot_agent_timeseries(self):
        """Plot per-agent metric timeseries."""
        rows = _normalize_plot_rows(
            self._agent_history,
            self.agent_rows,
            default_run_id=self.run_id or 1
        )
        
        if not rows:
            return
        
        fields = _get_numeric_fields(rows, AGENT_PREFERRED_FIELDS, MUST_KEEP_FIELDS)
        
        for field in fields:
            output_path = self.dir_plots / f"agent_{field}.png"
            _plot_timeseries_field(
                self.cfg, field, rows, ("run_id", "agent"), output_path,
                current_run_id=self.run_id,
                current_label=self.run_label,
                labels_by_rid=self._labels_by_rid
            )
    
    def _plot_phase_spaces(self):
        """Generate phase space plots."""
        if not self.agent_rows:
            return
        
        # μ_q vs σ_q
        if any("mu_q_norm_mean" in r and "sigma_q_trace_mean" in r for r in self.agent_rows):
            output_path = self.dir_plots / "phase_mu_q_vs_sigma_q.png"
            _plot_phase_space(
                self.cfg, self.agent_rows,
                "mu_q_norm_mean", "sigma_q_trace_mean",
                output_path, group_by="agent"
            )
        
        # φ norm vs φ_model norm
        if any("phi_norm_mean" in r and "phi_model_norm_mean" in r for r in self.agent_rows):
            output_path = self.dir_plots / "phase_phi_vs_phi_model.png"
            _plot_phase_space(
                self.cfg, self.agent_rows,
                "phi_norm_mean", "phi_model_norm_mean",
                output_path, group_by="agent"
            )
    
    def _plot_correlations(self):
        """Generate correlation heatmaps."""
        # Global correlations
        if self.global_rows:
            output_path = self.dir_plots / "correlation_global.png"
            _plot_correlation_heatmap(self.cfg, self.global_rows, output_path)
        
        # Agent correlations
        if self.agent_rows:
            output_path = self.dir_plots / "correlation_agent.png"
            _plot_correlation_heatmap(self.cfg, self.agent_rows, output_path)
    
    def _plot_agent_alignments(self):
        """Generate agent alignment visualizations."""
        if not self.agent_rows:
            return
        
        # Get latest step data
        latest_step = max(r.get("step", 0) for r in self.agent_rows)
        latest_rows = [r for r in self.agent_rows if r.get("step") == latest_step]
        
        if not latest_rows:
            return
        
        # Plot belief alignments (KL-based)
        if any("belief_alignment_kl" in r for r in latest_rows):
            output_path = self.dir_plots / "agent_belief_alignments_kl.png"
            _plot_agent_alignment_bars(
                self.cfg, latest_rows, "belief_alignment_kl",
                output_path, "Agent Belief Alignments: KL(q_i || Ω_ij q_j)",
                is_kl_divergence=True
            )
        # Plot belief alignments (KL-based)
        if any("model_alignment_kl" in r for r in latest_rows):
            output_path = self.dir_plots / "agent_model_alignments_kl.png"
            _plot_agent_alignment_bars(
                self.cfg, latest_rows, "model_alignment_kl",
                output_path, "Agent Model Alignments: KL(p_i || Ω~_ij p_j)",
                is_kl_divergence=True
            )
        # Plot model alignments (KL-based)
        if any("self_alignment_kl" in r for r in latest_rows):
            output_path = self.dir_plots / "agent_self_alignments_kl.png"
            _plot_agent_alignment_bars(
                self.cfg, latest_rows, "self_alignment_kl",
                output_path, "Agent Self Alignments: KL(q_i || p_i)",
                is_kl_divergence=True
            )
    
    # ═══════════════════════════════════════════════════════════════════════
    # Snapshots
    # ═══════════════════════════════════════════════════════════════════════
    
    def maybe_snapshot(self, step: int, runtime_ctx, agents):
        """Save field snapshots if needed."""
        if not self.cfg.enable_snapshots:
            return
        
        if step % self.cfg.snapshot_every_steps != 0:
            return
        
        # Step directory
        dstep = self.dir_snapshots / f"step_{step:04d}"
        _ensure_dir(dstep)
        
        # Global A field
        try:
            self._snapshot_global_A(step, dstep, runtime_ctx)
        except Exception as e:
            print(f"[SNAPSHOT] Global A failed: {e}")
        
        # Per-agent fields
        for agent in (agents or []):
            if agent is None:
                continue
            try:
                self._snapshot_agent(step, dstep, agent, runtime_ctx)
            except Exception as e:
                print(f"[SNAPSHOT] Agent {_aid(agent)} failed: {e}")
    
    def _snapshot_global_A(self, step: int, dstep: Path, ctx):
        """Snapshot global connection field A."""
        if not hasattr(ctx, "fields") or ctx.fields is None:
            return
        
        # Get A field
        A = ctx.fields.get("A")
        if A is None:
            return
        
        # Convert to 2D visualization slice
        A = np.asarray(A, np.float32)
        A2 = _center_slice_to_2d(A, trailing=2)  # Keep last 2 dims (D, 3)
        
        if A2.ndim != 4 or A2.shape[-2:] != (2, 3):
            return
        
        # Compute curvature
        F, F2 = _curvature_from_A(A2)
        
        # Snapshot curvature magnitude
        output_path = dstep / "global_curvature.png"
        _snapshot_field_2d(
            self.cfg, F2, output_path,
            f"Curvature |F|² (step {step})"
        )
    
    def _snapshot_agent(self, step: int, dstep: Path, agent, ctx):
        """Snapshot agent fields (μ, Σ, φ, φ̃) to 2-D heatmaps with meaningful reductions."""
        import numpy as np
    
        def _aid(a):
            return int(getattr(a, "id", -1))
    
        aid = _aid(agent)
    
        # --- helpers ---
        def _spatial_shape_for(arr, attr_name: str):
            """Infer spatial shape; prefer agent.spatial_shape if present and sensible."""
            S = getattr(agent, "spatial_shape", None)
            if isinstance(S, (tuple, list)) and len(S) >= 2 and np.prod(S) > 0:
                return tuple(int(x) for x in S)
            # Fallback: infer from tensor rank
            if attr_name in ("sigma_q_field", "sigma_p_field"):
                # (*S, K, K)
                if arr.ndim >= 3:
                    return tuple(int(x) for x in arr.shape[:-2])
            else:
                # (*S, C)
                if arr.ndim >= 2:
                    return tuple(int(x) for x in arr.shape[:-1])
            return None  # give up; caller will skip
    
        def _reduce_to_2d(image_like, S):
            """Return a 2-D array for snapshot: prefer first two spatial dims; average the rest."""
            if S is None or len(S) < 2:
                return None
            # If exactly 2-D, reshape directly
            if len(S) == 2:
                return np.asarray(image_like, np.float32).reshape(S)
            # If more than 2-D, average the trailing spatial axes to get (H, W)
            v = np.asarray(image_like, np.float64).reshape(S)
            # Keep the first two (H,W), average across any remaining spatial dims
            if len(S) > 2:
                axes = tuple(range(2, len(S)))
                v = np.nanmean(v, axis=axes)
            return v.astype(np.float32, copy=False)
    
        def _snap(field_name: str, attr_name: str, title_suffix: str):
            field = getattr(agent, attr_name, None)
            if field is None:
                return
    
            arr = np.asarray(field)
            S = _spatial_shape_for(arr, attr_name)
            if S is None or len(S) < 2 or np.prod(S) == 0:
                return
    
            # ---------- μ-fields: (*S, K) → per-site L2 norm ----------
            if attr_name in ("mu_q_field", "mu_p_field"):
                if arr.ndim >= 2:
                    v = np.linalg.norm(np.asarray(arr, np.float64), axis=-1)  # (*S,)
                    v2d = _reduce_to_2d(v, S)
                    if v2d is not None:
                        _snapshot_field_2d(
                            self.cfg,
                            v2d,
                            dstep / f"agent_{aid}_{field_name}_norm.png",
                            f"{title_suffix} ‖μ‖ (step {step})",
                        )
                return
    
            # ---------- Σ-fields: (*S, K, K) → per-site tr(Σ) and logdet(Σ) ----------
            if attr_name in ("sigma_q_field", "sigma_p_field"):
                if arr.ndim >= 3 and arr.shape[-1] == arr.shape[-2]:
                    A = np.asarray(arr, np.float64)
                    K = A.shape[-1]
                    A2 = A.reshape((-1, K, K))
    
                    # trace
                    tr = np.trace(A2, axis1=-2, axis2=-1)
                    tr2d = _reduce_to_2d(tr, S)
                    if tr2d is not None:
                        _snapshot_field_2d(
                            self.cfg,
                            tr2d,
                            dstep / f"agent_{aid}_{field_name}_trace.png",
                            f"{title_suffix} tr(Σ) (step {step})",
                        )
    
                    # logdet (robust via slogdet)
                    sign, logabs = np.linalg.slogdet(A2)
                    # If Σ is not SPD somewhere, sign may be -1 or 0; keep signed logdet for debugging
                    logdet = sign * logabs
                    # Replace NaN/inf with finite numbers for plotting stability
                    logdet = np.where(np.isfinite(logdet), logdet, np.nan)
                    logdet2d = _reduce_to_2d(logdet, S)
                    if logdet2d is not None:
                        _snapshot_field_2d(
                            self.cfg,
                            logdet2d,
                            dstep / f"agent_{aid}_{field_name}_logdet.png",
                            f"{title_suffix} logdet(Σ) (step {step})",
                        )
                return
    
            # ---------- φ / φ̃ (or general vector fields): (*S, C) → per-site L2 norm ----------
            if arr.ndim >= 2 and arr.shape[-1] in (2, 3, 4, 6, 8, 16):
                v = np.linalg.norm(np.asarray(arr, np.float64), axis=-1)
                v2d = _reduce_to_2d(v, S)
                if v2d is not None:
                    _snapshot_field_2d(
                        self.cfg,
                        v2d,
                        dstep / f"agent_{aid}_{field_name}_norm.png",
                        f"{title_suffix} norm (step {step})",
                    )
                return
    
            # ---------- Fallback ----------
            # If it's already scalar per site, just reshape; otherwise mean-reduce last axis.
            x = np.asarray(arr, np.float64)
            if x.shape[-1] > 1 and x.ndim >= 2:
                x = np.nanmean(x, axis=-1)
            v2d = _reduce_to_2d(x, S)
            if v2d is not None:
                _snapshot_field_2d(
                    self.cfg,
                    v2d,
                    dstep / f"agent_{aid}_{field_name}.png",
                    f"{title_suffix} (step {step})",
                )
    
        # ---- Snapshot calls ----
        _snap("phi",       "phi",           "φ")
        _snap("phi_model", "phi_model",     "φ̃")
        _snap("mu_q",      "mu_q_field",    "μ_q")
        _snap("mu_p",      "mu_p_field",    "μ_p")
        _snap("sigma_q",   "sigma_q_field", "Σ_q")
        _snap("sigma_p",   "sigma_p_field", "Σ_p")

# ═══════════════════════════════════════════════════════════════════════════
# Module-level convenience functions
# ═══════════════════════════════════════════════════════════════════════════

def save_phi_series_npz(ctx, path: str):
    """
    Save φ/φ̃ timeseries to NPZ file.
    
    Args:
        ctx: Runtime context with _phi_series, _phi_model_series dicts
        path: Output NPZ path
    """
    phi = ctx.__dict__.get("_phi_series", {})
    phim = ctx.__dict__.get("_phi_model_series", {})
    
    # Pack as ragged object arrays by agent ID
    def _to_object_array(d: Dict[int, List]) -> np.ndarray:
        keys = sorted(d.keys())
        arr = np.empty(len(keys), dtype=object)
        for i, k in enumerate(keys):
            arr[i] = np.asarray(d[k], dtype=np.float32)
        return arr
    
    np.savez_compressed(
        path,
        agent_ids=np.array(sorted(set(phi.keys()) | set(phim.keys())), dtype=np.int32),
        phi_series=_to_object_array(phi),
        phim_series=_to_object_array(phim),
    )