"""
fep_transformer_hybrid.py - Practical FEP-consistent transformer

STRATEGY: Multi-level approximations for speed vs. rigor
=========================================================

Level 0 (FULL FEP): Research/validation only, ~100x slower
    - Full Gaussian beliefs (μ, Σ) per token
    - All KL alignment terms
    - Natural gradient descent
    - Gauge frame evolution
    
Level 1 (FROZEN UNCERTAINTY): Practical training, ~10x slower
    - Fixed Σ (e.g., isotropic σ²I)
    - KL reduces to Mahalanobis distance
    - Standard gradient descent OK
    - Gauge frames still learnable
    
Level 2 (DELTA-FUNCTION): Standard inference, same speed as transformers
    - Σ → 0 limit (deterministic embeddings)
    - Recovers QK^T attention
    - Use for inference after training
    
TIMESCALE SEPARATION (from your paper):
    - Fast: beliefs μ (every step)
    - Medium: gauge frames φ (every 10 steps)
    - Slow: covariances Σ (every 100 steps, or fixed)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Optional, Tuple, Literal
from dataclasses import dataclass
import math


# ============================================================================
#                    SO(3) GAUGE MACHINERY (from your code)
# ============================================================================

def so3_generators(K: int) -> torch.Tensor:
    """Generate SO(3) generators for irrep K=2ℓ+1"""
    if K % 2 == 0:
        raise ValueError("K must be odd")
    ℓ = (K - 1) // 2
    
    # Build angular momentum matrices (complex)
    Jp = np.zeros((K, K), dtype=np.complex128)
    Jm = np.zeros((K, K), dtype=np.complex128)
    Jz = np.zeros((K, K), dtype=np.complex128)
    
    for m in range(-ℓ, ℓ + 1):
        i = m + ℓ
        Jz[i, i] = m
        if m < ℓ:
            a = np.sqrt((ℓ - m) * (ℓ + m + 1))
            Jp[i, i+1] = a
            Jm[i+1, i] = a
    
    Jx = (Jp + Jm) / 2.0
    Jy = (Jp - Jm) / (2.0j)
    
    # Real tesseral transform
    S = np.zeros((K, K), dtype=np.complex128)
    S[0, ℓ] = 1.0
    r = 1
    for m in range(1, ℓ + 1):
        phase = (-1) ** m
        S[r, ℓ+m] = 1/np.sqrt(2)
        S[r, ℓ-m] = phase/np.sqrt(2)
        S[r+1, ℓ+m] = -1j/np.sqrt(2)
        S[r+1, ℓ-m] = 1j*phase/np.sqrt(2)
        r += 2
    Sinv = S.conj().T
    
    def to_real_skew(iJ):
        G = (S @ iJ @ Sinv).real
        return 0.5 * (G - G.T)
    
    Gx = to_real_skew(1j * Jx)
    Gy = to_real_skew(1j * Jy)
    Gz = to_real_skew(1j * Jz)
    
    G = np.stack([Gx, Gy, Gz], axis=0)
    return torch.from_numpy(G.astype(np.float32))


def parallel_transport(v: torch.Tensor, G: torch.Tensor) -> torch.Tensor:
    """
    Compute Ω = exp(v·G) where v ∈ R³ and G are SO(3) generators
    
    Args:
        v: (..., 3) Lie algebra coordinates
        G: (3, K, K) generators
    Returns:
        Ω: (..., K, K) rotation matrices
    """
    X = torch.einsum('...a,aij->...ij', v, G)
    X = 0.5 * (X - X.transpose(-2, -1))  # enforce skew
    
    # Small angle: Taylor, large angle: expm
    norms = torch.linalg.norm(v, dim=-1)
    threshold = 1e-3
    
    K = G.shape[-1]
    eye = torch.eye(K, device=v.device, dtype=v.dtype)
    
    # Simple approach: always use matrix exp (PyTorch handles batching well)
    Omega = torch.matrix_exp(X)
    
    return Omega


# ============================================================================
#                    EFFICIENT KL DIVERGENCE COMPUTATION
# ============================================================================

def kl_gaussian_batch(
    mu_i: torch.Tensor,      # (B, N, K) - batch, sequence, dimension
    Sigma_i: torch.Tensor,   # (B, N, K, K) or (B, N) if diagonal/isotropic
    mu_j: torch.Tensor,      # (B, N, K)
    Sigma_j: torch.Tensor,   # (B, N, K, K) or (B, N)
    isotropic: bool = False
) -> torch.Tensor:
    """
    Efficient batched KL divergence between Gaussians.
    
    If isotropic=True: Σᵢ = σᵢ²I, shape (B,N) containing σ²
    Otherwise: full covariances (B,N,K,K)
    
    Returns: (B, N, N) pairwise KL matrix
    """
    B, N, K = mu_i.shape
    
    if isotropic:
        # FAST PATH: Σᵢ = σᵢ²I, Σⱼ = σⱼ²I
        # KL(i||j) = K/2 * [σᵢ²/σⱼ² - 1 - log(σᵢ²/σⱼ²)] + 1/(2σⱼ²) ||μᵢ-μⱼ||²
        
        sigma2_i = Sigma_i  # (B, N)
        sigma2_j = Sigma_j  # (B, N)
        
        # Broadcast to (B, N, N)
        s2i = sigma2_i.unsqueeze(2)  # (B,N,1)
        s2j = sigma2_j.unsqueeze(1)  # (B,1,N)
        
        ratio = s2i / (s2j + 1e-8)
        log_ratio = torch.log(ratio + 1e-8)
        
        # Pairwise distances
        dmu = mu_i.unsqueeze(2) - mu_j.unsqueeze(1)  # (B,N,N,K)
        dist2 = (dmu ** 2).sum(dim=-1)  # (B,N,N)
        
        kl = 0.5 * K * (ratio - 1 - log_ratio) + 0.5 * dist2 / (s2j + 1e-8)
        
    else:
        # FULL PATH: general covariances (slower)
        # Use Cholesky decomposition for numerical stability
        L_j = torch.linalg.cholesky(Sigma_j + 1e-6 * torch.eye(K, device=Sigma_j.device))
        logdet_j = 2 * torch.log(torch.diagonal(L_j, dim1=-2, dim2=-1)).sum(dim=-1)
        
        L_i = torch.linalg.cholesky(Sigma_i + 1e-6 * torch.eye(K, device=Sigma_i.device))
        logdet_i = 2 * torch.log(torch.diagonal(L_i, dim1=-2, dim2=-1)).sum(dim=-1)
        
        # Compute pairwise terms (expensive!)
        kl = torch.zeros(B, N, N, device=mu_i.device)
        for i in range(N):
            for j in range(N):
                dmu = mu_i[:, i] - mu_j[:, j]  # (B, K)
                Sj_inv = torch.cholesky_inverse(L_j[:, j])
                
                # Trace term
                tr = torch.einsum('bii->b', Sj_inv @ Sigma_i[:, i])
                # Quadratic term
                quad = torch.einsum('bi,bij,bj->b', dmu, Sj_inv, dmu)
                
                kl[:, i, j] = 0.5 * (tr + quad - K + logdet_j[:, j] - logdet_i[:, i])
    
    return kl.clamp(min=0)  # Numerical stability


# ============================================================================
#                    FEP ATTENTION LAYER (HYBRID)
# ============================================================================

@dataclass
class FEPConfig:
    """Configuration for FEP-aware attention"""
    # Architecture
    d_model: int = 256
    n_heads: int = 4
    n_layers: int = 4
    seq_len: int = 128
    vocab_size: int = 50000
    
    # FEP parameters
    fep_level: Literal['full', 'frozen_sigma', 'delta'] = 'frozen_sigma'
    
    # Gauge
    use_gauge: bool = True
    gauge_irrep: int = 1  # SO(3) irrep: ℓ
    gauge_dim: int = 3    # Dimension for gauge transport
    
    # Uncertainty
    init_sigma2: float = 1.0  # Initial variance
    sigma2_fixed: Optional[float] = None  # Fix Σ=σ²I if not None
    
    # Update frequencies (timescale separation)
    update_phi_every: int = 10   # Update gauge frames every N steps
    update_sigma_every: int = 100  # Update covariances every N steps
    
    # FEP energy terms
    beta_coupling: float = 1.0   # Belief alignment weight
    gamma_coupling: float = 0.0  # Model alignment (set to 0 for fast regime)
    prior_weight: float = 0.1    # D_KL(q||p) term
    
    # Training
    dropout: float = 0.1


class FEPAttention(nn.Module):
    """
    FEP-consistent attention with multiple approximation levels.
    
    Variables per token:
        μ: (d_model,) - belief mean
        Σ: (d_model, d_model) or scalar σ² - uncertainty
        φ: (3,) - gauge frame (SO(3) Lie algebra coordinates)
    """
    
    def __init__(self, config: FEPConfig, layer_idx: int):
        super().__init__()
        self.config = config
        self.layer_idx = layer_idx
        self.d_head = config.d_model // config.n_heads
        
        # Standard projections (these learn Q,K,V in the delta limit)
        self.q_proj = nn.Linear(config.d_model, config.d_model, bias=False)
        self.k_proj = nn.Linear(config.d_model, config.d_model, bias=False)
        self.v_proj = nn.Linear(config.d_model, config.d_model, bias=False)
        self.o_proj = nn.Linear(config.d_model, config.d_model, bias=False)
        
        # Gauge connection (learnable per position pair)
        if config.use_gauge and config.fep_level != 'delta':
            self.A_params = nn.Parameter(
                torch.randn(config.seq_len, config.seq_len, 3) * 0.01
            )
            K = 2 * config.gauge_irrep + 1
            self.register_buffer('generators', so3_generators(K))
            self.K_gauge = K
        
        # Prior parameters (for D_KL(q||p) term)
        if config.fep_level == 'full':
            self.register_buffer('mu_prior', torch.zeros(self.d_head))
            self.register_buffer('Sigma_prior', 
                               torch.eye(self.d_head) * config.init_sigma2)
        
        # Uncertainty parameters
        if config.fep_level == 'frozen_sigma':
            # Fixed isotropic uncertainty
            sigma2 = config.sigma2_fixed if config.sigma2_fixed else config.init_sigma2
            self.register_buffer('sigma2', torch.tensor(sigma2))
        elif config.fep_level == 'full':
            # Learnable per-head covariances (diagonal for efficiency)
            self.log_sigma2 = nn.Parameter(
                torch.log(torch.ones(config.n_heads, self.d_head) * config.init_sigma2)
            )
        
        self.dropout = nn.Dropout(config.dropout)
        self.step_count = 0
    
    def forward(
        self,
        x: torch.Tensor,  # (B, N, d_model)
        mask: Optional[torch.Tensor] = None,
        return_energy: bool = False
    ) -> Tuple[torch.Tensor, Optional[dict]]:
        """
        Forward pass with optional FEP energy computation.
        
        Returns:
            output: (B, N, d_model)
            energy_dict: Optional energy terms for training
        """
        B, N, D = x.shape
        H = self.config.n_heads
        d_head = self.d_head
        
        # Project to Q, K, V (these are μ in the FEP framework)
        Q = self.q_proj(x).view(B, N, H, d_head).transpose(1, 2)  # (B,H,N,d)
        K = self.k_proj(x).view(B, N, H, d_head).transpose(1, 2)
        V = self.v_proj(x).view(B, N, H, d_head).transpose(1, 2)
        
        # === COMPUTE ATTENTION WEIGHTS ===
        if self.config.fep_level == 'delta':
            # Standard dot-product attention (fast)
            scores = (Q @ K.transpose(-2, -1)) / math.sqrt(d_head)
            if mask is not None:
                scores = scores.masked_fill(mask == 0, -1e9)
            beta = F.softmax(scores, dim=-1)
            
        else:
            # KL-based attention (FEP-consistent)
            beta = self._compute_kl_attention(Q, K, mask)
        
        beta = self.dropout(beta)
        
        # === APPLY GAUGE TRANSPORT (if enabled) ===
        if self.config.use_gauge and self.config.fep_level != 'delta':
            output = self._gauge_transport(V, beta, B, N, H)
        else:
            output = beta @ V  # (B,H,N,d)
        
        # Concatenate heads
        output = output.transpose(1, 2).contiguous().view(B, N, D)
        output = self.o_proj(output)
        
        # === COMPUTE FEP ENERGY (if requested) ===
        energy_dict = None
        if return_energy and self.config.fep_level != 'delta':
            energy_dict = self._compute_fep_energy(Q, K, V, beta)
        
        self.step_count += 1
        return output, energy_dict
    
    def _compute_kl_attention(
        self,
        Q: torch.Tensor,  # (B,H,N,d) - queries (μᵢ)
        K: torch.Tensor,  # (B,H,N,d) - keys (μⱼ)
        mask: Optional[torch.Tensor]
    ) -> torch.Tensor:
        """
        Compute attention weights from KL divergence:
        β_ij ∝ exp(-D_KL(qᵢ || Ωᵢⱼqⱼ) / κ)
        """
        B, H, N, d = Q.shape
        
        # Get uncertainties
        if self.config.fep_level == 'frozen_sigma':
            # Isotropic: Σᵢ = σ²I
            sigma2 = self.sigma2.expand(B, N)
            kl = kl_gaussian_batch(
                Q[:, 0],  # Use first head for simplicity (can extend)
                sigma2, sigma2, sigma2, isotropic=True
            )
        else:
            # Full covariances (expensive!)
            sigma2 = torch.exp(self.log_sigma2[0])  # (d,)
            Sigma = torch.diag(sigma2).expand(B, N, d, d)
            kl = kl_gaussian_batch(
                Q[:, 0], Sigma, K[:, 0], Sigma, isotropic=False
            )
        
        # Compute attention weights: β = softmax(-KL / κ)
        kappa = self.config.init_sigma2 * math.sqrt(d)  # Temperature
        scores = -kl / kappa
        
        if mask is not None:
            scores = scores.masked_fill(mask[:, 0, :, :] == 0, -1e9)
        
        beta = F.softmax(scores, dim=-1)
        return beta.unsqueeze(1).expand(B, H, N, N)  # Broadcast to all heads
    
    def _gauge_transport(
        self,
        V: torch.Tensor,   # (B,H,N,d) - values
        beta: torch.Tensor,  # (B,H,N,N) - attention weights
        B: int, N: int, H: int
    ) -> torch.Tensor:
        """
        Apply gauge-covariant transport: out_i = Σⱼ βᵢⱼ Ωᵢⱼ vⱼ
        """
        K_gauge = self.K_gauge
        gauge_dim = min(K_gauge, self.d_head)
        
        # Split V into gauge and non-gauge parts
        V_gauge = V[..., :gauge_dim]
        V_other = V[..., gauge_dim:]
        
        # Compute transport operators Ωᵢⱼ for each pair
        # (This is expensive - future optimization: sparse/local transport)
        A = self.A_params[:N, :N, :]  # (N,N,3)
        
        if gauge_dim == K_gauge:
            # Compute all Ω at once (batched)
            A_flat = A.reshape(N*N, 3)
            Omega_flat = parallel_transport(A_flat, self.generators)  # (N²,K,K)
            Omega = Omega_flat.reshape(N, N, K_gauge, K_gauge)
            
            # Apply transport: out_i = Σⱼ βᵢⱼ Ωᵢⱼ vⱼ
            # V_gauge: (B,H,N,K), Omega: (N,N,K,K), beta: (B,H,N,N)
            V_transported = torch.einsum('ijkl,bhnjl->bhnik', Omega, V_gauge)
            out_gauge = torch.einsum('bhij,bhijk->bhik', beta, V_transported)
        else:
            # Dimension mismatch - use standard attention for now
            out_gauge = beta @ V_gauge
        
        # Standard attention for non-gauge dimensions
        out_other = beta @ V_other
        
        # Concatenate
        output = torch.cat([out_gauge, out_other], dim=-1)
        return output
    
    def _compute_fep_energy(
        self,
        Q: torch.Tensor,
        K: torch.Tensor,
        V: torch.Tensor,
        beta: torch.Tensor
    ) -> dict:
        """
        Compute FEP energy terms:
        𝓕 = Σᵢ D_KL(qᵢ||pᵢ) + Σᵢⱼ βᵢⱼ D_KL(qᵢ||Ωᵢⱼqⱼ) + obs_term
        
        Returns dict with energy components for training.
        """
        B, H, N, d = Q.shape
        
        energy = {}
        
        # Prior term: Σᵢ D_KL(qᵢ || p₀)
        if self.config.prior_weight > 0 and self.config.fep_level == 'full':
            # KL to centered Gaussian prior
            mu_diff = Q - self.mu_prior
            sigma2 = torch.exp(self.log_sigma2[0])
            
            # Simplified KL (isotropic case)
            kl_prior = 0.5 * (
                sigma2.sum() / self.config.init_sigma2 +
                (mu_diff ** 2).sum() / self.config.init_sigma2 -
                d +
                d * math.log(self.config.init_sigma2) -
                torch.log(sigma2).sum()
            )
            energy['kl_prior'] = self.config.prior_weight * kl_prior / (B * H * N)
        
        # *** CRITICAL: Alignment term Σᵢⱼ βᵢⱼ D_KL(qᵢ||Ωᵢⱼqⱼ) ***
        # This is NOT implicit - we must compute it explicitly!
        if self.config.beta_coupling > 0:
            # Recompute KL matrix (we computed it for attention, but need it for loss)
            if self.config.fep_level == 'frozen_sigma':
                sigma2 = self.sigma2.expand(B, N)
                kl_matrix = kl_gaussian_batch(
                    Q[:, 0], sigma2, K[:, 0], sigma2, isotropic=True
                )  # (B, N, N)
            else:
                # Full covariance case
                sigma2 = torch.exp(self.log_sigma2[0])
                Sigma = torch.diag(sigma2).expand(B, N, d, d)
                kl_matrix = kl_gaussian_batch(
                    Q[:, 0], Sigma, K[:, 0], Sigma, isotropic=False
                )  # (B, N, N)
            
            # Weighted sum: Σᵢⱼ βᵢⱼ D_KL(qᵢ||Ωᵢⱼqⱼ)
            # beta: (B, H, N, N), kl_matrix: (B, N, N)
            # Use first head for simplicity (could average over heads)
            alignment_energy = (beta[:, 0] * kl_matrix).sum() / B
            
            energy['kl_alignment'] = self.config.beta_coupling * alignment_energy
        
        return energy


class FEPTransformer(nn.Module):
    """Full transformer with FEP-consistent attention"""
    
    def __init__(self, config: FEPConfig):
        super().__init__()
        self.config = config
        
        self.token_embed = nn.Embedding(config.vocab_size, config.d_model)
        self.pos_embed = nn.Parameter(
            torch.randn(1, config.seq_len, config.d_model) * 0.02
        )
        
        # FEP attention layers
        self.layers = nn.ModuleList([
            FEPAttentionBlock(config, i) for i in range(config.n_layers)
        ])
        
        self.norm = nn.LayerNorm(config.d_model)
        self.lm_head = nn.Linear(config.d_model, config.vocab_size, bias=False)
        self.lm_head.weight = self.token_embed.weight  # Weight tying
        
        self.apply(self._init_weights)
    
    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            torch.nn.init.normal_(module.weight, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            torch.nn.init.normal_(module.weight, std=0.02)
    
    def forward(
        self,
        input_ids: torch.Tensor,
        labels: Optional[torch.Tensor] = None,
        return_fep_energy: bool = False
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor], Optional[dict]]:
        """
        Args:
            input_ids: (B, N)
            labels: (B, N)
            return_fep_energy: Whether to compute FEP energy terms
        
        Returns:
            logits: (B, N, vocab)
            loss: scalar
            fep_energy: dict of energy components
        """
        B, N = input_ids.shape
        
        # Embed
        x = self.token_embed(input_ids) + self.pos_embed[:, :N, :]
        
        # Causal mask
        mask = torch.tril(torch.ones(N, N, device=x.device, dtype=torch.bool))
        mask = mask.unsqueeze(0).unsqueeze(0)
        
        # Apply FEP layers
        total_fep_energy = {}
        for layer in self.layers:
            x, energy = layer(x, mask, return_energy=return_fep_energy)
            if energy:
                for k, v in energy.items():
                    total_fep_energy[k] = total_fep_energy.get(k, 0) + v
        
        x = self.norm(x)
        logits = self.lm_head(x)
        
        # Compute loss
        loss = None
        if labels is not None:
            # Observation term: -log p(o|μ)
            obs_loss = F.cross_entropy(
                logits.view(-1, self.config.vocab_size),
                labels.view(-1),
                ignore_index=-100
            )
            
            # Total FEP loss
            if return_fep_energy and total_fep_energy:
                fep_loss = sum(total_fep_energy.values())
                loss = obs_loss + fep_loss
                total_fep_energy['obs_loss'] = obs_loss
                total_fep_energy['fep_loss'] = fep_loss
            else:
                loss = obs_loss
        
        return logits, loss, total_fep_energy if return_fep_energy else None


class FEPAttentionBlock(nn.Module):
    """Transformer block with FEP attention"""
    
    def __init__(self, config: FEPConfig, layer_idx: int):
        super().__init__()
        self.attention = FEPAttention(config, layer_idx)
        self.norm1 = nn.LayerNorm(config.d_model)
        self.norm2 = nn.LayerNorm(config.d_model)
        
        self.ffn = nn.Sequential(
            nn.Linear(config.d_model, 4 * config.d_model),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(4 * config.d_model, config.d_model),
            nn.Dropout(config.dropout)
        )
    
    def forward(self, x, mask, return_energy=False):
        attn_out, energy = self.attention(self.norm1(x), mask, return_energy)
        x = x + attn_out
        x = x + self.ffn(self.norm2(x))
        return x, energy


# ============================================================================
#                        DEMO
# ============================================================================

if __name__ == "__main__":
    print("="*70)
    print("FEP-CONSISTENT TRANSFORMER - HYBRID IMPLEMENTATION")
    print("="*70)
    
    # Test different levels
    for level in ['delta', 'frozen_sigma', 'full']:
        print(f"\nTesting FEP level: {level}")
        print("-" * 70)
        
        config = FEPConfig(
            d_model=128,
            n_heads=4,
            n_layers=2,
            seq_len=32,
            vocab_size=1000,
            fep_level=level,
            use_gauge=(level != 'delta'),
            gauge_irrep=1,
            sigma2_fixed=1.0 if level == 'frozen_sigma' else None
        )
        
        model = FEPTransformer(config)
        n_params = sum(p.numel() for p in model.parameters())
        print(f"  Parameters: {n_params:,}")
        
        # Forward pass
        x = torch.randint(0, 1000, (2, 32))
        labels = x.clone()
        
        import time
        start = time.time()
        logits, loss, energy = model(x, labels, return_fep_energy=(level != 'delta'))
        elapsed = time.time() - start
        
        print(f"  Forward pass: {elapsed*1000:.1f} ms")
        print(f"  Output shape: {logits.shape}")
        print(f"  Loss: {loss.item():.4f}")
        
        if energy:
            print(f"  FEP energy components:")
            for k, v in energy.items():
                print(f"    {k}: {v.item():.4f}")
    
    print("\n" + "="*70)
    print("✓ All FEP levels working!")
    print("="*70)