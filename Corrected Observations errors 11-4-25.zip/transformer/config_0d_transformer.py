# -*- coding: utf-8 -*-
"""
Created on Sat Nov  1 19:01:45 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
Configuration for 0-Dimensional FEP Transformer

This config is specifically for training transformers as 0D gauge theories:
- All tokens at single base point c*
- No spatial structure
- Causal masking for autoregressive generation
- Natural gradient descent with exponential speedup
"""

import numpy as np

# ============================================================================
# GEOMETRY (0-Dimensional!)
# ============================================================================

dimension = 0  # Zero-dimensional base manifold
domain_size = (1,)  # Single point c*
base_manifold_type = "point"

# All agents at same location
fixed_location = True
agent_radius_range = (0, 0)  # No spatial extent

# ============================================================================
# GAUGE STRUCTURE
# ============================================================================

gauge_group = "SO(3)"
irrep_q = 9  # ℓ=9 → K_q = 2*9+1 = 19 dimensional representation
irrep_p = 9  # Same for model

# Gauge frames
phi_init = 0.1  # Initial frame randomness
phi_model_offset = 0.0  # No model frame offset (identical priors)
identical_models = True  # All tokens share same prior

# ============================================================================
# LEARNING RATES (Natural Gradients)
# ============================================================================

# Belief parameters (trainable)
alpha_mu_q = 0.1      # Belief means
alpha_sigma_q = 0.05  # Belief covariances  
alpha_phi = 0.05      # Belief gauge frames

# Model parameters (usually slower or frozen)
alpha_mu_p = 0.01
alpha_sigma_p = 0.01
alpha_phi_tilde = 0.01

# ============================================================================
# FREE ENERGY WEIGHTS
# ============================================================================

# KL(q||p) term
alpha = 1.0

# Agent coupling: Σ_j β_ij·KL(q_i || Ω_ij q_j)
beta_kappa_q = 0.1  # Attention strength
beta_kappa_p = 0.0  # No model coupling

# Cross-agent model alignment: Σ_j γ_ij·KL(p_i || Ω_ij p_j)
gamma_kappa_q = 0.0  # Not used for transformers
gamma_kappa_p = 0.0

# Observation energy weight
feedback_weight = 1.0
obs_scale = 1.0

# ============================================================================
# ATTENTION PARAMETERS
# ============================================================================

tau = 1.0  # Softmax temperature (√d_k in transformers)

# CRITICAL: Causal masking for autoregressive generation
use_causal_mask = True  # β_ij = 0 for j > i

# ============================================================================
# OBSERVATIONS (Language Modeling)
# ============================================================================

obs_precision = 10.0  # Λ = observation precision matrix scale
obs_dim = 16  # Dimension of observation space D_x

# ============================================================================
# INITIALIZATION RANGES
# ============================================================================

# Belief (q) parameters
q_mu_range = [0.0, 0.5]      # Random embeddings
q_sigma_range = [0.5, 1.0]   # Initial uncertainty

# Model (p) parameters  
p_mu_range = [0.0, 0.1]      # Weak prior mean
p_sigma_range = [1.0, 2.0]   # High prior uncertainty

# ============================================================================
# NUMERICAL SETTINGS
# ============================================================================

dtype = np.float32
eps = 1e-8  # Numerical stability
support_tau = 1e-6  # Support threshold

# Covariance structure
diagonal_sigma = False  # Use full covariances (more expressive)

# SPD sanitization
sigma_outside_val = 1000.0  # Large variance outside support

# Smoothing (not used for 0D)
init_smooth_sigma = 0.0
phi_init_smooth_sigma = 0.0

# ============================================================================
# NEIGHBOR GRAPH (0D: Complete graph)
# ============================================================================

# All agents interact (complete overlap at c*)
max_neighbors = None  # No limit (full attention)
overlap_eps = 0.0  # Any overlap counts
neighbors_symmetric = True

# ============================================================================
# PARALLELIZATION
# ============================================================================

n_jobs = 4  # Number of parallel workers
transport_backend = "ctx"  # Use cached transport
transport_validation = False  # Skip validation for speed

# ============================================================================
# MONITORING & VALIDATION
# ============================================================================

enable_energy_budget = True
enable_stability_monitor = True

# Energy conservation tolerance
energy_conservation_tol = 1e-3

# Stability thresholds
condition_number_warn = 1e8
condition_number_error = 1e10
gradient_norm_warn = 10.0
gradient_norm_error = 100.0

# ============================================================================
# CHECKPOINTING
# ============================================================================

checkpoint_every = 20  # Save every N batches
plot_every = 10
snapshot_every = 50

# ============================================================================
# TRANSFORMER-SPECIFIC
# ============================================================================

# Sequence length (number of tokens/agents)
max_seq_len = 128

# Vocabulary
vocab_size = None  # Set dynamically from dataset

# Multi-head attention (future)
n_heads = 1  # Currently single "head" per agent
head_dim = 19  # = K_q for ℓ=9

# Layer normalization (implicit in natural gradients)
use_layer_norm = False  # Natural gradients provide similar effect

# ============================================================================
# VALIDATION
# ============================================================================

def validate_config():
    """Check that configuration is valid for 0D transformer."""
    
    errors = []
    warnings = []
    
    # Check dimensions
    if dimension != 0:
        errors.append(f"dimension must be 0 for transformers, got {dimension}")
    
    if domain_size != (1,):
        errors.append(f"domain_size must be (1,) for single point, got {domain_size}")
    
    # Check gauge
    if irrep_q != irrep_p:
        warnings.append(f"irrep_q={irrep_q} != irrep_p={irrep_p}, bundles may not match")
    
    # Check learning rates
    if alpha_mu_q <= 0:
        errors.append(f"alpha_mu_q must be positive, got {alpha_mu_q}")
    
    # Check causal mask
    if not use_causal_mask:
        warnings.append("use_causal_mask=False: model will see future tokens!")
    
    # Check energy weights
    if alpha < 0:
        errors.append(f"alpha must be non-negative, got {alpha}")
    
    if beta_kappa_q < 0:
        errors.append(f"beta_kappa_q must be non-negative, got {beta_kappa_q}")
    
    # Report
    if errors:
        print("\n❌ Configuration ERRORS:")
        for err in errors:
            print(f"  - {err}")
        raise ValueError("Invalid configuration")
    
    if warnings:
        print("\n⚠️  Configuration WARNINGS:")
        for warn in warnings:
            print(f"  - {warn}")
    
    print("\n✅ Configuration valid for 0D transformer training")
    return True


# ============================================================================
# PRESETS
# ============================================================================

def config_small():
    """Small model for debugging."""
    global irrep_q, irrep_p, obs_dim, max_seq_len
    irrep_q = 3  # K=7
    irrep_p = 3
    obs_dim = 8
    max_seq_len = 64


def config_medium():
    """Medium model (default)."""
    global irrep_q, irrep_p, obs_dim, max_seq_len
    irrep_q = 9  # K=19
    irrep_p = 9
    obs_dim = 16
    max_seq_len = 128


def config_large():
    """Larger model."""
    global irrep_q, irrep_p, obs_dim, max_seq_len
    irrep_q = 15  # K=31
    irrep_p = 15
    obs_dim = 32
    max_seq_len = 256


if __name__ == "__main__":
    print("="*70)
    print("0-DIMENSIONAL FEP TRANSFORMER CONFIGURATION")
    print("="*70)
    
    validate_config()
    
    print(f"\nGeometry:")
    print(f"  Base manifold: {dimension}D (single point)")
    print(f"  Domain size: {domain_size}")
    
    print(f"\nGauge Theory:")
    print(f"  Group: {gauge_group}")
    print(f"  Irrep: ℓ_q={irrep_q}, ℓ_p={irrep_p}")
    print(f"  Fiber dims: K_q={(2*irrep_q+1)}, K_p={(2*irrep_p+1)}")
    
    print(f"\nAttention:")
    print(f"  Temperature: τ={tau}")
    print(f"  Causal mask: {use_causal_mask}")
    print(f"  Coupling: β={beta_kappa_q}")
    
    print(f"\nLearning:")
    print(f"  Natural gradients: α_μ={alpha_mu_q}, α_Σ={alpha_sigma_q}")
    print(f"  Exponential speedup: O(log(1/ε)) vs O(1/ε)")
    
    print(f"\nObservations:")
    print(f"  Dimension: {obs_dim}")
    print(f"  Precision: {obs_precision}")
    print(f"  Weight: {obs_scale}")
    
    print("\n" + "="*70)