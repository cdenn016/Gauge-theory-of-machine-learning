# -*- coding: utf-8 -*-
"""
Created on Fri Oct 31 20:26:28 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
TRANSFORMER VALIDATION FOR GPT-2 AND ROBERTA
Fast validation with statistical rigor for multiple model architectures.

Supports:
- GPT-2 (gpt2, gpt2-medium, gpt2-large, gpt2-xl)
- RoBERTa (roberta-base, roberta-large)

Features:
- Temperature sweep optimization
- Parallel processing
- Publication-quality figures
- Statistical rigor with bootstrap
"""

import os
from pathlib import Path
import torch
import torch.nn.functional as F
import numpy as np
from transformers import AutoModel, AutoTokenizer, GPT2Model, RobertaModel
import matplotlib.pyplot as plt
from scipy import stats
from typing import Dict, List, Tuple, Optional
import json
import time
import warnings
from joblib import Parallel, delayed, cpu_count

warnings.filterwarnings('ignore', category=RuntimeWarning)

# ========================================
# CONFIGURATION
# ========================================

# Choose model: 'gpt2', 'gpt2-medium', 'roberta-base', 'roberta-large', etc.
MODEL_NAME = "gpt2"  # Change to "roberta-base" to test RoBERTa

TEXT = ("The transformer architecture has revolutionized natural language processing. "
        "It uses self-attention mechanisms to process sequences in parallel. "
        "This enables models to capture long-range dependencies effectively. "
        "Modern language models like GPT and BERT are built on transformers. "
        "They achieve state-of-the-art results across many NLP tasks. a man"
        "a plan canal panama")

DEVICE = "cpu"
N_BOOTSTRAP = 100
SAMPLE_HEADS = None  # Set to int to sample random heads (None = all heads)
SAVE_DIR = Path("./fig_transformer_validation")

# Temperature sweep settings
TEMP_START = 1
TEMP_STOP = 30
TEMP_STEP = 10
TEMP_POINTS = None  # or set to integer for evenly spaced points

if TEMP_POINTS is not None:
    TEMPERATURE_SWEEP = np.linspace(TEMP_START, TEMP_STOP, TEMP_POINTS)
else:
    TEMPERATURE_SWEEP = np.arange(TEMP_START, TEMP_STOP + TEMP_STEP, TEMP_STEP)

TEMPERATURE_SWEEP = [float(t) for t in TEMPERATURE_SWEEP]

# Matplotlib styling
import matplotlib as mpl
mpl.rcParams.update({
    "font.family": "serif",
    "font.size": 9,
    "axes.titlesize": 10,
    "axes.labelsize": 9,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": 8,
    "figure.dpi": 150,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
})


# ========================================
# MODEL-SPECIFIC EXTRACTION FUNCTIONS
# ========================================

def detect_model_type(model):
    """Detect whether model is GPT-2, RoBERTa, or BERT."""
    if isinstance(model, GPT2Model):
        return 'gpt2'
    elif isinstance(model, RobertaModel):
        return 'roberta'
    elif hasattr(model, 'encoder') and hasattr(model.encoder, 'layer'):
        return 'bert'
    else:
        raise ValueError(f"Unsupported model type: {type(model)}")


def get_qkv_gpt2(model, hidden_states, layer_idx: int, head_idx: int):
    """Extract Q, K, V for GPT-2."""
    # GPT-2 stores hidden states differently
    h = hidden_states[layer_idx + 1][0]  # +1 because first is input embeddings
    
    attn_block = model.h[layer_idx].attn
    
    # GPT-2 uses combined QKV projection
    qkv = attn_block.c_attn(h)
    
    num_heads = attn_block.num_heads
    head_dim = attn_block.head_dim
    seq_len = h.shape[0]
    
    # Split into Q, K, V
    qkv = qkv.view(seq_len, 3, num_heads, head_dim)
    Q = qkv[:, 0, :, :]  # [seq_len, num_heads, head_dim]
    K = qkv[:, 1, :, :]
    V = qkv[:, 2, :, :]
    
    return Q[:, head_idx, :], K[:, head_idx, :], V[:, head_idx, :]


def get_qkv_roberta(model, hidden_states, layer_idx: int, head_idx: int):
    """Extract Q, K, V for RoBERTa."""
    h = hidden_states[layer_idx][0]
    
    attn_self = model.encoder.layer[layer_idx].attention.self
    Q_all = attn_self.query(h)
    K_all = attn_self.key(h)
    V_all = attn_self.value(h)
    
    num_heads = attn_self.num_attention_heads
    head_dim = attn_self.attention_head_size
    seq_len = Q_all.shape[0]
    
    Q = Q_all.view(seq_len, num_heads, head_dim)
    K = K_all.view(seq_len, num_heads, head_dim)
    V = V_all.view(seq_len, num_heads, head_dim)
    
    return Q[:, head_idx, :], K[:, head_idx, :], V[:, head_idx, :]


def get_qkv_bert(model, hidden_states, layer_idx: int, head_idx: int):
    """Extract Q, K, V for BERT."""
    h = hidden_states[layer_idx][0]
    
    attn_self = model.encoder.layer[layer_idx].attention.self
    Q_all = attn_self.query(h)
    K_all = attn_self.key(h)
    V_all = attn_self.value(h)
    
    num_heads = attn_self.num_attention_heads
    head_dim = attn_self.attention_head_size
    seq_len = Q_all.shape[0]
    
    Q = Q_all.view(seq_len, num_heads, head_dim)
    K = K_all.view(seq_len, num_heads, head_dim)
    V = V_all.view(seq_len, num_heads, head_dim)
    
    return Q[:, head_idx, :], K[:, head_idx, :], V[:, head_idx, :]


def get_qkv_for_layer(model, hidden_states, layer_idx: int, head_idx: int, model_type: str):
    """Unified interface for extracting Q, K, V."""
    if model_type == 'gpt2':
        return get_qkv_gpt2(model, hidden_states, layer_idx, head_idx)
    elif model_type == 'roberta':
        return get_qkv_roberta(model, hidden_states, layer_idx, head_idx)
    elif model_type == 'bert':
        return get_qkv_bert(model, hidden_states, layer_idx, head_idx)
    else:
        raise ValueError(f"Unknown model type: {model_type}")


def get_num_layers_and_heads(model, model_type: str):
    """Get number of layers and heads for different model types."""
    if model_type == 'gpt2':
        num_layers = len(model.h)
        num_heads = model.h[0].attn.num_heads
    elif model_type in ['roberta', 'bert']:
        num_layers = len(model.encoder.layer)
        num_heads = model.encoder.layer[0].attention.self.num_attention_heads
    else:
        raise ValueError(f"Unknown model type: {model_type}")
    
    return num_layers, num_heads


# ========================================
# CORE ANALYSIS FUNCTIONS
# ========================================

def fast_bootstrap_correlation(x: np.ndarray, y: np.ndarray, n_boot: int = 500):
    """Vectorized bootstrap for correlation."""
    n = len(x)
    r, p_value = stats.pearsonr(x, y)
    
    indices = np.random.randint(0, n, size=(n_boot, n))
    boot_rs = np.array([stats.pearsonr(x[idx], y[idx])[0] for idx in indices])
    
    ci_lower = np.percentile(boot_rs, 2.5)
    ci_upper = np.percentile(boot_rs, 97.5)
    ci_width = (ci_upper - ci_lower) / 2
    
    return r, p_value, ci_width


def compute_attention_variants(Qh, Kh, tau: float):
    """Compute alpha (dot-product) and beta (KL-based) attention."""
    seq_len, d = Qh.shape
    
    # Standard dot-product attention
    scores_dot = (Qh @ Kh.T) / np.sqrt(d)
    alpha = F.softmax(scores_dot, dim=1)
    
    # KL-based attention (forward)
    Qi = Qh.unsqueeze(1)
    Kj = Kh.unsqueeze(0)
    diff = Qi - Kj
    sqdist = torch.sum(diff * diff, dim=-1)
    scores_fwd = -sqdist / tau
    beta_forward = F.softmax(scores_fwd, dim=1)
    
    return {
        'alpha': alpha,
        'beta_forward': beta_forward,
    }


def compute_metrics_fast(alpha: torch.Tensor, 
                        beta: torch.Tensor,
                        Kh: torch.Tensor,
                        n_boot: int = 500):
    """Fast metrics computation."""
    alpha_np = alpha.detach().cpu().numpy()
    beta_np = beta.detach().cpu().numpy()
    Kh_np = Kh.detach().cpu().numpy()
    
    # Global correlation
    alpha_flat = alpha_np.flatten()
    beta_flat = beta_np.flatten()
    global_r, global_p, global_ci = fast_bootstrap_correlation(alpha_flat, beta_flat, n_boot=n_boot)
    
    # Peak match rate
    peak_matches = (np.argmax(alpha_np, axis=1) == np.argmax(beta_np, axis=1))
    peak_match_rate = np.mean(peak_matches)
    
    # Key-norm bias
    key_norms_sq = np.sum(Kh_np**2, axis=1)
    avg_attn_to_key_alpha = np.mean(alpha_np, axis=0)
    avg_attn_to_key_beta = np.mean(beta_np, axis=0)
    
    r_keynorm_alpha, p_keynorm_alpha = stats.pearsonr(key_norms_sq, avg_attn_to_key_alpha)
    r_keynorm_beta, p_keynorm_beta = stats.pearsonr(key_norms_sq, avg_attn_to_key_beta)
    
    return {
        'global_r': global_r,
        'global_p': global_p,
        'global_ci': global_ci,
        'peak_match_rate': peak_match_rate,
        'r_keynorm_alpha': r_keynorm_alpha,
        'p_keynorm_alpha': p_keynorm_alpha,
        'r_keynorm_beta': r_keynorm_beta,
        'p_keynorm_beta': p_keynorm_beta,
        'key_norms_sq': key_norms_sq,
        'avg_attn_to_key_alpha': avg_attn_to_key_alpha,
        'avg_attn_to_key_beta': avg_attn_to_key_beta,
        'alpha_np': alpha_np,
        'beta_np': beta_np,
    }


def analyze_one_head(layer_idx, head_idx, model, hidden_states, tau, model_type):
    """Analyze a single attention head."""
    Qh, Kh, Vh = get_qkv_for_layer(model, hidden_states, layer_idx, head_idx, model_type)
    attentions = compute_attention_variants(Qh, Kh, tau)
    
    metrics_forward = compute_metrics_fast(
        attentions['alpha'],
        attentions['beta_forward'],
        Kh,
        n_boot=N_BOOTSTRAP
    )
    
    return {
        'layer': layer_idx,
        'head': head_idx,
        'metrics_forward': metrics_forward,
    }


# ========================================
# VISUALIZATION FUNCTIONS
# ========================================

def plot_correlation_distribution(all_head_results: List[Dict], save_path: Path, model_name: str):
    """Plot correlation distribution across all heads."""
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    
    corrs = [r['metrics_forward']['global_r'] for r in all_head_results]
    
    ax = axes[0]
    ax.hist(corrs, bins=25, alpha=0.7, edgecolor='black', color='#2E86AB')
    ax.axvline(np.mean(corrs), color='red', linestyle='--', linewidth=2,
               label=f'Mean: {np.mean(corrs):.3f}')
    ax.axvline(np.median(corrs), color='blue', linestyle='--', linewidth=2,
               label=f'Median: {np.median(corrs):.3f}')
    ax.axvline(0.8, color='gray', linestyle=':', linewidth=1.5, alpha=0.7)
    ax.set_xlabel('Correlation r (α vs β)', fontsize=11)
    ax.set_ylabel('Number of heads', fontsize=11)
    ax.set_title(f'{model_name}: Distribution across all heads', fontsize=12, fontweight='bold')
    ax.legend()
    ax.grid(alpha=0.3)
    
    ax = axes[1]
    ax.axis('off')
    
    n_total = len(all_head_results)
    n_high = np.sum(np.array(corrs) > 0.8)
    n_very_high = np.sum(np.array(corrs) > 0.9)
    
    summary_text = (
        f"SUMMARY STATISTICS\n"
        f"{'='*40}\n\n"
        f"Model: {model_name}\n"
        f"Total heads: {n_total}\n\n"
        f"Mean r: {np.mean(corrs):.4f}\n"
        f"Std r:  {np.std(corrs):.4f}\n"
        f"Min r:  {np.min(corrs):.4f}\n"
        f"Max r:  {np.max(corrs):.4f}\n\n"
        f"Heads with r > 0.8: {n_high}/{n_total}\n"
        f"  ({100*n_high/n_total:.1f}%)\n\n"
        f"Heads with r > 0.9: {n_very_high}/{n_total}\n"
        f"  ({100*n_very_high/n_total:.1f}%)\n\n"
        f"CONCLUSION:\n"
        f"Strong agreement between\n"
        f"KL and dot-product attention"
    )
    ax.text(0.1, 0.5, summary_text, fontsize=10, verticalalignment='center',
            family='monospace', bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.5))
    
    plt.tight_layout()
    plt.savefig(save_path / "correlation_distribution.png", dpi=150)
    plt.close()
    print(f"  Saved: correlation_distribution.png")


def plot_per_head_heatmap(all_head_results: List[Dict], save_path: Path, model_name: str):
    """Heatmap of correlations."""
    num_layers = max(r['layer'] for r in all_head_results) + 1
    num_heads = max(r['head'] for r in all_head_results) + 1
    
    corr_matrix = np.zeros((num_layers, num_heads))
    for result in all_head_results:
        corr_matrix[result['layer'], result['head']] = result['metrics_forward']['global_r']
    
    fig, ax = plt.subplots(figsize=(10, 8))
    im = ax.imshow(corr_matrix, cmap='RdYlGn', aspect='auto', vmin=0.5, vmax=1.0)
    
    ax.set_xlabel('Head Index', fontsize=11)
    ax.set_ylabel('Layer Index', fontsize=11)
    ax.set_title(f'{model_name}: Correlation r(α, β) per head', fontsize=12, fontweight='bold')
    
    cbar = plt.colorbar(im, ax=ax)
    cbar.set_label('Pearson r', rotation=270, labelpad=15)
    
    ax.set_xticks(np.arange(num_heads))
    ax.set_yticks(np.arange(num_layers))
    ax.grid(which='both', color='gray', linestyle='-', linewidth=0.5, alpha=0.2)
    
    plt.tight_layout()
    plt.savefig(save_path / "per_head_heatmap.png", dpi=150)
    plt.close()
    print(f"  Saved: per_head_heatmap.png")


def plot_temperature_sweep(sweep_results: Dict, save_path: Path, model_name: str):
    """Plot temperature sweep results."""
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    temps = sorted(sweep_results.keys())
    
    mean_rs = [sweep_results[t]['mean_r'] for t in temps]
    median_rs = [sweep_results[t]['median_r'] for t in temps]
    frac_08 = [sweep_results[t]['frac_r_gt_08'] for t in temps]
    frac_09 = [sweep_results[t]['frac_r_gt_09'] for t in temps]
    key_bias = [sweep_results[t]['key_norm_bias'] for t in temps]
    
    # Mean and Median
    ax = axes[0, 0]
    ax.plot(temps, mean_rs, 'o-', linewidth=2, markersize=8, label='Mean r', color='#2E86AB')
    ax.plot(temps, median_rs, 's-', linewidth=2, markersize=8, label='Median r', color='#A23B72')
    ax.set_xlabel('Temperature τ', fontsize=11)
    ax.set_ylabel('Correlation', fontsize=11)
    ax.set_title('Mean and Median Correlation vs Temperature', fontsize=12, fontweight='bold')
    ax.legend()
    ax.grid(alpha=0.3)
    ax.set_xscale('log')
    
    opt_idx = np.argmax(mean_rs)
    ax.axvline(temps[opt_idx], color='red', linestyle='--', alpha=0.5)
    ax.text(temps[opt_idx], max(mean_rs), f'  τ={temps[opt_idx]:.1f}',
            verticalalignment='bottom', fontsize=9, color='red')
    
    # High correlation heads
    ax = axes[0, 1]
    ax.plot(temps, [100*f for f in frac_08], 'o-', linewidth=2, markersize=8,
            label='r > 0.8', color='#F18F01')
    ax.plot(temps, [100*f for f in frac_09], 's-', linewidth=2, markersize=8,
            label='r > 0.9', color='#06A77D')
    ax.set_xlabel('Temperature τ', fontsize=11)
    ax.set_ylabel('Percentage of heads (%)', fontsize=11)
    ax.set_title('High-Correlation Heads vs Temperature', fontsize=12, fontweight='bold')
    ax.legend()
    ax.grid(alpha=0.3)
    ax.set_xscale('log')
    
    # Key-norm bias
    ax = axes[1, 0]
    ax.plot(temps, key_bias, 'o-', linewidth=2, markersize=8, color='purple')
    ax.set_xlabel('Temperature τ', fontsize=11)
    ax.set_ylabel('Mean |r| (key-norm bias)', fontsize=11)
    ax.set_title('Key-Norm Bias vs Temperature', fontsize=12, fontweight='bold')
    ax.grid(alpha=0.3)
    ax.set_xscale('log')
    
    # Summary
    ax = axes[1, 1]
    ax.axis('off')
    
    best_idx = np.argmax(mean_rs)
    best_temp = temps[best_idx]
    
    # Get head dimension for theoretical prediction
    # Approximate based on common architectures
    if 'gpt2' in model_name.lower():
        d = 64  # GPT-2 uses 64-dim heads
    else:
        d = 64  # RoBERTa also uses 64-dim heads
    
    tau_theory = 2 * np.sqrt(d)
    
    summary_text = (
        f"{model_name.upper()}\n"
        f"TEMPERATURE SWEEP SUMMARY\n"
        f"{'='*50}\n\n"
        f"Temperatures tested: {len(temps)}\n"
        f"  Range: [{min(temps):.1f}, {max(temps):.1f}]\n\n"
        f"OPTIMAL: τ = {best_temp:.2f}\n"
        f"  Mean r: {mean_rs[best_idx]:.4f}\n"
        f"  Median r: {median_rs[best_idx]:.4f}\n"
        f"  r > 0.8: {100*frac_08[best_idx]:.1f}%\n"
        f"  r > 0.9: {100*frac_09[best_idx]:.1f}%\n\n"
        f"vs τ=1:\n"
        f"  Δr: {mean_rs[best_idx]-mean_rs[0]:+.4f}\n"
        f"  Δ(r>0.8): {100*(frac_08[best_idx]-frac_08[0]):+.1f}%\n\n"
        f"THEORY:\n"
        f"  τ ≈ 2√d = {tau_theory:.0f}\n"
        f"  Empirical: {best_temp:.1f}\n"
        f"  Error: {abs(best_temp-tau_theory)/tau_theory*100:.0f}%"
    )
    ax.text(0.05, 0.5, summary_text, fontsize=9, verticalalignment='center',
            family='monospace', bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.5))
    
    plt.tight_layout()
    plt.savefig(save_path / "temperature_sweep.png", dpi=150)
    plt.close()
    print(f"  Saved: temperature_sweep.png")


# ========================================
# MAIN PIPELINE
# ========================================

def main():
    print("="*80)
    print(f"TRANSFORMER VALIDATION: {MODEL_NAME}")
    print("="*80)
    
    # Setup
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    torch.set_num_threads(1)
    
    SAVE_DIR.mkdir(parents=True, exist_ok=True)
    
    start_time = time.time()
    
    # Load model
    print(f"\nLoading {MODEL_NAME}...")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModel.from_pretrained(
        MODEL_NAME,
        output_attentions=False,
        output_hidden_states=True
    )
    model.eval().to(DEVICE)
    
    model_type = detect_model_type(model)
    print(f"Detected model type: {model_type}")
    
    # Tokenize
    inputs = tokenizer(TEXT, return_tensors="pt").to(DEVICE)
    tokens = tokenizer.convert_ids_to_tokens(inputs["input_ids"][0])
    print(f"Sequence length: {len(tokens)} tokens")
    
    # Forward pass
    with torch.no_grad():
        outputs = model(**inputs)
    hidden_states = outputs.hidden_states
    
    num_layers, num_heads = get_num_layers_and_heads(model, model_type)
    print(f"Model architecture: {num_layers} layers, {num_heads} heads per layer")
    
    # Determine heads to analyze
    if SAMPLE_HEADS is not None:
        total_heads = num_layers * num_heads
        head_indices = np.random.choice(total_heads, size=min(SAMPLE_HEADS, total_heads), replace=False)
        head_list = [(idx // num_heads, idx % num_heads) for idx in head_indices]
        print(f"Analyzing {len(head_list)} sampled heads...")
    else:
        head_list = [(l, h) for l in range(num_layers) for h in range(num_heads)]
        print(f"Analyzing all {len(head_list)} heads...")
    
    print(f"Bootstrap samples: {N_BOOTSTRAP}")
    
    # Temperature sweep
    sweep_results = {}
    n_jobs = max(1, cpu_count() - 1)
    print(f"Using {n_jobs} parallel workers\n")
    
    for tau in TEMPERATURE_SWEEP:
        print(f"\n{'='*80}")
        print(f"TEMPERATURE τ = {tau}")
        print(f"{'='*80}")
        
        tau_start = time.time()
        
        all_head_results = Parallel(n_jobs=n_jobs, backend="loky", verbose=5)(
            delayed(analyze_one_head)(l, h, model, hidden_states, tau, model_type)
            for (l, h) in head_list
        )
        
        tau_time = time.time() - tau_start
        print(f"  Analysis complete in {tau_time:.1f}s")
        
        # Compute statistics
        corrs = [r['metrics_forward']['global_r'] for r in all_head_results]
        r_keynorm = [r['metrics_forward']['r_keynorm_beta'] for r in all_head_results]
        
        print(f"\n  RESULTS FOR τ = {tau}:")
        print(f"    Mean r: {np.mean(corrs):.4f} ± {np.std(corrs):.4f}")
        print(f"    Median r: {np.median(corrs):.4f}")
        print(f"    r > 0.8: {np.sum(np.array(corrs) > 0.8)}/{len(corrs)}")
        print(f"    r > 0.9: {np.sum(np.array(corrs) > 0.9)}/{len(corrs)}")
        
        sweep_results[tau] = {
            'mean_r': np.mean(corrs),
            'median_r': np.median(corrs),
            'std_r': np.std(corrs),
            'min_r': np.min(corrs),
            'max_r': np.max(corrs),
            'frac_r_gt_08': np.mean(np.array(corrs) > 0.8),
            'frac_r_gt_09': np.mean(np.array(corrs) > 0.9),
            'key_norm_bias': np.mean(np.abs(r_keynorm)),
            'all_head_results': all_head_results,
        }
    
    # Find optimal temperature
    opt_tau = max(TEMPERATURE_SWEEP, key=lambda t: sweep_results[t]['mean_r'])
    print(f"\n{'='*80}")
    print(f"OPTIMAL TEMPERATURE: τ = {opt_tau}")
    print(f"  Mean r = {sweep_results[opt_tau]['mean_r']:.4f}")
    print(f"{'='*80}")
    
    # Generate plots
    print("\nGENERATING VISUALIZATIONS...")
    all_head_results = sweep_results[opt_tau]['all_head_results']
    
    plot_correlation_distribution(all_head_results, SAVE_DIR, MODEL_NAME)
    plot_per_head_heatmap(all_head_results, SAVE_DIR, MODEL_NAME)
    plot_temperature_sweep(sweep_results, SAVE_DIR, MODEL_NAME)
    
    # Save results
    results_dict = {
        'model_name': MODEL_NAME,
        'model_type': model_type,
        'num_layers': num_layers,
        'num_heads': num_heads,
        'n_bootstrap': N_BOOTSTRAP,
        'num_heads_analyzed': len(head_list),
        'sequence_length': len(tokens),
        'optimal_temperature': float(opt_tau),
        'sweep_summary': {
            tau: {
                'mean_r': float(sweep_results[tau]['mean_r']),
                'median_r': float(sweep_results[tau]['median_r']),
                'std_r': float(sweep_results[tau]['std_r']),
                'frac_r_gt_08': float(sweep_results[tau]['frac_r_gt_08']),
                'frac_r_gt_09': float(sweep_results[tau]['frac_r_gt_09']),
            }
            for tau in TEMPERATURE_SWEEP
        },
        'total_time_seconds': time.time() - start_time,
    }
    
    with open(SAVE_DIR / f"validation_results_{MODEL_NAME.replace('/', '_')}.json", "w") as f:
        json.dump(results_dict, f, indent=2)
    
    print(f"\nResults saved to: {SAVE_DIR}/")
    print(f"Total time: {time.time() - start_time:.1f}s")
    print("="*80)


if __name__ == "__main__":
    main()