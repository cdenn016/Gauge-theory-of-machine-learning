# -*- coding: utf-8 -*-
"""
Created on Fri Oct 31 20:27:03 2025

@author: chris and christine
"""

# -*- coding: utf-8 -*-
"""
PUBLICATION-QUALITY FIGURES FOR GPT-2 AND ROBERTA

Creates Nature/Science compatible figures for transformer validation results.
Supports comparison between different model architectures.

Features:
- High-resolution vector graphics (PDF + SVG)
- Professional styling
- Model comparison plots
- Statistical rigor visualization
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import patches
from pathlib import Path
from typing import Dict, List
import seaborn as sns

# ========================================
# PUBLICATION STYLING
# ========================================

NATURE_STYLE = {
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
    'font.size': 7,
    'axes.labelsize': 7,
    'axes.titlesize': 8,
    'xtick.labelsize': 6,
    'ytick.labelsize': 6,
    'legend.fontsize': 6,
    'figure.titlesize': 8,
    'figure.dpi': 300,
    'savefig.dpi': 600,
    'savefig.bbox': 'tight',
    'savefig.pad_inches': 0.05,
    'axes.linewidth': 0.5,
    'axes.labelpad': 3,
    'xtick.major.width': 0.5,
    'ytick.major.width': 0.5,
    'xtick.major.size': 2,
    'ytick.major.size': 2,
    'lines.linewidth': 1.0,
    'lines.markersize': 3,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.grid': False,
}

# Color schemes for different models
MODEL_COLORS = {
    'gpt2': '#2E86AB',           # Blue
    'gpt2-medium': '#1A5F7A',    # Dark blue
    'gpt2-large': '#0C3C53',     # Darker blue
    'roberta-base': '#A23B72',   # Purple
    'roberta-large': '#7A1D54',  # Dark purple
    'bert-base': '#06A77D',      # Green (for comparison)
}

COLORS = {
    'primary': '#2E86AB',
    'secondary': '#A23B72',
    'accent': '#F18F01',
    'success': '#06A77D',
    'warning': '#D9534F',
    'neutral': '#6C757D',
    'light': '#E9ECEF',
}

def apply_publication_style():
    """Apply Nature/Science style."""
    plt.style.use('default')
    plt.rcParams.update(NATURE_STYLE)


# ========================================
# FIGURE 1: TEMPERATURE SWEEP
# ========================================

def plot_temperature_sweep_publication(sweep_results: Dict, 
                                      save_path: Path,
                                      model_name: str):
    """Publication-quality temperature sweep figure."""
    apply_publication_style()
    
    fig = plt.figure(figsize=(7, 5))
    gs = fig.add_gridspec(2, 3, hspace=0.4, wspace=0.4)
    
    temps = sorted(sweep_results.keys())
    
    mean_rs = [sweep_results[t]['mean_r'] for t in temps]
    median_rs = [sweep_results[t]['median_r'] for t in temps]
    std_rs = [sweep_results[t]['std_r'] for t in temps]
    frac_08 = [100*sweep_results[t]['frac_r_gt_08'] for t in temps]
    frac_09 = [100*sweep_results[t]['frac_r_gt_09'] for t in temps]
    key_bias = [sweep_results[t]['key_norm_bias'] for t in temps]
    
    opt_idx = np.argmax(mean_rs)
    opt_temp = temps[opt_idx]
    
    # Panel A: Mean correlation
    ax1 = fig.add_subplot(gs[0, :2])
    
    model_color = MODEL_COLORS.get(model_name.lower(), COLORS['primary'])
    
    ax1.errorbar(temps, mean_rs, yerr=std_rs, marker='o', markersize=5,
                 linewidth=1.5, capsize=3, capthick=1.5,
                 color=model_color, label='Mean $r$')
    ax1.plot(temps, median_rs, marker='s', markersize=4,
             linewidth=1.5, color=COLORS['secondary'], alpha=0.7, label='Median $r$')
    
    ax1.axvline(opt_temp, color=COLORS['warning'], linestyle='--', 
                linewidth=1.5, alpha=0.7, label=f'Optimal $\\tau$ = {opt_temp:.1f}')
    ax1.axhline(0.8, color=COLORS['neutral'], linestyle=':', 
                linewidth=1, alpha=0.5)
    
    # Theoretical prediction (assume 64-dim heads)
    d = 64
    tau_theory = 2 * np.sqrt(d)
    ax1.axvline(tau_theory, color=COLORS['success'], linestyle=':', 
                linewidth=1.5, alpha=0.7, label=f'Theory: $\\tau \\approx {tau_theory:.0f}$')
    
    ax1.set_xlabel('Temperature $\\tau$', fontweight='bold')
    ax1.set_ylabel('Correlation $r$', fontweight='bold')
    ax1.set_xscale('log')
    ax1.legend(frameon=False, loc='lower right')
    ax1.text(-0.15, 1.05, 'a', transform=ax1.transAxes, 
             fontsize=10, fontweight='bold', va='top')
    
    ax1.annotate(f'{mean_rs[opt_idx]:.3f}',
                xy=(opt_temp, mean_rs[opt_idx]),
                xytext=(opt_temp*1.5, mean_rs[opt_idx]+0.02),
                fontsize=6, ha='left',
                arrowprops=dict(arrowstyle='->', lw=0.5, color=COLORS['warning']))
    
    # Panel B: High-correlation heads
    ax2 = fig.add_subplot(gs[0, 2])
    
    width = 0.35
    x_pos = np.arange(len(temps))
    
    ax2.bar(x_pos - width/2, frac_08, width, 
            color=COLORS['accent'], alpha=0.8, label='$r > 0.8$')
    ax2.bar(x_pos + width/2, frac_09, width,
            color=COLORS['success'], alpha=0.8, label='$r > 0.9$')
    
    ax2.set_xlabel('$\\tau$', fontweight='bold')
    ax2.set_ylabel('Heads (%)', fontweight='bold')
    ax2.set_xticks(x_pos[::max(1, len(temps)//5)])
    ax2.set_xticklabels([f'{t:.1f}' if t < 1 else f'{int(t)}' 
                         for t in temps[::max(1, len(temps)//5)]], rotation=45)
    ax2.legend(frameon=False, loc='upper left')
    ax2.text(-0.35, 1.05, 'b', transform=ax2.transAxes,
             fontsize=10, fontweight='bold', va='top')
    
    # Panel C: Key-norm bias
    ax3 = fig.add_subplot(gs[1, :2])
    
    ax3.plot(temps, key_bias, marker='D', markersize=4,
             linewidth=1.5, color=COLORS['secondary'])
    ax3.fill_between(temps, key_bias, alpha=0.2, color=COLORS['secondary'])
    
    ax3.set_xlabel('Temperature $\\tau$', fontweight='bold')
    ax3.set_ylabel('Key-norm bias $|\\rho|$', fontweight='bold')
    ax3.set_xscale('log')
    ax3.text(-0.15, 1.05, 'c', transform=ax3.transAxes,
             fontsize=10, fontweight='bold', va='top')
    
    # Panel D: Summary
    ax4 = fig.add_subplot(gs[1, 2])
    ax4.axis('off')
    
    summary_text = (
        f"{model_name.upper()}\n"
        f"\n"
        f"Optimal: $\\tau$ = {opt_temp:.1f}\n"
        f"Mean $r$ = {mean_rs[opt_idx]:.3f}\n"
        f"Median $r$ = {median_rs[opt_idx]:.3f}\n"
        f"\n"
        f"$r > 0.8$: {frac_08[opt_idx]:.1f}%\n"
        f"$r > 0.9$: {frac_09[opt_idx]:.1f}%\n"
        f"\n"
        f"vs. $\\tau$=1:\n"
        f"$\\Delta r$ = +{(mean_rs[opt_idx]-mean_rs[0])*100:.1f}%\n"
        f"\n"
        f"Theory: $\\tau \\approx {tau_theory:.0f}$\n"
        f"Error: {abs(opt_temp-tau_theory)/tau_theory*100:.0f}%"
    )
    
    ax4.text(0.1, 0.9, summary_text, transform=ax4.transAxes,
             fontsize=6, verticalalignment='top', family='monospace',
             bbox=dict(boxstyle='round', facecolor=COLORS['light'], 
                      edgecolor=COLORS['neutral'], linewidth=0.5))
    ax4.text(-0.35, 1.05, 'd', transform=ax4.transAxes,
             fontsize=10, fontweight='bold', va='top')
    
    # Save
    for fmt in ['pdf', 'svg', 'png']:
        plt.savefig(save_path / f"fig1_temperature_sweep_{model_name}.{fmt}", 
                   dpi=600 if fmt == 'png' else None, bbox_inches='tight')
    
    plt.close()
    print(f"  Saved: fig1_temperature_sweep_{model_name}")


# ========================================
# FIGURE 2: MODEL COMPARISON
# ========================================

def plot_model_comparison(results_dict: Dict[str, Dict], save_path: Path):
    """
    Compare multiple models side-by-side.
    
    Parameters:
    -----------
    results_dict : dict
        Dictionary mapping model_name -> sweep_results
    """
    apply_publication_style()
    
    fig, axes = plt.subplots(2, 2, figsize=(7, 6))
    
    model_names = list(results_dict.keys())
    
    # Panel A: Optimal temperature comparison
    ax = axes[0, 0]
    
    opt_temps = []
    opt_mean_rs = []
    colors = []
    
    for model_name in model_names:
        sweep_results = results_dict[model_name]
        temps = sorted(sweep_results.keys())
        mean_rs = [sweep_results[t]['mean_r'] for t in temps]
        opt_idx = np.argmax(mean_rs)
        opt_temps.append(temps[opt_idx])
        opt_mean_rs.append(mean_rs[opt_idx])
        colors.append(MODEL_COLORS.get(model_name.lower(), COLORS['primary']))
    
    x_pos = np.arange(len(model_names))
    ax.bar(x_pos, opt_temps, color=colors, alpha=0.8, edgecolor='black', linewidth=0.5)
    
    # Add theoretical line
    ax.axhline(16, color='red', linestyle='--', linewidth=1.5, 
               alpha=0.7, label='Theory: $\\tau \\approx 16$')
    
    ax.set_ylabel('Optimal $\\tau$', fontweight='bold')
    ax.set_xticks(x_pos)
    ax.set_xticklabels(model_names, rotation=45, ha='right')
    ax.legend(frameon=False)
    ax.text(-0.15, 1.05, 'a', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top')
    
    # Panel B: Best correlation comparison
    ax = axes[0, 1]
    
    ax.bar(x_pos, opt_mean_rs, color=colors, alpha=0.8, edgecolor='black', linewidth=0.5)
    ax.axhline(0.8, color='gray', linestyle=':', linewidth=1, alpha=0.5)
    
    ax.set_ylabel('Mean correlation $r$', fontweight='bold')
    ax.set_xticks(x_pos)
    ax.set_xticklabels(model_names, rotation=45, ha='right')
    ax.set_ylim([0.5, 1.0])
    ax.text(-0.15, 1.05, 'b', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top')
    
    # Panel C: Temperature sweep overlay
    ax = axes[1, 0]
    
    for model_name in model_names:
        sweep_results = results_dict[model_name]
        temps = sorted(sweep_results.keys())
        mean_rs = [sweep_results[t]['mean_r'] for t in temps]
        color = MODEL_COLORS.get(model_name.lower(), COLORS['primary'])
        ax.plot(temps, mean_rs, 'o-', linewidth=1.5, markersize=4,
                label=model_name, color=color)
    
    ax.set_xlabel('Temperature $\\tau$', fontweight='bold')
    ax.set_ylabel('Mean correlation $r$', fontweight='bold')
    ax.set_xscale('log')
    ax.legend(frameon=False, fontsize=5)
    ax.grid(alpha=0.3)
    ax.text(-0.15, 1.05, 'c', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top')
    
    # Panel D: Summary table
    ax = axes[1, 1]
    ax.axis('off')
    
    summary_lines = ["MODEL COMPARISON\n" + "="*30 + "\n"]
    for i, model_name in enumerate(model_names):
        summary_lines.append(
            f"{model_name}:\n"
            f"  τ* = {opt_temps[i]:.1f}\n"
            f"  r* = {opt_mean_rs[i]:.3f}\n"
        )
    
    summary_text = "\n".join(summary_lines)
    ax.text(0.1, 0.9, summary_text, transform=ax.transAxes,
            fontsize=6, verticalalignment='top', family='monospace',
            bbox=dict(boxstyle='round', facecolor=COLORS['light'], 
                     edgecolor=COLORS['neutral'], linewidth=0.5))
    ax.text(-0.15, 1.05, 'd', transform=ax.transAxes,
            fontsize=10, fontweight='bold', va='top')
    
    plt.tight_layout()
    
    for fmt in ['pdf', 'svg', 'png']:
        plt.savefig(save_path / f"fig_model_comparison.{fmt}",
                   dpi=600 if fmt == 'png' else None, bbox_inches='tight')
    
    plt.close()
    print(f"  Saved: fig_model_comparison")


# ========================================
# FIGURE 3: ARCHITECTURE ANALYSIS
# ========================================

def plot_architecture_analysis(all_head_results: List[Dict],
                               save_path: Path,
                               model_name: str):
    """Analyze correlation patterns across architecture."""
    apply_publication_style()
    
    fig = plt.figure(figsize=(7, 4))
    gs = fig.add_gridspec(1, 3, wspace=0.4)
    
    # Extract layer-wise statistics
    num_layers = max(r['layer'] for r in all_head_results) + 1
    num_heads = max(r['head'] for r in all_head_results) + 1
    
    layer_mean_r = []
    layer_std_r = []
    
    for layer in range(num_layers):
        layer_corrs = [r['metrics_forward']['global_r'] 
                      for r in all_head_results if r['layer'] == layer]
        layer_mean_r.append(np.mean(layer_corrs))
        layer_std_r.append(np.std(layer_corrs))
    
    # Panel A: Correlation by layer
    ax1 = fig.add_subplot(gs[0, 0])
    
    ax1.errorbar(range(num_layers), layer_mean_r, yerr=layer_std_r,
                marker='o', markersize=5, linewidth=1.5, capsize=3,
                color=MODEL_COLORS.get(model_name.lower(), COLORS['primary']))
    ax1.axhline(0.8, color='gray', linestyle=':', linewidth=1, alpha=0.5)
    
    ax1.set_xlabel('Layer index', fontweight='bold')
    ax1.set_ylabel('Mean correlation $r$', fontweight='bold')
    ax1.set_title(f'{model_name}: Layer-wise', fontsize=8, fontweight='bold')
    ax1.text(-0.2, 1.05, 'a', transform=ax1.transAxes,
            fontsize=10, fontweight='bold', va='top')
    
    # Panel B: Head-wise variation
    ax2 = fig.add_subplot(gs[0, 1])
    
    head_mean_r = []
    for head in range(num_heads):
        head_corrs = [r['metrics_forward']['global_r']
                     for r in all_head_results if r['head'] == head]
        head_mean_r.append(np.mean(head_corrs))
    
    ax2.bar(range(num_heads), head_mean_r, 
           color=MODEL_COLORS.get(model_name.lower(), COLORS['primary']),
           alpha=0.8, edgecolor='white', linewidth=0.5)
    ax2.axhline(0.8, color='gray', linestyle=':', linewidth=1, alpha=0.5)
    
    ax2.set_xlabel('Head index', fontweight='bold')
    ax2.set_ylabel('Mean correlation $r$', fontweight='bold')
    ax2.set_title(f'{model_name}: Head-wise', fontsize=8, fontweight='bold')
    ax2.text(-0.2, 1.05, 'b', transform=ax2.transAxes,
            fontsize=10, fontweight='bold', va='top')
    
    # Panel C: Distribution
    ax3 = fig.add_subplot(gs[0, 2])
    
    all_corrs = [r['metrics_forward']['global_r'] for r in all_head_results]
    
    ax3.hist(all_corrs, bins=20, edgecolor='white', linewidth=0.5,
            color=MODEL_COLORS.get(model_name.lower(), COLORS['primary']),
            alpha=0.8)
    ax3.axvline(np.mean(all_corrs), color='red', linestyle='--',
               linewidth=1.5, label=f'Mean: {np.mean(all_corrs):.3f}')
    ax3.axvline(0.8, color='gray', linestyle=':', linewidth=1, alpha=0.5)
    
    ax3.set_xlabel('Correlation $r$', fontweight='bold')
    ax3.set_ylabel('Count', fontweight='bold')
    ax3.set_title(f'{model_name}: Distribution', fontsize=8, fontweight='bold')
    ax3.legend(frameon=False, fontsize=5)
    ax3.text(-0.2, 1.05, 'c', transform=ax3.transAxes,
            fontsize=10, fontweight='bold', va='top')
    
    for fmt in ['pdf', 'svg', 'png']:
        plt.savefig(save_path / f"fig3_architecture_{model_name}.{fmt}",
                   dpi=600 if fmt == 'png' else None, bbox_inches='tight')
    
    plt.close()
    print(f"  Saved: fig3_architecture_{model_name}")


# ========================================
# HELPER: GENERATE ALL FIGURES
# ========================================

def generate_all_publication_figures(sweep_results: Dict,
                                    all_head_results: List[Dict],
                                    save_path: Path,
                                    model_name: str,
                                    optimal_tau: float):
    """Generate all publication figures for a single model."""
    print("\n" + "="*60)
    print(f"GENERATING PUBLICATION FIGURES: {model_name}")
    print("="*60)
    
    print("\n1. Temperature sweep...")
    plot_temperature_sweep_publication(sweep_results, save_path, model_name)
    
    print("\n2. Architecture analysis...")
    plot_architecture_analysis(all_head_results, save_path, model_name)
    
    print("\n" + "="*60)
    print("PUBLICATION FIGURES COMPLETE")
    print("="*60)
    print(f"\nFormats: PDF (vector), SVG (vector), PNG (600 DPI)")
    print(f"Location: {save_path}/")


if __name__ == "__main__":
    print(__doc__)
    print("\nPublication-quality figure generation for GPT-2 and RoBERTa.")
    print("Use generate_all_publication_figures() for single models.")
    print("Use plot_model_comparison() to compare multiple models.")