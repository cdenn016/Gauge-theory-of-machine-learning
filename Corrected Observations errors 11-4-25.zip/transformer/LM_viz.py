# -*- coding: utf-8 -*-
"""
Created on Fri Oct 31 20:40:51 2025

@author: chris and christine
"""

import torch
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.spatial.distance import cosine
from sklearn.decomposition import PCA

# ============================================================================
# Gauge Frame Analysis
# ============================================================================

def analyze_gauge_frames(model_fep, checkpoint_path=None):
    """
    Analyze evolution and structure of gauge frames during training.
    
    Shows:
    1. Gauge frame magnitudes over time
    2. Pairwise angles between frames
    3. Symmetry breaking patterns
    """
    if checkpoint_path:
        checkpoint = torch.load(checkpoint_path)
        gauge_frames_history = checkpoint['gauge_frames_history']
    else:
        # Extract current gauge frames
        gauge_frames = []
        for block in model_fep.blocks:
            if hasattr(block.attn, 'gauge_frames'):
                gauge_frames.append(block.attn.gauge_frames.detach().cpu().numpy())
        gauge_frames = np.stack(gauge_frames)  # (n_layers, n_heads, 3)
    
    # Plot gauge frame magnitudes
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    
    # 1. Frame magnitudes per layer
    ax = axes[0, 0]
    for layer_idx in range(len(gauge_frames)):
        norms = np.linalg.norm(gauge_frames[layer_idx], axis=1)
        ax.plot(norms, marker='o', label=f'Layer {layer_idx}')
    ax.set_xlabel('Head Index')
    ax.set_ylabel('||φᵢ|| (Frame Magnitude)')
    ax.set_title('Gauge Frame Magnitudes by Layer')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # 2. Pairwise angles between frames (Layer 0)
    ax = axes[0, 1]
    layer_0_frames = gauge_frames[0]  # (n_heads, 3)
    n_heads = layer_0_frames.shape[0]
    
    # Compute pairwise cosine similarities
    similarity_matrix = np.zeros((n_heads, n_heads))
    for i in range(n_heads):
        for j in range(n_heads):
            if i != j and np.linalg.norm(layer_0_frames[i]) > 0 and np.linalg.norm(layer_0_frames[j]) > 0:
                similarity_matrix[i, j] = np.dot(layer_0_frames[i], layer_0_frames[j]) / (
                    np.linalg.norm(layer_0_frames[i]) * np.linalg.norm(layer_0_frames[j])
                )
            elif i == j:
                similarity_matrix[i, j] = 1.0
    
    sns.heatmap(similarity_matrix, annot=True, fmt='.2f', cmap='coolwarm', 
                center=0, vmin=-1, vmax=1, ax=ax, cbar_kws={'label': 'Cosine Similarity'})
    ax.set_title('Gauge Frame Alignment (Layer 0)')
    ax.set_xlabel('Head j')
    ax.set_ylabel('Head i')
    
    # 3. Distribution of frame magnitudes
    ax = axes[1, 0]
    all_norms = np.linalg.norm(gauge_frames.reshape(-1, 3), axis=1)
    ax.hist(all_norms, bins=20, edgecolor='black', alpha=0.7)
    ax.axvline(np.mean(all_norms), color='red', linestyle='--', 
               label=f'Mean: {np.mean(all_norms):.3f}')
    ax.set_xlabel('||φᵢ||')
    ax.set_ylabel('Frequency')
    ax.set_title('Distribution of Gauge Frame Magnitudes')
    ax.legend()
    ax.grid(True, alpha=0.3)
    
    # 4. PCA visualization of frame directions
    ax = axes[1, 1]
    all_frames = gauge_frames.reshape(-1, 3)
    # Normalize to unit vectors
    normalized_frames = all_frames / (np.linalg.norm(all_frames, axis=1, keepdims=True) + 1e-8)
    
    if normalized_frames.shape[0] >= 3:
        pca = PCA(n_components=2)
        frames_2d = pca.fit_transform(normalized_frames)
        
        # Color by layer
        colors = np.repeat(np.arange(len(gauge_frames)), gauge_frames.shape[1])
        scatter = ax.scatter(frames_2d[:, 0], frames_2d[:, 1], c=colors, 
                           cmap='viridis', alpha=0.6, s=100)
        ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]:.1%} var)')
        ax.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]:.1%} var)')
        ax.set_title('Gauge Frame Directions (PCA)')
        plt.colorbar(scatter, ax=ax, label='Layer')
        ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('gauge_frame_analysis.png', dpi=150)
    print("Saved gauge frame analysis to gauge_frame_analysis.png")
    return fig


# ============================================================================
# Attention Pattern Comparison
# ============================================================================

def compare_attention_patterns(model_standard, model_fep, sample_text, dataset, device):
    """
    Compare attention patterns between standard and FEP transformers.
    
    Shows correlation and key differences in learned attention.
    """
    # Encode sample
    sample_ids = torch.tensor([dataset.stoi[c] for c in sample_text], 
                              dtype=torch.long).unsqueeze(0).to(device)
    
    # Get attention maps
    model_standard.eval()
    model_fep.eval()
    
    with torch.no_grad():
        _, _, attn_standard = model_standard(sample_ids)
        _, _, attn_fep = model_fep(sample_ids)
    
    # Compare first layer, first head
    attn_std = attn_standard[0][0, 0].cpu().numpy()  # (seq_len, seq_len)
    attn_fep = attn_fep[0][0, 0].cpu().numpy()
    
    fig, axes = plt.subplots(1, 3, figsize=(15, 4))
    
    # Standard attention
    ax = axes[0]
    im1 = ax.imshow(attn_std, cmap='viridis', aspect='auto')
    ax.set_title('Standard Transformer\nAttention (Layer 0, Head 0)')
    ax.set_xlabel('Key Position')
    ax.set_ylabel('Query Position')
    plt.colorbar(im1, ax=ax)
    
    # FEP attention
    ax = axes[1]
    im2 = ax.imshow(attn_fep, cmap='viridis', aspect='auto')
    ax.set_title('FEP Transformer\nAttention (Layer 0, Head 0)')
    ax.set_xlabel('Key Position')
    ax.set_ylabel('Query Position')
    plt.colorbar(im2, ax=ax)
    
    # Difference
    ax = axes[2]
    diff = attn_fep - attn_std
    im3 = ax.imshow(diff, cmap='RdBu_r', aspect='auto', vmin=-0.1, vmax=0.1)
    ax.set_title('Difference\n(FEP - Standard)')
    ax.set_xlabel('Key Position')
    ax.set_ylabel('Query Position')
    plt.colorbar(im3, ax=ax)
    
    plt.tight_layout()
    plt.savefig('attention_comparison.png', dpi=150)
    print("Saved attention comparison to attention_comparison.png")
    
    # Compute correlation
    correlation = np.corrcoef(attn_std.flatten(), attn_fep.flatten())[0, 1]
    print(f"\nAttention pattern correlation: {correlation:.4f}")
    
    return fig, correlation


# ============================================================================
# Perplexity Evaluation
# ============================================================================

def evaluate_perplexity(model, test_loader, device):
    """Compute perplexity on test set."""
    model.eval()
    total_loss = 0
    total_tokens = 0
    
    with torch.no_grad():
        for x, y in test_loader:
            x, y = x.to(device), y.to(device)
            _, loss, _ = model(x, y)
            
            total_loss += loss.item() * x.size(0) * x.size(1)
            total_tokens += x.size(0) * x.size(1)
    
    avg_loss = total_loss / total_tokens
    perplexity = np.exp(avg_loss)
    
    return perplexity


# ============================================================================
# Symmetry Breaking Analysis
# ============================================================================

def analyze_symmetry_breaking(model_fep, checkpoints_dir='checkpoints'):
    """
    Track gauge frame evolution to visualize symmetry breaking.
    
    In vacuum (no data): frames should converge to similar orientations.
    With data: frames specialize (break symmetry).
    """
    import glob
    import os
    
    checkpoint_files = sorted(glob.glob(os.path.join(checkpoints_dir, 'checkpoint_epoch_*.pt')))
    
    if not checkpoint_files:
        print("No checkpoints found. Save checkpoints during training with:")
        print("  torch.save({'epoch': epoch, 'gauge_frames': [...]}, f'checkpoint_epoch_{epoch}.pt')")
        return
    
    # Extract gauge frames at each checkpoint
    frame_norms_over_time = []
    frame_variance_over_time = []
    epochs = []
    
    for ckpt_file in checkpoint_files:
        ckpt = torch.load(ckpt_file)
        epoch = ckpt['epoch']
        epochs.append(epoch)
        
        # Get gauge frames from first layer
        gauge_frames = ckpt['gauge_frames'][0]  # (n_heads, 3)
        norms = np.linalg.norm(gauge_frames, axis=1)
        
        frame_norms_over_time.append(norms)
        frame_variance_over_time.append(np.var(norms))
    
    frame_norms_over_time = np.array(frame_norms_over_time)  # (n_checkpoints, n_heads)
    
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    
    # Plot individual frame norm trajectories
    ax = axes[0]
    for head_idx in range(frame_norms_over_time.shape[1]):
        ax.plot(epochs, frame_norms_over_time[:, head_idx], marker='o', 
                label=f'Head {head_idx}', alpha=0.7)
    ax.set_xlabel('Epoch')
    ax.set_ylabel('||φᵢ|| (Frame Norm)')
    ax.set_title('Gauge Frame Evolution\n(Symmetry Breaking)')
    ax.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
    ax.grid(True, alpha=0.3)
    
    # Plot variance in frame norms
    ax = axes[1]
    ax.plot(epochs, frame_variance_over_time, marker='o', color='red', linewidth=2)
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Var(||φᵢ||)')
    ax.set_title('Frame Norm Variance\n(Specialization Measure)')
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('symmetry_breaking.png', dpi=150)
    print("Saved symmetry breaking analysis to symmetry_breaking.png")
    
    return fig


# ============================================================================
# Generate Comparison Report
# ============================================================================

def generate_report(model_standard, model_fep, test_loader, dataset, device):
    """Generate comprehensive comparison report."""
    
    print("=" * 70)
    print("FEP vs Standard Transformer - Comparison Report")
    print("=" * 70)
    
    # 1. Model size comparison
    n_params_std = sum(p.numel() for p in model_standard.parameters())
    n_params_fep = sum(p.numel() for p in model_fep.parameters())
    
    print(f"\n1. Model Size:")
    print(f"   Standard: {n_params_std:,} parameters")
    print(f"   FEP:      {n_params_fep:,} parameters")
    print(f"   Overhead: {n_params_fep - n_params_std:,} parameters " +
          f"({100*(n_params_fep - n_params_std)/n_params_std:.2f}%)")
    
    # 2. Perplexity comparison
    print(f"\n2. Performance:")
    ppl_std = evaluate_perplexity(model_standard, test_loader, device)
    ppl_fep = evaluate_perplexity(model_fep, test_loader, device)
    
    print(f"   Standard Perplexity: {ppl_std:.4f}")
    print(f"   FEP Perplexity:      {ppl_fep:.4f}")
    print(f"   Difference:          {ppl_fep - ppl_std:+.4f} " +
          f"({100*(ppl_fep - ppl_std)/ppl_std:+.2f}%)")
    
    # 3. Sample generation
    print(f"\n3. Sample Generation:")
    context = "The king"
    context_ids = torch.tensor([dataset.stoi[c] for c in context], 
                               dtype=torch.long).unsqueeze(0).to(device)
    
    model_standard.eval()
    model_fep.eval()
    
    gen_std = model_standard.generate(context_ids, max_new_tokens=100, temperature=0.8)
    gen_fep = model_fep.generate(context_ids, max_new_tokens=100, temperature=0.8)
    
    sample_std = ''.join([dataset.itos[i.item()] for i in gen_std[0]])
    sample_fep = ''.join([dataset.itos[i.item()] for i in gen_fep[0]])
    
    print(f"\n   Context: '{context}'")
    print(f"\n   Standard:\n   {sample_std}\n")
    print(f"   FEP:\n   {sample_fep}\n")
    
    # 4. Gauge frame statistics
    if hasattr(model_fep.blocks[0].attn, 'gauge_frames'):
        print(f"\n4. Gauge Frame Statistics:")
        
        all_frames = []
        for block in model_fep.blocks:
            if hasattr(block.attn, 'gauge_frames'):
                frames = block.attn.gauge_frames.detach().cpu().numpy()
                all_frames.append(frames)
        
        all_frames = np.concatenate(all_frames, axis=0)  # (total_heads, 3)
        norms = np.linalg.norm(all_frames, axis=1)
        
        print(f"   Mean frame norm:   {np.mean(norms):.4f}")
        print(f"   Std frame norm:    {np.std(norms):.4f}")
        print(f"   Min frame norm:    {np.min(norms):.4f}")
        print(f"   Max frame norm:    {np.max(norms):.4f}")
        
        # Check for specialization
        if np.std(norms) > 0.1:
            print(f"   → Frames show specialization (high variance)")
        else:
            print(f"   → Frames are relatively uniform (low variance)")
    
    print("\n" + "=" * 70)
    print("Report generation complete. Check visualization files:")
    print("  - gauge_frame_analysis.png")
    print("  - attention_comparison.png")
    print("  - symmetry_breaking.png (if checkpoints available)")
    print("=" * 70)


# ============================================================================
# Training with Logging
# ============================================================================

def train_with_gauge_logging(model, train_loader, optimizer, device, epochs=10, save_dir='checkpoints'):
    """
    Training loop with gauge frame checkpointing for symmetry analysis.
    """
    import os
    os.makedirs(save_dir, exist_ok=True)
    
    model.train()
    losses = []
    
    for epoch in range(epochs):
        epoch_loss = 0
        
        for batch_idx, (x, y) in enumerate(train_loader):
            x, y = x.to(device), y.to(device)
            
            optimizer.zero_grad()
            logits, loss, _ = model(x, y)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            
            epoch_loss += loss.item()
            
            if batch_idx % 100 == 0:
                print(f"Epoch {epoch+1}/{epochs} | Batch {batch_idx} | Loss: {loss.item():.4f}")
        
        avg_loss = epoch_loss / len(train_loader)
        losses.append(avg_loss)
        print(f"Epoch {epoch+1} | Average Loss: {avg_loss:.4f}")
        
        # Save checkpoint with gauge frames
        if hasattr(model, 'blocks') and hasattr(model.blocks[0].attn, 'gauge_frames'):
            gauge_frames = []
            for block in model.blocks:
                if hasattr(block.attn, 'gauge_frames'):
                    gauge_frames.append(block.attn.gauge_frames.detach().cpu().numpy())
            
            checkpoint = {
                'epoch': epoch,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'loss': avg_loss,
                'gauge_frames': gauge_frames
            }
            torch.save(checkpoint, os.path.join(save_dir, f'checkpoint_epoch_{epoch}.pt'))
    
    return losses


# ============================================================================
# Usage Example
# ============================================================================

if __name__ == "__main__":
    from transformers.FEP_LM import CharacterLM, CharDataset
    from torch.utils.data import DataLoader
    import torch
    
    device = torch.device('cpu')
    
    # Load the text data
    with open('input.txt', 'r') as f:
        text = f.read()
    dataset = CharDataset(text, 128)
    
    # Load the trained models
    print("Loading models...")
    model_standard = CharacterLM(vocab_size=dataset.vocab_size, use_fep=False)
    model_standard.load_state_dict(torch.load('model_standard.pt'))
    
    model_fep = CharacterLM(vocab_size=dataset.vocab_size, use_fep=True)
    model_fep.load_state_dict(torch.load('model_fep.pt'))
    
    # Create test loader for evaluation
    test_loader = DataLoader(dataset, batch_size=32, shuffle=False)
    
    # Run all the analyses
    print("\n=== Analyzing Gauge Frames ===")
    analyze_gauge_frames(model_fep)
    
    print("\n=== Comparing Attention Patterns ===")
    compare_attention_patterns(model_standard, model_fep, "To be or not", dataset, device)
    
    print("\n=== Generating Full Report ===")
    generate_report(model_standard, model_fep, test_loader, dataset, device)
    
    print("\nDone! Check for PNG files in your folder.")