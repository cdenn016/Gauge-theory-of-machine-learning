"""
train_fep_transformer.py - Training script for TRUE FEP gauge transformer

This trains the CORRECTED version that actually implements:
1. KL-based attention: β_ij ∝ softmax(-D_KL(q_i || Ω_ij q_j))
2. Proper gauge transport in aggregation
3. Full Gaussian agents (not just vectors)

Usage:
    # Standard (no gauge, but KL-based)
    python train_fep_transformer.py --mode flat
    
    # Gauge with ℓ=1 (flat geometry)
    python train_fep_transformer.py --mode gauge --irrep 1
    
    # Gauge with ℓ=4 (curved geometry)
    python train_fep_transformer.py --mode gauge --irrep 4
    
    # Delta-function limit (standard transformer analogue)
    python train_fep_transformer.py --mode gauge --irrep 1 --delta_limit
"""

import argparse
import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
from pathlib import Path
import json
from tqdm import tqdm
import matplotlib.pyplot as plt

from transformer.gauge_transformer import (
    FEPGaugeTransformer, FEPTransformerConfig,
    train_epoch, evaluate
)


# ============================================================================
#                      WIKITEXT-2 DATA LOADING
# ============================================================================

class WikiText2Dataset(Dataset):
    """WikiText-2 dataset for language modeling"""
    
    def __init__(self, split='train', seq_len=128, cache_dir='./data/wikitext2'):
        self.split = split
        self.seq_len = seq_len
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        cache_file = self.cache_dir / f'{split}_tokenized.npz'
        
        if cache_file.exists():
            print(f"Loading {split} split from cache...")
            data = np.load(cache_file)
            self.tokens = data['tokens']
            self.vocab_size = int(data['vocab_size'])
            print(f"  {len(self.tokens):,} tokens, vocab size: {self.vocab_size:,}")
        else:
            print(f"Downloading and tokenizing {split} split...")
            self._download_and_tokenize()
    
    def _download_and_tokenize(self):
        try:
            from datasets import load_dataset
            
            print("  Downloading from HuggingFace...")
            dataset = load_dataset('wikitext', 'wikitext-2-raw-v1', split=self.split)
            
            # Simple character-level tokenization
            text = '\n'.join(dataset['text'])
            
            # Build vocabulary
            chars = sorted(list(set(text)))
            self.vocab_size = len(chars) + 3  # +3 for special tokens
            
            char_to_idx = {ch: i + 3 for i, ch in enumerate(chars)}
            char_to_idx['<PAD>'] = 0
            char_to_idx['<BOS>'] = 1
            char_to_idx['<EOS>'] = 2
            
            # Tokenize
            self.tokens = np.array([char_to_idx.get(ch, 0) for ch in text], dtype=np.int32)
            
            # Cache
            cache_file = self.cache_dir / f'{self.split}_tokenized.npz'
            np.savez_compressed(cache_file, tokens=self.tokens, vocab_size=self.vocab_size)
            
            vocab_file = self.cache_dir / 'vocab.json'
            with open(vocab_file, 'w') as f:
                json.dump(char_to_idx, f, indent=2)
            
            print(f"  Cached to {cache_file}")
            print(f"  {len(self.tokens):,} tokens, vocab size: {self.vocab_size:,}")
            
        except ImportError:
            print("ERROR: datasets library not installed!")
            print("Install with: pip install datasets")
            exit(1)
    
    def __len__(self):
        return max(0, len(self.tokens) - self.seq_len)
    
    def __getitem__(self, idx):
        chunk = self.tokens[idx : idx + self.seq_len + 1]
        input_ids = torch.tensor(chunk[:-1], dtype=torch.long)
        labels = torch.tensor(chunk[1:], dtype=torch.long)
        return {'input_ids': input_ids, 'labels': labels}


def load_wikitext2(batch_size=32, seq_len=128, cache_dir='./data/wikitext2'):
    """Load WikiText-2 dataloaders"""
    train_dataset = WikiText2Dataset('train', seq_len, cache_dir)
    valid_dataset = WikiText2Dataset('validation', seq_len, cache_dir)
    test_dataset = WikiText2Dataset('test', seq_len, cache_dir)
    
    train_loader = DataLoader(
        train_dataset, batch_size=batch_size, shuffle=True, num_workers=2
    )
    valid_loader = DataLoader(
        valid_dataset, batch_size=batch_size, shuffle=False, num_workers=2
    )
    test_loader = DataLoader(
        test_dataset, batch_size=batch_size, shuffle=False, num_workers=2
    )
    
    vocab_size = train_dataset.vocab_size
    
    return train_loader, valid_loader, test_loader, vocab_size


# ============================================================================
#                      TRAINING
# ============================================================================

def train_model(
    config: FEPTransformerConfig,
    train_loader,
    valid_loader,
    test_loader,
    epochs: int = 20,
    lr: float = 3e-4,
    device: str = 'cuda',
    save_dir: Path = None
):
    """Train FEP transformer"""
    
    print(f"\n{'='*70}")
    print(f"TRAINING FEP GAUGE TRANSFORMER")
    print(f"{'='*70}")
    print(f"Mode: {'Gauge' if config.use_gauge else 'Flat'}")
    if config.use_gauge:
        print(f"Irrep: ℓ={config.irrep_l}")
    print(f"Uncertainty: {'Full' if config.use_uncertainty else 'Delta-limit'}")
    print(f"Epochs: {epochs}")
    print(f"Device: {device}")
    print(f"{'='*70}\n")
    
    # Create model
    model = FEPGaugeTransformer(config).to(device)
    
    # Optimizer
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    
    # Scheduler
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=epochs, eta_min=lr/10
    )
    
    # Training history
    history = {
        'train_loss': [],
        'valid_ppl': [],
        'epoch_times': []
    }
    
    best_valid_ppl = float('inf')
    
    # Training loop
    for epoch in range(1, epochs + 1):
        import time
        start_time = time.time()
        
        # Train
        train_loss = train_epoch(model, train_loader, optimizer, device)
        
        # Validate
        valid_ppl = evaluate(model, valid_loader, device)
        
        # Step scheduler
        scheduler.step()
        
        epoch_time = time.time() - start_time
        
        # Log
        history['train_loss'].append(train_loss)
        history['valid_ppl'].append(valid_ppl)
        history['epoch_times'].append(epoch_time)
        
        print(f"Epoch {epoch:2d}/{epochs} | "
              f"Train Loss: {train_loss:.4f} | "
              f"Valid PPL: {valid_ppl:.2f} | "
              f"Time: {epoch_time:.1f}s")
        
        # Save best model
        if valid_ppl < best_valid_ppl:
            best_valid_ppl = valid_ppl
            if save_dir:
                torch.save(model.state_dict(), save_dir / 'best_model.pt')
    
    # Test
    print(f"\n{'='*70}")
    print("FINAL EVALUATION")
    print(f"{'='*70}")
    test_ppl = evaluate(model, test_loader, device)
    print(f"Test Perplexity: {test_ppl:.2f}")
    print(f"Best Valid Perplexity: {best_valid_ppl:.2f}")
    print(f"{'='*70}\n")
    
    # Save results
    results = {
        'config': {
            'use_gauge': config.use_gauge,
            'irrep_l': config.irrep_l if config.use_gauge else None,
            'use_uncertainty': config.use_uncertainty,
            'd_model': config.d_model,
            'n_heads': config.n_heads,
            'n_layers': config.n_layers,
        },
        'history': history,
        'best_valid_ppl': best_valid_ppl,
        'test_ppl': test_ppl
    }
    
    if save_dir:
        with open(save_dir / 'results.json', 'w') as f:
            json.dump(results, f, indent=2)
        
        # Plot training curve
        plt.figure(figsize=(10, 5))
        plt.plot(history['valid_ppl'], marker='o')
        plt.xlabel('Epoch')
        plt.ylabel('Validation Perplexity')
        plt.title(f"FEP Transformer Training ({'Gauge' if config.use_gauge else 'Flat'})")
        plt.grid(alpha=0.3)
        plt.tight_layout()
        plt.savefig(save_dir / 'training_curve.png', dpi=150)
        plt.close()
    
    return results


# ============================================================================
#                      MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(description='Train FEP Gauge Transformer')
    
    # Mode
    parser.add_argument('--mode', type=str, default='gauge', choices=['flat', 'gauge'],
                       help='flat=no gauge, gauge=with gauge transport')
    parser.add_argument('--irrep', type=int, default=1,
                       help='SO(3) irrep: ℓ=1(flat), ℓ=2,3,4(curved)')
    parser.add_argument('--delta_limit', action='store_true',
                       help='Use delta-function limit (no uncertainty)')
    
    # Model
    parser.add_argument('--d_model', type=int, default=256)
    parser.add_argument('--n_heads', type=int, default=4)
    parser.add_argument('--n_layers', type=int, default=4)
    parser.add_argument('--seq_len', type=int, default=128)
    
    # Training
    parser.add_argument('--epochs', type=int, default=20)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--lr', type=float, default=3e-4)
    
    # System
    parser.add_argument('--save_dir', type=str, default='./fep_transformer_results')
    parser.add_argument('--cpu', action='store_true', help='Force CPU')
    
    args = parser.parse_args()
    
    # Device
    device = 'cpu' if args.cpu or not torch.cuda.is_available() else 'cuda'
    print(f"Using device: {device}")
    
    # Load data
    print("\nLoading WikiText-2...")
    train_loader, valid_loader, test_loader, vocab_size = load_wikitext2(
        batch_size=args.batch_size,
        seq_len=args.seq_len
    )
    
    # Create config
    config = FEPTransformerConfig(
        vocab_size=vocab_size,
        d_model=args.d_model,
        n_heads=args.n_heads,
        n_layers=args.n_layers,
        seq_len=args.seq_len,
        use_gauge=(args.mode == 'gauge'),
        irrep_l=args.irrep,
        use_uncertainty=not args.delta_limit,
        init_sigma=0.01 if args.delta_limit else 0.1,
        diagonal_cov=True
    )
    
    # Create save directory
    mode_str = f"gauge_l{args.irrep}" if args.mode == 'gauge' else 'flat'
    if args.delta_limit:
        mode_str += '_delta'
    
    save_dir = Path(args.save_dir) / mode_str
    save_dir.mkdir(parents=True, exist_ok=True)
    
    # Train
    results = train_model(
        config,
        train_loader,
        valid_loader,
        test_loader,
        epochs=args.epochs,
        lr=args.lr,
        device=device,
        save_dir=save_dir
    )
    
    print(f"\nResults saved to: {save_dir}")
    print(f"  - Model: {save_dir / 'best_model.pt'}")
    print(f"  - Results: {save_dir / 'results.json'}")
    print(f"  - Plot: {save_dir / 'training_curve.png'}")


if __name__ == '__main__':
    main()