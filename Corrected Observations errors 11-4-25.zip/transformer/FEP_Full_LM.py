"""
0-DIMENSIONAL GAUGE THEORY: Transformer as FEP at Single Base Point

"Standard attention transformers represent a 0-dimensional gauge theory"
- Each token = one agent at the SAME base manifold point
- No spatial grid, no transport operators
- Pure agent-agent coupling via KL divergence

Free Energy (Eq. 42, single point):
  F = Σ_i KL(q_i||p_i) + Σ_{i,j} β_ij·KL(q_i||q_j) + Σ_i E_obs^i
  
where each token i has:
  - Belief q_i = N(μ_i, Σ_i)
  - Prior p_i = N(μ_p, Σ_p) [frozen]
  - Observation x_i with likelihood p(x_i | k_i) = N(W·k_i, Λ^{-1})
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import numpy as np
import math
import os
from datetime import datetime


# ============================================================================
# Dataset
# ============================================================================

class CharDataset(Dataset):
    def __init__(self, text: str, seq_len: int):
        chars = sorted(list(set(text)))
        self.vocab_size = len(chars)
        self.stoi = {ch: i for i, ch in enumerate(chars)}
        self.itos = {i: ch for i, ch in enumerate(chars)}
        self.data = torch.tensor([self.stoi[c] for c in text], dtype=torch.long)
        self.seq_len = seq_len
        
    def __len__(self):
        return len(self.data) - self.seq_len
    
    def __getitem__(self, idx):
        x = self.data[idx:idx + self.seq_len]
        y = self.data[idx + 1:idx + self.seq_len + 1]
        return x, y


# ============================================================================
# Natural Gradient Utilities
# ============================================================================

def sanitize_sigma(sigma, eps=1e-8):
    """Ensure covariance is SPD."""
    sigma = 0.5 * (sigma + sigma.transpose(-2, -1))
    try:
        w, V = torch.linalg.eigh(sigma)
        w = torch.clamp(w, min=eps)
        sigma = V @ torch.diag_embed(w) @ V.transpose(-2, -1)
    except:
        sigma = sigma + eps * torch.eye(sigma.shape[-1], device=sigma.device)
    return sigma


def apply_natural_gradient_mu(grad_mu, sigma):
    """δμ = Σ @ ∇_μ F"""
    sigma = sanitize_sigma(sigma)
    nat_grad = torch.matmul(sigma, grad_mu.unsqueeze(-1)).squeeze(-1)
    return nat_grad


def apply_natural_gradient_sigma(grad_sigma, sigma, learning_rate=1.0, 
                                  max_step=0.25, eps=1e-8):
    """Natural gradient with exponential map retraction."""
    sigma = sanitize_sigma(sigma, eps=eps)
    grad_sigma = 0.5 * (grad_sigma + grad_sigma.transpose(-2, -1))
    
    # Intrinsic tangent: Delta = -2 Σ sym(∇) Σ
    Delta = -2.0 * torch.matmul(torch.matmul(sigma, grad_sigma), sigma)
    Delta = learning_rate * Delta
    
    try:
        w, Q = torch.linalg.eigh(sigma)
        w = torch.clamp(w, min=eps)
    except:
        return torch.zeros_like(sigma)
    
    Qt = Q.transpose(-2, -1)
    sqrt_w = torch.sqrt(w)
    inv_sqrt = 1.0 / sqrt_w
    
    # Whitened tangent: R = Σ^{-1/2} Delta Σ^{-1/2}
    Deig = torch.matmul(torch.matmul(Qt, Delta), Q)
    R = (inv_sqrt.unsqueeze(-1) * Deig) * inv_sqrt.unsqueeze(-2)
    R = 0.5 * (R + R.transpose(-2, -1))
    
    # Trust region
    R_norm = torch.linalg.matrix_norm(R, ord='fro', keepdims=True)
    alpha = torch.clamp(max_step / (R_norm + eps), max=1.0)
    R = R * alpha
    
    # Exponential map: Σ_{k+1} = Σ^{1/2} exp(R) Σ^{1/2}
    try:
        lam, U = torch.linalg.eigh(R)
        exp_lam = torch.exp(lam)
        expR = torch.matmul(U * exp_lam.unsqueeze(-2), U.transpose(-2, -1))
        
        eye = torch.eye(R.shape[-1], device=R.device, dtype=R.dtype)
        Teig = (sqrt_w.unsqueeze(-1) * (expR - eye)) * sqrt_w.unsqueeze(-2)
        Delta_exp = torch.matmul(torch.matmul(Q, Teig), Qt)
        sigma_new = sigma + Delta_exp
    except:
        sigma_new = sigma
    
    sigma_new = sanitize_sigma(sigma_new, eps=eps)
    return sigma_new - sigma


# ============================================================================
# Standard Attention (baseline)
# ============================================================================

class StandardAttention(nn.Module):
    def __init__(self, d_model: int, n_heads: int, dropout: float = 0.1):
        super().__init__()
        assert d_model % n_heads == 0
        
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_head = d_model // n_heads
        
        self.q_proj = nn.Linear(d_model, d_model)
        self.k_proj = nn.Linear(d_model, d_model)
        self.v_proj = nn.Linear(d_model, d_model)
        self.o_proj = nn.Linear(d_model, d_model)
        
        self.dropout = nn.Dropout(dropout)
        
    def forward(self, x, mask=None):
        batch_size, seq_len, _ = x.shape
        
        Q = self.q_proj(x).view(batch_size, seq_len, self.n_heads, self.d_head).transpose(1, 2)
        K = self.k_proj(x).view(batch_size, seq_len, self.n_heads, self.d_head).transpose(1, 2)
        V = self.v_proj(x).view(batch_size, seq_len, self.n_heads, self.d_head).transpose(1, 2)
        
        scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.d_head)
        
        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)
        
        attn = F.softmax(scores, dim=-1)
        attn = self.dropout(attn)
        
        output = torch.matmul(attn, V)
        output = output.transpose(1, 2).contiguous().view(batch_size, seq_len, self.d_model)
        output = self.o_proj(output)
        
        return output, attn


# ============================================================================
# FEP Attention: 0-Dimensional Gauge Theory
# ============================================================================

class FEPAttention0D(nn.Module):
    """
    0-dimensional gauge theory: all tokens at same base point.
    
    Free Energy per token i:
      F_i = KL(q_i||p_i) + Σ_j β_ij·KL(q_i||q_j) + E_obs^i
    
    where:
      - q_i = N(μ_i, Σ_i): belief at token i
      - p_i = N(μ_p, Σ_p): frozen prior (same for all)
      - E_obs^i = (1/2)||x_i - W·μ_i||²_Λ + (1/2)tr(Λ·W·Σ_i·W^T)
    """
    
    def __init__(self, d_model: int, n_heads: int, dropout: float = 0.1,
                 obs_scale: float = 1.0):
        super().__init__()
        assert d_model % n_heads == 0
        
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_head = d_model // n_heads
        self.obs_scale = obs_scale
        
        # === AGENT BELIEFS (trainable) ===
        self.q_proj = nn.Linear(d_model, d_model)  # μ_i for each token
        self.k_proj = nn.Linear(d_model, d_model)  # Used for values
        self.v_proj = nn.Linear(d_model, d_model)
        self.o_proj = nn.Linear(d_model, d_model)
        
        # Covariances: diagonal per head
        self.log_diag_sigma_q = nn.Parameter(torch.zeros(n_heads, d_model // n_heads))
        
        # === FROZEN PRIOR (same for all tokens) ===
        self.prior_mean_proj = nn.Linear(d_model, d_model)
        self.prior_mean_proj.weight.requires_grad = False
        self.prior_mean_proj.bias.requires_grad = False
        nn.init.normal_(self.prior_mean_proj.weight, mean=0.0, std=0.02)
        nn.init.zeros_(self.prior_mean_proj.bias)
        
        # Prior covariance (frozen)
        self.register_buffer('log_diag_sigma_p', torch.zeros(n_heads, d_model // n_heads))
        
        # === OBSERVATION MODEL ===
        # Each token observes via: p(x_i | k_i) = N(W·k_i, Λ^{-1})
        d_obs = d_model // n_heads
        self.register_buffer('W_obs', torch.eye(d_obs))        # (d_obs, d_head)
        self.register_buffer('Lambda_obs', torch.eye(d_obs))   # (d_obs, d_obs) precision
        
        # === COUPLING ===
        self.log_beta = nn.Parameter(torch.ones(1) * math.log(0.1))
        self.temperature = nn.Parameter(torch.ones(1) * math.sqrt(self.d_head))
        
        self.dropout = nn.Dropout(dropout)
        
    def get_sigma_q(self):
        diag = torch.exp(self.log_diag_sigma_q)
        return torch.diag_embed(diag)
    
    def get_sigma_p(self):
        diag = torch.exp(self.log_diag_sigma_p)
        return torch.diag_embed(diag)
    
    def compute_kl_gaussian(self, mu_q, sigma_q, mu_p, sigma_p, eps=1e-8):
        """
        KL(q||p) for diagonal Gaussians.
        
        Args:
            mu_q: [batch, n_heads, n_tokens, d_head]  (belief means)
            sigma_q: [n_heads, d_head, d_head]         (belief covs)
            mu_p: [batch, n_heads, n_tokens, d_head]  (prior means)
            sigma_p: [n_heads, d_head, d_head]         (prior covs)
        """
        d = mu_q.shape[-1]
        
        # Extract diagonals and reshape for broadcasting
        sigma_q_diag = torch.diagonal(sigma_q, dim1=-2, dim2=-1).unsqueeze(2)  # [n_heads, 1, d_head]
        sigma_p_diag = torch.diagonal(sigma_p, dim1=-2, dim2=-1).unsqueeze(2)  # [n_heads, 1, d_head]
        sigma_p_inv_diag = 1.0 / (sigma_p_diag + eps)
        
        diff = mu_q - mu_p
        trace_term = torch.sum(sigma_p_inv_diag * sigma_q_diag, dim=-1)
        mahal_term = torch.sum(diff * sigma_p_inv_diag * diff, dim=-1)
        log_det_term = torch.sum(torch.log(sigma_p_diag + eps) - torch.log(sigma_q_diag + eps), dim=-1)
        
        kl = 0.5 * (trace_term + mahal_term - d + log_det_term)
        return kl
    
    def compute_kl_coupling(self, Q, sigma_q):
        """
        KL(q_i||q_j) between token beliefs at the same base point.
        
        Args:
            Q: [batch, n_heads, n_tokens, d_head]  (all belief means)
            sigma_q: [n_heads, d_head, d_head]      (belief covariances)
        
        Returns:
            kl_ij: [batch, n_heads, n_tokens, n_tokens]
        """
        # Pairwise differences
        q_i = Q.unsqueeze(3)  # [batch, n_heads, n_tokens, 1, d_head]
        q_j = Q.unsqueeze(2)  # [batch, n_heads, 1, n_tokens, d_head]
        diff = q_i - q_j      # [batch, n_heads, n_tokens, n_tokens, d_head]
        sq_dist = torch.sum(diff ** 2, dim=-1)
        
        # Normalize by covariance
        sigma_q_diag = torch.diagonal(sigma_q, dim1=-2, dim2=-1)
        sigma_q_sq = torch.mean(sigma_q_diag, dim=-1, keepdim=True)
        sigma_q_sq = sigma_q_sq.unsqueeze(0).unsqueeze(-1)
        
        kl_ij = sq_dist / (2 * sigma_q_sq + 1e-8)
        return kl_ij
    
    def compute_observation_energy_per_token(self, Q, sigma_q, x_obs):
        """
        Observation energy per token (0-dimensional theory).
        
        For token i at the base point:
          E_obs^i = (1/2)||x_i - W·μ_i||²_Λ + (1/2)tr(Λ·W·Σ_i·W^T)
        
        Args:
            Q: [batch, n_heads, n_tokens, d_head]  (belief means μ_i)
            sigma_q: [n_heads, d_head, d_head]      (belief covariances Σ_i)
            x_obs: [batch, n_heads, n_tokens, d_obs] (observations x_i)
        
        Returns:
            E_obs: [batch, n_heads, n_tokens]
        """
        # Predicted observations: ŷ_i = W·μ_i
        y_pred = torch.matmul(self.W_obs, Q.unsqueeze(-1)).squeeze(-1)
        
        # Residual: r_i = x_i - ŷ_i
        r = x_obs - y_pred
        
        # Mahalanobis: (1/2) r_i^T Λ r_i
        Lam_r = torch.matmul(self.Lambda_obs, r.unsqueeze(-1)).squeeze(-1)
        mahal = 0.5 * torch.sum(r * Lam_r, dim=-1)
        
        # Trace term: (1/2) tr(Λ·W·Σ_i·W^T)
        # Precompute: G = W^T Λ W (constant across tokens since Σ is shared)
        A = torch.matmul(self.Lambda_obs, self.W_obs)
        G = torch.matmul(self.W_obs.T, A)
        
        # For diagonal Σ: tr(Σ·G) = Σ_k σ_k G_kk
        sigma_q_diag = torch.diagonal(sigma_q, dim1=-2, dim2=-1)
        G_diag = torch.diagonal(G)
        trace = 0.5 * torch.sum(sigma_q_diag * G_diag.unsqueeze(0), dim=-1)
        trace = trace.view(1, self.n_heads, 1)  # Broadcast
        
        E_obs = mahal + trace
        return E_obs
    
    def forward(self, x, x_obs=None, mask=None):
        """
        0-dimensional FEP: all tokens as agents at single base point.
        
        Args:
            x: [batch, seq_len, d_model] - input embeddings
            x_obs: [batch, seq_len, d_model] - target observations (optional)
            mask: [1, 1, seq_len, seq_len] - causal mask
        """
        batch_size, seq_len, _ = x.shape
        
        # === BELIEFS q_i for each token i ===
        Q = self.q_proj(x).view(batch_size, seq_len, self.n_heads, self.d_head).transpose(1, 2)
        K = self.k_proj(x).view(batch_size, seq_len, self.n_heads, self.d_head).transpose(1, 2)
        V = self.v_proj(x).view(batch_size, seq_len, self.n_heads, self.d_head).transpose(1, 2)
        
        # === PRIOR p (frozen, same for all tokens) ===
        with torch.no_grad():
            P = self.prior_mean_proj(x).view(batch_size, seq_len, self.n_heads, self.d_head).transpose(1, 2)
        
        # === COVARIANCES ===
        sigma_q = self.get_sigma_q()  # Beliefs (trainable)
        sigma_p = self.get_sigma_p()  # Prior (frozen)
        
        # === COUPLING STRENGTH ===
        beta = torch.exp(self.log_beta)
        beta = torch.clamp(beta, min=1e-6, max=1.0)
        
        # ================================================================
        # FREE ENERGY COMPONENTS (per token)
        # ================================================================
        
        # 1. KL(q_i||p_i) - prior regularization
        kl_belief_prior = self.compute_kl_gaussian(
            Q, sigma_q.unsqueeze(0), 
            P.detach(), sigma_p.unsqueeze(0)
        )  # [batch, n_heads, n_tokens]
        
        # 2. Σ_j β_ij·KL(q_i||q_j) - agent coupling at same base point
        kl_belief_coupling = self.compute_kl_coupling(Q, sigma_q)
        # [batch, n_heads, n_tokens, n_tokens]
        
        # 3. E_obs^i - observation energy per token
        if x_obs is None:
            # Self-supervised: target = current embeddings
            x_obs_heads = x.view(batch_size, seq_len, self.n_heads, self.d_head).transpose(1, 2)
        else:
            x_obs_heads = x_obs.view(batch_size, seq_len, self.n_heads, self.d_head).transpose(1, 2)
        
        E_obs = self.compute_observation_energy_per_token(Q, sigma_q, x_obs_heads)
        # [batch, n_heads, n_tokens]
        
        # ================================================================
        # ATTENTION from KL coupling
        # ================================================================
        scores = -kl_belief_coupling / self.temperature
        
        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)
        
        attn_weights = F.softmax(scores, dim=-1)
        attn_weights = self.dropout(attn_weights)
        
        # Output
        output = torch.matmul(attn_weights, V)
        output = output.transpose(1, 2).contiguous().view(batch_size, seq_len, self.d_model)
        output = self.o_proj(output)
        
        fe_components = {
            'kl_belief_prior': kl_belief_prior,
            'kl_belief_coupling': kl_belief_coupling,
            'E_obs': E_obs,
            'beta': beta,
            'attn_weights': attn_weights,
            'Q': Q,
            'P': P,
            'sigma_q': sigma_q,
            'sigma_p': sigma_p
        }
        
        return output, attn_weights, fe_components


# ============================================================================
# Natural Gradient Optimizer
# ============================================================================

class NaturalGradientOptimizer:
    def __init__(self, model, lr_mu=0.1, lr_sigma=0.1, lr_other=0.001):
        self.model = model
        self.lr_mu = lr_mu
        self.lr_sigma = lr_sigma
        self.lr_other = lr_other
        
        self.belief_mean_params = []
        self.belief_sigma_params = []
        self.other_params = []
        
        for name, param in model.named_parameters():
            if not param.requires_grad:
                continue
            
            if 'q_proj' in name or 'k_proj' in name:
                self.belief_mean_params.append((name, param))
            elif 'log_diag_sigma_q' in name:
                self.belief_sigma_params.append((name, param))
            else:
                self.other_params.append((name, param))
        
        self.adam = torch.optim.Adam([p for _, p in self.other_params], lr=lr_other)
        
    def zero_grad(self):
        for _, param in self.belief_mean_params + self.belief_sigma_params + self.other_params:
            if param.grad is not None:
                param.grad.zero_()
        self.adam.zero_grad()
    
    def step(self):
        with torch.no_grad():
            for module in self.model.modules():
                if isinstance(module, FEPAttention0D):
                    sigma_q = module.get_sigma_q()
                    
                    # Natural gradient for belief means
                    if module.q_proj.weight.grad is not None:
                        grad = module.q_proj.weight.grad
                        sigma_avg = torch.mean(sigma_q, dim=0)
                        scale = torch.trace(sigma_avg) / sigma_avg.shape[0]
                        nat_grad = grad * scale.clamp(min=0.1, max=10.0)
                        module.q_proj.weight.data -= self.lr_mu * nat_grad
                    
                    if module.k_proj.weight.grad is not None:
                        grad = module.k_proj.weight.grad
                        sigma_avg = torch.mean(sigma_q, dim=0)
                        scale = torch.trace(sigma_avg) / sigma_avg.shape[0]
                        nat_grad = grad * scale.clamp(min=0.1, max=10.0)
                        module.k_proj.weight.data -= self.lr_mu * nat_grad
                    
                    # Natural gradient for covariances
                    if module.log_diag_sigma_q.grad is not None:
                        grad = module.log_diag_sigma_q.grad
                        current_sigma = torch.exp(module.log_diag_sigma_q)
                        nat_grad = grad * current_sigma
                        nat_grad = torch.clamp(nat_grad, -1.0, 1.0)
                        module.log_diag_sigma_q.data -= self.lr_sigma * nat_grad
        
        self.adam.step()


# ============================================================================
# Transformer Block
# ============================================================================

class TransformerBlock(nn.Module):
    def __init__(self, d_model: int, n_heads: int, d_ff: int, 
                 dropout: float = 0.1, use_fep: bool = False, obs_scale: float = 1.0):
        super().__init__()
        
        self.use_fep = use_fep
        
        if use_fep:
            self.attn = FEPAttention0D(d_model, n_heads, dropout, obs_scale)
        else:
            self.attn = StandardAttention(d_model, n_heads, dropout)
        
        self.ffn = nn.Sequential(
            nn.Linear(d_model, d_ff),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_ff, d_model),
            nn.Dropout(dropout)
        )
        
        self.ln1 = nn.LayerNorm(d_model)
        self.ln2 = nn.LayerNorm(d_model)
        
    def forward(self, x, x_obs=None, mask=None):
        if self.use_fep:
            attn_out, attn_weights, fe_components = self.attn(self.ln1(x), x_obs, mask)
        else:
            attn_out, attn_weights = self.attn(self.ln1(x), mask)
            fe_components = None
        
        x = x + attn_out
        x = x + self.ffn(self.ln2(x))
        
        return x, attn_weights, fe_components


# ============================================================================
# Language Model
# ============================================================================

class CharacterLM(nn.Module):
    def __init__(self, vocab_size: int, d_model: int = 256, n_layers: int = 4,
                 n_heads: int = 4, d_ff: int = 1024, max_seq_len: int = 512,
                 dropout: float = 0.1, use_fep: bool = False, obs_scale: float = 1.0):
        super().__init__()
        
        self.vocab_size = vocab_size
        self.d_model = d_model
        self.use_fep = use_fep
        self.obs_scale = obs_scale
        
        self.token_emb = nn.Embedding(vocab_size, d_model)
        self.pos_emb = nn.Embedding(max_seq_len, d_model)
        
        self.blocks = nn.ModuleList([
            TransformerBlock(d_model, n_heads, d_ff, dropout, use_fep, obs_scale)
            for _ in range(n_layers)
        ])
        
        self.ln_f = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, vocab_size, bias=False)
        
        self.apply(self._init_weights)
        
    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
    
    def forward(self, idx, targets=None):
        batch_size, seq_len = idx.shape
        device = idx.device
        
        mask = torch.tril(torch.ones(seq_len, seq_len, device=device)).unsqueeze(0).unsqueeze(0)
        
        tok_emb = self.token_emb(idx)
        pos = torch.arange(0, seq_len, dtype=torch.long, device=device).unsqueeze(0)
        pos_emb = self.pos_emb(pos)
        x = tok_emb + pos_emb
        
        # Observations (self-supervised)
        x_obs = x.detach()
        
        attention_maps = []
        all_fe_components = []
        
        for block in self.blocks:
            x, attn_weights, fe_components = block(x, x_obs, mask)
            attention_maps.append(attn_weights)
            if fe_components is not None:
                all_fe_components.append(fe_components)
        
        x = self.ln_f(x)
        logits = self.head(x)
        
        loss = None
        if targets is not None:
            if self.use_fep and len(all_fe_components) > 0:
                # === FREE ENERGY (0-dimensional theory) ===
                # F = Σ_i [KL(q_i||p_i) + Σ_j β_ij·KL(q_i||q_j) + E_obs^i]
                
                total_kl_belief_prior = 0
                total_kl_belief_coupling = 0
                total_E_obs = 0
                
                for fe in all_fe_components:
                    total_kl_belief_prior += fe['kl_belief_prior'].mean()
                    attn_weighted = (fe['kl_belief_coupling'] * fe['attn_weights'].detach())
                    total_kl_belief_coupling += attn_weighted.mean() * fe['beta']
                    total_E_obs += fe['E_obs'].mean()
                
                n_layers = len(all_fe_components)
                total_kl_belief_prior = total_kl_belief_prior / n_layers
                total_kl_belief_coupling = total_kl_belief_coupling / n_layers
                total_E_obs = total_E_obs / n_layers
                
                # Free energy at single base point
                free_energy = (total_kl_belief_prior + 
                              total_kl_belief_coupling + 
                              self.obs_scale * total_E_obs)
                
                loss = free_energy
                
                if torch.isnan(loss) or loss < 0:
                    print("⚠️ Invalid loss, using cross-entropy fallback")
                    loss = F.cross_entropy(logits.view(-1, self.vocab_size), targets.view(-1))
                
                self.last_loss_components = {
                    'kl_belief_prior': total_kl_belief_prior.item(),
                    'kl_belief_coupling': total_kl_belief_coupling.item(),
                    'E_obs': total_E_obs.item(),
                    'free_energy': loss.item()
                }
            else:
                loss = F.cross_entropy(logits.view(-1, self.vocab_size), targets.view(-1))
                self.last_loss_components = {'cross_entropy': loss.item()}
        
        return logits, loss, attention_maps
    
    @torch.no_grad()
    def generate(self, idx, max_new_tokens, temperature=1.0, top_k=None):
        for _ in range(max_new_tokens):
            idx_cond = idx if idx.size(1) <= 512 else idx[:, -512:]
            logits, _, _ = self.forward(idx_cond)
            logits = logits[:, -1, :] / temperature
            
            if top_k is not None:
                v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < v[:, [-1]]] = -float('Inf')
            
            probs = F.softmax(logits, dim=-1)
            idx_next = torch.multinomial(probs, num_samples=1)
            idx = torch.cat((idx, idx_next), dim=1)
        
        return idx


# ============================================================================
# Training
# ============================================================================

def train_model(model, train_loader, optimizer, device, epochs=10, model_name="model"):
    model.train()
    losses = []
    
    for epoch in range(epochs):
        epoch_loss = 0
        epoch_components = {'kl_belief_prior': 0, 'kl_belief_coupling': 0, 'E_obs': 0}
        
        for batch_idx, (x, y) in enumerate(train_loader):
            x, y = x.to(device), y.to(device)
            
            optimizer.zero_grad()
            logits, loss, _ = model(x, y)
            
            if torch.isnan(loss):
                print(f"⚠️ Batch {batch_idx}: NaN loss, skipping")
                continue
            
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            
            epoch_loss += loss.item()
            
            if hasattr(model, 'last_loss_components'):
                for key in epoch_components.keys():
                    if key in model.last_loss_components:
                        epoch_components[key] += model.last_loss_components[key]
            
            if batch_idx % 100 == 0:
                print(f"Epoch {epoch+1}/{epochs} | Batch {batch_idx} | Loss: {loss.item():.4f}")
                if hasattr(model, 'last_loss_components') and model.use_fep:
                    comp = model.last_loss_components
                    print(f"  KL(q||p): {comp.get('kl_belief_prior', 0):.4f} | " +
                          f"β·KL(qi||qj): {comp.get('kl_belief_coupling', 0):.4f} | " +
                          f"E_obs: {comp.get('E_obs', 0):.4f}")
        
        avg_loss = epoch_loss / len(train_loader)
        losses.append(avg_loss)
        
        print(f"\n{'='*70}")
        print(f"Epoch {epoch+1} Complete | Avg Loss: {avg_loss:.4f}")
        if model.use_fep:
            for key in epoch_components.keys():
                print(f"  {key}: {epoch_components[key]/len(train_loader):.4f}")
        print('='*70 + '\n')
    
    torch.save(model.state_dict(), f'{model_name}.pt')
    return losses


# ============================================================================
# Main
# ============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("0-DIMENSIONAL GAUGE THEORY: Transformer as FEP")
    print("=" * 70)
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    print("Architecture:")
    print("  • Base manifold: SINGLE POINT (0-dimensional)")
    print("  • Each token = one agent at that point")
    print("  • No spatial grid, no transport operators")
    print("  • Free energy: F = Σ_i [KL(q_i||p_i) + Σ_j β_ij·KL(q_i||q_j) + E_obs^i]")
    print("  • Observation model: p(x_i|k_i) = N(W·k_i, Λ^{-1})")
    print("  • Natural gradients with exponential map\n")
    
    D_MODEL = 128
    N_LAYERS = 2
    N_HEADS = 4
    D_FF = 4 * D_MODEL
    SEQ_LEN = 128
    BATCH_SIZE = 32
    EPOCHS = 3
    OBS_SCALE = 1.0  # 0=vacuum, 1=full observations
    
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}\n")
    
    if not os.path.exists('input.txt'):
        print("❌ ERROR: input.txt not found!")
        exit(1)
    
    print("Loading dataset...")
    with open('input.txt', 'r', encoding='utf-8') as f:
        text = f.read()
    
    dataset = CharDataset(text, SEQ_LEN)
    VOCAB_SIZE = dataset.vocab_size
    print(f"✓ Vocabulary size: {VOCAB_SIZE}\n")
    
    train_loader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
    
    print("=" * 70)
    print("Training FEP Model (0-Dimensional)")
    print("=" * 70)
    
    model = CharacterLM(
        vocab_size=VOCAB_SIZE,
        d_model=D_MODEL,
        n_layers=N_LAYERS,
        n_heads=N_HEADS,
        d_ff=D_FF,
        use_fep=True,
        obs_scale=OBS_SCALE
    ).to(device)
    
    optimizer = NaturalGradientOptimizer(
        model,
        lr_mu=0.1,
        lr_sigma=0.1,
        lr_other=0.01
    )
    
    print(f"\nConfiguration:")
    print(f"  - obs_scale: {OBS_SCALE} (0=vacuum, 1=observations)")
    print(f"  - All tokens at same base point (0D)")
    print(f"  - Learning rates: μ=0.1, Σ=0.1, other=0.001\n")
    
    losses = train_model(model, train_loader, optimizer, device, EPOCHS, "model_fep_0d")
    
    print("\n" + "=" * 70)
    print("TRAINING COMPLETE!")
    print("=" * 70)
    print(f"Finished: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    print("✓ 0-dimensional gauge theory at single base point")
    print("✓ No spatial grid - pure token-token coupling")
    print("✓ Observation model with W, Λ matrices")
    print("✓ Natural gradient descent")